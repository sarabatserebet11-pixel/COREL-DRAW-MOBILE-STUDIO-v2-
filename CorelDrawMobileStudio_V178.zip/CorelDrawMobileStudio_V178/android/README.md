# Host Android — CorelDraw Mobile Studio (V150)

Pembungkus WebView supaya Panel Aplikasi Lain bisa **mengambang sungguhan** di atas aplikasi lain.

## Cara build
1. Buka **Android Studio** → *Open* → pilih folder `android` ini (jangan folder induknya).
2. Tunggu *Gradle Sync* selesai (butuh internet untuk mengunduh dependensi). Jika diminta membuat/memperbarui Gradle wrapper, setujui.
3. *Build > Build Bundle(s) / APK(s) > Build APK(s)*, lalu pasang `app-debug.apk` di HP. File web (`index.html`, `css`, `js`, …) disalin otomatis dari folder induk ke dalam APK saat build, jadi setiap perubahan di web ikut terbawa.

## Izin yang diminta di HP
- **Tampil di atas aplikasi lain** — dibuka lewat tombol *⚠ Izinkan…* di Panel Aplikasi Lain (mengarah ke Pengaturan; nyalakan untuk aplikasi ini lalu kembali).
- **Notifikasi** (Android 13+) — untuk tanda "Jendela mengambang aktif" yang berisi tombol *Tutup semua*.
Tidak memakai `QUERY_ALL_PACKAGES`; daftar aplikasi diambil dari aplikasi berikon peluncur.

## Apa yang benar-benar mengambang
| Jenis item | Perilaku |
|---|---|
| Item berisi **URL** (mis. situs/web app) | Jendela overlay milik aplikasi ini, mengambang di atas **semua** aplikasi. Butuh izin di atas. |
| Aplikasi **terpasang** (package) | Dibuka dengan *launch bounds* freeform. Hanya jalan jika HP mendukung dan mengaktifkan freeform. |

Android tidak mengizinkan aplikasi biasa "menempelkan" tampilan aplikasi lain ke overlay, jadi aplikasi terpasang hanya bisa mengambang lewat freeform bawaan sistem. Jika belum aktif, aplikasi menawarkan membuka **Opsi Pengembang** (aktifkan *Aktifkan jendela freeform*, lalu *Paksa aktivitas dapat diubah ukurannya*, restart HP). Hasilnya tergantung merek/versi Android; sebagian HP mengabaikan ukuran jendela.

## Simpan file & cetak (V151)
- **Ekspor/unduh** (PNG, SVG, JSON, DOCX/XLS, dll.) disimpan ke folder **Download** HP lewat `js/native-save.js` + `saveFile` di bridge (Android 10+ tanpa izin tambahan; Android 9 ke bawah masuk ke `Android/data/id.cdms.studio/files/Download`). Maksimal 25 MB per file.
- **Cetak / PDF** dari Word, Excel, dan PowerPoint membuka dialog cetak Android; pilih *Simpan sebagai PDF*. Ukuran/orientasi kertas mengikuti dialog Android, bukan selalu `@page` di dokumen.

## Catatan
- Kode ini ditulis dan diperiksa sintaksnya, tetapi **belum dikompilasi atau diuji di perangkat** (tidak ada Android SDK di lingkungan penulisan). Jika ada galat build, kirim pesan galatnya.
- Situs `http://` (tanpa https) diblokir Android secara default; gunakan `https://`.
- Tautan luar di dalam aplikasi dibuka di browser, bukan di WebView yang memiliki bridge.

## Tombol Kembali (V152)
Tombol/gestur kembali Android menutup panel, dialog, dan mode Office satu per satu (lihat `js/back-nav.js`); di beranda perlu ditekan dua kali untuk keluar.
