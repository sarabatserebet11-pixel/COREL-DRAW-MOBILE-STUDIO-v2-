package id.cdms.studio;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

/** Menampilkan aplikasi web dari assets/www lewat origin https lokal dan menyediakan bridge AndroidAppPanel. */
public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_FILE = 4201;
    private WebView web;
    private ValueCallback<Uri[]> filePathCb;   // V162: pemilih file untuk <input type=file>

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);

        final WebViewAssetLoader.AssetsPathHandler assets = new WebViewAssetLoader.AssetsPathHandler(this);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/www/", new WebViewAssetLoader.PathHandler() {
                    @Override
                    public WebResourceResponse handle(String path) {
                        WebResourceResponse r = assets.handle(path);
                        // V162: modul ES (pdf.js .mjs) wajib bertipe JavaScript
                        if (r != null && path.endsWith(".mjs")) r.setMimeType("text/javascript");
                        return r;
                    }
                })
                .build();

        // V162: tanpa ini, <input type="file"> (impor PPT/PDF/CSV/gambar) tidak membuka apa pun di WebView
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    String single = null;
                    boolean ext = false;
                    int mimes = 0;
                    String[] acc = params == null ? null : params.getAcceptTypes();
                    if (acc != null) for (String a : acc) {
                        if (a == null || a.trim().isEmpty()) continue;
                        a = a.trim();
                        if (a.startsWith(".")) ext = true;
                        else if (a.indexOf('/') > 0) { mimes++; single = a; }
                    }
                    i.setType(!ext && mimes == 1 ? single : "*/*");
                    if (params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE)
                        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(i, "Pilih file"), REQ_FILE);
                } catch (Exception e) {
                    filePathCb = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                if (!request.isForMainFrame()) return true;   // V153: bingkai/iframe pihak ketiga tidak pernah dimuat atau dibuka ke browser
                openExternal(u);   // tautan luar dibuka di browser, bukan di WebView yang memiliki bridge
                return true;
            }
        });

        // Bridge hanya untuk konten lokal tepercaya (origin appassets). Jangan memuat situs pihak ketiga di WebView ini.
        web.addJavascriptInterface(new AppPanelBridge(this), "AndroidAppPanel");
        web.loadUrl("https://" + HOST + "/www/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            if (filePathCb != null) filePathCb.onReceiveValue(result);
            filePathCb = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void openExternal(Uri u) {
        String sc = u.getScheme();
        if (!"http".equals(sc) && !"https".equals(sc)) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onBackPressed() {
        // Riwayat WebView berisi jebakan kembali dari back-nav.js; popstate menutup lapisan teratas.
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Segarkan status izin setelah pengguna kembali dari Pengaturan
        if (web != null) {
            web.evaluateJavascript("window.PanelAppDrawer&&PanelAppDrawer.refresh&&PanelAppDrawer.refresh()", null);
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("AndroidAppPanel");
            web.destroy();
        }
        super.onDestroy();
    }
}
