package id.cdms.studio;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.DisplayMetrics;

import java.lang.ref.WeakReference;

import androidx.browser.customtabs.CustomTabsClient;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.browser.customtabs.CustomTabsServiceConnection;
import androidx.browser.customtabs.CustomTabsSession;

/**
 * Membuka URL di Chrome asli sebagai lembar setengah layar (Partial Custom Tab) di atas aplikasi.
 * Ini browser sungguhan, jadi login Google/WhatsApp/dll. diterima, dan login dibagi dengan Chrome.
 * Chrome lama tanpa dukungan lembar akan membuka Custom Tab layar penuh; tanpa Chrome, ACTION_VIEW biasa.
 */
final class ChromeSheet {
    private ChromeSheet() {
    }

    /** V178: Activity terakhir; Partial Custom Tab hanya jadi setengah layar bila diluncurkan dari Activity (bukan Service/appContext). */
    private static WeakReference<Activity> lastAct = new WeakReference<Activity>(null);

    static void remember(Activity a) {
        lastAct = new WeakReference<Activity>(a);
    }

    static boolean open(final Context ctx, final String url, final double heightRatio) {
        if (url == null || url.length() > 2048) return false;
        final Uri u = Uri.parse(url);
        String sc = u.getScheme();
        if (!"http".equals(sc) && !"https".equals(sc)) return false;
        if (u.getHost() == null) return false;
        final Context app = ctx.getApplicationContext();
        Activity a0 = ctx instanceof Activity ? (Activity) ctx : lastAct.get();
        if (a0 != null && (a0.isFinishing() || (android.os.Build.VERSION.SDK_INT >= 17 && a0.isDestroyed()))) a0 = null;
        final Context launchCtx = a0 != null ? a0 : app;   // Activity → lembar setengah layar; tanpa Activity → layar penuh (batasan Chrome)
        final String pkg = CustomTabsClient.getPackageName(app, null);
        if (pkg == null) return view(app, u);
        final int h = (int) (app.getResources().getDisplayMetrics().heightPixels * Math.max(0.4, Math.min(0.95, heightRatio)));
        try {
            boolean ok = CustomTabsClient.bindCustomTabsService(app, pkg, new CustomTabsServiceConnection() {
                @Override
                public void onCustomTabsServiceConnected(ComponentName name, CustomTabsClient client) {
                    try {
                        client.warmup(0L);
                        CustomTabsSession session = client.newSession(null);
                        CustomTabsIntent.Builder b = session != null ? new CustomTabsIntent.Builder(session) : new CustomTabsIntent.Builder();
                        b.setInitialActivityHeightPx(h, CustomTabsIntent.ACTIVITY_HEIGHT_ADJUSTABLE);
                        b.setShowTitle(true);
                        CustomTabsIntent cti = b.build();
                        cti.intent.setPackage(pkg);
                        if (!(launchCtx instanceof Activity)) cti.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);   // NEW_TASK membuat Chrome membuka layar penuh
                        cti.launchUrl(launchCtx, u);
                    } catch (Throwable t) {
                        view(app, u);
                    }
                }

                @Override
                public void onServiceDisconnected(ComponentName name) {
                }
            });
            if (!ok) return view(app, u);
            return true;
        } catch (Throwable t) {
            return view(app, u);
        }
    }

    private static boolean view(Context app, Uri u) {
        try {
            app.startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
