package id.cdms.studio;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;

/**
 * V172: Activity transparan untuk memilih file bagi jendela mengambang (Service tidak bisa memanggil startActivityForResult).
 * Hasilnya diteruskan ke FloatingWebService.deliverFiles().
 */
public class FilePickerActivity extends Activity {
    static final String EXTRA_TYPE = "type";
    static final String EXTRA_MULTI = "multi";
    private static final int REQ = 5301;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            String t = getIntent().getStringExtra(EXTRA_TYPE);
            i.setType(t == null || t.isEmpty() ? "*/*" : t);
            if (getIntent().getBooleanExtra(EXTRA_MULTI, false)) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(Intent.createChooser(i, "Pilih file"), REQ);
        } catch (Throwable t) {
            FloatingWebService.deliverFiles(null);
            finish();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        Uri[] r = null;
        if (req == REQ && res == RESULT_OK && data != null) r = WebChromeClient.FileChooserParams.parseResult(res, data);
        FloatingWebService.deliverFiles(r);
        finish();
    }
}
