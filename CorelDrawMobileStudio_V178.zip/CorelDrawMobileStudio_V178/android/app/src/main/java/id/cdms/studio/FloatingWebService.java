package id.cdms.studio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.os.Message;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Jendela web mengambang (overlay) di atas semua aplikasi. Maksimal 3 jendela.
 * Memerlukan izin "Tampil di atas aplikasi lain" (SYSTEM_ALERT_WINDOW).
 * WebView di sini TIDAK diberi JavascriptInterface apa pun.
 */
public class FloatingWebService extends Service {
    public static final String ACTION_OPEN = "id.cdms.studio.OPEN";
    public static final String ACTION_CLOSE_ALL = "id.cdms.studio.CLOSE_ALL";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_RATIO = "ratio";
    private static final String CHANNEL = "floating_windows";
    private static final int MAX_WINDOWS = 3;

    /** V165: hasil percobaan terakhir ("" = berhasil / belum ada, selain itu = pesan galat) dibaca lewat bridge floatStatus(). */
    static volatile String lastError = "";
    static volatile int openCount = 0;
    private static android.webkit.ValueCallback<Uri[]> fileCb;   // V172: pemilih file untuk <input type=file>

    /** Dipanggil FilePickerActivity dengan hasil pilihan (null = batal). */
    static void deliverFiles(Uri[] r) {
        android.webkit.ValueCallback<Uri[]> cb = fileCb;
        fileCb = null;
        if (cb != null) cb.onReceiveValue(r);
    }

    private WindowManager wm;
    private final ArrayList<Win> wins = new ArrayList<>();

    private static class Win {
        FrameLayout root;
        WebView web;
        View grip;
        WindowManager.LayoutParams lp;
        boolean min;
        boolean desktop;
        boolean moved;
        boolean maxed;
        int[] prev;
        int restoreW;
        String mobileUa;
        int fullH;
        String host;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        try {
            startAsForeground();
        } catch (Throwable t) {   // V165: jangan sampai Service mati diam-diam; tetap coba tampilkan jendela
            lastError = "Notifikasi layanan gagal: " + t;
            try {   // V166: cadangan — notifikasi polos agar aplikasi tidak ditutup sistem (batas 5 detik startForeground)
                Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
                nb.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Jendela mengambang aktif");
                if (Build.VERSION.SDK_INT >= 34) startForeground(77, nb.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
                else startForeground(77, nb.build());
            } catch (Throwable t2) {
                lastError += " | cadangan gagal: " + t2;
                stopSelf();
            }
        }
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Jendela mengambang",
                    NotificationManager.IMPORTANCE_LOW));
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        Intent close = new Intent(this, FloatingWebService.class).setAction(ACTION_CLOSE_ALL);
        PendingIntent pc = PendingIntent.getService(this, 1, close, PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(getApplicationInfo().icon != 0 ? getApplicationInfo().icon : android.R.drawable.ic_dialog_info)
                .setContentTitle("Jendela mengambang aktif")
                .setContentText("Ketuk untuk membuka aplikasi")
                .setContentIntent(pi)
                .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Tutup semua", pc).build());
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(77, n);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_CLOSE_ALL.equals(intent.getAction())) {
            closeAll();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            lastError = "Izin \"Tampil di atas aplikasi lain\" belum aktif";
            stopSelf();
            return START_NOT_STICKY;
        }
        String url = intent.getStringExtra(EXTRA_URL);
        if (url != null) {
            Uri u = Uri.parse(url);
            String sc = u.getScheme();
            if ("http".equals(sc) || "https".equals(sc)) {
                try {
                    open(url, intent.getStringExtra(EXTRA_TITLE), intent.getFloatExtra(EXTRA_RATIO, 0.6f));
                } catch (Throwable t) {   // V165
                    lastError = "Jendela gagal dibuat: " + t;
                }
            }
        }
        if (wins.isEmpty()) stopSelf();
        return START_NOT_STICKY;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView headerButton(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(7), 0, dp(7), 0);   // V167: lebih ramping karena tombol bertambah
        return t;
    }

    // V168: posisi & ukuran jendela diingat per situs (host)
    private SharedPreferences prefs() {
        return getSharedPreferences("float_pos", Context.MODE_PRIVATE);
    }

    private void savePos(Win w, String host) {
        if (host == null || w.min) return;
        try {
            prefs().edit().putString(host, w.lp.x + "," + w.lp.y + "," + w.lp.width + "," + w.lp.height).apply();
        } catch (Throwable ignored) {
        }
    }

    private boolean restorePos(Win w, String host) {
        try {
            String v = host == null ? null : prefs().getString(host, null);
            if (v == null) return false;
            String[] p = v.split(",");
            DisplayMetrics d = getResources().getDisplayMetrics();
            int wd = Math.max(dp(220), Math.min(d.widthPixels, Integer.parseInt(p[2])));
            int ht = Math.max(dp(160), Math.min(d.heightPixels, Integer.parseInt(p[3])));
            w.lp.width = wd;
            w.lp.height = ht;
            w.lp.x = Math.max(-wd / 2, Math.min(d.widthPixels - dp(60), Integer.parseInt(p[0])));
            w.lp.y = Math.max(0, Math.min(d.heightPixels - dp(60), Integer.parseInt(p[1])));
            w.fullH = ht;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** V169/V171: beralih situs seluler <-> desktop. */
    private void toggleDesktop(Win win) {
        try {
            WebSettings ws = win.web.getSettings();
            if (win.mobileUa == null) win.mobileUa = ws.getUserAgentString();
            win.desktop = !win.desktop;
            ws.setUserAgentString(win.desktop
                    ? "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                    : win.mobileUa);
            ws.setUseWideViewPort(win.desktop);
            ws.setLoadWithOverviewMode(win.desktop);
            win.web.reload();
            Toast.makeText(this, win.desktop ? "Mode situs desktop" : "Mode situs seluler", Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {
        }
    }

    /** V171: layar penuh <-> ukuran semula. */
    private void toggleMax(Win win) {
        DisplayMetrics d = getResources().getDisplayMetrics();
        if (win.min) return;
        if (!win.maxed) {
            win.prev = new int[]{win.lp.x, win.lp.y, win.lp.width, win.lp.height};
            win.lp.x = 0;
            win.lp.y = dp(24);
            win.lp.width = d.widthPixels;
            win.lp.height = d.heightPixels - dp(24) - dp(48);
            win.maxed = true;
        } else if (win.prev != null) {
            win.lp.x = win.prev[0];
            win.lp.y = win.prev[1];
            win.lp.width = win.prev[2];
            win.lp.height = win.prev[3];
            win.maxed = false;
        }
        win.fullH = win.lp.height;
        update(win);
        if (!win.maxed) savePos(win, win.host);
    }

    private void open(String url, String title, float ratio) {
        if (wins.size() >= MAX_WINDOWS) removeWin(wins.get(0));   // tutup yang tertua

        DisplayMetrics dm = getResources().getDisplayMetrics();
        final int w = Math.min((int) (dm.widthPixels * ratio), dm.widthPixels - dp(8));
        final int h = (int) (dm.heightPixels * 0.55f);
        final int n = wins.size();

        final Win win = new Win();
        win.fullH = h;

        win.root = new FrameLayout(this);
        win.root.setBackgroundColor(0xFF0B1220);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(0xFF1E293B);
        header.setPadding(dp(10), 0, 0, 0);

        TextView tv = new TextView(this);
        tv.setText(title == null || title.isEmpty() ? Uri.parse(url).getHost() : title);
        tv.setTextColor(Color.WHITE);
        tv.setSingleLine(true);
        tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        header.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));


        TextView bBack = headerButton("\u2039");   // V167: halaman sebelumnya
        TextView bSnap = headerButton("\u2B12");   // V167: tata letak cepat
        TextView bAlpha = headerButton("\u25D0");   // V166: transparansi
        TextView bChrome = headerButton("G");
        TextView bReload = headerButton("\u27F3");
        TextView bMin = headerButton("\u2013");
        TextView bClose = headerButton("\u00D7");
        header.addView(bBack, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        header.addView(bSnap, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        header.addView(bAlpha, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        header.addView(bChrome, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        header.addView(bReload, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        header.addView(bMin, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        header.addView(bClose, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        col.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));

        win.web = new WebView(new ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault));   // V164: konteks bertema
        WebSettings s = win.web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        configureForLogin(win.web, s, tv, title == null || title.isEmpty() ? Uri.parse(url).getHost() : title, win.root, col);
        col.addView(win.web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        win.root.addView(col, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView grip = new TextView(this);
        grip.setText("\u25E2");
        grip.setTextColor(0xFF94A3B8);
        grip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        grip.setGravity(Gravity.CENTER);
        win.grip = grip;
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.BOTTOM | Gravity.END);
        win.root.addView(grip, gp);

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        win.lp = new WindowManager.LayoutParams(w, h, type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);   // V164
        win.lp.gravity = Gravity.TOP | Gravity.START;
        win.lp.x = Math.max(0, (dm.widthPixels - w) / 2 + n * dp(16));
        win.lp.y = (int) (dm.heightPixels * 0.10f) + n * dp(24);
        win.lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;

        // Geser lewat bilah judul
        final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());
        final Runnable longPress = new Runnable() {
            @Override
            public void run() {
                win.moved = true;   // jangan lanjut dianggap ketukan
                toggleDesktop(win);
            }
        };
        header.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy, ox, oy;
            long lastTap = 0;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = (int) e.getRawX();
                        sy = (int) e.getRawY();
                        ox = win.lp.x;
                        oy = win.lp.y;
                        win.moved = false;
                        ui.postDelayed(longPress, 700);   // V171: tekan lama judul = situs desktop/seluler
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs((int) e.getRawX() - sx) > dp(8) || Math.abs((int) e.getRawY() - sy) > dp(8)) {
                            win.moved = true;
                            ui.removeCallbacks(longPress);
                        }
                        if (win.moved) {
                            win.lp.x = ox + (int) e.getRawX() - sx;
                            win.lp.y = Math.max(0, oy + (int) e.getRawY() - sy);
                            update(win);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        ui.removeCallbacks(longPress);
                        if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                            if (!win.moved) {   // V171: ketuk dua kali judul = layar penuh <-> ukuran semula
                                long now = System.currentTimeMillis();
                                if (now - lastTap < 350) {
                                    lastTap = 0;
                                    toggleMax(win);
                                } else lastTap = now;
                            } else savePos(win, win.host);
                        }
                        return true;
                }
                return false;
            }
        });
        // Ubah ukuran lewat pegangan pojok kanan-bawah
        grip.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy, ow, oh;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = (int) e.getRawX();
                        sy = (int) e.getRawY();
                        ow = win.lp.width;
                        oh = win.lp.height;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        DisplayMetrics d = getResources().getDisplayMetrics();
                        win.lp.width = Math.max(dp(220), Math.min(d.widthPixels, ow + (int) e.getRawX() - sx));
                        win.lp.height = Math.max(dp(160), Math.min(d.heightPixels, oh + (int) e.getRawY() - sy));
                        win.fullH = win.lp.height;
                        update(win);
                        return true;
                    case MotionEvent.ACTION_UP:
                        savePos(win, win.host);
                        return true;
                }
                return false;
            }
        });

        final String startUrl = url;
        bBack.setOnClickListener(new View.OnClickListener() {   // V167
            @Override
            public void onClick(View v) {
                if (win.web.canGoBack()) win.web.goBack();
            }
        });
        bSnap.setOnClickListener(new View.OnClickListener() {   // V167: kanan-bawah 60% -> kiri 50% -> kanan 50% -> atas 50% -> bawah 50% -> penuh -> semula
            int step = 0;

            @Override
            public void onClick(View v) {
                DisplayMetrics d = getResources().getDisplayMetrics();
                int W = d.widthPixels, H = d.heightPixels, top = dp(24);
                win.min = false;
                win.web.setVisibility(View.VISIBLE);
                win.grip.setVisibility(View.VISIBLE);
                switch (step % 6) {
                    case 0: win.lp.x = 0; win.lp.y = top; win.lp.width = W / 2; win.lp.height = H - top - dp(48); break;
                    case 1: win.lp.x = W / 2; win.lp.y = top; win.lp.width = W / 2; win.lp.height = H - top - dp(48); break;
                    case 2: win.lp.x = 0; win.lp.y = top; win.lp.width = W; win.lp.height = (H - top) / 2 - dp(24); break;
                    case 3: win.lp.x = 0; win.lp.y = H / 2; win.lp.width = W; win.lp.height = H / 2 - dp(48); break;
                    case 4: win.lp.x = 0; win.lp.y = top; win.lp.width = W; win.lp.height = H - top - dp(48); break;
                    default: win.lp.width = w; win.lp.height = h; win.lp.x = Math.max(0, (W - w) / 2); win.lp.y = (int) (H * 0.10f);
                }
                win.fullH = win.lp.height;
                step++;
                update(win);
                savePos(win, win.host);
            }
        });
        bAlpha.setOnClickListener(new View.OnClickListener() {   // V166: 100% -> 80% -> 60% -> 40%
            @Override
            public void onClick(View v) {
                float a = win.lp.alpha;
                win.lp.alpha = a > 0.95f ? 0.8f : a > 0.75f ? 0.6f : a > 0.55f ? 0.4f : 1f;
                update(win);
            }
        });
        bReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                win.web.loadUrl(startUrl);
            }
        });
        bChrome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {   // lanjut di Chrome asli (untuk login Google dll.)
                String cur = win.web.getUrl();
                ChromeSheet.open(FloatingWebService.this, cur != null ? cur : startUrl, 0.75);
            }
        });
        bMin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                win.min = !win.min;
                win.web.setVisibility(win.min ? View.GONE : View.VISIBLE);
                win.grip.setVisibility(win.min ? View.GONE : View.VISIBLE);
                win.lp.height = win.min ? dp(40) : win.fullH;
                if (win.min) {   // V171: jendela kecil memanjang hanya selebar bilah
                    win.restoreW = win.lp.width;
                    win.lp.width = Math.min(win.lp.width, dp(220));
                } else if (win.restoreW > 0) win.lp.width = win.restoreW;
                update(win);
            }
        });
        bClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeWin(win);
                if (wins.isEmpty()) stopSelf();
            }
        });

        final String hostKey = Uri.parse(url).getHost();
        win.host = hostKey;
        restorePos(win, hostKey);
        try {
            wm.addView(win.root, win.lp);
        } catch (Throwable t) {   // izin dicabut / gagal menambah window
            lastError = "addView gagal: " + t;
            win.web.destroy();
            return;
        }
        lastError = "";
        openCount++;
        wins.add(win);
        win.web.loadUrl(url);
    }

    /**
     * Agar login (mis. Google) bisa berjalan di jendela mengambang: UA seperti Chrome seluler (tanpa penanda WebView "wv"),
     * header X-Requested-With dimatikan, cookie (termasuk pihak ketiga) disimpan, dan window.open/popup login dimuat
     * di WebView yang sama. Tetap tanpa JavascriptInterface; hanya http/https yang boleh dimuat.
     */
    /** V173: alert()/confirm() dari situs. Service tak punya window Activity, jadi dialog memakai tipe overlay; tanpa ini dialog tidak tampil dan halaman bisa macet. */
    private boolean showJsDialog(String msg, final android.webkit.JsResult r, boolean confirm) {
        try {
            android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(new ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert));
            b.setMessage(msg == null ? "" : msg);
            b.setPositiveButton("OK", new android.content.DialogInterface.OnClickListener() {
                @Override
                public void onClick(android.content.DialogInterface d, int w) {
                    r.confirm();
                }
            });
            if (confirm) b.setNegativeButton("Batal", new android.content.DialogInterface.OnClickListener() {
                @Override
                public void onClick(android.content.DialogInterface d, int w) {
                    r.cancel();
                }
            });
            b.setOnCancelListener(new android.content.DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(android.content.DialogInterface d) {
                    r.cancel();
                }
            });
            android.app.AlertDialog d = b.create();
            d.getWindow().setType(Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE);
            d.show();
            return true;
        } catch (Throwable t) {
            r.cancel();
            return true;
        }
    }

    private void configureForLogin(final WebView web, WebSettings s, final TextView titleView, final String baseTitle, final FrameLayout rootView, final View colView) {
        String ua = s.getUserAgentString();
        if (ua != null) {
            ua = ua.replace("; wv)", ")").replaceAll("Version/\\d+(\\.\\d+)*\\s", "");
            s.setUserAgentString(ua);
        }
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
                WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, Collections.<String>emptySet());
            }
        } catch (Throwable ignored) {
        }
        // V170: unduhan dari jendela mengambang diserahkan ke browser/pengelola unduhan sistem (tadinya tidak melakukan apa pun)
        web.setDownloadListener(new android.webkit.DownloadListener() {
            @Override
            public void onDownloadStart(String dl, String ua, String cd, String mime, long len) {
                try {
                    Uri du = Uri.parse(dl);
                    String sc = du.getScheme();
                    if (!"http".equals(sc) && !"https".equals(sc)) return;
                    startActivity(new Intent(Intent.ACTION_VIEW, du).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    Toast.makeText(FloatingWebService.this, "Unduhan dibuka di browser", Toast.LENGTH_SHORT).show();
                } catch (Throwable ignored) {
                }
            }
        });
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setLoadWithOverviewMode(true);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                return !("http".equals(sc) || "https".equals(sc));   // skema lain (intent:, market:, dll.) tidak dibuka
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                CookieManager.getInstance().flush();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            private View customView;
            private WebChromeClient.CustomViewCallback customCb;

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {   // V175: video layar penuh di dalam jendela mengambang
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCb = cb;
                colView.setVisibility(View.GONE);
                rootView.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                rootView.removeView(customView);
                customView = null;
                colView.setVisibility(View.VISIBLE);
                if (customCb != null) customCb.onCustomViewHidden();
                customCb = null;
            }

            @Override
            public boolean onJsAlert(WebView v, String u, String msg, final android.webkit.JsResult r) {   // V173: dialog situs di atas jendela mengambang
                return showJsDialog(msg, r, false);
            }

            @Override
            public boolean onJsConfirm(WebView v, String u, String msg, final android.webkit.JsResult r) {
                return showJsDialog(msg, r, true);
            }

            @Override
            public boolean onShowFileChooser(WebView v, android.webkit.ValueCallback<Uri[]> cb, FileChooserParams params) {
                // V172: unggah file di jendela mengambang (sebelumnya tidak membuka apa pun)
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    String single = null;
                    boolean ext = false;
                    int mimes = 0;
                    String[] acc = params == null ? null : params.getAcceptTypes();
                    if (acc != null) for (String a : acc) {
                        if (a == null || a.trim().isEmpty()) continue;
                        a = a.trim();
                        if (a.startsWith(".")) ext = true;
                        else if (a.indexOf('/') > 0) { mimes++; single = a; }
                    }
                    Intent i = new Intent(FloatingWebService.this, FilePickerActivity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            .putExtra(FilePickerActivity.EXTRA_TYPE, !ext && mimes == 1 ? single : "*/*")
                            .putExtra(FilePickerActivity.EXTRA_MULTI, params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                    startActivity(i);
                } catch (Throwable t) {
                    fileCb = null;
                    cb.onReceiveValue(null);
                }
                return true;
            }

            @Override
            public void onReceivedTitle(WebView v, String t) {   // V170: judul halaman tampil di bilah judul
                if (t != null && !t.isEmpty() && !t.startsWith("http")) titleView.setText(t);
            }

            @Override
            public void onProgressChanged(WebView v, int p) {   // V170: indikator muat
                if (p < 100) titleView.setAlpha(0.55f);
                else titleView.setAlpha(1f);
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                // Popup login: dimuat di WebView yang sama lewat WebView perantara
                final WebView target = view;
                WebView tmp = new WebView(view.getContext());
                tmp.setWebViewClient(new WebViewClient() {
                    private boolean done;

                    private void go(WebView v, String u) {
                        if (done) return;
                        done = true;
                        if (u != null && (u.startsWith("https://") || u.startsWith("http://"))) target.loadUrl(u);
                        v.stopLoading();
                        v.destroy();
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                        go(v, r.getUrl().toString());
                        return true;
                    }

                    @Override
                    public void onPageStarted(WebView v, String u, android.graphics.Bitmap f) {
                        go(v, u);   // sebagian versi WebView tidak memanggil shouldOverrideUrlLoading untuk popup
                    }
                });
                WebView.WebViewTransport t = (WebView.WebViewTransport) resultMsg.obj;
                t.setWebView(tmp);
                resultMsg.sendToTarget();
                return true;
            }
        });
    }

    private void update(Win w) {
        try {
            wm.updateViewLayout(w.root, w.lp);
        } catch (Throwable ignored) {
        }
    }

    private void removeWin(Win w) {
        savePos(w, w.host);
        wins.remove(w);
        try {
            wm.removeViewImmediate(w.root);
        } catch (Throwable ignored) {
        }
        try {
            w.web.stopLoading();
            w.web.destroy();
        } catch (Throwable ignored) {
        }
    }

    private void closeAll() {
        for (Win w : new ArrayList<>(wins)) removeWin(w);
    }

    @Override
    public void onDestroy() {
        closeAll();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
