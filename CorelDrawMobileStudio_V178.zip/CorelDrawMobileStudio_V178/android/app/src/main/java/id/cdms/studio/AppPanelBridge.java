package id.cdms.studio;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

/** Kontrak sesuai APP_PANEL_ANDROID.md. Semua input dari JavaScript divalidasi. */
public class AppPanelBridge {
    private static final Pattern PKG = Pattern.compile("^[a-zA-Z][\\w]*(\\.[a-zA-Z][\\w]*)+$");
    private final Activity act;
    private WebView printView;   // dijaga agar tidak di-GC selama dialog cetak

    public AppPanelBridge(Activity act) {
        this.act = act;
        ChromeSheet.remember(act);
    }

    private static double clamp(double v, double lo, double hi) {
        if (Double.isNaN(v)) return 0.6;
        return Math.max(lo, Math.min(hi, v));
    }

    /** JSON array {packageName,name,icon}. */
    @JavascriptInterface
    public String getInstalledApps() {
        try {
            PackageManager pm = act.getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = new ArrayList<>(pm.queryIntentActivities(q, 0));
            final PackageManager fpm = pm;
            Collections.sort(list, new Comparator<ResolveInfo>() {
                @Override
                public int compare(ResolveInfo a, ResolveInfo b) {
                    return String.valueOf(a.loadLabel(fpm)).compareToIgnoreCase(String.valueOf(b.loadLabel(fpm)));
                }
            });
            JSONArray out = new JSONArray();
            ArrayList<String> seen = new ArrayList<>();
            for (ResolveInfo ri : list) {
                if (out.length() >= 400) break;
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(act.getPackageName()) || seen.contains(pkg)) continue;
                seen.add(pkg);
                JSONObject o = new JSONObject();
                o.put("packageName", pkg);
                o.put("name", String.valueOf(ri.loadLabel(pm)));
                o.put("icon", iconDataUrl(ri.loadIcon(pm)));
                out.put(o);
            }
            return out.toString();
        } catch (Throwable t) {
            return "[]";
        }
    }

    private static String iconDataUrl(Drawable d) {
        try {
            int size = 72;
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            d.setBounds(0, 0, size, size);
            d.draw(c);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 90, bos);
            return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable t) {
            return "";
        }
    }

    /** True bila perangkat mendukung dan mengaktifkan freeform windows. */
    @JavascriptInterface
    public boolean freeformSupported() {
        if (Build.VERSION.SDK_INT < 24) return false;
        try {
            if (act.getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)) return true;
            // Opsi Pengembang > "Aktifkan jendela freeform"
            return Settings.Global.getInt(act.getContentResolver(), "enable_freeform_support", 0) != 0;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Membuka aplikasi lain di jendela freeform. Mengembalikan false bila tidak didukung/gagal. */
    @JavascriptInterface
    public boolean launchFreeform(String packageName, double widthRatio) {
        if (packageName == null || !PKG.matcher(packageName).matches()) return false;
        if (!freeformSupported()) return false;
        try {
            Intent li = act.getPackageManager().getLaunchIntentForPackage(packageName);
            if (li == null) return false;
            DisplayMetrics dm = act.getResources().getDisplayMetrics();
            int w = (int) (dm.widthPixels * clamp(widthRatio, 0.4, 0.8));
            int h = (int) (dm.heightPixels * 0.6);
            int l = (dm.widthPixels - w) / 2;
            int t = (int) (dm.heightPixels * 0.12);
            ActivityOptions o = ActivityOptions.makeBasic();
            o.setLaunchBounds(new Rect(l, t, l + w, t + h));
            try {   // mode windowing 5 = freeform (API tersembunyi; diabaikan bila tidak ada)
                ActivityOptions.class.getMethod("setLaunchWindowingMode", int.class).invoke(o, 5);
            } catch (Throwable ignored) {
            }
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            act.startActivity(li, o.toBundle());
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    @JavascriptInterface
    public void launchNormal(String packageName) {
        if (packageName == null || !PKG.matcher(packageName).matches()) return;
        try {
            Intent li = act.getPackageManager().getLaunchIntentForPackage(packageName);
            if (li == null) return;
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(li);
        } catch (Throwable ignored) {
        }
    }

    @JavascriptInterface
    public boolean hasOverlayPermission() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(act);
    }

    /** Membuka layar Pengaturan "Tampil di atas aplikasi lain" untuk aplikasi ini. */
    @JavascriptInterface
    public void requestOverlayPermission() {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + act.getPackageName()));
                    act.startActivity(i);
                } catch (Throwable ignored) {
                }
            }
        });
    }

    @JavascriptInterface
    public void openFreeformSettings() {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    act.startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
                } catch (Throwable ignored) {
                }
            }
        });
    }

    /** Jendela web mengambang di atas semua aplikasi (butuh izin overlay). Hanya http(s). */
    @JavascriptInterface
    public boolean openFloatingWeb(String url, String title, double widthRatio) {
        if (!hasOverlayPermission()) return false;
        if (url == null) return false;
        Uri u = Uri.parse(url);
        String sc = u.getScheme();
        if (!"http".equals(sc) && !"https".equals(sc)) return false;
        if (u.getHost() == null || url.length() > 2048) return false;
        try {
            Intent i = new Intent(act, FloatingWebService.class);
            i.setAction(FloatingWebService.ACTION_OPEN);
            i.putExtra(FloatingWebService.EXTRA_URL, url);
            i.putExtra(FloatingWebService.EXTRA_TITLE, title == null ? "" : title);
            i.putExtra(FloatingWebService.EXTRA_RATIO, (float) clamp(widthRatio, 0.4, 0.8));
            if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i);
            else act.startService(i);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** V165: "" bila jendela mengambang terakhir berhasil dibuat; selain itu alasan kegagalannya. */
    @JavascriptInterface
    public String floatStatus() {
        return FloatingWebService.lastError == null ? "" : FloatingWebService.lastError;
    }

    @JavascriptInterface
    public int floatCount() {
        return FloatingWebService.openCount;
    }

    /** Chrome asli sebagai lembar setengah layar di atas aplikasi (login Google dll. diterima). Hanya http(s). */
    @JavascriptInterface
    public boolean openChromeSheet(final String url, double heightRatio) {
        final double r = clamp(heightRatio, 0.4, 0.95);
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ChromeSheet.open(act, url, r);
            }
        });
        return url != null && (url.startsWith("https://") || url.startsWith("http://"));
    }

    @JavascriptInterface
    public void closeAllFloating() {
        try {
            Intent i = new Intent(act, FloatingWebService.class);
            i.setAction(FloatingWebService.ACTION_CLOSE_ALL);
            act.startService(i);
        } catch (Throwable ignored) {
        }
    }

    /**
     * Menyimpan file dari aplikasi web ke folder Download. Mengembalikan teks lokasi, atau "" jika gagal.
     * Android 10+: MediaStore (tanpa izin). Android 9 ke bawah: folder Download khusus aplikasi.
     */
    @JavascriptInterface
    public String saveFile(String name, String mime, String base64) {
        if (name == null || base64 == null || base64.length() > 34 * 1024 * 1024) return "";
        String safe = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]+", "_");
        if (safe.length() > 100) safe = safe.substring(0, 100);
        if (safe.isEmpty()) safe = "file";
        if (mime == null || !mime.matches("^[\\w.+-]+/[\\w.+-]+$")) mime = "application/octet-stream";
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri uri = act.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) return "";
                OutputStream os = act.getContentResolver().openOutputStream(uri);
                if (os == null) return "";
                try {
                    os.write(data);
                } finally {
                    os.close();
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                act.getContentResolver().update(uri, done, null, null);
                return "Download";
            }
            File dir = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) return "";
            if (!dir.exists() && !dir.mkdirs()) return "";
            FileOutputStream fos = new FileOutputStream(new File(dir, safe));
            try {
                fos.write(data);
            } finally {
                fos.close();
            }
            return "Android/data/" + act.getPackageName() + "/files/Download";
        } catch (Throwable t) {
            return "";
        }
    }

    /** Membuka dialog cetak Android (termasuk "Simpan sebagai PDF") untuk HTML statis. JavaScript dimatikan. */
    @JavascriptInterface
    public boolean printHtml(final String html) {
        if (html == null || html.length() > 12000000) return false;
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    final WebView pv = new WebView(act);
                    WebSettings ws = pv.getSettings();
                    ws.setJavaScriptEnabled(false);
                    ws.setAllowFileAccess(false);
                    ws.setAllowContentAccess(false);
                    printView = pv;
                    pv.setWebViewClient(new WebViewClient() {
                        private boolean started;

                        @Override
                        public void onPageFinished(WebView v, String url) {
                            if (started) return;
                            started = true;
                            PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                            String job = "CorelDraw Mobile Studio";
                            PrintDocumentAdapter ad = v.createPrintDocumentAdapter(job);
                            pm.print(job, ad, new PrintAttributes.Builder().build());
                        }
                    });
                    pv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                } catch (Throwable ignored) {
                }
            }
        });
        return true;
    }

    /** Menutup aplikasi (dipakai saat "tekan kembali 2x" di beranda). */
    @JavascriptInterface
    public void exitApp() {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                act.finish();
            }
        });
    }
}
