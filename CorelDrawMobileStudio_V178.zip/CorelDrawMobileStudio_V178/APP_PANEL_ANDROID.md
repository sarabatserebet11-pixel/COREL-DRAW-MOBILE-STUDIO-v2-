# Panel Aplikasi Lain — catatan integrasi Android

Versi ini menambahkan panel drawer, penyimpanan `localStorage`, pencarian, pilihan aplikasi melalui bridge native, pin/hapus, ukuran default, serta fallback shortcut URL untuk browser biasa.

## Batasan penting
Aplikasi ini adalah PWA berbasis HTML/JS. Browser standar tidak menyediakan API untuk membaca seluruh paket terinstal, membuka aplikasi pihak ketiga dalam freeform window, atau meminta `QUERY_ALL_PACKAGES`. Karena itu tombol tambah di browser menyediakan shortcut manual. Fitur native aktif hanya jika aplikasi dibungkus dalam Android WebView dan menyediakan bridge `window.AndroidAppPanel`.

## Kontrak bridge
Expose objek berikut dari Android WebView (gunakan `@JavascriptInterface` dan validasi input):
- `getInstalledApps()` — mengembalikan JSON array `{packageName,name,icon?}`. Untuk ikon, gunakan data URL PNG kecil.
- `launchFreeform(packageName, widthRatio)` — mengembalikan `true` jika peluncuran freeform berhasil; selain itu `false`.
- `launchNormal(packageName)` — fallback peluncuran normal.

`widthRatio` dibatasi di UI ke 0.4–0.8. Android host harus memvalidasi package name terhadap PackageManager dan tidak boleh menerima intent/component arbitrary dari JavaScript.

## Implementasi Android host yang diperlukan
- Android 11+ package visibility membatasi query. Deklarasikan `<queries>` untuk paket yang diketahui bila memungkinkan. `QUERY_ALL_PACKAGES` hanya untuk aplikasi yang memenuhi kebijakan distribusi Google Play; jangan meminta izin ini tanpa kebutuhan inti yang memenuhi syarat.
- `PackageManager.getInstalledApplications()` / `getLaunchIntentForPackage()` dipanggil dari kode native.
- Freeform window bukan fitur yang dapat dipaksa oleh aplikasi biasa. Dukungan bergantung pada versi Android, firmware, ukuran layar, dan mode desktop/manufacturer. Implementasikan `ActivityOptions` freeform hanya pada host yang mendukungnya; tangkap kegagalan lalu kembalikan `false`.
- `SYSTEM_ALERT_WINDOW` hanya dibutuhkan untuk overlay milik aplikasi sendiri (jendela web mengambang, V150). Izin itu tidak diperlukan dan tidak membantu untuk membuka aplikasi *lain* dalam freeform window. Picture-in-Picture ditujukan untuk activity milik aplikasi sendiri, bukan jendela umum aplikasi lain.
- Untuk WebView, tambahkan JavaScript interface hanya pada konten lokal/tepercaya. Jangan expose bridge ke halaman web pihak ketiga.

## Struktur modul
- `js/app-panel.js`: UI `PanelAppDrawer` dan `AppPickerDialog`, repository lokal, serta `WindowLauncher` melalui bridge.
- `css/app-panel.css`: tampilan panel responsif dan animasi.
- Integrasi menu utama: tombol `data-action="openAppPanel"` di `index.html`.

Data panel disimpan lokal pada browser/WebView origin. Hapus data situs atau ganti origin dapat menghapus daftar.


## V150 — Host Android siap pakai
Folder `android/` berisi proyek Android Studio yang mengimplementasikan kontrak di atas, ditambah metode baru:
- `hasOverlayPermission()`, `requestOverlayPermission()` — izin "Tampil di atas aplikasi lain".
- `openFloatingWeb(url,title,widthRatio)`, `closeAllFloating()` — jendela web mengambang (overlay) yang bisa digeser, diubah ukuran, dikecilkan, maksimal 3.
- `freeformSupported()`, `openFreeformSettings()` — deteksi/pengaktifan jendela freeform untuk aplikasi lain.
Lihat `android/README.md` untuk langkah build.
