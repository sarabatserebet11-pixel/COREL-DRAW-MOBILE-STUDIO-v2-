Simpan font berlisensi untuk aplikasi di folder ini.
