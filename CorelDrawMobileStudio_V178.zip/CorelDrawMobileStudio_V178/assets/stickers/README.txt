Simpan aset stiker di folder ini.
