/* V111: panel Properti dikelompokkan jadi bagian yang bisa dilipat (seperti panel Format di Office).
   Elemen dan id asli dipindahkan apa adanya, jadi semua fitur lama tetap bekerja. Status lipat diingat. */
(()=>{
const P=document.getElementById("properties");if(!P||P.dataset.v111)return;P.dataset.v111="1";
const K="cdms-props-closed";
let closed=[];try{closed=JSON.parse(localStorage.getItem(K)||"[]");}catch(e){}
const kids=[...P.children];
const SEC=[["pos","Posisi & ukuran",[1,2,3]],["warna","Warna & garis",[4,5,6,7]],["teks","Teks",[8,9]],["aksi","Aksi",[10,11]]];
SEC.forEach(([id,title,idx])=>{
 const nodes=idx.map(i=>kids[i]).filter(Boolean);if(!nodes.length)return;
 const d=document.createElement("details");d.className="prop-sec";d.dataset.sec=id;d.open=!closed.includes(id);
 const s=document.createElement("summary");s.textContent=title;d.appendChild(s);
 const body=document.createElement("div");body.className="prop-body";d.appendChild(body);
 P.insertBefore(d,nodes[0]);nodes.forEach(n=>body.appendChild(n));
 d.addEventListener("toggle",()=>{try{const set=new Set(JSON.parse(localStorage.getItem(K)||"[]"));d.open?set.delete(id):set.add(id);localStorage.setItem(K,JSON.stringify([...set]));}catch(e){}});
});
/* bagian Teks hanya tampil saat objek teks dipilih */
const tp=document.getElementById("textProperty"),ts=P.querySelector('[data-sec="teks"]');
if(tp&&ts){const sync=()=>ts.classList.toggle("hidden",tp.classList.contains("hidden"));
 new MutationObserver(sync).observe(tp,{attributes:true,attributeFilter:["class"]});sync();}
})();
