/* V81: tab baru Hias (garis hias: gelombang, zigzag, gelombang kotak, spiral, lengkung; lebar, amplitudo, periode, tebal, warna, putus-putus) dan Acak (geser/putar/skala/warna/opasitas acak, tukar posisi acak, acak urutan layer) di panel Penata + tombol cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const uid=()=>crypto.randomUUID();
const val=(id,d)=>{const e=$("#"+id);return e&&e.value?e.value:d;};
const chk=(id,d)=>{const e=$("#"+id);return e?e.checked:d;};
const rnd=(a,z)=>a+Math.random()*(z-a),sg=()=>rnd(-1,1);
const base=(t,x,y,w,h,f)=>({id:uid(),type:t,name:t[0].toUpperCase()+t.slice(1),x:Math.round(x),y:Math.round(y),w:Math.max(1,Math.round(w)),h:Math.max(1,Math.round(h)),fill:f,stroke:"#20243a",strokeWidth:0,opacity:100,rotation:0});
const bbox=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y));return{x,y,w:Math.max(...a.map(o=>o.x+(o.w||0)))-x,h:Math.max(...a.map(o=>o.y+(o.h||0)))-y};};
function units(){const seen=new Map();M.sels().forEach(o=>{if(o.locked)return;const k=o.groupId||o.id;if(!seen.has(k))seen.set(k,o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]);});return [...seen.values()].map(m=>({m,r:bbox(m)}));}
/* ---- Hias ---- */
let jenis="gel";
const NAMA={gel:"Gelombang",zig:"Zigzag",kot:"Gelombang kotak",spi:"Spiral",len:"Lengkung"};
function hias(){const W=Math.max(20,num("p81w",600)),A=Math.max(2,num("p81a",40)),N=Math.max(1,Math.min(40,num("p81p",6))),tw=Math.max(1,num("p81t",6)),col=val("p81c","#6d5dfc");
 const f=v=>Math.round(v*10)/10;let w=W,h,d="";
 if(jenis==="spi"){h=W;const cx=W/2,cy=W/2,R=W/2-tw,n=Math.round(N*48);for(let i=0;i<=n;i++){const t=i/n,a=t*N*2*Math.PI,r=R*t;d+=(i?"L":"M")+f(cx+r*Math.cos(a))+" "+f(cy+r*Math.sin(a));}}
 else{h=Math.max(4,A*2+tw*2);const mid=h/2;
  if(jenis==="gel"){const n=Math.round(N*28);for(let i=0;i<=n;i++){const t=i/n;d+=(i?"L":"M")+f(t*W)+" "+f(mid+A*Math.sin(t*N*2*Math.PI));}}
  else if(jenis==="zig"){const n=Math.round(N*2);for(let i=0;i<=n;i++)d+=(i?"L":"M")+f(i/n*W)+" "+f(mid+(i%2?A:-A));}
  else if(jenis==="kot"){const n=Math.round(N*2),st=W/n;for(let i=0;i<n;i++){const y=mid+(i%2?A:-A);d+=(i?"L":"M")+f(i*st)+" "+f(y)+"L"+f((i+1)*st)+" "+f(y);}}
  else{d="M0 "+f(mid+A)+"Q"+f(W/2)+" "+f(mid-A*3)+" "+f(W)+" "+f(mid+A);h=Math.max(h,A*2+tw*2);}}
 let cx=S.page.width/2,cy=S.page.height/2;const m=M.sels();if(chk("p81at",false)&&m.length){const r=bbox(m);cx=r.x+r.w/2;cy=r.y+r.h/2;}
 const o=base("path",cx-w/2,cy-h/2,w,h,"none");o.d=d;o.vw=w;o.vh=h;o.name=NAMA[jenis];o.stroke=col;o.strokeWidth=tw;if(chk("p81d",false))o.dash=Math.round(tw*2)+" "+Math.round(tw*1.5);
 Hi.snapshot();S.objects.push(o);pick([o]);T(NAMA[jenis]+" disisipkan");}
/* ---- Acak ---- */
const PAL=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4cc9f0","#f72585","#80ed99","#ff9f1c"];
const hex=c=>/^#[0-9a-f]{6}$/i.test(c||"");
function h2hsl(h){const r=parseInt(h.slice(1,3),16)/255,g=parseInt(h.slice(3,5),16)/255,bl=parseInt(h.slice(5,7),16)/255,mx=Math.max(r,g,bl),mn=Math.min(r,g,bl),l=(mx+mn)/2;let H=0,Sx=0;if(mx!==mn){const d=mx-mn;Sx=l>.5?d/(2-mx-mn):d/(mx+mn);H=mx===r?(g-bl)/d+(g<bl?6:0):mx===g?(bl-r)/d+2:(r-g)/d+4;H*=60;}return[H,Sx,l];}
function hsl2h(H,Sx,L){H=((H%360)+360)%360;const k=n=>(n+H/30)%12,a=Sx*Math.min(L,1-L),f=n=>L-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)));return"#"+[f(0),f(8),f(4)].map(v=>Math.round(v*255).toString(16).padStart(2,"0")).join("");}
function acak(){const u=units();if(!u.length)return T("Pilih objek dulu");
 const pos=chk("p81xp",true),rot=chk("p81xr",true),skl=chk("p81xs",false),opa=chk("p81xo",false),wr=chk("p81xw",false)?val("p81wm","palet"):"",
  gp=Math.max(0,num("p81gp",30)),gr=Math.max(0,num("p81gr",15)),gs=Math.max(0,Math.min(90,num("p81gs",20)))/100,o1=Math.max(0,Math.min(100,num("p81om",50))),o2=Math.max(o1,Math.min(100,num("p81ox",100)));
 if(!(pos||rot||skl||opa||wr))return T("Centang minimal satu jenis acak");
 Hi.snapshot();let nrot=0;
 u.forEach(({m,r})=>{
  if(skl){const k=1+sg()*gs,cx=r.x+r.w/2,cy=r.y+r.h/2;m.forEach(o=>{o.x=Math.round(cx+(o.x-cx)*k);o.y=Math.round(cy+(o.y-cy)*k);if(o.w)o.w=Math.max(1,Math.round(o.w*k));if(o.h)o.h=Math.max(1,Math.round(o.h*k));if(o.fontSize)o.fontSize=Math.max(1,Math.round(o.fontSize*k));if(o.rx)o.rx=Math.round(o.rx*k);});}
  if(pos){const dx=Math.round(sg()*gp),dy=Math.round(sg()*gp);m.forEach(o=>{o.x+=dx;o.y+=dy;});}
  if(rot&&m.length===1){m[0].rotation=Math.round((((m[0].rotation||0)+sg()*gr)%360));nrot++;}
  if(wr==="palet"){const c=PAL[Math.floor(Math.random()*PAL.length)];m.forEach(o=>{if(o.type!=="image"&&o.type!=="line"){o.fill=c;delete o.grad;}});}
  else if(wr==="variasi"){const dh=sg()*40,dl=sg()*.1;m.forEach(o=>{if(o.type!=="image"&&hex(o.fill)){const[h,s,l]=h2hsl(o.fill);o.fill=hsl2h(h+dh,s,Math.max(.1,Math.min(.9,l+dl)));delete o.grad;}});}
  if(opa){const v=Math.round(rnd(o1,o2));m.forEach(o=>{o.opacity=v;});}});
 C.render();T("Acak diterapkan pada "+u.length+" unit"+(rot&&nrot<u.length?" (rotasi hanya objek tunggal)":""));}
function tukar(){const u=units();if(u.length<2)return T("Pilih 2 unit atau lebih");Hi.snapshot();
 const pts=u.map(x=>({x:x.r.x,y:x.r.y})),pm=[...pts];for(let i=pm.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pm[i],pm[j]]=[pm[j],pm[i]];}
 u.forEach(({m,r},i)=>{const dx=Math.round(pm[i].x-r.x),dy=Math.round(pm[i].y-r.y);m.forEach(o=>{o.x+=dx;o.y+=dy;});});C.render();T("Posisi "+u.length+" unit ditukar acak");}
function urutan(){const u=units();if(u.length<2)return T("Pilih 2 unit atau lebih");Hi.snapshot();
 const info=u.map(x=>({m:[...x.m].sort((p,q)=>S.objects.indexOf(p)-S.objects.indexOf(q))}));const all=info.flatMap(x=>x.m),slots=all.map(o=>S.objects.indexOf(o)).filter(i=>i>=0).sort((a,b2)=>a-b2);
 for(let i=info.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[info[i],info[j]]=[info[j],info[i]];}
 const seq=info.flatMap(x=>x.m);if(seq.length!==slots.length)return T("Urutan tidak dapat diacak");seq.forEach((o,i)=>{S.objects[slots[i]]=o;});C.render();T("Urutan layer "+u.length+" unit diacak");}
const H={hg:()=>{jenis="gel";sUI();},hz:()=>{jenis="zig";sUI();},hk:()=>{jenis="kot";sUI();},hs:()=>{jenis="spi";sUI();},hl:()=>{jenis="len";sUI();},hs0:hias,ac:acak,tk:tukar,ur:urutan};
function sUI(){document.querySelectorAll(".p69 [data-hj]").forEach(x=>x.classList.toggle("on",x.dataset.hj===jenis));}
const cb=(id,l,on)=>`<label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 6px"><input id="${id}" type="checkbox" ${on?"checked":""}> ${l}</label>`;
P.addTab("hias","Hias",`<div class="p69btns c3">${[["hg","gel","Gelombang"],["hz","zig","Zigzag"],["hk","kot","Kotak"],["hs","spi","Spiral"],["hl","len","Lengkung"]].map(x=>`<button data-h="${x[0]}" data-hj="${x[1]}"><span>${x[2]}</span></button>`).join("")}</div>
 <div class="p69row" style="margin-top:10px">${fld("p81w","Lebar",600,'min="20"')}${fld("p81a","Amplitudo",40,'min="2"')}${fld("p81p","Periode",6,'min="1" max="40"')}${fld("p81t","Tebal garis",6,'min="1"')}<label>Warna<input id="p81c" type="color" value="#6d5dfc"></label></div>
 ${cb("p81d","Garis putus-putus",false)}${cb("p81at","Letakkan di tengah objek terpilih",false)}
 <div class="p69btns">${b("hs0","Sisipkan garis hias")}</div><p class="muted" style="margin-top:8px">Spiral memakai Lebar sebagai ukuran; Periode = jumlah gelombang/putaran.</p>`,H);
P.addTab("acak","Acak",`${cb("p81xp","Geser acak",true)}${cb("p81xr","Putar acak (objek tunggal)",true)}${cb("p81xs","Skala acak",false)}${cb("p81xo","Opasitas acak",false)}${cb("p81xw","Warna acak",false)}
 <div class="p69row" style="margin-top:6px">${fld("p81gp","Geser ± px",30,'min="0"')}${fld("p81gr","Putar ± °",15,'min="0"')}${fld("p81gs","Skala ± %",20,'min="0" max="90"')}${fld("p81om","Opasitas min %",50,'min="0" max="100"')}${fld("p81ox","Opasitas maks %",100,'min="0" max="100"')}
 <label>Mode warna<select id="p81wm"><option value="palet">Dari palet 8 warna</option><option value="variasi">Variasi warna isi</option></select></label></div>
 <div class="p69btns">${b("ac","Terapkan acak")}${b("tk","Tukar posisi acak")}${b("ur","Acak urutan layer")}</div><p class="muted" style="margin-top:8px">Berlaku per unit (objek tunggal atau satu grup). Semua bisa di-undo.</p>`,H);
document.addEventListener("click",e=>{if(e.target.closest&&e.target.closest(".p69 [data-t=hias]"))sUI();});
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q11="gel" title="Sisip gelombang">${ic("pen")}</button><button data-q11="hias" title="Garis hias">${ic("line")}</button><button data-q11="acak" title="Acak pilihan">${ic("rotate")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q11]");if(!x)return;const k=x.dataset.q11;
  if(k==="gel"){const old=jenis;jenis="gel";hias();jenis=old;}else if(k==="hias"){P.openTab("hias");sUI();}else acak();});}
MENUS.penata81=()=>[{h:"Tab Penata",items:[it("Hias (gelombang, zigzag, spiral)",()=>{P.openTab("hias");sUI();},"pen"),it("Acak (geser, putar, warna)",()=>P.openTab("acak"),"rotate")]},{h:"Cepat",items:[it("Sisip gelombang",()=>{const o=jenis;jenis="gel";hias();jenis=o;},"pen"),it("Tukar posisi acak",tukar,"multi"),it("Acak urutan layer",urutan,"layers")]}];
BT.push(["penata81","panel","Penata 12"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata81");
})();
