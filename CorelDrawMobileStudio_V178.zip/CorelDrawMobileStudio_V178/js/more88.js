/* V100: dua grup menu baru (helper bersama dari CDMS.Util97, tanpa kode duplikat).
   "Latar Seru" (ikon fun100): Sinar (sunburst berselang-seling), Percik (cipratan cat acak + tetesan), Konfeti (potongan warna-warni acak).
   "Catatan" (ikon note100): Kertas (bergaris / kotak / titik), Balon (bicara, pikir, teriak dengan teks otomatis dibungkus), Catatan Tempel (kertas sticky + selotip + lipatan).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U||!U.poly)return;
const{parse,mix,ramp,grup,shape,text,line,path,finish,rnd,PAL,defHub,W,H,chips,poly,clip}=U,R=Math.round,pick=a=>a[Math.floor(Math.random()*a.length)];
const bgc=()=>parse(S.page.background||"")?S.page.background:"#ffffff";
const ask=(m,d)=>{const q=prompt(m,d);return q===null?null:String(q).trim();};
const pal=()=>PAL[PAL[S.pal100]?S.pal100:"senja"],pc=(P,t)=>ramp(P.c.slice(1),t);
const palMenu=()=>({h:"Palet",items:["senja","laut","hijau","biru","mono"].map(k=>tc(PAL[k].n,()=>{S.pal100=k;},{keep:1,on:(S.pal100||"senja")===k}))});
const idx=(h,arr,key,def)=>({h,items:arr.map((x,i)=>tc(x[0],()=>{S[key]=i;},{keep:1,on:(S[key]??def)===i}))});
const wrap=(s,mc)=>{const L=[];let cur="";String(s).split(/\s+/).filter(Boolean).forEach(wd=>{while(wd.length>mc){if(cur){L.push(cur);cur="";}L.push(wd.slice(0,mc));wd=wd.slice(mc);}
 if(!wd)return;if(!cur)cur=wd;else if((cur+" "+wd).length<=mc)cur+=" "+wd;else{L.push(cur);cur=wd;}});if(cur)L.push(cur);return L;};

/* ================= LATAR SERU ================= */
const BP=[["Komik","#ffd23f","#ff6b35"],["Retro","#f4e3c1","#e07a5f"],["Biru","#dbeafe","#3b82f6"],["Mono","#f1f5f9","#94a3b8"]],PUS=[["Tengah",.5],["Atas",.25],["Bawah",.75]];
function burst(){const w=W(),h=H(),N=S.bsN100||20,B=BP[S.bsP100||0],cx=w/2,cy=h*PUS[S.bsC100||0][1],L=Math.hypot(w,h)*1.2,st=2*Math.PI/N,a0=-Math.PI/2+rnd(0,st),out=[shape("rect",0,0,w,h,B[1],{name:"Latar"})];Hi.snapshot();
 for(let i=0;i<N;i+=2){const pg=clip([[cx,cy],[cx+L*Math.cos(a0+i*st),cy+L*Math.sin(a0+i*st)],[cx+L*Math.cos(a0+(i+1)*st),cy+L*Math.sin(a0+(i+1)*st)]],w,h);if(pg.length>=3)out.push(poly(pg,B[2],"Sinar "+(i/2+1)));}
 finish(grup(out,"Sinar"),"Sinar "+N+" ("+B[0]+")");}
MENUS.bst100=()=>[idx("Warna",BP,"bsP100",0),chips("Jumlah sinar",[12,20,32],"bsN100",20),idx("Pusat",PUS,"bsC100",0),{h:"Buat",items:[it("Buat sinar (mengisi halaman)",burst,"sunburst100")]}];

const SZ=[["Kecil",.08],["Sedang",.14],["Besar",.22]];
function percik(){const P=pal(),w=W(),h=H(),n=S.pcN100||3,r0=Math.min(w,h)*SZ[S.pcS100??1][1],out=[];Hi.snapshot();
 for(let k=0;k<n;k++){const r=r0*rnd(.8,1.2),m=Math.min(r*2.4,w*.45,h*.45),cx=rnd(m,w-m),cy=rnd(m,h-m),col=pc(P,rnd(0,1)),N=14,D=R(r*2.5),c=D/2,pts=[];
  for(let i=0;i<N;i++){const a=2*Math.PI*i/N+rnd(-.12,.12),ri=r*(i%2?rnd(.55,.8):rnd(.95,1.25));pts.push([c+ri*Math.cos(a),c+ri*Math.sin(a)]);}
  const md=(a,b)=>[(a[0]+b[0])/2,(a[1]+b[1])/2],f=p=>R(p[0])+" "+R(p[1]);let d="M"+f(md(pts[N-1],pts[0]));
  for(let i=0;i<N;i++)d+="Q"+f(pts[i])+" "+f(md(pts[i],pts[(i+1)%N]));
  out.push(path(cx-c,cy-c,D,D,D,D,d+"Z",col,"none",0,{name:"Percik "+(k+1)}));
  for(let j=0;j<9;j++){const a=rnd(0,6.283),dd=r*rnd(1.35,2.3),s=r*rnd(.06,.2),px=cx+dd*Math.cos(a),py=cy+dd*Math.sin(a);if(px-s<0||py-s<0||px+s>w||py+s>h)continue;out.push(shape("ellipse",px-s,py-s,s*2,s*2,col,{name:"Tetes "+(k+1)+"."+(j+1)}));}}
 finish(grup(out,"Percik"),n+" percikan ("+P.n+")");}
MENUS.pcr100=()=>[palMenu(),idx("Ukuran",SZ,"pcS100",1),chips("Jumlah percikan",[1,3,5],"pcN100",3),{h:"Buat",items:[it("Buat percikan acak (hasil beda tiap kali)",percik,"splat100")]}];

const PES=["#ef4444","#f59e0b","#10b981","#3b82f6","#8b5cf6","#ec4899","#facc15"];
function konfeti(){const P=pal(),w=W(),h=H(),n=S.kfN100||80,u=Math.max(8,Math.min(w,h)/55),out=[];Hi.snapshot();
 for(let i=0;i<n;i++){const col=S.kfM100==="p"?pc(P,rnd(0,1)):pick(PES),x=rnd(0,w),y=rnd(0,h),t=Math.random(),rot=R(rnd(0,180)),op=R(rnd(80,100));
  if(t<.45){const a=u*rnd(.8,1.6);out.push(shape("rect",x,y,a,a*rnd(.35,.6),col,{name:"Kertas "+(i+1),rotation:rot,opacity:op}));}
  else if(t<.75){const s=u*rnd(.4,.8);out.push(shape("ellipse",x,y,s,s,col,{name:"Bulat "+(i+1),opacity:op}));}
  else{const s=u*rnd(.7,1.2);out.push(path(x,y,s,s,100,100,"M0 100L50 0L100 100Z",col,"none",0,{name:"Segitiga "+(i+1),rotation:rot,opacity:op}));}}
 finish(grup(out,"Konfeti"),"Konfeti "+n+" potong");}
MENUS.kfn100=()=>[{h:"Warna",items:[tc("Pesta",()=>{S.kfM100="m";},{keep:1,on:S.kfM100!=="p"}),tc("Ikut palet",()=>{S.kfM100="p";},{keep:1,on:S.kfM100==="p"})]},palMenu(),chips("Jumlah",[40,80,150],"kfN100",80),{h:"Buat",items:[it("Taburkan konfeti (mengisi halaman)",konfeti,"confetti100")]}];

/* ================= CATATAN ================= */
const KP=[["Krem","#fffdf5"],["Kuning","#fff7c2"],["Biru muda","#eef5ff"]],KG=[["Bergaris","l"],["Kotak","k"],["Titik","t"]];
function kertas(){const w=W(),h=H(),g=S.kgG100||"l",lc="#a9bde0",out=[shape("rect",0,0,w,h,KP[S.kgW100||0][1],{name:"Kertas"})];Hi.snapshot();
 let sp=Math.max(S.kgS100||36,(w+h)/200);if(g==="t")sp=Math.max(sp,Math.sqrt(w*h/900));
 if(g==="l"){for(let y=sp*2,i=1;y<h;y+=sp,i++)out.push(line(0,y,w,0,lc,2,{name:"Baris "+i}));out.push(line(w*.12,0,0,h,"#f87171",3,{name:"Margin"}));}
 else if(g==="k"){for(let x=sp,i=1;x<w;x+=sp,i++)out.push(line(x,0,0,h,lc,2,{name:"Kolom "+i,opacity:80}));for(let y=sp,i=1;y<h;y+=sp,i++)out.push(line(0,y,w,0,lc,2,{name:"Baris "+i,opacity:80}));}
 else{const r=Math.max(2,sp*.07);for(let y=sp;y<h;y+=sp)for(let x=sp;x<w;x+=sp)out.push(shape("ellipse",x-r,y-r,r*2,r*2,"#9fb0d4",{name:"Titik"}));}
 finish(grup(out,"Kertas"),"Kertas "+KG.find(x=>x[1]===g)[0].toLowerCase()+" · "+(out.length-1)+" elemen");}
MENUS.ktr100=()=>[{h:"Gaya",items:KG.map(x=>tc(x[0],()=>{S.kgG100=x[1];},{keep:1,on:(S.kgG100||"l")===x[1]}))},chips("Jarak (px)",[24,36,48],"kgS100",36),idx("Warna kertas",KP,"kgW100",0),{h:"Buat",items:[it("Buat kertas (mengisi halaman)",kertas,"paper100")]}];

const BS=[["Bicara","b"],["Pikir","t"],["Teriak","s"]];
function balon(){const q=ask("Teks balon (maks 60 huruf):","Halo, dunia!");if(q===null)return;const t=q.slice(0,60);if(!t)return T("Teks kosong");Hi.snapshot();
 const w=W(),h=H(),st=S.blS100||"b",L=wrap(t,18),n=L.length,ml=Math.max(...L.map(s=>s.length)),fs0=Math.max(12,Math.min(w,h)*.05),
 ext=f=>{const bw=ml*f*.6+f*1.6,bh=n*f*1.35+f*1.2;return st==="t"?[bw*1.45,bh*2.1,bw,bh]:st==="s"?[bw*1.7,bh*2.1,bw,bh]:[bw,bh*1.45,bw,bh];},
 e0=ext(fs0),fs=R(Math.max(6,fs0*Math.min(1,w*.92/e0[0],h*.92/e0[1]))),[ew,eh,bw,bh]=ext(fs),cx=w/2,cy=h/2,col="#111827",sw=Math.max(3,R(fs*.12)),top=cy-eh/2,out=[];let ty;
 if(st==="t"){const ey=top+bh*.8;ty=ey;out.push(shape("ellipse",cx-ew/2,top,ew,bh*1.6,"#ffffff",{name:"Balon pikir",stroke:col,strokeWidth:sw}),
  shape("ellipse",cx-ew*.28-bh*.1,top+bh*1.75-bh*.1,bh*.2,bh*.2,"#ffffff",{name:"Gelembung 1",stroke:col,strokeWidth:sw}),shape("ellipse",cx-ew*.36-bh*.06,top+bh*2.0-bh*.06,bh*.12,bh*.12,"#ffffff",{name:"Gelembung 2",stroke:col,strokeWidth:sw}));}
 else if(st==="s"){ty=cy;const ex=ew/2,ey=eh/2,P=[];for(let i=0;i<32;i++){const a=i*Math.PI/16-Math.PI/2,r=i%2?.85:1;P.push([cx+ex*r*Math.cos(a),cy+ey*r*Math.sin(a)]);}
  out.push(poly(P,"#ffe14d","Balon teriak",{stroke:col,strokeWidth:sw}));}
 else{const y0=top,x0=cx-bw/2,ax=cx-bw*.3,bx=cx-bw*.1;ty=y0+bh/2;
  out.push(poly([[ax,y0+bh-1],[cx-bw*.4,y0+bh+bh*.45],[bx,y0+bh-1]],"#ffffff","Ekor",{stroke:col,strokeWidth:sw}),
  shape("rect",x0,y0,bw,bh,"#ffffff",{name:"Balon bicara",rx:R(bh*.25),stroke:col,strokeWidth:sw}),
  shape("rect",ax+sw*.9,y0+bh-sw/2-.5,bx-ax-sw*1.8,sw+1,"#ffffff",{name:"Sambungan"}));}
 L.forEach((s,i)=>out.push(text(s,cx-s.length*fs*.3,ty-n*fs*1.35/2+fs*.1+i*fs*1.35,fs,col,{name:"Teks "+(i+1),bold:true})));
 finish(grup(out,"Balon"),"Balon "+BS.find(x=>x[1]===st)[0].toLowerCase()+" dipasang");}
MENUS.blo100=()=>[{h:"Gaya",items:BS.map(x=>tc(x[0],()=>{S.blS100=x[1];},{keep:1,on:(S.blS100||"b")===x[1]}))},{h:"Buat",items:[it("Buat balon di tengah halaman…",balon,"bubble100")]}];

const SC=[["Kuning","#fde047"],["Pink","#f9a8d4"],["Hijau","#86efac"],["Biru","#93c5fd"]];
function sticky(){const q=ask("Isi catatan (maks 60 huruf):","Jangan lupa rapat jam 3!");if(q===null)return;const t=q.slice(0,60);if(!t)return T("Teks kosong");Hi.snapshot();
 const L=wrap(t,14),n=L.length,ml=Math.max(...L.map(s=>s.length)),w=W(),h=H(),col=SC[S.stC100||0][1],sz=R(Math.min(w,h)*.5),x=R((w-sz)/2),y=R((h-sz)/2),
 fs=R(Math.max(8,Math.min(sz*.11,sz*.8/(ml*.6),sz*.68/(n*1.35)))),fc=R(sz*.16),
 out=[shape("rect",x+6,y+8,sz,sz,"#000000",{name:"Bayangan",opacity:18}),shape("rect",x,y,sz,sz,col,{name:"Catatan"}),
  path(x+sz-fc,y+sz-fc,fc,fc,100,100,"M100 0L100 100L0 100Z",mix(col,"#000000",.18),"none",0,{name:"Lipatan"}),
  shape("rect",x+sz*.34,y-sz*.045,sz*.32,sz*.09,"#ffffff",{name:"Selotip",opacity:65,rotation:-4})];
 L.forEach((s,i)=>out.push(text(s,x+sz*.1,y+sz*.18+i*fs*1.35,fs,"#1f2937",{name:"Teks "+(i+1)})));
 finish(grup(out,"Catatan tempel"),"Catatan tempel dipasang");}
MENUS.stk100=()=>[idx("Warna",SC,"stC100",0),{h:"Buat",items:[it("Buat catatan tempel di tengah…",sticky,"sticky100")]}];

Object.assign(U,{ask,wrap,idx});
/* ================= tombol & grup ================= */
BT.push(["bst100","sunburst100","Sinar"],["pcr100","splat100","Percik"],["kfn100","confetti100","Konfeti"],["ktr100","paper100","Kertas"],["blo100","bubble100","Balon"],["stk100","sticky100","Catatan Tempel"]);
defHub("catatan100","note100","Catatan",["ktr100","blo100","stk100"]);
defHub("seru100","fun100","Latar Seru",["bst100","pcr100","kfn100"]);
CDMS.Seru100={burst,percik,konfeti,kertas,balon,sticky};
})();
