/* V152 — Tombol/gestur "Kembali" yang konsisten (browser & APK Android).
   Urutan: menu item → dialog tambah/edit → pemilih aplikasi → panel aplikasi → jendela modal →
   layar penuh PPT → mode Word/Excel/PowerPoint → editor desain → (beranda) tekan 2x untuk keluar. */
(() => {
  'use strict';
  const q = s => document.querySelector(s);
  const shown = el => !!el && !el.classList.contains('hidden') && getComputedStyle(el).display !== 'none';
  function toast(msg) {
    let t = document.getElementById('appPanelToast');
    if (!t) { t = document.createElement('div'); t.id = 'appPanelToast'; t.className = 'app-panel-toast'; document.body.appendChild(t); }
    t.textContent = msg; t.classList.add('show'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('show'), 2000);
  }
  /** Menutup satu lapisan teratas. Mengembalikan true bila ada yang ditutup. */
  function handleBack() {
    const menu = q('#appItemMenu');
    if (menu) { menu.remove(); return true; }
    const fl = [...document.querySelectorAll('.app-float')].sort((a, b) => (+b.style.zIndex || 0) - (+a.style.zIndex || 0))[0];
    if (fl) { fl.remove(); return true; }
    const add = q('#appAddOverlay.is-open');
    if (add) { const b = add.querySelector('[data-add-close]'); if (b) b.click(); return true; }
    const pick = q('#appPickerOverlay.is-open');
    if (pick) { const b = pick.querySelector('[data-picker-close]'); if (b) b.click(); return true; }
    if (q('#appPanelOverlay.is-open')) { if (window.PanelAppDrawer) PanelAppDrawer.close(); return true; }
    const modal = q('#modalBackdrop');
    if (modal && !modal.classList.contains('hidden')) { const b = modal.querySelector('[data-action="closeModal"]'); if (b) b.click(); return true; }
    const show = q('#pptShow');
    if (show && !show.classList.contains('hidden')) { const b = q('#pptShowClose'); if (b) b.click(); return true; }
    for (const [view, home] of [['#pptMode', 'pptHome'], ['#wordMode', 'wordHome'], ['#excelMode', 'excelHome']]) {
      if (shown(q(view))) { const b = q('[data-action="' + home + '"]'); if (b) { b.click(); return true; } }
    }
    const ed = q('#editor');
    if (shown(ed)) {
      if (window.CDMS && CDMS.Navigation && CDMS.Navigation.showDashboard) CDMS.Navigation.showDashboard();
      else { const b = q('[data-action="home"]'); if (b) b.click(); }
      return true;
    }
    return false;
  }
  window.CDMSBack = { handle: handleBack };

  // Jebakan riwayat: tombol/gestur kembali browser atau WebView memicu popstate tanpa meninggalkan halaman.
  let lastRoot = 0;
  try { history.replaceState({ cdms: 0 }, ''); history.pushState({ cdms: 1 }, ''); } catch (_) { return; }
  window.addEventListener('popstate', () => {
    if (handleBack()) { try { history.pushState({ cdms: 1 }, ''); } catch (_) {} return; }
    const now = Date.now();
    if (now - lastRoot < 2000) {
      const b = window.AndroidAppPanel;
      if (b && typeof b.exitApp === 'function') b.exitApp(); else history.back();
      return;
    }
    lastRoot = now;
    toast('Tekan kembali sekali lagi untuk keluar');
    try { history.pushState({ cdms: 1 }, ''); } catch (_) {}
  });
  // Panah ← di bilah judul panel/dialog (tombol layar)
  document.addEventListener('click', e => {
    if (e.target.closest && e.target.closest('[data-app-back]')) handleBack();
  });
})();
