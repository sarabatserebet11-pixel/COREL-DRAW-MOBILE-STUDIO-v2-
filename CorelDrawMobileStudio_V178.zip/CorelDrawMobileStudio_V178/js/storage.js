window.CDMS=window.CDMS||{};CDMS.Storage={
 key:"cdms_projects_v1",
 list(){try{return JSON.parse(localStorage.getItem(this.key)||"[]")}catch{return[]}},
 save(){const S=CDMS.state;const item={name:S.projectName,width:S.page.width,height:S.page.height,background:S.page.background,objects:S.objects,updated:Date.now()};let list=this.list();const i=list.findIndex(x=>x.name===item.name);if(i>=0)list[i]=item;else list.unshift(item);list=list.slice(0,20);localStorage.setItem(this.key,JSON.stringify(list));CDMS.Navigation.renderRecents();this.downloadJSON(item,item.name.replace(/[^\w-]+/g,"_")+".cdms");CDMS.Navigation.openModal("Proyek disimpan",`<p>Proyek <b>${CDMS.escape(item.name)}</b> tersimpan di perangkat dan salinan berkas telah disiapkan.</p><button class="btn primary" data-action="closeModal">Selesai</button>`);},
 init(){document.getElementById("projectInput").addEventListener("change",async e=>{const f=e.target.files[0];if(!f)return;try{const p=JSON.parse(await f.text());CDMS.Canvas.loadProject(p); }catch{alert("Berkas proyek tidak valid.");}e.target.value="";});},
 openAt(i){const p=this.list()[i];if(p)CDMS.Canvas.loadProject(p);},
 downloadJSON(data,name){const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
};
