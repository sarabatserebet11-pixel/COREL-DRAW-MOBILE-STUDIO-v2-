/* V39: pemandu (guide) dengan snap, filter timbul/bayangan dalam, menu Diagram (flowchart) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;
function ask(title,html,cb,label){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">${label||"Tambah"}</button></div>`);$("#aOk").onclick=cb;}

/* ---- pemandu: garis bantu buatan sendiri dengan snap ---- */
S.guidesU=S.guidesU||[];
const dov=C.drawOverlay;
C.drawOverlay=function(){dov.call(this);const g=S.guidesU,ov=document.getElementById("overlayLayer");if(!g.length||!ov)return;const k=Math.max(1,W()/(this.svg.getBoundingClientRect().width||W()));
 ov.insertAdjacentHTML("afterbegin",`<g id="cdGuideU" pointer-events="none">${g.map(x=>x.a==="v"?`<line x1="${x.p}" y1="0" x2="${x.p}" y2="${H()}" stroke="#00b8ff" stroke-width="${1.5*k}"/>`:`<line x1="0" y1="${x.p}" x2="${W()}" y2="${x.p}" stroke="#00b8ff" stroke-width="${1.5*k}"/>`).join("")}</g>`);};
const pm=C.pointerMove;
C.pointerMove=function(e){pm.call(this,e);const d=S.drag;if(!d||d.mode!=="move"||!d.moved||!S.guidesU.length)return;
 const ids=new Set(S.selectedIds||[]),a=S.objects.filter(o=>ids.has(o.id));if(!a.length)return;const x0=Math.min(...a.map(o=>o.x)),x1=Math.max(...a.map(o=>o.x+o.w)),y0=Math.min(...a.map(o=>o.y)),y1=Math.max(...a.map(o=>o.y+(o.h||0))),TH=10;let dx=0,dy=0,bx=TH+1,by=TH+1;
 S.guidesU.forEach(g=>{const cs=g.a==="v"?[x0,(x0+x1)/2,x1]:[y0,(y0+y1)/2,y1];cs.forEach(c=>{const df=g.p-c;if(g.a==="v"&&Math.abs(df)<bx){bx=Math.abs(df);dx=df;}if(g.a==="h"&&Math.abs(df)<by){by=Math.abs(df);dy=df;}});});
 if(bx<=TH||by<=TH){a.forEach(o=>{if(bx<=TH)o.x=Math.round(o.x+dx);if(by<=TH)o.y=Math.round(o.y+dy);});this.render();}};
const addG=(a,p)=>{S.guidesU.push({a,p:Math.round(p)});C.render();T("Pemandu ditambahkan");};
const askG=a=>()=>ask("Pemandu "+(a==="v"?"vertikal":"horizontal"),`<label>Posisi (px kanvas, 0 - ${a==="v"?W():H()})<input id="gP" type="number" value="${Math.round((a==="v"?W():H())/2)}"></label>`,()=>{const v=+$("#gP").value;N.closeModal();if(Number.isFinite(v))addG(a,v);});
MENUS.guideU=()=>[{h:"Tambah pemandu (objek yang digeser akan menempel)",items:[it("Pemandu vertikal di…",askG("v"),"line"),it("Pemandu horizontal di…",askG("h"),"line"),it("Pemandu tengah halaman",()=>{S.guidesU.push({a:"v",p:Math.round(W()/2)},{a:"h",p:Math.round(H()/2)});C.render();},"grid"),it("Pemandu sepertiga halaman",()=>{[1/3,2/3].forEach(f=>S.guidesU.push({a:"v",p:Math.round(W()*f)},{a:"h",p:Math.round(H()*f)}));C.render();},"grid"),it("Pemandu margin 6%",()=>{const m=.06;S.guidesU.push({a:"v",p:Math.round(W()*m)},{a:"v",p:Math.round(W()*(1-m))},{a:"h",p:Math.round(H()*m)},{a:"h",p:Math.round(H()*(1-m))});C.render();},"grid")]},
 {h:"Kelola ("+S.guidesU.length+" pemandu)",items:[it("Hapus semua pemandu",()=>{S.guidesU=[];C.render();T("Pemandu dihapus");},"trash")]}];

/* ---- filter timbul & bayangan dalam ---- */
const F=(id,b)=>`<filter id="${id}" x="-10%" y="-10%" width="120%" height="120%" color-interpolation-filters="sRGB">${b}</filter>`;
Object.assign(M.FXS,{
 bevel:id=>F(id,'<feGaussianBlur in="SourceAlpha" stdDeviation="5" result="b"/><feSpecularLighting in="b" surfaceScale="8" specularConstant="1.2" specularExponent="70" lighting-color="#ffffff" result="s"><fePointLight x="-4000" y="-8000" z="16000"/></feSpecularLighting><feComposite in="s" in2="SourceAlpha" operator="in" result="s2"/><feComposite in="SourceGraphic" in2="s2" operator="arithmetic" k1="0" k2="1" k3="1" k4="0"/>'),
 inner:id=>F(id,'<feComponentTransfer in="SourceAlpha" result="inv"><feFuncA type="table" tableValues="1 0"/></feComponentTransfer><feGaussianBlur in="inv" stdDeviation="7" result="bl"/><feOffset in="bl" dx="5" dy="8" result="o"/><feFlood flood-color="#000" flood-opacity=".55" result="fc"/><feComposite in="fc" in2="o" operator="in" result="sh"/><feComposite in="sh" in2="SourceAlpha" operator="in" result="sh2"/><feMerge><feMergeNode in="SourceGraphic"/><feMergeNode in="sh2"/></feMerge>'),
 glow2:id=>F(id,'<feComponentTransfer in="SourceAlpha" result="inv"><feFuncA type="table" tableValues="1 0"/></feComponentTransfer><feGaussianBlur in="inv" stdDeviation="9" result="bl"/><feFlood flood-color="#ffffff" flood-opacity=".85" result="fc"/><feComposite in="fc" in2="bl" operator="in" result="g"/><feComposite in="g" in2="SourceAlpha" operator="in" result="g2"/><feMerge><feMergeNode in="SourceGraphic"/><feMergeNode in="g2"/></feMerge>')});
const os=MENUS.sfx;
MENUS.sfx=()=>{const s=os();s.splice(1,0,{h:"Timbul & kedalaman",items:[["Bevel timbul","bevel"],["Bayangan dalam","inner"],["Kilau tepi dalam","glow2"]].map(x=>it(x[0],()=>edit(o=>{o.svgfx=x[1];},"Filter diterapkan",o=>o.type!=="line"),"studio"))});return s;};

/* ---- diagram / flowchart ---- */
const PC=["#dbe4ff","#d3f9d8","#fff3bf","#ffe3e3","#e5dbff"];
const KIND={proses:{n:"Proses",t:"rect",r:8},mulai:{n:"Mulai / Selesai",t:"rect",pill:true},keputusan:{n:"Keputusan",t:"path",d:"M50 0L100 50L50 100L0 50Z",hr:.8},data:{n:"Data (input/output)",t:"path",d:"M18 0H100L82 100H0Z"},dokumen:{n:"Dokumen",t:"path",d:"M0 0H100V82C82 72 68 100 50 90C32 80 18 100 0 86Z"},basis:{n:"Basis data",t:"path",d:"M0 14A50 14 0 0 1 100 14V86A50 14 0 0 1 0 86ZM0 14A50 14 0 0 0 100 14",hr:.9}};
let ci=0;
function node(kind,label,cx,cy){const K=KIND[kind],w=Math.round(W()*.24),h=Math.round(w*(K.hr||.5)),g=uid(),col=PC[ci++%5],base={id:uid(),groupId:g,name:K.n,x:Math.round(cx-w/2),y:Math.round(cy-h/2),w,h,fill:col,stroke:"#20243a",strokeWidth:4,opacity:100,rotation:0};
 const sh=K.t==="rect"?{...base,type:"rect",rx:K.pill?Math.round(h/2):K.r}:{...base,type:"path",vw:100,vh:100,d:K.d},tx={id:uid(),groupId:g,type:"text",name:"Label",text:label,x:0,y:0,w:50,h:30,fontSize:Math.round(Math.min(h*.3,w*.1)),fill:"#20243a",bold:true,stroke:"none",strokeWidth:0,opacity:100,rotation:0};return{sh,tx};}
const center=(a)=>{a.forEach(n=>{n.tx.x=Math.round(n.sh.x+(n.sh.w-n.tx.w)/2);n.tx.y=Math.round(n.sh.y+(n.sh.h-n.tx.h)/2);});};
function addNodes(list){Hi.snapshot();const nodes=list.map(l=>node(l[0],l[1],l[2],l[3]));nodes.forEach(n=>S.objects.push(n.sh,n.tx));S.selectedIds=nodes.flatMap(n=>[n.sh.id,n.tx.id]);S.selected=nodes[0].sh.id;C.render();center(nodes);C.render();return nodes;}
const one=kind=>()=>addNodes([[kind,KIND[kind].n,W()/2,H()/2]]);
function sample(){const cx=W()/2,gap=Math.round(H()*.19),y0=Math.round(H()*.14),ns=addNodes([["mulai","Mulai",cx,y0],["proses","Isi data",cx,y0+gap],["keputusan","Valid?",cx,y0+gap*2.2],["mulai","Selesai",cx,y0+gap*3.4]]);
 const conn=M.MENUS.conn()[0].items[0].f;for(let i=0;i<ns.length-1;i++){S.selectedIds=[ns[i].sh.id,ns[i+1].sh.id];S.selected=ns[i].sh.id;conn();}S.selectedIds=[];S.selected=null;C.render();T("Contoh alur dibuat dengan 3 konektor panah");}
MENUS.diagram=()=>[{h:"Bentuk flowchart (berlabel, bisa dihubungkan dengan Konektor)",items:Object.keys(KIND).map(k=>it(KIND[k].n,one(k),"rect"))},{h:"Contoh",items:[it("Contoh alur 4 langkah + konektor",sample,"layers")]}];

BT.push(["guideU","guides","Pemandu"],["diagram","diagram","Diagram"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("kanvas").push("guideU");hub("pustaka").push("diagram");
})();
