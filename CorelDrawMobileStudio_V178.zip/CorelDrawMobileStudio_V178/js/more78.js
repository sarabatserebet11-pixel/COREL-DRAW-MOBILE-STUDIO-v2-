/* V90: grup menu baru "Periksa" - pemeriksa desain (teks kosong, teks terlalu kecil, kontras teks rendah, objek di luar halaman, duplikat persis,
   objek nyaris tak terlihat, objek tersembunyi) dengan skor, tombol Pilih/Perbaiki per masalah dan Perbaiki semua + tab Periksa di panel Penata + tombol cepat */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,P=CDMS.Penata,{MENUS,BT,it,pick,T,cell}=M;
if(!M.HUBS||!P)return;
const addTab=(k,l,html,h)=>{const nh={};Object.keys(h).forEach(x=>{nh["x90_"+x]=h[x];});P.addTab(k,l,html.replace(/data-h="([^"]+)"/g,'data-h="x90_$1"'),nh);};
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n);
const b=(k,l,i)=>`<button data-h="${k}">${i?ic(i):""}<span>${l}</span></button>`;
const norm=c=>{if(typeof c!=="string")return null;c=c.trim().toLowerCase();if(/^#[0-9a-f]{6}$/.test(c))return c;if(/^#[0-9a-f]{3}$/.test(c))return"#"+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];return null;};
const lum=h=>{const p=[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255).map(v=>v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4));return .2126*p[0]+.7152*p[1]+.0722*p[2];};
const rasio=(a,c)=>{const x=lum(a),y=lum(c);return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
const MIN_FONT=12,MIN_RASIO=3;
/* warna latar di belakang sebuah teks: objek berisi warna paling atas di bawahnya, jika tidak ada maka latar halaman */
function latarDi(t){const i=S.objects.indexOf(t),cx=t.x+(t.w||0)/2,cy=t.y+(t.h||t.fontSize||0)/2;
 for(let j=i-1;j>=0;j--){const o=S.objects[j];if(o.hidden||o.type==="text"||o.type==="image"||o.type==="line")continue;if((o.opacity===undefined?100:o.opacity)<60)continue;
  if(cx>=o.x&&cx<=o.x+(o.w||0)&&cy>=o.y&&cy<=o.y+(o.h||0)){const c=norm(o.fill);if(c)return c;if(Array.isArray(o.grad)&&norm(o.grad[0]))return norm(o.grad[0]);}}
 return norm(S.page.background)||"#ffffff";}
const terbaik=bg=>rasio("#000000",bg)>=rasio("#ffffff",bg)?"#000000":"#ffffff";
/* ---- pemeriksaan ---- */
function periksa(){const A=S.objects,L=[],add=(k,judul,objs,bobot,fix,aksi)=>{if(objs.length)L.push({k,judul,objs,bobot,fix,aksi});};
 const teks=A.filter(o=>o.type==="text"&&!o.isoWas);
 add("kosong","Teks kosong",teks.filter(o=>!String(o.text||"").trim()),6,os=>{S.objects=S.objects.filter(o=>!os.includes(o));},"Dihapus");
 add("kecil","Teks terlalu kecil (< "+MIN_FONT+" px)",teks.filter(o=>String(o.text||"").trim()&&(o.fontSize||0)<MIN_FONT&&(o.fontSize||0)>0),4,os=>os.forEach(o=>{o.fontSize=MIN_FONT;}),"Dinaikkan ke "+MIN_FONT+" px");
 add("kontras","Kontras teks rendah (< "+MIN_RASIO+":1)",teks.filter(o=>{const c=norm(o.fill);return c&&String(o.text||"").trim()&&!o.hidden&&rasio(c,latarDi(o))<MIN_RASIO;}),8,os=>os.forEach(o=>{o.fill=terbaik(latarDi(o));}),"Warna teks disesuaikan");
 const W=S.page.width,Hh=S.page.height,luar=A.filter(o=>!o.hidden&&(o.x+(o.w||0)<=0||o.y+(o.h||0)<=0||o.x>=W||o.y>=Hh));
 add("luar","Objek sepenuhnya di luar halaman",luar,6,os=>os.forEach(o=>{o.x=Math.round((W-(o.w||0))/2);o.y=Math.round((Hh-(o.h||0))/2);}),"Dipindahkan ke tengah halaman");
 const sebagian=A.filter(o=>!o.hidden&&!luar.includes(o)&&(o.w||0)>0&&(o.x<0||o.y<0||o.x+o.w>W||o.y+(o.h||0)>Hh)&&o.type!=="line");
 add("sebagian","Objek menjorok keluar halaman",sebagian,2,os=>os.forEach(o=>{o.x=Math.round(Math.max(0,Math.min(o.x,W-o.w)));o.y=Math.round(Math.max(0,Math.min(o.y,Hh-(o.h||0))));}),"Ditarik masuk (objek lebih besar dari halaman tetap di tepi)");
 const seen=new Map(),dup=[];A.forEach(o=>{if(o.hidden)return;const k=[o.type,o.x,o.y,o.w,o.h,o.fill,o.stroke,o.text,o.d,o.rotation||0].join("|");if(seen.has(k))dup.push(o);else seen.set(k,o);});
 add("dup","Duplikat persis (tumpuk di tempat sama)",dup,5,os=>{S.objects=S.objects.filter(o=>!os.includes(o));},"Salinan ganda dihapus");
 add("tak","Hampir tak terlihat (opasitas ≤ 3% atau ukuran < 2 px)",A.filter(o=>!o.hidden&&o.type!=="line"&&((o.opacity!==undefined&&o.opacity<=3)||((o.w||0)<2&&(o.h||0)<2&&(o.w!==undefined)))),5,os=>{S.objects=S.objects.filter(o=>!os.includes(o));},"Dihapus");
 add("sembunyi","Objek tersembunyi",A.filter(o=>o.hidden&&!o.isoWas),1,os=>os.forEach(o=>{delete o.hidden;}),"Ditampilkan");
 return L;}
let hasil=[];
const skor=L=>Math.max(0,100-L.reduce((t,x)=>t+Math.min(30,x.bobot*x.objs.length),0));
function jalankan(quiet){hasil=periksa();draw();if(!quiet)T(hasil.length?hasil.length+" jenis masalah ditemukan (skor "+skor(hasil)+"/100)":"Tidak ada masalah, skor 100/100");}
function perbaiki(k){const x=hasil.find(h=>h.k===k);if(!x)return;Hi.snapshot();x.fix(x.objs.filter(o=>S.objects.includes(o)));S.selected=null;S.selectedIds=[];C.render();const t=x.aksi,n=x.objs.length;jalankan(true);T(t+" ("+n+" objek)");}
function perbaikiSemua(){jalankan(true);if(!hasil.length)return T("Tidak ada yang perlu diperbaiki");Hi.snapshot();let n=0;
 ["kosong","dup","tak","luar","sebagian","kecil","kontras"].forEach(k=>{const x=periksa().find(h=>h.k===k);if(x){x.fix(x.objs.filter(o=>S.objects.includes(o)));n+=x.objs.length;}});
 S.selected=null;S.selectedIds=[];C.render();jalankan(true);T(n+" objek diperbaiki (objek tersembunyi dibiarkan). Skor "+skor(hasil)+"/100");}
function pilih(k){const x=hasil.find(h=>h.k===k);if(!x)return;const a=x.objs.filter(o=>S.objects.includes(o));if(!a.length)return;pick(a);T(a.length+" objek dipilih");}
function draw(){const box=$("#p90list");if(!box)return;const s=skor(hasil),sk=$("#p90skor");
 if(sk){sk.textContent=s;sk.className="p90skor "+(s>=90?"ok":s>=60?"mid":"bad");}
 box.innerHTML=hasil.length?hasil.map(x=>`<div class="p90row"><div class="p90nm"><b>${x.judul}</b><small>${x.objs.length} objek</small></div><button data-p90="sel" data-k="${x.k}" title="Pilih objek">${ic("select")}</button><button data-p90="fix" data-k="${x.k}" title="${x.k==="sembunyi"?"Tampilkan":"Perbaiki"}">${ic("sparkles")}</button></div>`).join(""):'<div class="kosong">✔ Tidak ada masalah ditemukan.</div>';}
document.addEventListener("click",e=>{const x=e.target.closest&&e.target.closest("[data-p90]");if(x){x.dataset.p90==="sel"?pilih(x.dataset.k):perbaiki(x.dataset.k);return;}
 if(e.target.closest&&e.target.closest(".p69 [data-t=periksa90]"))setTimeout(()=>jalankan(true),0);});
const H={pr:()=>jalankan(),pa:perbaikiSemua};
addTab("periksa90","Periksa",`<div class="p90top"><div id="p90skor" class="p90skor ok">–</div><div><b>Skor desain</b><div class="muted" style="font-size:11px">Pemeriksaan lokal: teks, kontras, posisi, duplikat</div></div></div>
 <div class="p69btns">${b("pr","Periksa lagi","search")}${b("pa","Perbaiki semua","sparkles")}</div>
 <div id="p90list" class="p90list" style="margin-top:10px"></div>
 <p class="muted" style="margin:0">Ikon pilih menyorot objek bermasalah; ikon kilau memperbaikinya (bisa di-undo). Kontras memakai rasio WCAG terhadap objek berwarna di belakang teks, atau latar halaman.</p>`,H);
const ot=P.openTab;P.openTab=function(){const r=ot.apply(this,arguments);setTimeout(()=>{if($("#p90list"))jalankan(true);},0);return r;};
const buka=()=>{P.openTab("periksa90");};
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q90="cek" title="Periksa desain">${ic("search")}</button><button data-q90="fix" title="Perbaiki semua masalah">${ic("sparkles")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q90]");if(!x)return;if(x.dataset.q90==="cek"){buka();jalankan();}else perbaikiSemua();});}
MENUS.per1=()=>[{h:"Periksa",items:[it("Periksa desain sekarang",()=>{buka();jalankan();},"search"),it("Perbaiki semua masalah",perbaikiSemua,"sparkles"),it("Buka panel Periksa",buka,"panel")]}];
MENUS.per2=()=>{jalankan(true);return[{h:"Masalah ("+hasil.length+")",items:hasil.length?hasil.flatMap(x=>[it("Pilih: "+x.judul+" ("+x.objs.length+")",()=>pilih(x.k),"select"),it("Perbaiki: "+x.judul,()=>perbaiki(x.k),"sparkles")]):[it("Tidak ada masalah ✔",()=>{},"info")]}];};
BT.push(["per1","search","Periksa desain"],["per2","info","Daftar masalah"]);
const PER=["per1","per2"],ai=M.HUBS.findIndex(h=>h[0]==="varian");
M.HUBS.splice(ai<0?M.HUBS.length:ai+1,0,["periksa","search","Periksa",PER]);
MENUS.hub_periksa=()=>[{h:"Periksa",items:PER.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($('[data-menu="hub_periksa"]'),k),0));})}];
})();
