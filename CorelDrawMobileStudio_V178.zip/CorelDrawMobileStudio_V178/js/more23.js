/* V36: edit simpul (node editing) objek path + ubah bentuk jadi kurva */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,sels,T,it}=M,NS="http://www.w3.org/2000/svg";
const num=v=>+(+v).toFixed(2);
/* ---- parser path -> segmen absolut M/L/C/Z ---- */
function parse(d){const segs=[],re=/([MmLlHhVvCcSsQqTtZzAa])([^MmLlHhVvCcSsQqTtZzAa]*)/g;let m,cx=0,cy=0,sx=0,sy=0,lc=null,lq=null,prev="";
 while((m=re.exec(d||""))){const c=m[1],rel=c===c.toLowerCase(),u=c.toUpperCase(),n=(m[2].match(/-?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?/gi)||[]).map(Number);
  if(u==="A")return null;
  if(u==="Z"){segs.push({c:"Z",p:[]});cx=sx;cy=sy;lc=lq=null;prev="Z";continue;}
  const need={M:2,L:2,H:1,V:1,C:6,S:4,Q:4,T:2}[u];if(!need)return null;
  for(let i=0;i+need<=n.length;i+=need){const a=n.slice(i,i+need),X=v=>rel?cx+v:v,Y=v=>rel?cy+v:v;
   if(u==="M"){const k=i===0?"M":"L";cx=X(a[0]);cy=Y(a[1]);if(k==="M"){sx=cx;sy=cy;}segs.push({c:k,p:[[cx,cy]]});lc=lq=null;}
   else if(u==="L"){cx=X(a[0]);cy=Y(a[1]);segs.push({c:"L",p:[[cx,cy]]});lc=lq=null;}
   else if(u==="H"){cx=rel?cx+a[0]:a[0];segs.push({c:"L",p:[[cx,cy]]});lc=lq=null;}
   else if(u==="V"){cy=rel?cy+a[0]:a[0];segs.push({c:"L",p:[[cx,cy]]});lc=lq=null;}
   else if(u==="C"){const p1=[X(a[0]),Y(a[1])],p2=[X(a[2]),Y(a[3])],p=[X(a[4]),Y(a[5])];segs.push({c:"C",p:[p1,p2,p]});lc=p2;lq=null;cx=p[0];cy=p[1];}
   else if(u==="S"){const p1=lc?[2*cx-lc[0],2*cy-lc[1]]:[cx,cy],p2=[X(a[0]),Y(a[1])],p=[X(a[2]),Y(a[3])];segs.push({c:"C",p:[p1,p2,p]});lc=p2;lq=null;cx=p[0];cy=p[1];}
   else{let q;if(u==="Q")q=[X(a[0]),Y(a[1])];else q=lq?[2*cx-lq[0],2*cy-lq[1]]:[cx,cy];const p=u==="Q"?[X(a[2]),Y(a[3])]:[X(a[0]),Y(a[1])];
    segs.push({c:"C",p:[[cx+2/3*(q[0]-cx),cy+2/3*(q[1]-cy)],[p[0]+2/3*(q[0]-p[0]),p[1]+2/3*(q[1]-p[1])],p]});lq=q;lc=null;cx=p[0];cy=p[1];}}
  prev=u;}
 return segs.length&&segs[0].c==="M"?segs:null;}
const build=s=>s.map(g=>g.c==="Z"?"Z":g.c+g.p.map(q=>num(q[0])+" "+num(q[1])).join(" ")).join(" ");
const anchor=(segs,i)=>{const s=segs[i];return s.c==="C"?s.p[2]:s.p[0];};

/* ---- pemetaan koordinat lokal <-> halaman ---- */
const G=o=>({sx:o.w/(o.vw||o.w||1),sy:o.h/(o.vh||o.h||1),px:(o.pt||[0,0])[0],py:(o.pt||[0,0])[1]});
const toPage=(o,x,y)=>{const g=G(o);return[o.x+(x-g.px)*g.sx,o.y+(y-g.py)*g.sy];};
const toLocal=(o,X,Y)=>{const g=G(o);return[(X-o.x)/g.sx+g.px,(Y-o.y)/g.sy+g.py];};
/* path dengan lebar/tinggi 0 (mis. garis lurus mendatar) tak bisa dipetakan balik: beri ukuran minimal 1 px dengan skala 1:1 */
const norm=o=>{if(!(o.h>=1)){o.h=1;o.vh=1;}if(!(o.w>=1)){o.w=1;o.vw=1;}};
const cur=()=>{const ne=S.nodeEdit;return ne?{ne,o:S.objects.find(x=>x.id===ne.id)}:{};};

/* ---- overlay simpul ---- */
const dov=C.drawOverlay;
C.drawOverlay=function(){dov.call(this);const ne=S.nodeEdit;if(!ne)return;const o=S.objects.find(x=>x.id===ne.id);if(!o||S.selected!==o.id){S.nodeEdit=null;return;}
 const ov=document.getElementById("overlayLayer");if(!ov)return;const k=Math.max(1,S.page.width/(this.svg.getBoundingClientRect().width||S.page.width)),r=7*k,P=(x,y)=>toPage(o,x,y).map(v=>+v.toFixed(1));let h="",prevA=null;
 ne.segs.forEach((s,i)=>{if(s.c==="C"){const a=P(...prevA),c1=P(...s.p[0]),c2=P(...s.p[1]),b=P(...s.p[2]);h+=`<line x1="${a[0]}" y1="${a[1]}" x2="${c1[0]}" y2="${c1[1]}" stroke="#8a93aa" stroke-width="${k}"/><line x1="${b[0]}" y1="${b[1]}" x2="${c2[0]}" y2="${c2[1]}" stroke="#8a93aa" stroke-width="${k}"/><rect data-ctl="${i}:0" x="${c1[0]-r*.7}" y="${c1[1]-r*.7}" width="${r*1.4}" height="${r*1.4}" fill="#ffc857" stroke="#20243a" stroke-width="${k}"/><rect data-ctl="${i}:1" x="${c2[0]-r*.7}" y="${c2[1]-r*.7}" width="${r*1.4}" height="${r*1.4}" fill="#ffc857" stroke="#20243a" stroke-width="${k}"/>`;}
  if(s.c!=="Z"){prevA=anchor(ne.segs,i);const a=P(...prevA);h+=`<circle data-node="${i}" cx="${a[0]}" cy="${a[1]}" r="${r}" fill="${ne.sel===i?"#7b6cff":"#ffffff"}" stroke="#7b6cff" stroke-width="${2*k}"/>`;}});
 ov.insertAdjacentHTML("beforeend",`<g id="cdNodes">${h}</g>`);};

/* ---- seret simpul / kontrol ---- */
const pd=C.pointerDown,pm=C.pointerMove;
C.pointerDown=function(e){const t=e.target,n=t.closest&&t.closest("[data-node]"),c=t.closest&&t.closest("[data-ctl]"),{ne,o}=cur();
 if(ne&&o&&(n||c)){Hi.snapshot();if(n){ne.sel=+n.dataset.node;S.drag={mode:"node",kind:"n",i:ne.sel,last:this.point(e)};}else{const[i,j]=c.dataset.ctl.split(":").map(Number);S.drag={mode:"node",kind:"c",i,j};}this.svg.setPointerCapture&&this.svg.setPointerCapture(e.pointerId);this.render();return;}
 pd.call(this,e);};
C.pointerMove=function(e){const d=S.drag;if(d&&d.mode==="node"){const{ne,o}=cur();if(!ne||!o)return;const p=this.point(e),q=toLocal(o,p.x,p.y),s=ne.segs[d.i];
  if(d.kind==="c")s.p[d.j]=q;else{const old=anchor(ne.segs,d.i),dx=q[0]-old[0],dy=q[1]-old[1],mv=pt=>{pt[0]+=dx;pt[1]+=dy;};if(s.c==="C"){mv(s.p[1]);s.p[2]=q;}else s.p[0]=q;const nx=ne.segs[d.i+1];if(nx&&nx.c==="C")mv(nx.p[0]);}
  o.d=build(ne.segs);d.dirty=true;this.render();return;}
 pm.call(this,e);};
function tidy(){const{ne,o}=cur();if(!ne||!o)return;const pts=[];let pv=null;
 /* kotak objek mengikuti kurva yang terlihat (bukan titik kontrol), supaya bingkai seleksi pas */
 ne.segs.forEach(s=>{if(s.c==="C"&&pv){for(let k=1;k<=24;k++){const t=k/24,u=1-t,a=u*u*u,b=3*u*u*t,c=3*u*t*t,d=t*t*t;pts.push([a*pv[0]+b*s.p[0][0]+c*s.p[1][0]+d*s.p[2][0],a*pv[1]+b*s.p[0][1]+c*s.p[1][1]+d*s.p[2][1]]);}pv=s.p[2];}
  else if(s.c!=="Z"){const q=s.p[0];pts.push(q);pv=q;}});if(!pts.length)return;
 const x0=Math.min(...pts.map(q=>q[0])),x1=Math.max(...pts.map(q=>q[0])),y0=Math.min(...pts.map(q=>q[1])),y1=Math.max(...pts.map(q=>q[1])),a=toPage(o,x0,y0),b=toPage(o,x1,y1);
 /* ukuran minimal 1 px dengan skala 1:1, agar garis lurus (tinggi/lebar 0) tetap bisa dilengkungkan */
 o.pt=[x0,y0];o.vw=Math.max(x1-x0,1);o.vh=Math.max(y1-y0,1);o.x=num(a[0]);o.y=num(a[1]);o.w=Math.max(1,num(b[0]-a[0]));o.h=Math.max(1,num(b[1]-a[1]));}
window.addEventListener("pointerup",()=>{const d=S.drag;if(d&&d.mode==="node"&&d.dirty){tidy();setTimeout(()=>C.render(),0);}});

/* ---- aksi edit ---- */
function start(){const o=sels()[0];if(!o||o.type!=="path")return T("Pilih objek path dulu (atau ubah bentuk jadi kurva)");if(o.rotation||o.flipH||o.flipV)return T("Path harus tanpa rotasi atau balik");
 const segs=parse(o.d);if(!segs)return T("Path memakai busur (arc) dan belum didukung");norm(o);S.nodeEdit={id:o.id,segs,sel:null};S.selected=o.id;S.selectedIds=[o.id];C.render();T("Seret simpul putih. Ketuk simpul untuk memilihnya.");}
const commit=o=>{o.d=build(S.nodeEdit.segs);C.render();};
function addNode(){const{ne,o}=cur();if(!ne||ne.sel==null)return T("Ketuk satu simpul dulu");const i=ne.sel+1,s=ne.segs[i];if(!s||s.c==="M"||s.c==="Z")return T("Tidak ada segmen setelah simpul ini");Hi.snapshot();const a=anchor(ne.segs,ne.sel),L=(p,q,t)=>[p[0]+(q[0]-p[0])*t,p[1]+(q[1]-p[1])*t];
 if(s.c==="L"){const m=L(a,s.p[0],.5);ne.segs.splice(i,1,{c:"L",p:[m]},{c:"L",p:[s.p[0]]});}
 else{const[c1,c2,b]=s.p,p01=L(a,c1,.5),p12=L(c1,c2,.5),p23=L(c2,b,.5),p012=L(p01,p12,.5),p123=L(p12,p23,.5),m=L(p012,p123,.5);ne.segs.splice(i,1,{c:"C",p:[p01,p012,m]},{c:"C",p:[p123,p23,b]});}
 ne.sel=i;commit(o);}
function delNode(){const{ne,o}=cur();if(!ne||ne.sel==null)return T("Ketuk satu simpul dulu");const i=ne.sel,s=ne.segs[i];if(ne.segs.filter(x=>x.c!=="Z"&&x.c!=="M").length<2&&s.c!=="M")return T("Path butuh minimal 2 segmen");Hi.snapshot();
 if(s.c==="M"){const nx=ne.segs[i+1];if(!nx||nx.c==="Z")return T("Tidak bisa menghapus");ne.segs.splice(i,2,{c:"M",p:[anchor(ne.segs,i+1)]});}else ne.segs.splice(i,1);ne.sel=null;commit(o);}
function conv(toCurve){const{ne,o}=cur();if(!ne||ne.sel==null)return T("Ketuk satu simpul dulu");const i=ne.sel+1,s=ne.segs[i];if(!s||s.c==="M"||s.c==="Z")return T("Tidak ada segmen setelah simpul ini");Hi.snapshot();const a=anchor(ne.segs,ne.sel);
 if(toCurve&&s.c==="L"){const b=s.p[0];ne.segs[i]={c:"C",p:[[a[0]+(b[0]-a[0])/3,a[1]+(b[1]-a[1])/3],[a[0]+2*(b[0]-a[0])/3,a[1]+2*(b[1]-a[1])/3],b]};}else if(!toCurve&&s.c==="C")ne.segs[i]={c:"L",p:[s.p[2]]};commit(o);}
function toggleClose(){const{ne,o}=cur();if(!ne)return T("Mulai edit simpul dulu");Hi.snapshot();const l=ne.segs[ne.segs.length-1];if(l.c==="Z")ne.segs.pop();else ne.segs.push({c:"Z",p:[]});commit(o);}

/* ---- ubah bentuk dasar jadi kurva ---- */
function toCurves(){const a=sels().filter(o=>["rect","ellipse","star","polygon","line"].includes(o.type));if(!a.length)return T("Pilih persegi, elips, bintang, poligon, atau garis");Hi.snapshot();
 a.forEach(o=>{const w=o.w,h=Math.max(o.h||0,.01),f=n=>num(n);let d;
  if(o.type==="rect")d=`M0 0L${f(w)} 0L${f(w)} ${f(h)}L0 ${f(h)}Z`;
  else if(o.type==="ellipse"){const kx=w/2*.5523,ky=h/2*.5523,cx=w/2,cy=h/2;d=`M${f(cx)} 0C${f(cx+kx)} 0 ${f(w)} ${f(cy-ky)} ${f(w)} ${f(cy)}C${f(w)} ${f(cy+ky)} ${f(cx+kx)} ${f(h)} ${f(cx)} ${f(h)}C${f(cx-kx)} ${f(h)} 0 ${f(cy+ky)} 0 ${f(cy)}C0 ${f(cy-ky)} ${f(cx-kx)} 0 ${f(cx)} 0Z`;}
  else if(o.type==="star")d="M"+C.starPoints(w,h).trim().split(/\s+/).map(p=>p.replace(",", " ")).join("L")+"Z";
  else if(o.type==="polygon")d=`M${f(w*.5)} 0L${f(w)} ${f(h*.35)}L${f(w*.82)} ${f(h)}L${f(w*.18)} ${f(h)}L0 ${f(h*.35)}Z`;
  else d=`M0 0L${f(w)} ${f(o.h||0)}`;
  o.type="path";o.d=d;o.vw=Math.max(w,.01);o.vh=Math.max(h,.01);delete o.pt;delete o.rx;if(!o.fill||o.fill==="")o.fill="none";});
 C.render();T(a.length+" objek diubah jadi kurva. Sekarang bisa diedit simpulnya.");}
MENUS.node=()=>[{h:"Edit simpul (path)",items:[it("Mulai edit simpul objek terpilih",start,"pen"),it("Selesai edit simpul",()=>{S.nodeEdit=null;C.render();},"eye")]},
 {h:"Simpul terpilih (ketuk simpul putih)",items:[it("Tambah simpul setelahnya",addNode,"plus"),it("Hapus simpul",delNode,"trash"),it("Segmen berikutnya jadi lengkung",()=>conv(true),"redo"),it("Segmen berikutnya jadi lurus",()=>conv(false),"line"),it("Tutup / buka path",toggleClose,"lock")]},
 {h:"Konversi",items:[it("Ubah bentuk jadi kurva",toCurves,"polygon")]}];
CDMS.Nodes={parse,build,anchor,toPage,toLocal,tidy,toCurves,norm,G,del:delNode};
BT.push(["node","nodes","Simpul"]);M.HUBS.find(h=>h[0]==="atur")[3].push("node");
})();
