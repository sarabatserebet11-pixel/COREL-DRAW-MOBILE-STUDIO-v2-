/* V23: bar aksi cepat di dekat objek + menu Melengkung (teks), Segel, Latar */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height,rnd=(a,b)=>a+Math.random()*(b-a);
function ask(title,html,cb){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">Buat</button></div>`);$("#aOk").onclick=cb;}
const txt=(text,x,y,size,fill,x2)=>({type:"text",name:"Teks",text,x:Math.round(x),y:Math.round(y),w:50,h:30,fontSize:Math.round(size),fill,...x2});
function grp(arr,post){Hi.snapshot();const g=uid();arr.forEach(o=>Object.assign(o,{id:uid(),groupId:g,opacity:o.opacity??100,rotation:o.rotation||0,stroke:o.stroke||"none",strokeWidth:o.strokeWidth||0}));S.objects.push(...arr);pick(arr);if(post){post();C.render();}}
const mid=(t,r)=>{t.x=Math.round(r.x+(r.w-t.w)/2);t.y=Math.round(r.y+(r.h-t.h)/2);};

/* ---- teks melengkung: tiap huruf jadi objek ---- */
function arcText(kind){const t=($("#atT").value||"").trim();if(!t)return T("Isi teks dulu");const col=$("#atC").value,fs=Math.round(W()*(Math.max(2,Math.min(20,+$("#atS").value||7)))/100);N.closeModal();
 const arr=[...t].map(ch=>({type:"text",name:"Huruf "+ch,text:ch===" "?"\u00A0":ch,x:0,y:0,w:fs*.6,h:fs*1.2,fontSize:fs,fill:col,bold:true}));
 grp(arr,()=>{const ws=arr.map(o=>o.w||fs*.6),tot=ws.reduce((a,b)=>a+b,0),cx=W()/2,cy=H()/2,R=W()*.3,Rc=Math.max(fs,(tot+fs*.9)/(2*Math.PI));let cum=0;
  arr.forEach((o,i)=>{const s=cum+ws[i]/2;cum+=ws[i];let px,py,rot;
   if(kind==="up"){const th=-Math.PI/2+(s-tot/2)/R;px=cx+R*Math.cos(th);py=cy+R*Math.sin(th);rot=th*180/Math.PI+90;}
   else if(kind==="down"){const th=Math.PI/2-(s-tot/2)/R;px=cx+R*Math.cos(th);py=cy+R*Math.sin(th);rot=th*180/Math.PI-90;}
   else if(kind==="circle"){const th=-Math.PI/2+s/Rc;px=cx+Rc*Math.cos(th);py=cy+Rc*Math.sin(th);rot=th*180/Math.PI+90;}
   else{const A=fs*.6,lam=W()*.5,k=2*Math.PI*s/lam;px=cx-tot/2+s;py=cy+A*Math.sin(k);rot=Math.atan(A*2*Math.PI/lam*Math.cos(k))*180/Math.PI;}
   o.x=Math.round(px-o.w/2);o.y=Math.round(py-o.h/2);o.rotation=Math.round(rot);});});}
const askArc=k=>()=>ask("Teks melengkung",'<label>Teks<input id="atT" value="TEKS MELENGKUNG"></label><div class="st-grid"><label>Ukuran (% lebar)<input id="atS" type="number" min="2" max="20" value="7"></label><label>Warna<input id="atC" type="color" value="#20243a"></label></div>',()=>arcText(k));
MENUS.arc=()=>[{h:"Teks mengikuti lengkung (tiap huruf = 1 objek)",items:[it("Busur atas",askArc("up"),"text"),it("Busur bawah",askArc("down"),"text"),it("Lingkaran penuh",askArc("circle"),"text"),it("Gelombang",askArc("wave"),"text")]}];

/* ---- segel & bingkai ---- */
function stamp(label,col){const w=Math.round(W()*.42),h=Math.round(w*.32),x=Math.round((W()-w)/2),y=Math.round((H()-h)/2),r={type:"rect",name:"Bingkai stempel",x,y,w,h,rx:14,fill:"none",stroke:col,strokeWidth:8,rotation:-12,opacity:88},r2={type:"rect",name:"Garis dalam",x:x+12,y:y+12,w:w-24,h:h-24,rx:8,fill:"none",stroke:col,strokeWidth:3,rotation:-12,opacity:88},t=txt(label,0,0,h*.42,col,{bold:true,fontFamily:"Impact, 'Arial Black', sans-serif",rotation:-12,opacity:88});grp([r,r2,t],()=>mid(t,r));}
function wmTile(){const t=($("#wtT").value||"").trim();if(!t)return T("Isi teks dulu");N.closeModal();const cols=3,rows=4,arr=[],fs=W()*.05;
 for(let i=0;i<rows;i++)for(let j=0;j<cols;j++)arr.push(txt(t,0,0,fs,"#808080",{name:"Watermark",bold:true,opacity:16,rotation:-30}));
 grp(arr,()=>arr.forEach((o,k)=>{const i=Math.floor(k/cols),j=k%cols,px=W()*((j+.5+(i%2?.5:0))/cols),py=H()*((i+.5)/rows);o.x=Math.round(px-o.w/2);o.y=Math.round(py-o.h/2);}));}
const frame=kind=>{Hi.snapshot();const m=Math.round(W()*.04),base={id:uid(),type:"rect",x:m,y:m,w:W()-2*m,h:H()-2*m,fill:"none",stroke:"#20243a",strokeWidth:6,opacity:100,rotation:0},arr=[];
 if(kind==="one")arr.push({...base,name:"Bingkai"});
 if(kind==="double"){arr.push({...base,name:"Bingkai luar"});const i=m*.6;arr.push({...base,id:uid(),name:"Bingkai dalam",x:m+i,y:m+i,w:base.w-2*i,h:base.h-2*i,strokeWidth:3});}
 if(kind==="round")arr.push({...base,name:"Bingkai bulat",rx:Math.round(W()*.05),dash:"6 4"});
 if(kind==="corner"){const l=Math.round(W()*.08),w=base.w,h=base.h;arr.push({...base,type:"path",name:"Siku sudut",vw:w,vh:h,d:`M0 ${l}V0H${l}M${w-l} 0H${w}V${l}M${w} ${h-l}V${h}H${w-l}M${l} ${h}H0V${h-l}`,strokeWidth:8});}
 S.objects.push(...arr);pick(arr);};
MENUS.seal=()=>[
 {h:"Stempel",items:[["LUNAS","#d63a3a"],["DISETUJUI","#1f9d55"],["DRAFT","#7b6cff"],["ASLI","#0b7285"],["URGENT","#e8590c"]].map(x=>it(x[0],()=>stamp(x[0],x[1]),"star"))},
 {h:"Bingkai halaman",items:[tc("Tunggal",()=>frame("one")),tc("Ganda",()=>frame("double")),tc("Bulat putus",()=>frame("round")),tc("Siku sudut",()=>frame("corner"))]},
 {h:"Lainnya",items:[it("Watermark pola diagonal…",()=>ask("Watermark pola",'<label>Teks watermark<input id="wtT" value="CONTOH"></label>',wmTile),"text"),it("Garis tanda tangan",()=>{const w=Math.round(W()*.3),x=Math.round((W()-w)/2),y=Math.round(H()*.7),t=txt("Tanda tangan",0,0,W()*.025,"#68728a",{});grp([{type:"line",name:"Garis",x,y,w,h:0,stroke:"#20243a",strokeWidth:3,fill:"none"},t],()=>{t.x=Math.round(x+(w-t.w)/2);t.y=y+12;});},"line")]}];

/* ---- latar aurora & bokeh ---- */
const PALS={"Ungu-biru":["#6d5dfc","#00d6c9","#4f83ff","#ff7ac8"],"Sunset":["#ff9a3c","#ff4f6d","#7b2ff7","#ffc857"],"Mint":["#3ddc84","#00d6c9","#a8ff78","#4f83ff"],"Neon":["#ff39bd","#05d9e8","#7b6cff","#ffe44d"]};
function genBg(name,bokeh){const w=W(),h=H(),cols=PALS[name],g=uid(),out=[];Hi.snapshot();S.page.background="#0b0d16";
 if(bokeh)for(let i=0;i<18;i++){const s=rnd(w*.04,w*.14);out.push({type:"ellipse",x:rnd(0,w-s),y:rnd(0,h-s),w:s,h:s,fill:cols[i%4],opacity:Math.round(rnd(25,55)),imgFx:"blur(8px)"});}
 else cols.forEach(c=>{const s=Math.min(w,h)*rnd(.5,.8);out.push({type:"ellipse",x:rnd(-.1*w,.7*w),y:rnd(-.1*h,.7*h),w:s,h:s*rnd(.7,1),fill:c,opacity:62,imgFx:"blur(90px)"});});
 out.forEach(o=>Object.assign(o,{id:uid(),groupId:g,deco:true,name:(bokeh?"Bokeh ":"Aurora ")+name,x:Math.round(o.x),y:Math.round(o.y),w:Math.round(o.w),h:Math.round(o.h),stroke:"none",strokeWidth:0,rotation:0}));
 S.objects.unshift(...out);S.selected=null;S.selectedIds=[];C.render();T("Latar "+name+" dibuat (hapus lewat Hiasan > Hapus semua hiasan)");}
MENUS.bg=()=>[{h:"Latar aurora (latar jadi gelap)",items:Object.keys(PALS).map(k=>tc(k,()=>genBg(k,false)))},{h:"Latar bokeh",items:Object.keys(PALS).map(k=>tc(k,()=>genBg(k,true)))}];

/* ---- bar aksi cepat ---- */
const qb=document.createElement("div");qb.className="qbar";qb.hidden=true;document.body.appendChild(qb);
const QA=[["duplicate","copy","Duplikat"],["front","front","Ke depan"],["back","back","Ke belakang"],["flipH","flipH","Balik"],["lock","lock","Kunci"],["delete","trash","Hapus"]];
qb.innerHTML=QA.map(a=>`<button data-qa="${a[0]}" title="${a[2]}">${CDMS.Icons.svg(a[1])}</button>`).join("");
qb.addEventListener("pointerdown",e=>e.stopPropagation());
qb.addEventListener("click",e=>{const b=e.target.closest("[data-qa]");if(!b)return;const a=b.dataset.qa;if(a==="lock")edit(o=>{o.locked=true;},"Objek dikunci (buka lewat panel layer)");else N.action(a);});
function placeQ(){const ids=S.selectedIds&&S.selectedIds.length?S.selectedIds:(S.selected?[S.selected]:[]),ed=$("#editor");
 if(!ids.length||S.nodeEdit||S.tool!=="select"||!ed||ed.classList.contains("hidden")||(S.drag&&(S.drag.moved||S.drag.mode==="draw"))||S.drawPath||$(".modal-backdrop:not(.hidden)")){qb.hidden=true;return;}
 const g=C.group&&C.group.querySelector(`[data-id="${ids[ids.length-1]}"]`),vp=$("#canvasViewport");if(!g||!vp){qb.hidden=true;return;}
 const r=g.getBoundingClientRect(),v=vp.getBoundingClientRect();qb.hidden=false;const bw=qb.offsetWidth||250,limit=Math.min(v.bottom,innerHeight-96);
 let x=r.left+r.width/2-bw/2,y=r.bottom+10;x=Math.max(v.left+4,Math.min(v.right-bw-4,x));if(y>limit-48)y=Math.max(v.top+4,r.top-54);qb.style.left=Math.round(x)+"px";qb.style.top=Math.round(y)+"px";}
const rr=C.render;C.render=function(){rr.call(this);placeQ();};
window.addEventListener("pointerup",()=>setTimeout(placeQ,0));window.addEventListener("resize",placeQ);document.addEventListener("click",e=>{if(e.target.closest("[data-tool]"))setTimeout(placeQ,0);});
const vp0=$("#canvasViewport");if(vp0)vp0.addEventListener("scroll",placeQ);

BT.push(["arc","arctext","Melengkung"],["seal","seal","Segel"],["bg","background","Latar"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("teks").push("arc");hub("buat").push("seal");hub("kanvas").push("bg");
})();
