/* V114: Asisten AI (opsional). Dua fitur:
   1) Prompt -> Desain: model bahasa menyusun tata letak (JSON) yang diubah jadi objek biasa di kanvas, bisa diedit/undo.
   2) Variasi Teks: tulis ulang teks objek terpilih (3 pilihan).
   Penyedia dipilih pengguna (OpenAI-compatible atau Anthropic). Kunci API dan alamat disimpan HANYA di localStorage
   browser ini dan dikirim langsung ke penyedia; tidak ada kunci yang tertanam di kode. Keluaran model divalidasi:
   hanya jenis objek, warna, angka, dan font yang diizinkan yang dipakai, sehingga tidak bisa menyisipkan kode. */
(()=>{
const S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,E=CDMS.escape,$=(s,r=document)=>r.querySelector(s);
const K="cdms-ai";
const DEF={openai:{base:"https://api.openai.com/v1",model:"gpt-4o-mini"},anthropic:{base:"https://api.anthropic.com/v1",model:"claude-sonnet-4-5"}};
const load=()=>{let c={};try{c=JSON.parse(localStorage.getItem(K)||"{}")||{};}catch(e){}const p=c.provider==="anthropic"?"anthropic":"openai";return{provider:p,base:c.base||DEF[p].base,model:c.model||DEF[p].model,key:c.key||""};};
const save=c=>{try{localStorage.setItem(K,JSON.stringify(c));return true;}catch(e){return false;}};

/* ---------- panggilan ke penyedia ---------- */
function cekBase(u){let x;try{x=new URL(u);}catch(e){throw new Error("Alamat API tidak valid.");}
 if(x.protocol!=="https:"&&!(x.protocol==="http:"&&/^(localhost|127\.0\.0\.1)$/.test(x.hostname)))throw new Error("Alamat API harus memakai https.");
 return u.replace(/\/+$/,"");}
async function ask(system,user,maxTok){const c=load();if(!c.key)throw new Error("Kunci API belum diisi. Buka tab Pengaturan.");
 const base=cekBase(c.base),ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),60000);
 try{let url,headers={"Content-Type":"application/json"},body;
  if(c.provider==="anthropic"){url=base+"/messages";headers["x-api-key"]=c.key;headers["anthropic-version"]="2023-06-01";headers["anthropic-dangerous-direct-browser-access"]="true";
   body={model:c.model,max_tokens:maxTok||4000,system,messages:[{role:"user",content:user}]};}
  else{url=base+"/chat/completions";headers.Authorization="Bearer "+c.key;
   body={model:c.model,temperature:.7,max_tokens:maxTok||4000,messages:[{role:"system",content:system},{role:"user",content:user}]};}
  const r=await fetch(url,{method:"POST",headers,body:JSON.stringify(body),signal:ctl.signal});
  const raw=await r.text();let j=null;try{j=JSON.parse(raw);}catch(e){}
  if(!r.ok){const m=j&&(j.error&&(j.error.message||j.error)||j.message)||raw.slice(0,160);
   const h=r.status===401||r.status===403?"Kunci API ditolak (periksa kunci dan penyedia).":r.status===404?"Alamat API atau nama model tidak ditemukan.":r.status===429?"Kuota/batas permintaan tercapai. Coba lagi nanti.":"Server mengembalikan galat "+r.status+".";
   throw new Error(h+(m?" ("+String(m).slice(0,140)+")":""));}
  const out=c.provider==="anthropic"?(j&&j.content||[]).map(b=>b.text||"").join(""):(j&&j.choices&&j.choices[0]&&j.choices[0].message&&j.choices[0].message.content)||"";
  if(!out)throw new Error("Jawaban model kosong.");return out;
 }catch(e){if(e.name==="AbortError")throw new Error("Waktu habis (60 detik).");
  if(e instanceof TypeError)throw new Error("Tidak bisa terhubung. Periksa alamat API dan internet; sebagian penyedia memblokir pemanggilan langsung dari browser (CORS).");throw e;}
 finally{clearTimeout(to);}}

/* ---------- parsing & validasi keluaran ---------- */
function cut(t,a,b){t=String(t).replace(/```[a-z]*/gi,"");const i=t.indexOf(a),j=t.lastIndexOf(b);if(i<0||j<=i)throw new Error("Jawaban model bukan JSON yang valid. Coba lagi.");return JSON.parse(t.slice(i,j+1));}
const HEX=/^#[0-9a-f]{3,8}$/i,FONTS=["Arial","Georgia","Times New Roman","Courier New","Impact"],TYPES=["rect","ellipse","star","polygon","line","text"];
const NAMA={rect:"Persegi",ellipse:"Elips",star:"Bintang",polygon:"Poligon",line:"Garis",text:"Teks"};
const num=(v,lo,hi,d)=>{v=+v;return Number.isFinite(v)?Math.min(hi,Math.max(lo,v)):d;};
const col=(v,d)=>{if(typeof v!=="string")return d;v=v.trim();return HEX.test(v)||v==="none"?v:d;};
function bersih(spec,W,H){if(!spec||typeof spec!=="object"||!Array.isArray(spec.objects))throw new Error("Susunan desain tidak lengkap. Coba lagi.");
 const g=crypto.randomUUID(),out=[];
 for(const o of spec.objects.slice(0,60)){if(!o||typeof o!=="object"||!TYPES.includes(o.type))continue;
  const t=o.type,nm=String(o.name||NAMA[t]).slice(0,40);let r={id:crypto.randomUUID(),groupId:g,type:t,name:nm,rotation:Math.round(num(o.rotation,-360,360,0)),opacity:Math.round(num(o.opacity,0,100,100))};
  if(t==="text"){const s=String(o.text==null?"":o.text).slice(0,200);if(!s.trim())continue;const fs=Math.round(num(o.fontSize,8,400,48)),w=Math.round(s.length*fs*.6),h=Math.round(fs*1.25);
   let x=num(o.x,-W,2*W,0);if(o.center===true)x-=w/2;
   Object.assign(r,{text:s,fontSize:fs,bold:o.bold===true,fontFamily:FONTS.includes(o.fontFamily)?o.fontFamily:"Arial",x:Math.round(x),y:Math.round(num(o.y,-H,2*H,0)),w,h,fill:col(o.fill,"#20243a"),stroke:"none",strokeWidth:0});}
  else{const w=Math.round(num(o.w,1,3*W,200)),h=t==="line"?0:Math.round(num(o.h,1,3*H,150));
   Object.assign(r,{x:Math.round(num(o.x,-W,2*W,0)),y:Math.round(num(o.y,-H,2*H,0)),w,h,fill:col(o.fill,"#6d5dfc"),stroke:col(o.stroke,"none"),strokeWidth:Math.round(num(o.strokeWidth,0,60,t==="line"?4:0))});
   if(t==="line"&&r.stroke==="none"){r.stroke=r.fill;}
   if(t==="rect")r.rx=Math.round(num(o.rx,0,Math.min(w,h)/2,0));}
  out.push(r);}
 if(!out.length)throw new Error("Model tidak menghasilkan objek yang bisa dipakai. Coba prompt lain.");
 return{background:col(spec.background,"#ffffff"),objects:out};}

/* ---------- aksi ---------- */
const SYS_D=`You are a graphic-design layout engine. Reply with ONLY one JSON object, no prose, no markdown.
Schema: {"background":"#rrggbb","objects":[{"type":"rect|ellipse|star|polygon|line|text","name":"short label","x":number,"y":number,"w":number,"h":number,"fill":"#rrggbb","stroke":"#rrggbb or none","strokeWidth":number,"opacity":0-100,"rotation":degrees,"rx":corner radius (rect only),"text":"text only","fontSize":number,"bold":true|false,"fontFamily":"Arial|Georgia|Times New Roman|Courier New|Impact","center":true|false}]}
Rules: origin is top-left; x,y is the top-left corner of the object; for text, x,y is the top-left of the text, or if "center" is true then x is the horizontal center. Keep every object inside the canvas. Use 8-30 objects ordered back to front (background shapes first). Ensure strong text contrast and a clear hierarchy. Write all visible text in the same language as the user's request.`;
async function buatDesain(prompt,gaya,ganti){const W=S.page.width,H=S.page.height;
 const raw=await ask(SYS_D,`Canvas: ${W}x${H} px. Style: ${gaya}. Request: ${prompt}`,4000);
 const d=bersih(cut(raw,"{","}"),W,H);
 Hi.snapshot();if(ganti)S.objects.splice(0,S.objects.length);S.page.background=d.background;S.objects.push(...d.objects);S.selected=null;S.selectedIds=[];
 CDMS.Navigation.showEditor();C.render();return d.objects.length;}
const SYS_T=`You rewrite short texts for graphic designs. Reply with ONLY a JSON array of exactly 3 strings (3 alternative versions), no prose. Keep each version short enough to fit as a design headline unless asked otherwise. Keep the language of the original unless the instruction says otherwise.`;
async function variasi(teks,instr){const raw=await ask(SYS_T,`Original: ${teks}\nInstruction: ${instr||"Make it catchier."}`,600);
 const a=cut(raw,"[","]");if(!Array.isArray(a))throw new Error("Jawaban model tidak valid.");return a.map(x=>String(x).slice(0,200)).filter(x=>x.trim()).slice(0,3);}
const terpilih=()=>{const ids=S.selectedIds&&S.selectedIds.length?S.selectedIds:(S.selected?[S.selected]:[]);return S.objects.filter(o=>ids.includes(o.id)&&o.type==="text");};

/* ---------- antarmuka ---------- */
function ui(tab){const c=load(),adaTeks=terpilih();
 CDMS.Navigation.openModal("Asisten AI",`<div class="st-tabs" id="aiTabs"><button class="st-tab" data-t="d">Desain</button><button class="st-tab" data-t="t">Variasi teks</button><button class="st-tab" data-t="s">Pengaturan</button></div>
<section class="st-pane" data-p="d"><p class="st-note">Tulis desain yang kamu mau; AI menyusun objek yang tetap bisa diedit. Hasil bisa dibatalkan dengan Undo.</p>
<label>Prompt<textarea id="aiPrompt" rows="3" maxlength="600" placeholder="Contoh: poster promo kopi dengan judul besar, harga, dan tombol ajakan"></textarea></label>
<label>Gaya<select id="aiStyle"><option>Modern minimal</option><option>Neon gelap</option><option>Cerah dan ceria</option><option>Elegan dan mewah</option><option>Retro</option></select></label>
<label class="chk"><input id="aiClear" type="checkbox"> Ganti isi kanvas saat ini</label>
<button class="btn primary" id="aiGo">Buat desain</button><div class="st-note" id="aiMsgD" role="status"></div></section>
<section class="st-pane hidden" data-p="t"><p class="st-note" id="aiSel">${adaTeks.length?"Teks terpilih: <b>"+E(adaTeks[0].text||"").slice(0,80)+"</b>":"Pilih satu objek teks di kanvas dulu, lalu buka tab ini."}</p>
<label>Instruksi (opsional)<input id="aiInstr" maxlength="120" placeholder="mis. lebih singkat, bahasa Inggris, nada santai"></label>
<button class="btn primary" id="aiVar">Buat 3 variasi</button><div class="ai-vars" id="aiVars"></div><div class="st-note" id="aiMsgT" role="status"></div></section>
<section class="st-pane hidden" data-p="s"><p class="st-note">Kunci API disimpan hanya di browser ini dan dikirim langsung ke penyedia yang kamu pilih bersama prompt kamu. Jangan pakai kunci yang tidak ingin terpapar di perangkat ini.</p>
<label>Penyedia<select id="aiProv"><option value="openai">OpenAI-compatible</option><option value="anthropic">Anthropic</option></select></label>
<label>Alamat API (base URL)<input id="aiBase" value="${E(c.base)}" autocomplete="off" spellcheck="false"></label>
<label>Model<input id="aiModel" value="${E(c.model)}" autocomplete="off" spellcheck="false"></label>
<label>Kunci API<input id="aiKey" type="password" value="${E(c.key)}" autocomplete="off" spellcheck="false" placeholder="tempel kunci di sini"></label>
<label class="chk"><input id="aiShow" type="checkbox"> Tampilkan kunci</label>
<div class="st-grid"><button class="btn primary" id="aiSave">Simpan</button><button class="btn subtle" id="aiTest">Tes koneksi</button></div><div class="st-note" id="aiMsgS" role="status"></div></section>`);
 const m=$("#modalBody"),tabs=[...m.querySelectorAll(".st-tab")],panes=[...m.querySelectorAll(".st-pane")];
 const show=t=>{tabs.forEach(b=>b.classList.toggle("active",b.dataset.t===t));panes.forEach(p=>p.classList.toggle("hidden",p.dataset.p!==t));};
 tabs.forEach(b=>b.addEventListener("click",()=>show(b.dataset.t)));show(tab||(c.key?"d":"s"));
 const msg=(id,t,err)=>{const e=$("#"+id,m);if(e){e.textContent=t;e.classList.toggle("ai-err",!!err);}};
 $("#aiProv",m).value=c.provider;
 $("#aiProv",m).addEventListener("change",e=>{const p=e.target.value;$("#aiBase",m).value=DEF[p].base;$("#aiModel",m).value=DEF[p].model;});
 $("#aiShow",m).addEventListener("change",e=>{$("#aiKey",m).type=e.target.checked?"text":"password";});
 const simpan=()=>{const cfg={provider:$("#aiProv",m).value,base:$("#aiBase",m).value.trim(),model:$("#aiModel",m).value.trim(),key:$("#aiKey",m).value.trim()};
  return save(cfg)?cfg:null;};
 $("#aiSave",m).addEventListener("click",()=>{if(!simpan())return msg("aiMsgS","Gagal menyimpan (penyimpanan browser tidak tersedia).",true);msg("aiMsgS","Tersimpan di browser ini.");});
 const busy=(btn,on,label)=>{btn.disabled=on;btn.dataset.l=btn.dataset.l||btn.textContent;btn.textContent=on?label:btn.dataset.l;};
 $("#aiTest",m).addEventListener("click",async e=>{const b=e.currentTarget;if(!simpan())return;busy(b,true,"Menguji...");msg("aiMsgS","");
  try{await ask("Reply with the single word OK.","ping",16);msg("aiMsgS","Koneksi berhasil.");}catch(x){msg("aiMsgS",x.message,true);}busy(b,false);});
 $("#aiGo",m).addEventListener("click",async e=>{const b=e.currentTarget,p=$("#aiPrompt",m).value.trim();if(!p)return msg("aiMsgD","Tulis dulu desain yang kamu mau.",true);
  busy(b,true,"Menyusun desain...");msg("aiMsgD","");
  try{const n=await buatDesain(p,$("#aiStyle",m).value,$("#aiClear",m).checked);CDMS.Navigation.closeModal();}
  catch(x){msg("aiMsgD",x.message,true);}busy(b,false);});
 $("#aiVar",m).addEventListener("click",async e=>{const b=e.currentTarget,sel=terpilih();if(!sel.length)return msg("aiMsgT","Pilih satu objek teks di kanvas dulu.",true);
  busy(b,true,"Menulis...");msg("aiMsgT","");$("#aiVars",m).innerHTML="";
  try{const v=await variasi(sel[0].text||"",$("#aiInstr",m).value.trim());
   const box=$("#aiVars",m);v.forEach(t=>{const bt=document.createElement("button");bt.className="btn subtle ai-var";bt.textContent=t;
    bt.addEventListener("click",()=>{Hi.snapshot();const o=S.objects.find(x=>x.id===sel[0].id);if(o){o.text=t;o.w=Math.round(t.length*(o.fontSize||48)*.6);}C.render();CDMS.Navigation.closeModal();});box.appendChild(bt);});
   if(!v.length)msg("aiMsgT","Tidak ada variasi. Coba lagi.",true);}
  catch(x){msg("aiMsgT",x.message,true);}busy(b,false);});}

function pasang(){const ab=$(".top-actions");if(!ab||$('[data-action="ai"]',ab))return;
 const st=$('[data-action="studio"]',ab),h='<button class="btn subtle ai-btn" data-action="ai" title="Asisten AI"><span>AI</span></button>';
 if(st)st.insertAdjacentHTML("afterend",h);else ab.insertAdjacentHTML("afterbegin",h);}
document.addEventListener("click",e=>{if(e.target.closest('[data-action="ai"]')){CDMS.Navigation.showEditor&&CDMS.Navigation.showEditor();ui();}});
pasang();setTimeout(pasang,400);
CDMS.AI={open:ui,_bersih:bersih};
})();
