/* V37: menu Tekstur (overlay halaman), Sesuaikan (penyesuaian foto dengan slider), gaya goresan pena */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;

/* ---- filter tekstur (menghasilkan noise di dalam bentuk objek) ---- */
const F=(id,b)=>`<filter id="${id}" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">${b}</filter>`;
Object.assign(M.FXS,{
 texGrain:id=>F(id,'<feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="3" seed="2" result="n"/><feColorMatrix in="n" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1.4 0 0 0 -.6" result="a"/><feComposite in="a" in2="SourceAlpha" operator="in"/>'),
 texPaper:id=>F(id,'<feTurbulence type="fractalNoise" baseFrequency=".035" numOctaves="5" seed="5" result="n"/><feColorMatrix in="n" type="matrix" values="0 0 0 0 .45 0 0 0 0 .33 0 0 0 0 .2 .9 0 0 0 -.2" result="a"/><feComposite in="a" in2="SourceAlpha" operator="in"/>'),
 texLinen:id=>F(id,'<feTurbulence type="fractalNoise" baseFrequency=".008 .55" numOctaves="2" seed="9" result="n"/><feColorMatrix in="n" type="matrix" values="0 0 0 0 .3 0 0 0 0 .3 0 0 0 0 .3 1.1 0 0 0 -.4" result="a"/><feComposite in="a" in2="SourceAlpha" operator="in"/>')});
function addTex(name,key,extra){Hi.snapshot();const o={id:uid(),type:"rect",name:"Tekstur "+name,x:0,y:0,w:W(),h:H(),fill:"#ffffff",stroke:"none",strokeWidth:0,opacity:100,rotation:0,locked:true,bm:"multiply",...(key?{svgfx:key}:{}),...extra};S.objects.push(o);S.selected=null;S.selectedIds=[];C.render();T("Tekstur "+name+" ditambahkan (terkunci di atas desain)");}
MENUS.tekstur=()=>[{h:"Tekstur di atas halaman",items:[it("Grain film halus",()=>addTex("grain","texGrain",{opacity:55}),"studio"),it("Kertas kasar",()=>addTex("kertas","texPaper",{opacity:45}),"studio"),it("Kain linen",()=>addTex("linen","texLinen",{opacity:55}),"studio"),it("Halftone titik",()=>addTex("halftone",null,{fill:"#707070",pat:"dot",opacity:14}),"grid"),it("Garis diagonal tipis",()=>addTex("garis",null,{fill:"#707070",pat:"stripe",opacity:10}),"line")]},
 {h:"Hapus",items:[it("Hapus semua tekstur",()=>{const n=S.objects.filter(o=>/^Tekstur /.test(o.name||"")).length;if(!n)return T("Belum ada tekstur");Hi.snapshot();S.objects=S.objects.filter(o=>!/^Tekstur /.test(o.name||""));C.render();T(n+" tekstur dihapus");},"trash")]}];

/* ---- penyesuaian foto ---- */
const SL=[["adB","Kecerahan",50,150,100,"%"],["adC","Kontras",50,150,100,"%"],["adS","Saturasi",0,200,100,"%"],["adH","Geser warna",-180,180,0,"°"],["adBl","Blur",0,20,0," px"]];
function adjust(){const a=sels().filter(o=>o.type!=="line");if(!a.length)return T("Pilih gambar atau objek dulu");Hi.snapshot();
 N.openModal("Penyesuaian",`<div class="st-pane">${SL.map(s=>`<label>${s[1]}: <b id="${s[0]}v">${s[4]}${s[5]}</b><input id="${s[0]}" type="range" min="${s[2]}" max="${s[3]}" value="${s[4]}"></label>`).join("")}<div class="st-grid"><button class="btn subtle" id="adR">Reset</button><button class="btn primary" id="adOk">Selesai</button></div></div>`);
 const v=id=>+$("#"+id).value,upd=()=>{SL.forEach(s=>{$("#"+s[0]+"v").textContent=v(s[0])+s[5];});const f=`brightness(${v("adB")}%) contrast(${v("adC")}%) saturate(${v("adS")}%) hue-rotate(${v("adH")}deg)`+(v("adBl")>0?` blur(${v("adBl")}px)`:"");a.forEach(o=>{o.imgFx=f;});C.render();};
 SL.forEach(s=>{$("#"+s[0]).oninput=upd;});$("#adOk").onclick=()=>N.closeModal();$("#adR").onclick=()=>{SL.forEach(s=>{$("#"+s[0]).value=s[4];});a.forEach(o=>{delete o.imgFx;});SL.forEach(s=>{$("#"+s[0]+"v").textContent=s[4]+s[5];});C.render();};}
MENUS.sesuai=()=>[{h:"Penyesuaian dengan slider (pratinjau langsung)",items:[it("Atur kecerahan, kontras, saturasi, warna, blur…",adjust,"settings")]},{h:"Cepat",items:[it("Hapus semua penyesuaian",()=>edit(o=>{delete o.imgFx;},"Penyesuaian dihapus"),"undo")]}];

/* ---- gaya goresan pena ---- */
S.penDash=S.penDash||"";S.penOp=S.penOp||100;
const fp=C.finishPath;
C.finishPath=function(){const n=S.objects.length;fp.apply(this,arguments);if(S.objects.length<=n)return;S.objects.slice(n).forEach(o=>{if(o.type!=="path")return;if(S.penDash)o.dash=S.penDash;if(S.penOp<100)o.opacity=S.penOp;});this.render();};
const setPen=(dash,op,w)=>{S.penDash=dash;S.penOp=op;if(w)S.penWidth=w;CDMS.setTool("pen");T("Gaya kuas diatur");};
const op=MENUS.pen;
MENUS.pen=()=>[...op(),{h:"Gaya goresan",items:[it((!S.penDash&&S.penOp===100?"✓ ":"")+"Solid",()=>setPen("",100),"pen"),it((S.penDash==="4 3"?"✓ ":"")+"Putus-putus",()=>setPen("4 3",100),"pen"),it((S.penDash==="1 2"?"✓ ":"")+"Titik-titik",()=>setPen("1 2",100,Math.max(S.penWidth||6,6)),"pen"),it((S.penOp<100?"✓ ":"")+"Stabilo transparan",()=>setPen("",45,26),"pen")]}];

BT.push(["tekstur","texture","Tekstur"],["sesuai","props","Sesuaikan"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("warna").push("tekstur","sesuai");
})();
