/* V31: menu Tema (ubah warna seluruh proyek) dan Carousel (generator multi-halaman dari daftar poin) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,P=CDMS.Pages,{MENUS,BT,pick,T,it,tc,cell}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID();
const isHex=c=>/^#[0-9a-f]{6}$/i.test(String(c)),rgb=c=>[1,3,5].map(i=>parseInt(c.substr(i,2),16)),hx=a=>"#"+a.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0")).join("");
function toHsl(hex){const[r,g,b]=rgb(hex).map(v=>v/255),mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;}return[h,s*100,l*100];}
function hsl(h,s,l){h=((h%360)+360)%360;s=Math.max(0,Math.min(100,s))/100;l=Math.max(0,Math.min(100,l))/100;const f=n=>{const k=(n+h/30)%12,a=s*Math.min(l,1-l);return Math.round(255*(l-a*Math.max(-1,Math.min(k-3,9-k,1))));};return hx([f(0),f(8),f(4)]);}
const via=fn=>c=>{if(!isHex(c))return c;const[h,s,l]=toHsl(c);return fn(h,s,l);};

/* ---- terapkan transformasi warna ke proyek ---- */
S.themeAll=S.themeAll||false;
function recolor(fn){Hi.snapshot();if(P)P.sync();const pages=S.themeAll&&S.pages.length>1?S.pages:[{objects:S.objects,page:S.page}];
 pages.forEach(pg=>{pg.objects.forEach(o=>{["fill","stroke","fxColor"].forEach(k=>{if(o[k])o[k]=fn(o[k]);});if(o.sh)o.sh.c=fn(o.sh.c);if(o.grad)o.grad=[fn(o.grad[0]),fn(o.grad[1]),o.grad[2]];});
  const b=String(pg.page.background||"");if(b.startsWith("grad:")){const[a,c,m]=b.slice(5).split(",");pg.page.background="grad:"+fn(a)+","+fn(c)+","+m;}else pg.page.background=fn(b);});
 C.render();T(S.themeAll&&S.pages.length>1?"Warna diubah di semua halaman":"Warna diubah");}
function replaceModal(){N.openModal("Ganti warna",`<div class="st-pane"><div class="st-grid"><label>Dari<input id="rpA" type="color" value="#6d5dfc"></label><label>Menjadi<input id="rpB" type="color" value="#ff6b6b"></label></div><label>Kecocokan<select id="rpT"><option value="0">Persis sama</option><option value="40" selected>Mirip (±40)</option><option value="90">Longgar (±90)</option></select></label><button class="btn primary" id="rpOk">Ganti</button></div>`);
 $("#rpOk").onclick=()=>{const a=rgb($("#rpA").value),b=$("#rpB").value,t=+$("#rpT").value;N.closeModal();recolor(c=>{if(!isHex(c))return c;const v=rgb(c);return Math.hypot(v[0]-a[0],v[1]-a[1],v[2]-a[2])<=t+.01?b:c;});};}
function used(){const cnt={};S.objects.forEach(o=>["fill","stroke"].forEach(k=>{if(isHex(o[k]))cnt[o[k].toLowerCase()]=(cnt[o[k].toLowerCase()]||0)+1;}));return Object.entries(cnt).sort((a,b)=>b[1]-a[1]).slice(0,12);}
MENUS.theme=()=>[
 {h:"Geser warna (hue)",items:[30,60,120,180,240].map(d=>tc("+"+d+"°",()=>recolor(via((h,s,l)=>hsl(h+d,s,l)))))},
 {h:"Saturasi & kecerahan",items:[["Lebih hidup",(h,s,l)=>hsl(h,s*1.3,l)],["Lebih pudar",(h,s,l)=>hsl(h,s*.7,l)],["Lebih terang",(h,s,l)=>hsl(h,s,l+8)],["Lebih gelap",(h,s,l)=>hsl(h,s,l-8)],["Kontras tinggi",(h,s,l)=>hsl(h,s,l>50?l+(100-l)*.35:l*.65)],["Monokrom",(h,s,l)=>hsl(h,0,l)]].map(x=>tc(x[0],()=>recolor(via(x[1]))))},
 {h:"Ganti & cakupan",items:[it("Ganti satu warna…",replaceModal,"color"),it((S.themeAll?"✓ ":"")+"Berlaku di semua halaman",()=>{S.themeAll=!S.themeAll;T(S.themeAll?"Berlaku di semua halaman":"Hanya halaman ini");},"layers")]},
 {h:"Warna yang dipakai di halaman ini (ketuk untuk memilih objeknya)",items:used().map(([c,n])=>cell(`<i style="background:${c};border:1px solid var(--line)"></i><span>${c} ·${n}</span>`,()=>pick(S.objects.filter(o=>String(o.fill).toLowerCase()===c||String(o.stroke).toLowerCase()===c))))}];

/* ---- carousel generator ---- */
const THEMES={neon:{bg:"#10131c",fg:"#ffffff",ac:"#00d6c9"},sunrise:{bg:"#fff4e6",fg:"#2b1b00",ac:"#ff6b35"},royal:{bg:"#160b32",fg:"#f8edff",ac:"#ffc857"},minimal:{bg:"#f5f3ef",fg:"#181818",ac:"#6d5dfc"}};
const wrapT=(t,n)=>{const out=[];let l="";t.split(/\s+/).filter(Boolean).forEach(w=>{if(l&&(l+" "+w).length>n){out.push(l);l=w;}else l=(l+" "+w).trim();});if(l)out.push(l);return out.join("\n");};
const O=(type,x,y,w,h,ex)=>({id:uid(),type,name:ex&&ex.name||type,x:Math.round(x),y:Math.round(y),w:Math.max(1,Math.round(w)),h:Math.round(h),fill:"#000000",stroke:"none",strokeWidth:0,opacity:100,rotation:0,...ex});
const TX=(text,x,y,size,fill,ex)=>O("text",x,y,size*Math.max(...text.split("\n").map(l=>l.length))*.55,size*1.2*text.split("\n").length,{text,fontSize:Math.round(size),fill,bold:true,name:"Teks",...ex});
function carousel(){const title=$("#caT").value.trim()||"Judul Carousel",pts=$("#caP").value.split("\n").map(s=>s.trim()).filter(Boolean).slice(0,9),th=THEMES[$("#caS").value],W=1080,H=1350;if(!pts.length)return T("Isi minimal satu poin");N.closeModal();
 const total=pts.length+2,pages=[],dots=(i,pg)=>{const d=Math.round(W*.018),g=Math.round(d*1.1),x0=Math.round((W-(total*d+(total-1)*g))/2);for(let k=0;k<total;k++)pg.objects.push(O("ellipse",x0+k*(d+g),H-96,d,d,{name:"Titik",fill:k===i?th.ac:th.fg,opacity:k===i?100:28}));};
 const mk=()=>({objects:[],page:{width:W,height:H,background:th.bg}});
 let pg=mk();pg.objects.push(O("ellipse",W*.55,-W*.2,W*.7,W*.7,{name:"Hiasan",fill:th.ac,opacity:22}),O("rect",W*.08,H*.27,W*.16,H*.012,{name:"Garis aksen",fill:th.ac}));
 const ts=Math.round(W*.1);pg.objects.push(TX(wrapT(title,Math.floor(W*.84/(ts*.58))),W*.08,H*.3,ts,th.fg,{name:"Judul"}),TX("Geser untuk lanjut  →",W*.08,H*.84,W*.032,th.ac,{name:"Petunjuk"}));dots(0,pg);pages.push(pg);
 pts.forEach((p,i)=>{pg=mk();const fs=Math.round(W*.07);pg.objects.push(TX(String(i+1),W*.52,-W*.02,W*.62,th.ac,{name:"Nomor besar",opacity:14,fontFamily:"Impact, 'Arial Black', sans-serif"}),O("rect",W*.08,H*.3,W*.16,H*.012,{name:"Garis aksen",fill:th.ac}),TX(wrapT(p,Math.floor(W*.84/(fs*.58))),W*.08,H*.34,fs,th.fg,{name:"Poin "+(i+1)}));dots(i+1,pg);pages.push(pg);});
 pg=mk();pg.objects.push(O("ellipse",-W*.2,H*.55,W*.7,W*.7,{name:"Hiasan",fill:th.ac,opacity:22}),TX("Terima kasih!",W*.08,H*.38,W*.11,th.fg,{name:"Judul penutup"}),TX("Simpan & bagikan postingan ini",W*.08,H*.5,W*.04,th.ac,{name:"Ajakan"}));dots(total-1,pg);pages.push(pg);
 P.sync();const at=S.pageIdx;S.pages.splice(at+1,0,...pages);P.go(at+1);T(pages.length+" halaman carousel dibuat");}
function carouselModal(){N.openModal("Carousel dari daftar poin",`<div class="st-pane"><label>Judul cover<input id="caT" value="5 Tips Desain Cepat"></label><label>Poin (satu per baris, maks 9)<textarea id="caP" rows="5">Gunakan maksimal 2 font\nBuat kontras yang jelas\nBeri ruang kosong\nUlangi pola yang konsisten\nSelalu periksa hasil di HP</textarea></label><label>Tema<select id="caS"><option value="neon">Neon gelap</option><option value="sunrise">Sunrise hangat</option><option value="royal">Royal ungu</option><option value="minimal">Minimal terang</option></select></label><p class="st-note">Halaman dibuat berukuran 1080 × 1350 dan disisipkan setelah halaman ini.</p><button class="btn primary" id="caOk">Buat carousel</button></div>`);$("#caOk").onclick=carousel;}
MENUS.carousel=()=>[{h:"Generator",items:[it("Carousel dari daftar poin…",carouselModal,"layers")]},{h:"Tips",items:[it("Hasilnya halaman biasa: edit teks dengan ketuk dua kali",()=>{},"text"),it("Ekspor lewat Halaman > Ekspor semua halaman",()=>{},"export")]}];

BT.push(["theme","theme","Tema"],["carousel","carousel","Carousel"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("warna").push("theme");hub("buat").push("carousel");
})();
