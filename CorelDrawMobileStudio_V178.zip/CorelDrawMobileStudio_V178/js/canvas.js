window.CDMS=window.CDMS||{};CDMS.Canvas={
 init(){
  this.svg=document.getElementById("designCanvas");this.group=document.getElementById("designObjects");
  this.svg.addEventListener("pointerdown",e=>this.pointerDown(e));
  this.svg.addEventListener("pointermove",e=>this.pointerMove(e));
  window.addEventListener("pointerup",()=>{this.finishPath();CDMS.state.drag=null;});
  document.getElementById("zoomRange").addEventListener("input",e=>this.setZoom(+e.target.value));
  this.bindProperties();this.render();
 },
 newDocument(w,h){CDMS.History.snapshot();const S=CDMS.state;S.objects=[];S.selected=null;S.selectedIds=[];S.page={width:w,height:h,background:"#ffffff"};S.projectName="Desain "+new Date().toLocaleDateString("id-ID");CDMS.Navigation.showEditor();this.render();},
 loadProject(p){const S=CDMS.state;S.objects=Array.isArray(p.objects)?p.objects:[];S.page={width:p.width||1080,height:p.height||1080,background:p.background||"#ffffff"};S.projectName=p.name||"Proyek dibuka";S.selected=null;S.selectedIds=[];CDMS.Navigation.showEditor();this.render();},
 render(){
  const S=CDMS.state;this.svg.setAttribute("viewBox",`0 0 ${S.page.width} ${S.page.height}`);
  document.getElementById("pageBackground").setAttribute("width",S.page.width);document.getElementById("pageBackground").setAttribute("height",S.page.height);document.getElementById("pageBackground").setAttribute("fill",S.page.background);
  this.group.innerHTML="";
  S.objects.forEach(o=>{
   if(o.hidden)return;
   let el;
   if(o.type==="text"){el=document.createElementNS("http://www.w3.org/2000/svg","text");el.textContent=o.text||"Teks";el.setAttribute("font-size",o.fontSize||64);el.setAttribute("font-family",o.fontFamily||"Arial");el.setAttribute("font-weight",o.bold?"700":"400");el.setAttribute("dominant-baseline","hanging");}
   else if(o.type==="image"){el=document.createElementNS("http://www.w3.org/2000/svg","image");el.setAttribute("href",o.href);el.setAttribute("preserveAspectRatio","none");}
   else if(o.type==="line"){el=document.createElementNS("http://www.w3.org/2000/svg","line");el.setAttribute("x1",0);el.setAttribute("y1",0);el.setAttribute("x2",o.w);el.setAttribute("y2",o.h);}
   else if(o.type==="path"){el=document.createElementNS("http://www.w3.org/2000/svg","path");el.setAttribute("d",o.d||"");}
   else {const tag=o.type==="ellipse"?"ellipse":o.type==="star"?"polygon":o.type==="polygon"?"polygon":"rect";el=document.createElementNS("http://www.w3.org/2000/svg",tag);
    if(tag==="ellipse"){el.setAttribute("cx",o.w/2);el.setAttribute("cy",o.h/2);el.setAttribute("rx",o.w/2);el.setAttribute("ry",o.h/2);}
    else if(o.type==="star")el.setAttribute("points",this.starPoints(o.w,o.h));
    else if(o.type==="polygon")el.setAttribute("points",`${o.w*.5},0 ${o.w},${o.h*.35} ${o.w*.82},${o.h} ${o.w*.18},${o.h} 0,${o.h*.35}`);
    else {el.setAttribute("width",o.w);el.setAttribute("height",o.h);el.setAttribute("rx",o.rx||0);}
   }
   el.setAttribute("x",o.x);el.setAttribute("y",o.y);el.setAttribute("fill",["line","path"].includes(o.type)?"none":(o.fill||"#6d5dfc"));el.setAttribute("stroke",o.stroke||"#20243a");el.setAttribute("stroke-width",o.strokeWidth??2);el.setAttribute("opacity",(o.opacity??100)/100);
   el.setAttribute("transform",`translate(${o.x} ${o.y}) rotate(${o.rotation||0} ${o.w/2} ${o.h/2}) scale(${o.flipH?-1:1} ${o.flipV?-1:1}) translate(${-o.x} ${-o.y})`);
   el.dataset.id=o.id;el.style.cursor="pointer";
   if((S.selectedIds||[S.selected]).includes(o.id)){el.setAttribute("stroke","#00d6c9");el.setAttribute("stroke-width",Math.max(3,(o.strokeWidth||2)+2));el.setAttribute("stroke-dasharray","8 5");}
   el.addEventListener("pointerdown",e=>{if(o.locked)return;if(S.tool==="eraser"){e.stopPropagation();this.deleteObject(o.id);return;}if(S.tool==="select"){e.stopPropagation();if(e.shiftKey){S.selectedIds=S.selectedIds||[];if(S.selectedIds.includes(o.id))S.selectedIds=S.selectedIds.filter(id=>id!==o.id);else S.selectedIds.push(o.id);S.selected=o.id;}else{S.selected=o.id;S.selectedIds=[o.id];}this.render();S.drag={id:o.id,start:this.point(e),x:o.x,y:o.y,starts:(S.selectedIds||[o.id]).map(id=>{const ob=S.objects.find(x=>x.id===id);return{id,x:ob.x,y:ob.y};})};}});
   this.group.appendChild(el);
  });
  document.getElementById("documentLabel").textContent=S.projectName;this.updateProperties();CDMS.Layers.render();
  const count=(S.selectedIds||[]).length;document.getElementById("selectionStatus").textContent=count>1?`${count} objek dipilih`:S.selected?"1 objek dipilih":"Tidak ada objek dipilih";
 },
 starPoints(w,h){const pts=[];for(let i=0;i<10;i++){const r=i%2===0?.48:.22;const a=-Math.PI/2+i*Math.PI/5;pts.push(`${w/2+Math.cos(a)*w*r},${h/2+Math.sin(a)*h*r}`);}return pts.join(" ");},
 point(e){const p=this.svg.createSVGPoint();p.x=e.clientX;p.y=e.clientY;const q=p.matrixTransform(this.svg.getScreenCTM().inverse());return{x:q.x,y:q.y};},
 pointerDown(e){if(e.target!==this.svg&&e.target.id!=="pageBackground")return;const S=CDMS.state;if(S.tool==="select"){S.selected=null;S.selectedIds=[];this.render();return;}const p=this.point(e);if(["rect","ellipse","star","polygon"].includes(S.tool))CDMS.Shapes.add(S.tool,p.x,p.y);else if(S.tool==="text")CDMS.Shapes.add("text",p.x,p.y);else if(S.tool==="line")CDMS.Shapes.add("line",p.x,p.y);else if(S.tool==="image")document.getElementById("imageInput").click();else if(S.tool==="pen"){CDMS.History.snapshot();S.drawPath={points:[p]};}},
 pointerMove(e){const S=CDMS.state;if(S.drawPath){S.drawPath.points.push(this.point(e));const points=S.drawPath.points;let path=this.group.querySelector('[data-preview="path"]');if(!path){path=document.createElementNS("http://www.w3.org/2000/svg","path");path.dataset.preview="path";path.setAttribute("fill","none");path.setAttribute("stroke","#6d5dfc");path.setAttribute("stroke-width","5");path.setAttribute("stroke-linecap","round");path.setAttribute("stroke-linejoin","round");this.group.appendChild(path);}path.setAttribute("d",points.map((p,i)=>(i?"L":"M")+p.x+" "+p.y).join(" "));return;}
  if(!S.drag)return;const p=this.point(e);const dx=p.x-S.drag.start.x,dy=p.y-S.drag.start.y;const starts=S.drag.starts||[{id:S.drag.id,x:S.drag.x,y:S.drag.y}];starts.forEach(st=>{const o=S.objects.find(x=>x.id===st.id);if(o){o.x=Math.round(st.x+dx);o.y=Math.round(st.y+dy);}});this.render();},
 finishPath(){const S=CDMS.state;if(!S.drawPath)return;const pts=S.drawPath.points;S.drawPath=null;if(pts.length<2)return;const xs=pts.map(p=>p.x),ys=pts.map(p=>p.y),minX=Math.min(...xs),minY=Math.min(...ys);const d=pts.map((p,i)=>(i?"L":"M")+(p.x-minX)+" "+(p.y-minY)).join(" ");const id=crypto.randomUUID();S.objects.push({id,type:"path",name:"Freehand",x:minX,y:minY,w:Math.max(...xs)-minX,h:Math.max(...ys)-minY,d,fill:"none",stroke:"#6d5dfc",strokeWidth:5,opacity:100});S.selected=id;S.selectedIds=[id];this.render();},
 select(id){CDMS.state.selected=id;CDMS.state.selectedIds=id?[id]:[];this.render();},
 updateObject(id,patch){const o=CDMS.state.objects.find(x=>x.id===id);if(!o)return;CDMS.History.snapshot();Object.assign(o,patch);this.render();},
 updateProperties(){const S=CDMS.state,o=S.objects.find(x=>x.id===S.selected);document.getElementById("noSelection").classList.toggle("hidden",!!o);document.getElementById("properties").classList.toggle("hidden",!o);if(!o)return;const vals={propName:o.name,propX:o.x,propY:o.y,propW:o.w,propH:o.h,propRotation:o.rotation||0,propFill:o.fill||"#6d5dfc",propStroke:o.stroke||"#20243a",propStrokeWidth:o.strokeWidth??2,propOpacity:o.opacity??100,propText:o.text||""};Object.entries(vals).forEach(([id,v])=>{const el=document.getElementById(id);if(el&&document.activeElement!==el)el.value=v;});document.getElementById("rotationOutput").textContent=(o.rotation||0)+"°";document.getElementById("textProperty").classList.toggle("hidden",o.type!=="text");},
 bindProperties(){const bind=(id,key,parse=v=>v)=>document.getElementById(id).addEventListener("change",e=>{const o=CDMS.state.objects.find(x=>x.id===CDMS.state.selected);if(!o)return;CDMS.History.snapshot();o[key]=parse(e.target.value);this.render();});bind("propName","name");bind("propX","x",Number);bind("propY","y",Number);bind("propW","w",Number);bind("propH","h",Number);bind("propRotation","rotation",Number);bind("propFill","fill");bind("propStroke","stroke");bind("propStrokeWidth","strokeWidth",Number);bind("propOpacity","opacity",Number);bind("propText","text");},
 deleteSelected(){const ids=CDMS.state.selectedIds?.length?CDMS.state.selectedIds:[CDMS.state.selected];ids.filter(Boolean).forEach(id=>this.deleteObject(id));},
 deleteObject(id){CDMS.History.snapshot();CDMS.state.objects=CDMS.state.objects.filter(o=>o.id!==id);CDMS.state.selected=null;CDMS.state.selectedIds=[];this.render();},
 duplicateSelected(){const S=CDMS.state;const ids=S.selectedIds?.length?S.selectedIds:[S.selected];if(!ids.filter(Boolean).length)return;CDMS.History.snapshot();const copies=ids.filter(Boolean).map(id=>S.objects.find(x=>x.id===id)).filter(Boolean).map(o=>({...o,id:crypto.randomUUID(),name:(o.name||o.type)+" copy",x:o.x+20,y:o.y+20}));S.objects.push(...copies);S.selectedIds=copies.map(x=>x.id);S.selected=copies[0]?.id;this.render();},
 setZoom(z){CDMS.state.zoom=Math.max(25,Math.min(200,z));document.getElementById("zoomRange").value=CDMS.state.zoom;document.getElementById("zoomLabel").textContent=CDMS.state.zoom+"%";this.svg.style.width=(Math.min(680,document.getElementById("canvasViewport").clientWidth-30)*CDMS.state.zoom/100)+"px";this.svg.style.height="auto";},
 arrange(action){const S=CDMS.state;let arr=(S.selectedIds||[]).map(id=>S.objects.find(o=>o.id===id)).filter(Boolean);if(!arr.length&&S.selected)arr=[S.objects.find(o=>o.id===S.selected)].filter(Boolean);if(!arr.length)return;CDMS.History.snapshot();const minX=Math.min(...arr.map(o=>o.x)),maxX=Math.max(...arr.map(o=>o.x+o.w)),minY=Math.min(...arr.map(o=>o.y)),maxY=Math.max(...arr.map(o=>o.y+o.h));arr.forEach(o=>{if(action==="left")o.x=minX;if(action==="center")o.x=(minX+maxX)/2-o.w/2;if(action==="right")o.x=maxX-o.w;if(action==="top")o.y=minY;if(action==="middle")o.y=(minY+maxY)/2-o.h/2;if(action==="bottom")o.y=maxY-o.h;if(action==="flipH")o.flipH=!o.flipH;if(action==="flipV")o.flipV=!o.flipV;});this.render();}
};

