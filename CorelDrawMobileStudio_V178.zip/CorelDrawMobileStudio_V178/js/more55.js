/* V66: menu Isi Kartu - edit semua teks dalam satu grup lewat satu formulir, salin/tempel isi teks antar grup, pilih teks dalam grup */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,it,tc,sels,pick,T}=M;
const $=s=>document.querySelector(s);
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const esc=s=>String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;");
/* semua objek dalam grup yang terpilih (atau objek itu sendiri jika tanpa grup) */
function cakupan(){const a=sels(),gids=new Set(a.map(o=>o.groupId).filter(Boolean));
 return S.objects.filter(o=>gids.has(o.groupId)||(!o.groupId&&a.includes(o)));}
function teksGrup(){return cakupan().filter(o=>o.type==="text"&&!o.hidden).sort((p,q)=>(Math.round(p.y/6)-Math.round(q.y/6))||(p.x-q.x));}
function ukur(o){const f=CDMS.PusatTeks&&CDMS.PusatTeks.ukur;return f?f(o):o.w;}
/* ubah isi teks; pertahankan titik tengah bila semula berpusat di grup, selain itu pertahankan sisi kiri */
function setTeks(o,txt,gcx){if(o.text===txt)return false;const tengah=gcx!=null&&Math.abs((o.x+o.w/2)-gcx)<=8,cx=o.x+o.w/2;
 o.text=txt;const w=ukur(o);o.w=w;if(tengah)o.x=Math.round(cx-w/2);return true;}
function pusatGrup(a){const m=a.filter(o=>o.type!=="text"&&o.w>0);const b=m.length?m:a;const x1=Math.min(...b.map(o=>o.x)),x2=Math.max(...b.map(o=>o.x+o.w));return (x1+x2)/2;}
function formulir(){const t=teksGrup();if(!t.length)return T("Pilih kartu/grup yang berisi teks dulu");
 const gcx=pusatGrup(cakupan());
 N.openModal("Edit isi kartu",`<div class="st-pane"><p class="muted">${t.length} teks · urut dari atas ke bawah</p><div class="st-grid" style="grid-template-columns:1fr">${t.slice(0,40).map((o,i)=>{const v=esc(o.text||""),ml=String(o.text||"").includes("\n");return `<label>${esc(String(o.text||"").slice(0,18)||"Teks")+" · "+(o.fontSize||32)+"px"}${ml?`<textarea data-i="${i}" rows="2">${v}</textarea>`:`<input data-i="${i}" type="text" value="${v}">`}</label>`;}).join("")}</div>${t.length>40?'<p class="muted">Hanya 40 teks pertama yang ditampilkan.</p>':""}<button class="btn primary" id="ikOk">Terapkan</button></div>`);
 $("#ikOk").onclick=()=>{Hi.snapshot();let n=0;document.querySelectorAll("#modalBody [data-i]").forEach(el=>{const o=t[+el.dataset.i];if(o&&setTeks(o,el.value,gcx))n++;});C.render();N.closeModal();T(n?n+" teks diperbarui":"Tidak ada perubahan");};}
let simpan=null;
function salin(){const t=teksGrup();if(!t.length)return T("Pilih kartu/grup yang berisi teks dulu");simpan=t.map(o=>o.text);T(simpan.length+" isi teks disalin");}
function tempel(){if(!simpan)return T("Belum ada isi teks yang disalin");const t=teksGrup();if(!t.length)return T("Pilih kartu/grup tujuan dulu");
 Hi.snapshot();const gcx=pusatGrup(cakupan());let n=0;t.forEach((o,i)=>{if(i<simpan.length&&setTeks(o,simpan[i],gcx))n++;});C.render();T(n+" teks ditempel"+(t.length!==simpan.length?" · jumlah teks berbeda ("+simpan.length+" → "+t.length+")":""));}
function pilihTeks(){const t=teksGrup();if(!t.length)return T("Tidak ada teks di grup ini");pick(t);T(t.length+" teks dipilih");}
function kosongkan(){const t=teksGrup();if(!t.length)return T("Pilih kartu/grup yang berisi teks dulu");Hi.snapshot();const gcx=pusatGrup(cakupan());t.forEach(o=>setTeks(o,"Teks",gcx));C.render();T(t.length+" teks diganti placeholder");}
MENUS.isikartu=()=>[
 {h:"Edit",items:[it("Edit semua teks di grup…",formulir,"text"),tc("Pilih teks dalam grup",pilihTeks)]},
 {h:"Pindah isi",items:[tc("Salin isi teks grup",salin),tc("Tempel isi ke grup lain",tempel),tc("Ganti semua jadi “Teks”",kosongkan)]}];
BT.push(["isikartu","fillcard","Isi Kartu"]);
hubAdd("teks","isikartu");
CDMS.IsiKartu={cakupan,teksGrup,setTeks,pusatGrup};
})();
