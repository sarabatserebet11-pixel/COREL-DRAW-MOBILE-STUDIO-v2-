/* V74: tab baru Gradien (dua warna kustom, arah diagonal/vertikal/mendatar/radial, tukar, gradien dari warna isi) dan Filter (kecerahan, kontras, saturasi, blur, grayscale, sepia, hue - tampil langsung) di panel Penata + tombol cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n);
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const done=m=>{C.render();if(m)T(m);};
const tgt=()=>M.sels().filter(o=>!o.locked);
const okG=o=>o.type!=="image"&&o.type!=="line"&&o.type!=="text";
const hex=c=>/^#[0-9a-f]{6}$/i.test(c||"");
function shade(h,t){const p=[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));return "#"+p.map(v=>Math.max(0,Math.min(255,Math.round(t>0?v+(255-v)*t:v*(1+t))))).map(v=>v.toString(16).padStart(2,"0")).join("");}
let mode="d";
const grad=(fn,msg)=>{const a=tgt().filter(okG);if(!a.length)return T("Pilih bentuk dulu (bukan teks/foto/garis)");Hi.snapshot();a.forEach(fn);done(msg);};
/* ---- filter ---- */
const FL=[["fb","brightness","Kecerahan %",100,0,250],["fc","contrast","Kontras %",100,0,250],["fs","saturate","Saturasi %",100,0,300],["fg","grayscale","Grayscale %",0,0,100],["fe","sepia","Sepia %",0,0,100]];
const read=()=>{const v=k=>+$("#p74"+k).value;const p=[];FL.forEach(f=>{const x=v(f[0]);if(x!==f[3])p.push(`${f[1]}(${x}%)`);});if(v("fh"))p.push(`hue-rotate(${v("fh")}deg)`);if(v("fl"))p.push(`blur(${v("fl")}px)`);return p.join(" ");};
let gest=false;
function liveFx(){const a=tgt();if(!a.length)return T("Pilih objek dulu");if(!gest){Hi.snapshot();gest=true;}const f=read();a.forEach(o=>{if(f)o.imgFx=f;else delete o.imgFx;});C.render();}
function resetUI(){FL.forEach(f=>{$("#p74"+f[0]).value=f[3];});$("#p74fh").value=0;$("#p74fl").value=0;}
const H={
 gOn:()=>grad(o=>{o.grad=[$("#p74a").value,$("#p74b").value,mode];},"Gradien diterapkan"),
 gSwap:()=>{const x=$("#p74a").value;$("#p74a").value=$("#p74b").value;$("#p74b").value=x;H.gOn();},
 gFill:()=>grad(o=>{const f=hex(o.fill)?o.fill:"#6d5dfc";o.grad=[shade(f,.35),shade(f,-.35),mode];},"Gradien dari warna isi"),
 gOff:()=>grad(o=>{delete o.grad;},"Gradien dihapus"),
 gd:()=>{mode="d";modeUI();},gv:()=>{mode="v";modeUI();},gh:()=>{mode="h";modeUI();},gr:()=>{mode="r";modeUI();},
 fReset:()=>{const a=tgt();resetUI();if(!a.length)return;Hi.snapshot();a.forEach(o=>{delete o.imgFx;});done("Filter dihapus");}};
function modeUI(){document.querySelectorAll(".p69 [data-h^=g][data-m]").forEach(x=>x.classList.toggle("on",x.dataset.m===mode));}
const slid=f=>`<label class="p69rg">${f[2]} <input id="p74${f[0]}" type="range" min="${f[4]}" max="${f[5]}" value="${f[3]}"></label>`;
P.addTab("gradien","Gradien",`<div class="p69row"><label>Warna 1<input id="p74a" type="color" value="#6d5dfc"></label><label>Warna 2<input id="p74b" type="color" value="#00d6c9"></label></div>
 <div class="p69h">Arah</div><div class="p69btns c4">${["d:Diagonal","v:Vertikal","h:Mendatar","r:Radial"].map(x=>{const [k,l]=x.split(":");return `<button data-h="g${k}" data-m="${k}"><span>${l}</span></button>`;}).join("")}</div>
 <div class="p69btns" style="margin-top:8px">${b("gOn","Terapkan gradien")}${b("gSwap","Tukar warna")}${b("gFill","Dari warna isi")}${b("gOff","Hapus gradien")}</div>`,H);
P.addTab("filter","Filter",`${FL.map(slid).join("")}<label class="p69rg">Hue (°) <input id="p74fh" type="range" min="0" max="360" value="0"></label><label class="p69rg">Blur (px) <input id="p74fl" type="range" min="0" max="40" value="0"></label>
 <div class="p69btns" style="margin-top:10px">${b("fReset","Reset filter")}</div><p class="muted" style="margin-top:8px">Filter tampil langsung pada semua objek terpilih.</p>`,H);
document.addEventListener("input",e=>{if(e.target.closest&&e.target.closest(".p69")&&/^p74f/.test(e.target.id||""))liveFx();});
document.addEventListener("change",e=>{if(/^p74f/.test(e.target.id||""))gest=false;});
document.addEventListener("click",e=>{if(e.target.closest&&e.target.closest("[data-t=gradien]"))modeUI();});
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q4="grad" title="Gradien">${ic("color")}</button><button data-q4="filter" title="Filter">${ic("image")}</button><button data-q4="bersih" title="Hapus gradien, bayangan & filter">${ic("trash")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q4]");if(!x)return;const k=x.dataset.q4;if(k==="grad"){P.openTab("gradien");modeUI();}else if(k==="filter")P.openTab("filter");
  else{const a=tgt();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();a.forEach(o=>{delete o.grad;delete o.sh;delete o.imgFx;});done("Gradien, bayangan & filter dihapus");}});}
MENUS.penata74=()=>[{h:"Tab Penata",items:[it("Gradien (warna, arah)",()=>{P.openTab("gradien");modeUI();},"color"),it("Filter (cerah, kontras, blur...)",()=>P.openTab("filter"),"image")]}];
BT.push(["penata74","panel","Penata 5"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata74");
})();
