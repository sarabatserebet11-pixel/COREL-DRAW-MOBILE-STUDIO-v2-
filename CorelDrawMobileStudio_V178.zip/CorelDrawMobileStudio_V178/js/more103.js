/* V115: Navigator (peta mini). Panel kecil di sudut kanvas yang menampilkan seluruh halaman beserta kotak area yang sedang terlihat.
   Klik atau geser di peta untuk berpindah; tombol ◎ memusatkan ke objek terpilih. Tombol "Peta" di bawah kanvas menampilkan/menyembunyikan
   (pilihan diingat). Hanya tampilan: tidak mengubah objek, riwayat, atau data proyek. */
(()=>{
const S=CDMS.state,C=CDMS.Canvas,$=(s,r=document)=>r.querySelector(s);
const K="cdms-nav-off",NS="http://www.w3.org/2000/svg";
let box,svg,bg,layer,view,raf=0,off=false,drag=false;
try{off=localStorage.getItem(K)==="1";}catch(e){}

function bangun(){const area=$(".canvas-area");if(!area||$("#navMap"))return;
 box=document.createElement("div");box.id="navMap";box.className="nav-map";box.setAttribute("role","group");box.setAttribute("aria-label","Peta mini kanvas");
 box.innerHTML='<div class="nav-head"><span>Peta</span><span><button type="button" class="nav-btn" data-nav="sel" title="Pusatkan ke objek terpilih" aria-label="Pusatkan ke objek terpilih">◎</button><button type="button" class="nav-btn" data-nav="x" title="Sembunyikan peta" aria-label="Sembunyikan peta">×</button></span></div><div class="nav-body"></div>';
 area.appendChild(box);
 svg=document.createElementNS(NS,"svg");svg.setAttribute("class","nav-svg");svg.setAttribute("aria-hidden","true");
 bg=document.createElementNS(NS,"rect");layer=document.createElementNS(NS,"g");view=document.createElementNS(NS,"rect");view.setAttribute("class","nav-view");
 svg.append(bg,layer,view);$(".nav-body",box).appendChild(svg);
 svg.addEventListener("pointerdown",e=>{drag=true;try{svg.setPointerCapture(e.pointerId);}catch(x){}pindah(e);e.preventDefault();});
 svg.addEventListener("pointermove",e=>{if(drag)pindah(e);});
 const stop=()=>{drag=false;};svg.addEventListener("pointerup",stop);svg.addEventListener("pointercancel",stop);
 box.addEventListener("click",e=>{const b=e.target.closest("[data-nav]");if(!b)return;if(b.dataset.nav==="x")atur(false);else pusat();});
 const tb=document.createElement("button");tb.type="button";tb.className="btn subtle nav-toggle";tb.dataset.action="minimap";tb.textContent="Peta";tb.setAttribute("aria-pressed","true");
 const fit=$('[data-action="fit"]');if(fit)fit.insertAdjacentElement("afterend",tb);else $(".canvas-bottomline",area)&&$(".canvas-bottomline",area).appendChild(tb);
 const vp=$("#canvasViewport");if(vp)vp.addEventListener("scroll",jadwal,{passive:true});
 window.addEventListener("resize",jadwal);
 atur(!off,true);}

function atur(on,init){off=!on;if(box)box.classList.toggle("hidden",off);
 const t=$(".nav-toggle");if(t)t.setAttribute("aria-pressed",String(on));
 if(!init){try{localStorage.setItem(K,off?"1":"0");}catch(e){}}
 if(on)jadwal();}

function jadwal(){if(raf||off)return;raf=requestAnimationFrame(()=>{raf=0;gambar();});}

function gambar(){if(!box||off||!svg)return;const W=S.page.width||1080,H=S.page.height||1080;
 const maks=box.classList.contains("nav-compact")?84:132,sk=Math.min(maks/W,maks/H),w=Math.max(20,Math.round(W*sk)),h=Math.max(20,Math.round(H*sk));
 svg.setAttribute("viewBox","0 0 "+W+" "+H);svg.setAttribute("width",w);svg.setAttribute("height",h);
 bg.setAttribute("x",0);bg.setAttribute("y",0);bg.setAttribute("width",W);bg.setAttribute("height",H);bg.setAttribute("fill",S.page.background||"#fff");
 const src=$("#designObjects");layer.textContent="";
 if(src){const k=src.cloneNode(true);k.removeAttribute("id");k.querySelectorAll("[id]").forEach(n=>n.removeAttribute("id"));
  k.querySelectorAll("[tabindex]").forEach(n=>n.removeAttribute("tabindex"));k.setAttribute("pointer-events","none");layer.appendChild(k);}
 sorot();}

function sorot(){const vp=$("#canvasViewport"),cv=C&&C.svg;if(!vp||!cv||!view)return;
 const a=vp.getBoundingClientRect(),b=cv.getBoundingClientRect(),W=S.page.width||1080,H=S.page.height||1080;
 if(!b.width||!b.height){view.setAttribute("width",0);return;}
 const x0=Math.max(a.left,b.left),y0=Math.max(a.top,b.top),x1=Math.min(a.right,b.right),y1=Math.min(a.bottom,b.bottom);
 if(x1<=x0||y1<=y0){view.setAttribute("width",0);view.setAttribute("height",0);return;}
 const fx=W/b.width,fy=H/b.height;
 view.setAttribute("x",(x0-b.left)*fx);view.setAttribute("y",(y0-b.top)*fy);view.setAttribute("width",(x1-x0)*fx);view.setAttribute("height",(y1-y0)*fy);
 view.setAttribute("stroke-width",Math.max(W,H)/90);}

/* pindahkan pusat tampilan ke titik (px,py) dalam koordinat halaman */
function ke(px,py){const vp=$("#canvasViewport"),cv=C&&C.svg;if(!vp||!cv)return;
 const a=vp.getBoundingClientRect(),b=cv.getBoundingClientRect(),W=S.page.width||1080,H=S.page.height||1080;
 const tx=b.left+px/W*b.width,ty=b.top+py/H*b.height;
 vp.scrollBy({left:tx-(a.left+a.width/2),top:ty-(a.top+a.height/2),behavior:"auto"});jadwal();}

function pindah(e){const r=svg.getBoundingClientRect();if(!r.width||!r.height)return;
 const W=S.page.width||1080,H=S.page.height||1080,fx=Math.min(1,Math.max(0,(e.clientX-r.left)/r.width)),fy=Math.min(1,Math.max(0,(e.clientY-r.top)/r.height));
 ke(fx*W,fy*H);}

function pusat(){const ids=S.selectedIds&&S.selectedIds.length?S.selectedIds:(S.selected?[S.selected]:[]);
 const o=S.objects.filter(x=>ids.includes(x.id));if(!o.length)return;
 let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;o.forEach(t=>{x0=Math.min(x0,t.x);y0=Math.min(y0,t.y);x1=Math.max(x1,t.x+(t.w||0));y1=Math.max(y1,t.y+(t.h||0));});
 ke((x0+x1)/2,(y0+y1)/2);}

function mode(){if(box)box.classList.toggle("nav-compact",window.innerWidth<=720);}

document.addEventListener("click",e=>{if(e.target.closest('[data-action="minimap"]')){bangun();atur(off);}});
if(C){const r=C.render;C.render=function(){const x=r.apply(this,arguments);jadwal();return x;};
 if(C.setZoom){const z=C.setZoom;C.setZoom=function(){const x=z.apply(this,arguments);jadwal();setTimeout(jadwal,60);return x;};}}
window.addEventListener("resize",mode);
bangun();setTimeout(()=>{bangun();mode();jadwal();},400);
CDMS.Navigator={show:()=>{bangun();atur(true);},hide:()=>atur(false),center:pusat,goTo:ke};
})();
