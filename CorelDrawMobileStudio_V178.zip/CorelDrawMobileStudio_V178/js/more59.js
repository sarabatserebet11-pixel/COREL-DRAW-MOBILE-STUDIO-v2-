/* V70: tab baru Efek dan Teks di panel Penata + tombol baru di bar aksi cepat (bayangan, salin ke kanan, panel Teks) */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num,cur}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const apply=(fn,msg,filter)=>{let a=cur();if(filter)a=a.filter(filter);if(!a.length){T(filter?"Pilih teks dulu":"Pilih objek dulu");return;}Hi.snapshot();a.forEach(fn);C.render();if(msg)T(msg);};
const isT=o=>o.type==="text";
const shadow=(x,y,bl,c,o)=>apply(ob=>{ob.sh={x,y,b:bl,c,o};},"Bayangan diterapkan");
const cases={up:s=>s.toUpperCase(),low:s=>s.toLowerCase(),title:s=>s.toLowerCase().replace(/(^|\s)(\p{L})/gu,(m,a,c)=>a+c.toUpperCase())};
function ukur(o){if(CDMS.PusatTeks){const w=CDMS.PusatTeks.ukur(o);if(Math.abs(w-o.w)>1){const cx=o.x+o.w/2;o.w=w;o.x=Math.round(cx-w/2);}}}
const txt=(fn,msg)=>apply(o=>{fn(o);ukur(o);},msg,isT);
function kanan(){const a=cur();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();
 const set=new Set(a.map(o=>o.groupId?"g"+o.groupId:o.id)),src=S.objects.filter(o=>set.has(o.groupId?"g"+o.groupId:o.id)),gap=24;
 const x1=Math.min(...src.map(o=>o.x)),x2=Math.max(...src.map(o=>o.x+(o.w||0))),dx=x2-x1+gap,gm={};
 const n=src.map(o=>{const c=JSON.parse(JSON.stringify(o));c.id=crypto.randomUUID();c.x=o.x+dx;if(o.groupId)c.groupId=gm[o.groupId]||(gm[o.groupId]=crypto.randomUUID());return c;});
 S.objects.push(...n);M.pick(n);T("Disalin ke kanan");}
function togSh(){const a=cur();if(!a.length)return T("Pilih objek dulu");const has=a.some(o=>o.sh);Hi.snapshot();a.forEach(o=>{if(has)delete o.sh;else o.sh={x:0,y:8,b:16,c:"#000000",o:.3};});C.render();T(has?"Bayangan dihapus":"Bayangan lembut ditambahkan");}
const H={
 shK:()=>apply(o=>{o.sh={x:num("p70x",6),y:num("p70y",8),b:Math.max(0,num("p70b",14)),c:$("#p70c").value,o:Math.max(0,Math.min(1,num("p70o",35)/100))};},"Bayangan diterapkan"),
 shGlow:()=>apply(o=>{o.sh={x:0,y:0,b:Math.max(8,num("p70b",24)),c:$("#p70c").value,o:.9};},"Glow diterapkan"),
 shOff:()=>apply(o=>{delete o.sh;},"Bayangan dihapus"),
 olOn:()=>apply(o=>{o.stroke=$("#p70c").value;o.strokeWidth=Math.max(1,num("p70w",4));},"Garis tepi diterapkan",o=>o.type!=="image"),
 olOff:()=>apply(o=>{o.strokeWidth=0;},"Garis tepi dihapus",o=>o.type!=="image"),
 fsSet:()=>txt(o=>{o.fontSize=Math.max(6,Math.round(num("p70fs",48)));},"Ukuran huruf diatur"),
 fsUp:()=>txt(o=>{o.fontSize=Math.round(o.fontSize*1.1);},"Huruf diperbesar 10%"),
 fsDn:()=>txt(o=>{o.fontSize=Math.max(6,Math.round(o.fontSize/1.1));},"Huruf diperkecil 10%"),
 bold:()=>txt(o=>{o.bold=!o.bold;}),ital:()=>txt(o=>{o.italic=!o.italic;}),
 ls:()=>txt(o=>{o.letterSpacing=num("p70ls",2);},"Spasi huruf diatur"),
 cUp:()=>txt(o=>{o.text=cases.up(String(o.text||""));},"HURUF BESAR"),cLow:()=>txt(o=>{o.text=cases.low(String(o.text||""));},"huruf kecil"),cTit:()=>txt(o=>{o.text=cases.title(String(o.text||""));},"Huruf Judul"),
 fit:()=>txt(()=>{},"Kotak teks diukur ulang")};
P.addTab("efek","Efek",`<div class="p69row">${fld("p70x","Geser X",6)}${fld("p70y","Geser Y",8)}${fld("p70b","Blur",14,'min="0"')}${fld("p70o","Opasitas %",35,'min="0" max="100"')}<label>Warna<input id="p70c" type="color" value="#000000"></label>${fld("p70w","Tebal garis",4,'min="1"')}</div>
 <div class="p69btns c3">${b("shK","Bayangan")}${b("shGlow","Glow")}${b("shOff","Hapus")}</div>
 <div class="p69h">Garis tepi (warna di atas)</div><div class="p69btns">${b("olOn","Beri garis tepi")}${b("olOff","Hapus garis tepi")}</div>`,H);
P.addTab("teks","Teks",`<div class="p69row">${fld("p70fs","Ukuran huruf",48,'min="6"')}${fld("p70ls","Spasi huruf",2)}</div>
 <div class="p69btns c3">${b("fsSet","Atur ukuran")}${b("fsUp","A +10%")}${b("fsDn","A −10%")}</div>
 <div class="p69btns c3" style="margin-top:6px">${b("bold","Tebal")}${b("ital","Miring")}${b("ls","Atur spasi")}</div>
 <div class="p69h">Huruf</div><div class="p69btns c3">${b("cUp","BESAR")}${b("cLow","kecil")}${b("cTit","Judul")}</div>
 <div class="p69btns" style="margin-top:6px">${b("fit","Ukur ulang kotak teks")}</div>`,H);
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<button data-qz="shadow" title="Bayangan hidup/mati">${ic("layers")}</button><button data-qz="kanan" title="Salin ke kanan">${ic("copy")}</button><button data-qz="teks" title="Panel Teks">${ic("text")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-qz]");if(!x)return;const k=x.dataset.qz;if(k==="shadow")togSh();else if(k==="kanan")kanan();else P.openTab("teks");});}
MENUS.penata70=()=>[{h:"Tab Penata",items:[it("Efek (bayangan, glow, garis)",()=>P.openTab("efek"),"layers"),it("Teks (ukuran, gaya, huruf)",()=>P.openTab("teks"),"text")]},{h:"Cepat",items:[it("Salin ke kanan",kanan,"copy"),it("Bayangan hidup/mati",togSh,"layers")]}];
BT.push(["penata70","panel","Penata+"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata70");
})();
