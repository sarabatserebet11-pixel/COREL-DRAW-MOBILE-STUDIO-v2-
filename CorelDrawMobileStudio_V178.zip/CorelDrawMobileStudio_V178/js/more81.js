/* V93: 16 tombol Penata (Penata, Penata+, Penata++, Penata 3 … Penata 15) digabung jadi SATU tombol "Penata".
   Isi menu: Panel (buka/tutup), Tab Penata (semua tab dalam grid ikon), Cepat (semua aksi cepat, tanpa duplikat).
   Menu sumber tidak diubah; hanya dibaca saat menu dibuka lalu digabung. */
(()=>{
const M=CDMS.Menus;if(!M||!M.HUBS)return;
const {MENUS,BT,cell}=M,ic=n=>CDMS.Icons.svg(n);
const KEYS=["penata",...Array.from({length:15},(_,i)=>"penata"+(70+i))];
const src={};KEYS.forEach(k=>{if(typeof MENUS[k]==="function")src[k]=MENUS[k];});
if(!src.penata)return;
/* nama pendek untuk tab (tanpa keterangan dalam kurung) */
const SHORT={"Info & pilih menurut jenis/nama":"Info & pilih","Teks kontras otomatis":"Kontras teks","Palet warna harmoni":"Palet harmoni"};
const short=l=>SHORT[l]||String(l).replace(/\s*\(.*$/,"");
MENUS.penata=()=>{
 const tabs=[],cepat=[],seen=new Set();let panel=[];
 KEYS.forEach(k=>{const f=src[k];if(!f)return;let secs=[];try{secs=f();}catch(e){return;}
  secs.forEach(s=>{
   if(s.h==="Panel")panel=panel.length?panel:s.items;
   else if(s.h==="Tab Penata")s.items.forEach(x=>tabs.push(x));
   else s.items.forEach(x=>{if(seen.has(x.l))return;seen.add(x.l);cepat.push(x);});});});
 return [
  {h:"Panel",items:panel},
  {h:"Tab Penata",items:tabs.map(x=>cell(`${ic(x.i||"panel")}<span>${short(x.l)}</span>`,x.f))},
  {h:"Cepat",items:cepat}];
};
/* hapus 15 tombol tambahan dari daftar tombol & grup Objek */
const drop=new Set(KEYS.slice(1));
for(let i=BT.length-1;i>=0;i--)if(drop.has(BT[i][0]))BT.splice(i,1);
M.HUBS.forEach(h=>{for(let i=h[3].length-1;i>=0;i--)if(drop.has(h[3][i]))h[3].splice(i,1);});
KEYS.slice(1).forEach(k=>{delete MENUS[k];});
})();
