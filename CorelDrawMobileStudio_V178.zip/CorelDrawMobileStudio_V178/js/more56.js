/* V67: menu Gabung Data - satu kartu/grup jadi banyak kartu dari daftar data (satu baris = satu kartu, kolom dipisah tab, |, ; atau koma), tersusun dalam grid */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,it,tc,sels,pick,T}=M,I=CDMS.IsiKartu;
const $=s=>document.querySelector(s);
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const esc=s=>String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;");
const uid=()=>crypto.randomUUID();
function parse(txt){const L=String(txt).split("\n").map(l=>l.replace(/\r/g,"")).filter(l=>l.trim());if(!L.length)return [];
 const dl=["\t","|",";",","].find(d=>L.some(l=>l.includes(d)))||null;return L.map(l=>dl?l.split(dl).map(s=>s.trim()):[l.trim()]);}
function bbox(a){const x1=Math.min(...a.map(o=>o.x)),y1=Math.min(...a.map(o=>o.y)),x2=Math.max(...a.map(o=>o.x+(o.w||0))),y2=Math.max(...a.map(o=>o.y+(o.h||0)));return {x:x1,y:y1,w:x2-x1,h:y2-y1};}
function dialog(){const unit=I.cakupan();if(!unit.length)return T("Pilih satu kartu/grup dulu");
 const tx=I.teksGrup();if(!tx.length)return T("Kartu ini tidak punya teks untuk diisi data");
 const contoh=tx.map(o=>String(o.text||"").replace(/\n/g," ")).join(" | "),bb=bbox(unit),auto=Math.max(1,Math.floor((S.page.width+24)/(bb.w+24)));
 N.openModal("Gabung data → banyak kartu",`<div class="st-pane"><p class="muted">Kartu ini punya ${tx.length} teks (urut atas ke bawah). Tulis satu baris per kartu, kolom dipisah <b>|</b>, tab, ; atau koma. Baris pertama mengisi kartu asli.</p><label>Data<textarea id="gdT" rows="7" style="width:100%">${esc(contoh)}\n</textarea></label><div class="st-grid"><label>Kartu per baris (grid)<input id="gdC" type="number" min="1" max="12" value="${auto}"></label><label>Jarak (px)<input id="gdG" type="number" min="0" max="300" value="24"></label></div><p id="gdI" class="muted"></p><button class="btn primary" id="gdOk">Buat kartu</button></div>`);
 const upd=()=>{const r=parse($("#gdT").value);$("#gdI").textContent=r.length+" kartu akan dibuat"+(r.length>60?" (maks. 60)":"");};$("#gdT").addEventListener("input",upd);upd();
 $("#gdOk").onclick=()=>{const rows=parse($("#gdT").value).slice(0,60);if(!rows.length)return T("Isi data dulu");
  const cols=Math.max(1,Math.min(12,+$("#gdC").value||1)),gap=Math.max(0,Math.min(300,+$("#gdG").value||0));
  Hi.snapshot();const base=JSON.parse(JSON.stringify(unit)),orig=unit,order=tx.map(o=>orig.indexOf(o)),gc=I.pusatGrup(orig);
  const all=[];
  rows.forEach((row,i)=>{const dx=(i%cols)*(bb.w+gap),dy=Math.floor(i/cols)*(bb.h+gap);let objs;
   if(i===0){objs=orig;}else{const gid=uid();objs=base.map(b=>({...b,id:uid(),groupId:b.groupId?gid:undefined}));objs.forEach(o=>{if(!o.groupId)delete o.groupId;});S.objects.push(...objs);}
   if(i>0)objs.forEach(o=>{o.x=Math.round(o.x+dx);o.y=Math.round(o.y+dy);});
   const gcx=gc+(i>0?dx:0);
   order.forEach((idx,k)=>{const o=objs[idx];if(o&&k<row.length)I.setTeks(o,row[k],gcx);});
   all.push(...objs);});
  C.render();N.closeModal();pick(all);T(rows.length+" kartu dibuat"+(bb.y+Math.ceil(rows.length/cols)*(bb.h+gap)>S.page.height?" · sebagian di luar halaman, perbesar kanvas":""));};}
MENUS.gabungdata=()=>[
 {h:"Dari data",items:[it("Buat banyak kartu dari data…",dialog,"copy")]},
 {h:"Cara pakai",items:[tc("1. Pilih satu kartu/grup",()=>T("Pilih kartu siap pakai atau grup buatan Anda")),tc("2. Tulis data, satu baris per kartu",()=>T("Kolom dipisah |, tab, ; atau koma"))]}];
BT.push(["gabungdata","database","Gabung Data"]);
hubAdd("atur","gabungdata");
})();
