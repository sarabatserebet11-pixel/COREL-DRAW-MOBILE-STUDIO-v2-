/* V34: menu QR (generator QR Code vektor) dan Kalender */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,pick,T,it}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;
function ask(title,html,cb,label){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">${label||"Buat"}</button></div>`);$("#aOk").onclick=cb;}

/* ===== encoder QR (mode byte, versi 1-10, ECC L/M/Q/H) ===== */
const ECC=[[0,7,10,15,20,26,18,20,24,30,18],[0,10,16,26,18,24,16,18,22,22,26],[0,13,22,18,26,18,24,18,22,20,24],[0,17,28,22,16,22,28,26,26,24,28]],
 BLK=[[0,1,1,1,1,1,2,2,2,2,4],[0,1,1,1,2,2,4,4,4,5,5],[0,1,1,2,2,4,4,6,6,8,8],[0,1,1,2,4,4,4,5,6,8,8]];
const raw=v=>{let r=(16*v+128)*v+64;if(v>=2){const a=Math.floor(v/7)+2;r-=(25*a-10)*a-55;if(v>=7)r-=36;}return r;};
const capBits=(v,e)=>((raw(v)>>3)-ECC[e][v]*BLK[e][v])*8;
const gmul=(x,y)=>{let z=0;for(let i=7;i>=0;i--){z=(z<<1)^((z>>>7)*0x11D);z^=((y>>>i)&1)*x;}return z;};
function rsGen(d){const r=new Array(d-1).fill(0);r.push(1);let root=1;for(let i=0;i<d;i++){for(let j=0;j<r.length;j++){r[j]=gmul(r[j],root);if(j+1<r.length)r[j]^=r[j+1];}root=gmul(root,2);}return r;}
function rsRem(data,gen){const r=gen.map(()=>0);for(const b of data){const f=b^r.shift();r.push(0);gen.forEach((c,i)=>{r[i]^=gmul(c,f);});}return r;}
function makeQR(text,e){const bytes=[...new TextEncoder().encode(text)];let v=1;for(;v<=10;v++)if(4+(v<10?8:16)+8*bytes.length<=capBits(v,e))break;if(v>10)return null;
 const bb=[],put=(x,n)=>{for(let i=n-1;i>=0;i--)bb.push((x>>>i)&1);};put(4,4);put(bytes.length,v<10?8:16);bytes.forEach(b=>put(b,8));const cap=capBits(v,e);put(0,Math.min(4,cap-bb.length));put(0,(8-bb.length%8)%8);for(let p=0xEC;bb.length<cap;p^=0xEC^0x11)put(p,8);
 const data=[];for(let i=0;i<bb.length;i+=8){let x=0;for(let j=0;j<8;j++)x=(x<<1)|bb[i+j];data.push(x);}
 const nb=BLK[e][v],eb=ECC[e][v],rawCw=raw(v)>>3,nShort=nb-rawCw%nb,shortLen=Math.floor(rawCw/nb),gen=rsGen(eb),blocks=[];let k=0;
 for(let i=0;i<nb;i++){const dl=shortLen-eb+(i<nShort?0:1),d=data.slice(k,k+dl);k+=dl;const ec=rsRem(d,gen);if(i<nShort)d.push(0);blocks.push(d.concat(ec));}
 const all=[];for(let i=0;i<blocks[0].length;i++)blocks.forEach((b,j)=>{if(i!==shortLen-eb||j>=nShort)all.push(b[i]);});
 const size=v*4+17,mod=Array.from({length:size},()=>Array(size).fill(false)),fn=Array.from({length:size},()=>Array(size).fill(false)),setF=(x,y,d)=>{mod[y][x]=d;fn[y][x]=true;},bit=(x,i)=>((x>>>i)&1)!==0;
 for(let i=0;i<size;i++){setF(6,i,i%2===0);setF(i,6,i%2===0);}
 [[3,3],[size-4,3],[3,size-4]].forEach(([cx,cy])=>{for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++){const d=Math.max(Math.abs(dx),Math.abs(dy)),x=cx+dx,y=cy+dy;if(x>=0&&x<size&&y>=0&&y<size)setF(x,y,d!==2&&d!==4);}});
 const na=v>1?Math.floor(v/7)+2:0,step=v===32?26:(na?Math.ceil((v*4+4)/(na*2-2))*2:0),pos=[6];for(let p=size-7;pos.length<na;p-=step)pos.splice(1,0,p);
 for(let i=0;i<na;i++)for(let j=0;j<na;j++){if((i===0&&j===0)||(i===0&&j===na-1)||(i===na-1&&j===0))continue;for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++)setF(pos[i]+dx,pos[j]+dy,Math.max(Math.abs(dx),Math.abs(dy))!==1);}
 const fmt=m=>{const d=([1,0,3,2][e]<<3)|m;let r=d;for(let i=0;i<10;i++)r=(r<<1)^((r>>>9)*0x537);const b=((d<<10)|r)^0x5412;for(let i=0;i<=5;i++)setF(8,i,bit(b,i));setF(8,7,bit(b,6));setF(8,8,bit(b,7));setF(7,8,bit(b,8));for(let i=9;i<15;i++)setF(14-i,8,bit(b,i));for(let i=0;i<8;i++)setF(size-1-i,8,bit(b,i));for(let i=8;i<15;i++)setF(8,size-15+i,bit(b,i));setF(8,size-8,true);};
 fmt(0);
 if(v>=7){let r=v;for(let i=0;i<12;i++)r=(r<<1)^((r>>>11)*0x1F25);const b=(v<<12)|r;for(let i=0;i<18;i++){const c=bit(b,i),a=size-11+i%3,bb2=Math.floor(i/3);setF(a,bb2,c);setF(bb2,a,c);}}
 let idx=0;for(let right=size-1;right>=1;right-=2){if(right===6)right=5;for(let vert=0;vert<size;vert++)for(let j=0;j<2;j++){const x=right-j,up=((right+1)&2)===0,y=up?size-1-vert:vert;if(!fn[y][x]&&idx<all.length*8){mod[y][x]=bit(all[idx>>>3],7-(idx&7));idx++;}}}
 const MS=[(x,y)=>(x+y)%2===0,(x,y)=>y%2===0,(x,y)=>x%3===0,(x,y)=>(x+y)%3===0,(x,y)=>(Math.floor(x/3)+Math.floor(y/2))%2===0,(x,y)=>x*y%2+x*y%3===0,(x,y)=>(x*y%2+x*y%3)%2===0,(x,y)=>((x+y)%2+x*y%3)%2===0];
 const mask=m=>{for(let y=0;y<size;y++)for(let x=0;x<size;x++)if(!fn[y][x]&&MS[m](x,y))mod[y][x]=!mod[y][x];};
 const pen=()=>{let p=0;for(let y=0;y<size;y++){let run=1;for(let x=1;x<=size;x++){if(x<size&&mod[y][x]===mod[y][x-1])run++;else{if(run>=5)p+=3+run-5;run=1;}}}
  for(let x=0;x<size;x++){let run=1;for(let y=1;y<=size;y++){if(y<size&&mod[y][x]===mod[y-1][x])run++;else{if(run>=5)p+=3+run-5;run=1;}}}
  for(let y=0;y<size-1;y++)for(let x=0;x<size-1;x++)if(mod[y][x]===mod[y][x+1]&&mod[y][x]===mod[y+1][x]&&mod[y][x]===mod[y+1][x+1])p+=3;
  let dark=0;mod.forEach(r=>r.forEach(c=>{if(c)dark++;}));p+=Math.floor(Math.abs(dark*20-size*size*10)/(size*size))*10;return p;};
 let best=0,bp=1e9;for(let m=0;m<8;m++){mask(m);fmt(m);const p=pen();if(p<bp){bp=p;best=m;}mask(m);}
 mask(best);fmt(best);return{size,mod};}

/* ===== objek QR di kanvas ===== */
function addQR(text,e,fg,bg){const q=makeQR(text,e);if(!q)return T("Teks terlalu panjang untuk QR (maks sekitar 150-270 karakter)");
 const Q=4,n=q.size+2*Q;let d="";for(let y=0;y<q.size;y++){let x=0;while(x<q.size){if(q.mod[y][x]){let l=1;while(x+l<q.size&&q.mod[y][x+l])l++;d+=`M${x+Q} ${y+Q}h${l}v1h${-l}z`;x+=l;}else x++;}}
 const side=Math.round(Math.min(W(),H())*.4),x=Math.round((W()-side)/2),y=Math.round((H()-side)/2),g=uid();Hi.snapshot();
 const a={id:uid(),groupId:g,type:"rect",name:"QR latar",x,y,w:side,h:side,fill:bg,stroke:"none",strokeWidth:0,opacity:100,rotation:0},b={id:uid(),groupId:g,type:"path",name:"QR kode",x,y,w:side,h:side,vw:n,vh:n,d,fill:fg,stroke:"none",strokeWidth:0,opacity:100,rotation:0};
 S.objects.push(a,b);pick([a,b]);T("QR dibuat (versi "+((q.size-17)/4)+")");}
const esc=s=>String(s).replace(/([\\;,:"])/g,"\\$1");
const KINDS={
 url:{t:"Tautan / URL",f:[["v","Alamat tautan","https://contoh.com"]],b:v=>v.v},
 text:{t:"Teks bebas",f:[["v","Teks","Halo dari CorelDraw Mobile Studio"]],b:v=>v.v},
 wifi:{t:"Wi-Fi",f:[["s","Nama jaringan (SSID)","RumahKu"],["p","Kata sandi","rahasia123"]],b:v=>`WIFI:T:WPA;S:${esc(v.s)};P:${esc(v.p)};;`},
 wa:{t:"WhatsApp",f:[["n","Nomor (kode negara, tanpa +)","628123456789"],["m","Pesan (opsional)","Halo!"]],b:v=>`https://wa.me/${v.n.replace(/\D/g,"")}${v.m?"?text="+encodeURIComponent(v.m):""}`},
 mail:{t:"Email",f:[["a","Alamat email","nama@contoh.com"],["s","Subjek (opsional)","Halo"]],b:v=>`mailto:${v.a}${v.s?"?subject="+encodeURIComponent(v.s):""}`},
 vcard:{t:"Kontak (vCard)",f:[["n","Nama","Budi Santoso"],["t","Telepon","+628123456789"],["e","Email","budi@contoh.com"]],b:v=>`BEGIN:VCARD\nVERSION:3.0\nFN:${v.n}\nTEL:${v.t}\nEMAIL:${v.e}\nEND:VCARD`}};
function qrModal(k){const K=KINDS[k];ask("QR: "+K.t,K.f.map(f=>`<label>${f[1]}<input id="qr_${f[0]}" value="${f[2].replace(/"/g,"&quot;")}"></label>`).join("")+'<div class="st-grid"><label>Warna kode<input id="qrFg" type="color" value="#111111"></label><label>Warna latar<input id="qrBg" type="color" value="#ffffff"></label></div><label>Koreksi kesalahan<select id="qrE"><option value="0">Rendah (L)</option><option value="1" selected>Sedang (M)</option><option value="2">Tinggi (Q)</option><option value="3">Sangat tinggi (H)</option></select></label>',()=>{const v={};K.f.forEach(f=>{v[f[0]]=$("#qr_"+f[0]).value;});const txt=K.b(v);if(!txt.trim())return T("Isi datanya dulu");const fg=$("#qrFg").value,bg=$("#qrBg").value,e=+$("#qrE").value;N.closeModal();addQR(txt,e,fg,bg);});}
CDMS.QR={make:makeQR,add:addQR};
MENUS.qr=()=>[{h:"Buat QR Code",items:Object.keys(KINDS).map(k=>it(KINDS[k].t+"…",()=>qrModal(k),"barcode"))},{h:"Catatan",items:[it("QR vektor: tajam di semua ukuran dan ikut ekspor PDF",()=>{},"settings"),it("Uji dengan kamera HP sebelum dicetak",()=>{},"eye")]}];

/* ===== kalender ===== */
const BL=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"],HR=["Sen","Sel","Rab","Kam","Jum","Sab","Min"];
function grp(arr,post){Hi.snapshot();const g=uid();arr.forEach(o=>Object.assign(o,{id:uid(),groupId:g,opacity:o.opacity??100,rotation:0,stroke:o.stroke||"none",strokeWidth:o.strokeWidth||0}));S.objects.push(...arr);pick(arr);if(post){post();C.render();}}
const tx=(text,size,fill,ex)=>({type:"text",name:"Teks",text,x:0,y:0,w:50,h:30,fontSize:Math.round(size),fill,bold:true,...ex});
function calendar(){const m=+$("#kmM").value,y=+$("#kmY").value||new Date().getFullYear();N.closeModal();const first=new Date(y,m,1),days=new Date(y,m+1,0).getDate(),off=(first.getDay()+6)%7,rows=Math.ceil((off+days)/7),now=new Date();
 const cw=Math.round(W()*.84/7),ch=Math.round(Math.min(cw*.95,H()*.5/(rows+1))),gw=cw*7,x0=Math.round((W()-gw)/2),y0=Math.round(H()*.3),pad=Math.round(cw*.3),fs=Math.round(cw*.34),arr=[],pairs=[];
 arr.push({type:"rect",name:"Panel kalender",x:x0-pad,y:y0-ch*1.9,w:gw+2*pad,h:ch*(rows+1)+ch*2.2+pad,rx:28,fill:"#ffffff",stroke:"#d9deea",strokeWidth:2,fx:"shadow",fxAmount:16});
 const title=tx(BL[m]+" "+y,cw*.5,"#20243a",{name:"Judul bulan"});arr.push(title);
 HR.forEach((h,i)=>{const t=tx(h,fs*.8,i===6?"#e03131":"#8a93aa",{name:"Hari "+h});arr.push(t);pairs.push([t,x0+i*cw+cw/2,y0+ch*.5]);});
 for(let d=1;d<=days;d++){const idx=off+d-1,c=idx%7,r=Math.floor(idx/7),cx=x0+c*cw+cw/2,cy=y0+ch*(r+1.5),today=now.getFullYear()===y&&now.getMonth()===m&&now.getDate()===d;
  if(today)arr.push({type:"ellipse",name:"Hari ini",x:Math.round(cx-ch*.42),y:Math.round(cy-ch*.42),w:Math.round(ch*.84),h:Math.round(ch*.84),fill:"#6d5dfc"});
  const t=tx(String(d),fs,today?"#ffffff":(c===6?"#e03131":"#20243a"),{name:"Tanggal "+d});arr.push(t);pairs.push([t,cx,cy]);}
 grp(arr,()=>{title.x=Math.round(W()/2-title.w/2);title.y=Math.round(y0-ch*1.4);pairs.forEach(p=>{p[0].x=Math.round(p[1]-p[0].w/2);p[0].y=Math.round(p[2]-p[0].h/2);});});}
MENUS.kalender=()=>[{h:"Kalender bulanan (Senin sebagai awal minggu)",items:[it("Buat kalender…",()=>{const n=new Date();ask("Kalender",`<div class="st-grid"><label>Bulan<select id="kmM">${BL.map((b,i)=>`<option value="${i}"${i===n.getMonth()?" selected":""}>${b}</option>`).join("")}</select></label><label>Tahun<input id="kmY" type="number" value="${n.getFullYear()}"></label></div>`,calendar);},"grid")]}];

BT.push(["qr","qr","QR"],["kalender","calendar","Kalender"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("buat").push("qr");hub("pustaka").push("kalender");
})();
