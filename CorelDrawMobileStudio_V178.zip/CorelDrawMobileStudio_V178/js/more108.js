/* V122: titik halus / sudut pada editor simpul.
   - Seret titik kontrol kuning pada simpul halus: titik kontrol di seberangnya ikut lurus (panjangnya tetap), jadi lengkungan tidak patah.
     Tahan Alt (Option) saat menyeret untuk memutus keselarasan sementara.
   - Menu Simpul: "Titik terpilih jadi halus" / "jadi sudut". Klik dobel pada simpul putih = ganti halus/sudut.
   Simpul awal dan akhir yang berimpit di path tertutup dianggap satu simpul. */
(()=>{
const S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,M=CDMS.Menus,N=CDMS.Nodes,{MENUS,T,it}=M;
if(!N||!C||!MENUS||!MENUS.node)return;
const cur=()=>{const ne=S.nodeEdit;return ne?{ne,o:S.objects.find(x=>x.id===ne.id)}:{};};
const eq=(a,b)=>Math.abs(a[0]-b[0])<1e-6&&Math.abs(a[1]-b[1])<1e-6;
/* simpul n (referensi titik) dan titik kontrol seberangnya untuk simpul di indeks k */
function pair(segs,k){const last=segs.length-2,closed=segs[segs.length-1].c==="Z",cs=segs;
 const inH=(()=>{const s=cs[k];if(s&&s.c==="C")return s.p[1];if(k===0&&closed&&cs[last]&&cs[last].c==="C"&&eq(cs[0].p[0],N.anchor(cs,last)))return cs[last].p[1];return null;})();
 const outH=(()=>{const s=cs[k+1];if(s&&s.c==="C")return s.p[0];if(k===last&&closed&&cs[1]&&cs[1].c==="C"&&eq(cs[0].p[0],N.anchor(cs,last)))return cs[1].p[0];return null;})();
 return{n:N.anchor(cs,k),inH,outH};}
const smooth=(n,a,b)=>{const u=[a[0]-n[0],a[1]-n[1]],v=[b[0]-n[0],b[1]-n[1]],lu=Math.hypot(...u),lv=Math.hypot(...v);
 return lu>1e-6&&lv>1e-6&&(u[0]*v[0]+u[1]*v[1])<0&&Math.abs(u[0]*v[1]-u[1]*v[0])/(lu*lv)<.03;};
/* node dan seberang untuk handle (i,j) */
function ctlInfo(segs,i,j){const last=segs.length-2;
 if(j===1){const k=i,p=pair(segs,k);return{n:p.n,h:segs[i].p[1],opp:p.outH,k};}
 const k=i-1;if(k<0)return null;const p=pair(segs,k);return{n:p.n,h:segs[i].p[0],opp:p.inH,k};}

const pm=C.pointerMove;
C.pointerMove=function(e){const d=S.drag;
 if(d&&d.mode==="node"&&d.kind==="c"){const{ne,o}=cur();if(!ne||!o)return;const segs=ne.segs,s=segs[d.i];if(!s||s.c!=="C")return pm.call(this,e);
  const info=ctlInfo(segs,d.i,d.j);
  if(d.sm===undefined)d.sm=!!(info&&info.opp&&smooth(info.n,info.h,info.opp));
  const p=this.point(e),q=N.toLocal(o,p.x,p.y);s.p[d.j]=q;
  if(info&&info.opp&&d.sm&&!e.altKey){const u=[q[0]-info.n[0],q[1]-info.n[1]],lu=Math.hypot(...u);
   if(lu>1e-6){const L=Math.hypot(info.opp[0]-info.n[0],info.opp[1]-info.n[1]);info.opp[0]=info.n[0]-u[0]/lu*L;info.opp[1]=info.n[1]-u[1]/lu*L;}}
  o.d=N.build(segs);d.dirty=true;this.render();return;}
 pm.call(this,e);};

/* ---- perintah halus / sudut ---- */
function makeSmooth(ne,k){const segs=ne.segs,p=pair(segs,k);if(!p.inH&&!p.outH)return false;
 /* arah singgung = dari titik sebelum ke titik sesudah simpul */
 const a=p.inH||p.n,b=p.outH||p.n,t=[b[0]-a[0],b[1]-a[1]];let lt=Math.hypot(...t);
 if(lt<1e-6){const nx=segs[k+1],pv=segs[k];const A=pv&&pv.c==="C"?pv.p[0]:p.n,B=nx&&nx.c==="C"?nx.p[1]:p.n;t[0]=B[0]-A[0];t[1]=B[1]-A[1];lt=Math.hypot(...t);}
 if(lt<1e-6)return false;const ux=t[0]/lt,uy=t[1]/lt;
 const len=h=>h?Math.hypot(h[0]-p.n[0],h[1]-p.n[1]):0;
 const li=len(p.inH),lo=len(p.outH);
 if(p.inH){p.inH[0]=p.n[0]-ux*li;p.inH[1]=p.n[1]-uy*li;}
 if(p.outH){p.outH[0]=p.n[0]+ux*lo;p.outH[1]=p.n[1]+uy*lo;}
 return true;}
function makeCorner(ne,k){const segs=ne.segs,p=pair(segs,k),last=segs.length-2;
 const toward=(h,from,to)=>{if(!h)return;h[0]=from[0]+(to[0]-from[0])/3;h[1]=from[1]+(to[1]-from[1])/3;};
 let prevAnchor=null,nextAnchor=null;
 if(k>0)prevAnchor=N.anchor(segs,k-1);else if(segs[segs.length-1].c==="Z"&&last>0)prevAnchor=N.anchor(segs,last-1);
 const nx=segs[k+1];if(nx&&nx.c!=="Z"&&nx.c!=="M")nextAnchor=N.anchor(segs,k+1);else if(k===last&&segs[segs.length-1].c==="Z"&&segs[1])nextAnchor=N.anchor(segs,1);
 if(prevAnchor)toward(p.inH,p.n,prevAnchor);if(nextAnchor)toward(p.outH,p.n,nextAnchor);return !!(p.inH||p.outH);}
function apply(fn,msg){const{ne,o}=cur();if(!ne||!o||ne.sel==null)return T("Ketuk satu titik dulu");
 const k=ne.sel;if(!segs0(ne,k))return T("Titik ini belum punya lengkungan");Hi.snapshot();
 if(!fn(ne,k)){return T("Titik ini belum punya lengkungan");}
 o.d=N.build(ne.segs);N.tidy();C.render();T(msg);}
const segs0=(ne,k)=>{const p=pair(ne.segs,k);return p.inH||p.outH;};
function toggle(){const{ne}=cur();if(!ne||ne.sel==null)return;const p=pair(ne.segs,ne.sel);
 if(p.inH&&p.outH&&smooth(p.n,p.inH,p.outH))apply(makeCorner,"Titik jadi sudut");else apply(makeSmooth,"Titik jadi halus");}
document.addEventListener("dblclick",e=>{const n=e.target.closest&&e.target.closest("[data-node]");if(!n||!S.nodeEdit)return;S.nodeEdit.sel=+n.dataset.node;toggle();});

const base=MENUS.node;
MENUS.node=()=>{const r=base();r.push({h:"Titik halus / sudut",items:[it("Titik terpilih jadi halus",()=>apply(makeSmooth,"Titik jadi halus"),"pen"),it("Titik terpilih jadi sudut",()=>apply(makeCorner,"Titik jadi sudut"),"polygon")]});return r;};
CDMS.NodeSmooth={makeSmooth,makeCorner,toggle,pair,smooth};
})();
