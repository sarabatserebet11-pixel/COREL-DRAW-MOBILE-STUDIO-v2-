/* V12: perapian tombol topbar & toolbar */
(()=>{const $=s=>document.querySelector(s);
const top=$(".top-actions");
if(top&&!top.querySelector(".seg")){const u=top.querySelector('[data-action="undo"]'),r=top.querySelector('[data-action="redo"]');if(u&&r){const g=document.createElement("div");g.className="seg";u.before(g);g.append(u,r);}
 [["save","Simpan (Ctrl+S)"],["export","Ekspor desain"],["settings","Pengaturan"],["undo","Urungkan"],["redo","Ulangi"]].forEach(([a,t])=>{const b=top.querySelector(`[data-action="${a}"]`);if(b)b.title=t;});}
const tb=$(".editor-toolbar");
if(tb){["[data-tool=rect]","[data-tool=pen]","[data-action=toggleGrid]"].forEach(q=>{const b=tb.querySelector(q);if(b){const s=document.createElement("i");s.className="tb-sep";b.before(s);}});
 const p=tb.querySelector("[data-tool=pen] span");if(p)p.textContent="Pensil";}
})();
