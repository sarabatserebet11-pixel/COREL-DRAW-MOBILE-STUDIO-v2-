/* V125: grafik (batang, garis, pai) dari rentang sel terpilih di mode Excel */
(()=>{
 const $=s=>document.querySelector(s);const api=window.cdmsExcel;const modal=$('#excelChartModal');
 if(!api||!modal)return;
 const COL=['#217346','#2f7fd1','#e8a317','#c0504d','#7b5cc4','#17a2a2','#8a8f98'];
 let type='bar';
 const nf=v=>v.toLocaleString('id-ID',{maximumFractionDigits:2});
 const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 function niceMax(m){if(m<=0)return 1;const p=Math.pow(10,Math.floor(Math.log10(m))),f=m/p;return(f<=1?1:f<=2?2:f<=5?5:10)*p;}
 function data(){
  const m=api.matrix();if(!m||m.length<2&&m[0]&&m[0].length<2)return null;
  const rows=m.map(r=>r.slice());
  const isNum=v=>typeof v==='number';
  const hasHead=rows.length>1&&rows[0].slice(1).every(v=>!isNum(v)&&v!=='')&&rows.slice(1).some(r=>r.slice(1).some(isNum));
  const head=hasHead?rows.shift():null;
  const hasLab=rows.length&&rows.every(r=>!isNum(r[0]));
  const labels=rows.map((r,i)=>hasLab?String(r[0]||'#'+(i+1)):String(i+1));
  const c0=hasLab?1:0,series=[];
  for(let c=c0;c<rows[0].length;c++){const vals=rows.map(r=>isNum(r[c])?r[c]:0);if(rows.some(r=>isNum(r[c])))series.push({name:head&&head[c]!==''?String(head[c]):'Seri '+(series.length+1),vals});}
  return series.length?{labels,series}:null;
 }
 function render(){
  const d=data(),box=$('#excelChartBox');
  if(!d){box.innerHTML='<p class="ox-empty">Pilih rentang sel yang berisi angka (mis. A1:C6, dengan judul kolom dan label baris) lalu buka grafik lagi.</p>';return;}
  const W=640,H=360,L=88,R=20,T=24,B=64,pw=W-L-R,ph=H-T-B;let s=`<svg id="excelChartSvg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" font-family="Segoe UI,Arial,sans-serif" font-size="12"><rect width="${W}" height="${H}" fill="#fff"/>`;
  const n=d.labels.length;
  if(type==='pie'){
   const v=d.series[0].vals.map(x=>Math.max(0,x)),tot=v.reduce((a,b)=>a+b,0)||1;let a0=-Math.PI/2;const cx=190,cy=H/2,r=130;
   v.forEach((x,i)=>{const a1=a0+x/tot*Math.PI*2,lg=a1-a0>Math.PI?1:0;const p=x/tot>=.9999?`<circle cx="${cx}" cy="${cy}" r="${r}" fill="${COL[i%COL.length]}"/>`:`<path d="M${cx} ${cy} L${cx+r*Math.cos(a0)} ${cy+r*Math.sin(a0)} A${r} ${r} 0 ${lg} 1 ${cx+r*Math.cos(a1)} ${cy+r*Math.sin(a1)}Z" fill="${COL[i%COL.length]}" stroke="#fff" stroke-width="2"/>`;s+=p;a0=a1;
    s+=`<rect x="380" y="${40+i*24}" width="14" height="14" rx="3" fill="${COL[i%COL.length]}"/><text x="402" y="${52+i*24}" fill="#333">${esc(d.labels[i])} — ${(x/tot*100).toFixed(1).replace('.',',')}%</text>`;});
   s+=`<text x="${cx}" y="${H-12}" text-anchor="middle" fill="#555">${esc(d.series[0].name)}</text>`;
  }else{
   const max=niceMax(Math.max(...d.series.flatMap(x=>x.vals),0)),min=Math.min(0,...d.series.flatMap(x=>x.vals)),lo=min<0?-niceMax(-min):0,span=max-lo;
   const y=v=>T+ph-(v-lo)/span*ph;
   for(let i=0;i<=5;i++){const v=lo+span*i/5,yy=y(v);s+=`<line x1="${L}" x2="${W-R}" y1="${yy}" y2="${yy}" stroke="#e3e6ea"/><text x="${L-8}" y="${yy+4}" text-anchor="end" fill="#667085">${nf(+v.toPrecision(4))}</text>`;}
   const gw=pw/n;
   d.labels.forEach((lb,i)=>{const x=L+gw*i+gw/2;s+=`<text x="${x}" y="${H-B+18}" text-anchor="middle" fill="#444">${esc(lb.length>12?lb.slice(0,11)+'…':lb)}</text>`;});
   if(type==='bar'){const k=d.series.length,bw=Math.min(38,gw*.8/k);d.series.forEach((se,j)=>se.vals.forEach((v,i)=>{const x=L+gw*i+gw/2-bw*k/2+bw*j,y0=y(Math.max(v,0)),h=Math.abs(y(v)-y(0));s+=`<rect x="${x}" y="${y0}" width="${bw-2}" height="${Math.max(h,1)}" rx="3" fill="${COL[j%COL.length]}"><title>${esc(se.name)}: ${nf(v)}</title></rect>`;}));}
   else d.series.forEach((se,j)=>{const pts=se.vals.map((v,i)=>[L+gw*i+gw/2,y(v)]);s+=`<polyline fill="none" stroke="${COL[j%COL.length]}" stroke-width="3" stroke-linejoin="round" points="${pts.map(p=>p.join(',')).join(' ')}"/>`+pts.map((p,i)=>`<circle cx="${p[0]}" cy="${p[1]}" r="4.5" fill="#fff" stroke="${COL[j%COL.length]}" stroke-width="2.5"><title>${esc(se.name)}: ${nf(se.vals[i])}</title></circle>`).join('');});
   s+=`<line x1="${L}" x2="${W-R}" y1="${y(0)}" y2="${y(0)}" stroke="#9aa3ad"/>`;
   if(d.series.length>1)d.series.forEach((se,j)=>{const x=L+j*110;s+=`<rect x="${x}" y="${H-18}" width="12" height="12" rx="3" fill="${COL[j%COL.length]}"/><text x="${x+18}" y="${H-8}" fill="#333">${esc(se.name)}</text>`;});
  }
  box.innerHTML=s+'</svg>';
  document.querySelectorAll('[data-chart-type]').forEach(b=>b.classList.toggle('on',b.dataset.chartType===type));
 }
 function open(t){type=t||type;if(!api.matrix())return;modal.classList.remove('hidden');render();}
 function close(){modal.classList.add('hidden');}
 document.addEventListener('click',e=>{
  const o=e.target.closest('[data-excel-chart]');if(o){open(o.dataset.excelChart);return;}
  const t=e.target.closest('[data-chart-type]');if(t){type=t.dataset.chartType;render();return;}
  if(e.target.closest('[data-chart-close]')||e.target===modal){close();return;}
  const dl=e.target.closest('[data-chart-dl]');if(dl)download(dl.dataset.chartDl);
 });
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!modal.classList.contains('hidden'))close();});
 function download(kind){
  const svg=$('#excelChartSvg');if(!svg)return;const str=new XMLSerializer().serializeToString(svg);
  const save=(blob,n)=>{const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=n;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1500);};
  if(kind==='svg'){save(new Blob([str],{type:'image/svg+xml'}),'grafik.svg');return;}
  const img=new Image();img.onload=()=>{const c=document.createElement('canvas');c.width=1280;c.height=720;const x=c.getContext('2d');x.drawImage(img,0,0,1280,720);c.toBlob(b=>b&&save(b,'grafik.png'),'image/png');};
  img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(str);
 }
})();
