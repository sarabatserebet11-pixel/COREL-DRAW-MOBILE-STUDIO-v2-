/* V20: toolbar dirapikan jadi 6 grup menu + menu Anim (SVG animasi) & Klip (PowerClip) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,T,it,tc,cell,openMenu}=M,$=s=>document.querySelector(s),W=()=>S.page.width,H=()=>S.page.height,NS="http://www.w3.org/2000/svg";
const nm=()=>(S.projectName||"desain").replace(/[^\w-]+/g,"_");

/* ---- klip (PowerClip) ---- */
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);
 if(o.clipBy&&!o.rotation&&!o.flipH&&!o.flipV){const q=S.objects.find(x=>x.id===o.clipBy);
  if(q&&!q.clipBy){const id="cl-"+o.id,inner=om.call(this,{...q,opacity:100,locked:false}).replace(` data-id="${q.id}"`,"");
   s=s.replace("<g ",`<g mask="url(#${id})" `).replace(">",`><mask id="${id}" mask-type="alpha" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="-6000" y="-6000" width="12000" height="12000"><g transform="translate(${-o.x} ${-o.y})">${inner}</g></mask>`);}}
 return s;};
function clipSet(){const a=sels();if(a.length<2)return T("Pilih 2 objek: isi dulu, lalu bentuk pemotong (tombol Multi)");const c=a[0],m=a[1];
 if(c.rotation||c.flipH||c.flipV)return T("Objek isi harus tanpa rotasi atau balik");if(m.clipBy)return T("Pemotong tidak boleh sedang berklip");
 Hi.snapshot();c.clipBy=m.id;m.hidden=true;S.selected=c.id;S.selectedIds=[c.id];C.render();T("Klip diterapkan. Lepas klip lewat menu Klip.");}
function clipFree(){const a=sels().filter(o=>o.clipBy);if(!a.length)return T("Pilih objek yang berklip");Hi.snapshot();a.forEach(o=>{const m=S.objects.find(x=>x.id===o.clipBy);if(m)m.hidden=false;delete o.clipBy;});C.render();T("Klip dilepas");}
MENUS.klip=()=>[{h:"PowerClip",items:[it("Klip: objek 1 dipotong objek 2",clipSet,"rect"),it("Lepas klip",clipFree,"unlock")]},{h:"Cara pakai",items:[it("Pilih isi, tekan Multi, pilih bentuk pemotong",()=>{},"select")]}];

/* ---- animasi SVG ---- */
function animSvg(preview){const sv=C.svg.cloneNode(true);["#overlayLayer","#cdGuides","#cdAid"].forEach(q=>{const e=sv.querySelector(q);if(e)e.remove();});
 sv.setAttribute("xmlns",NS);sv.removeAttribute("style");if(preview){sv.removeAttribute("height");sv.setAttribute("style","width:100%;height:auto;display:block");}else{sv.setAttribute("width",W());sv.setAttribute("height",H());}
 S.objects.forEach(o=>{if(!o.anim)return;const g=sv.querySelector(`[data-id="${o.id}"]`);if(!g)return;const d=(o.animDur||3)+"s",cx=o.w/2,cy=(o.h||0)/2,op=(o.opacity??100)/100;let h="";
  if(o.anim==="spin")h=`<animateTransform attributeName="transform" type="rotate" from="0 ${cx} ${cy}" to="360 ${cx} ${cy}" dur="${d}" repeatCount="indefinite" additive="sum"/>`;
  if(o.anim==="swing")h=`<animateTransform attributeName="transform" type="rotate" values="-15 ${cx} ${cy};15 ${cx} ${cy};-15 ${cx} ${cy}" dur="${d}" repeatCount="indefinite" additive="sum"/>`;
  if(o.anim==="float")h=`<animateTransform attributeName="transform" type="translate" values="0 0;0 ${-Math.round(H()*.03)};0 0" dur="${d}" repeatCount="indefinite" additive="sum"/>`;
  if(o.anim==="blink")h=`<animate attributeName="opacity" values="${op};0.2;${op}" dur="${d}" repeatCount="indefinite"/>`;
  g.insertAdjacentHTML("beforeend",h);});
 return new XMLSerializer().serializeToString(sv);}
const setAnim=k=>edit(o=>{o.anim=k;if(!o.animDur)o.animDur=3;},"Animasi diatur. Lihat di Pratinjau animasi.");
MENUS.anim=()=>[
 {h:"Gerakan objek terpilih",items:[it("Putar",()=>setAnim("spin"),"redo"),it("Ayun",()=>setAnim("swing"),"redo"),it("Melayang",()=>setAnim("float"),"arrange"),it("Berkedip",()=>setAnim("blink"),"eye"),it("Hapus animasi",()=>edit(o=>{delete o.anim;},"Animasi dihapus"),"trash")]},
 {h:"Kecepatan",items:[["Lambat 6 dtk",6],["Normal 3 dtk",3],["Cepat 1,2 dtk",1.2]].map(x=>tc(x[0],()=>edit(o=>{o.animDur=x[1];},"",o=>!!o.anim)))},
 {h:"Hasil",items:[it("Pratinjau animasi",()=>{if(!S.objects.some(o=>o.anim))return T("Belum ada objek beranimasi");N.openModal("Pratinjau animasi",`<div style="background:#fff;border-radius:10px;overflow:hidden;border:1px solid var(--line)">${animSvg(true)}</div>`);},"eye"),it("Ekspor SVG animasi",()=>{if(!S.objects.some(o=>o.anim))return T("Belum ada objek beranimasi");CDMS.Export.download(new Blob([animSvg(false)],{type:"image/svg+xml"}),nm()+"_animasi.svg");},"export")]}];
BT.push(["anim","play","Animasi"],["klip","scissors","Klip"]);

/* ---- grup menu (hub) ---- */
const HUBS=[["buat","insert","Buat",["shapes","curve","insert","mock","chart","emo","deco"]],
 ["atur","arrange","Atur",["arrange","transform","tata","dup","sel","layer","klip"]],
 ["warna","color","Warna",["color","style","fxm","blend","pal","fmt","photo","anim"]],
 ["teks","text","Teks",["text","tsty","txu"]],
 ["kanvas","grid","Kanvas",["canvas","view","aid"]],
 ["berkas","save","Berkas",["edit","proj","exp","ver"]]];
M.HUBS=HUBS;
const B=new Proxy({},{get:(_,k)=>BT.find(b=>b[0]===k)}),LK="cdms_tb_all",showAll=()=>{try{return localStorage.getItem(LK)==="1";}catch(e){return false;}};
HUBS.forEach(h=>{MENUS["hub_"+h[0]]=()=>{const secs=[{h:h[2],items:h[3].filter(k=>B[k]).map(k=>cell(`${CDMS.Icons.svg(B[k][1])}<span>${B[k][2]}</span>`,()=>setTimeout(()=>openMenu($(`[data-menu="hub_${h[0]}"]`),k),0)))}];
 if(h[0]==="berkas")secs.push({h:"Toolbar",items:[it(showAll()?"Ringkas: tampilkan 6 grup":"Tampilkan semua tombol menu",()=>{try{localStorage.setItem(LK,showAll()?"0":"1");}catch(e){}$(".editor-toolbar").classList.toggle("show-all",showAll());},"settings")]});
 return secs;};});
const ti=CDMS.Tools.init;
CDMS.Tools.init=function(){ti.call(this);const tb=$(".editor-toolbar");if(!tb||tb.querySelector(".hub"))return;
 const first=tb.querySelector("[data-menu]");
 tb.querySelectorAll("[data-menu]").forEach(b=>b.classList.add("mn-sub"));
 if(first)first.insertAdjacentHTML("beforebegin",HUBS.map(h=>`<button class="tool has-menu hub" data-menu="hub_${h[0]}" title="${h[2]}">${CDMS.Icons.svg(h[1])}<span>${h[2]}</span><i class="chev"></i></button>`).join(""));
 if(showAll())tb.classList.add("show-all");};
})();
