/* V75: tab baru Gaya (simpan gaya objek sebagai preset bernama di perangkat, terapkan/hapus, gaya terakhir) dan Info (statistik desain, pilih menurut tipe atau nama) di panel Penata + tombol cepat simpan/terapkan gaya */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n);
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const esc=s=>String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;");
const done=m=>{C.render();if(m)T(m);};
const KEYS=["fill","stroke","strokeWidth","opacity","rx","sh","grad","dash","imgFx"],LK="cdms-p75-styles";
let mem=[];
const load=()=>{try{const v=JSON.parse(localStorage.getItem(LK)||"[]");return Array.isArray(v)?v:mem;}catch(e){return mem;}};
const save=v=>{mem=v;try{localStorage.setItem(LK,JSON.stringify(v));}catch(e){}};
const grab=o=>{const s={};KEYS.forEach(k=>{if(o[k]!==undefined)s[k]=JSON.parse(JSON.stringify(o[k]));});return s;};
function put(o,s){KEYS.forEach(k=>{if(o.type==="image"&&["fill","stroke","strokeWidth","rx","grad","dash"].includes(k))return;
 if(o.type==="line"&&(k==="fill"||k==="grad"||k==="rx"))return;if(o.type==="text"&&["grad","rx","dash","stroke","strokeWidth"].includes(k))return;
 if(k in s)o[k]=JSON.parse(JSON.stringify(s[k]));else delete o[k];});}
let last=null;
function ambil(){const a=M.sels();if(!a.length){T("Pilih objek dulu");return null;}return grab(a[0]);}
function simpan(){const s=ambil();if(!s)return;const n=($("#p75nm").value||"").trim()||("Gaya "+(load().length+1));const v=load().filter(x=>x.n!==n);v.push({n,s});save(v.slice(-30));last=s;draw();T("Gaya \""+n+"\" disimpan");}
function terap(s){const a=M.sels().filter(o=>!o.locked);if(!a.length)return T("Pilih objek dulu");Hi.snapshot();a.forEach(o=>put(o,s));done("Gaya diterapkan ke "+a.length+" objek");}
function draw(){const l=$("#p75list");if(!l)return;const v=load();l.innerHTML=v.length?v.map((x,i)=>`<div class="p75it"><button data-h="ap${i}" class="p75ap"><i style="background:${esc((x.s.grad&&x.s.grad[0])||x.s.fill||"#999")}"></i><span>${esc(x.n)}</span></button><button data-h="rm${i}" title="Hapus" class="p75rm">×</button></div>`).join(""):'<p class="muted">Belum ada gaya tersimpan.</p>';}
const H={simpan,terakhir:()=>last?terap(last):T("Belum ada gaya terakhir. Simpan dulu."),
 hapusSemua:()=>{save([]);draw();T("Semua gaya dihapus");}};
const proxyH=new Proxy(H,{get:(t,k)=>{if(k in t)return t[k];let m;if(typeof k==="string"&&(m=/^ap(\d+)$/.exec(k)))return()=>{const x=load()[+m[1]];if(x){last=x.s;terap(x.s);}};if(typeof k==="string"&&(m=/^rm(\d+)$/.exec(k)))return()=>{const v=load();v.splice(+m[1],1);save(v);draw();};return undefined;}});
/* ---- Info ---- */
const TIPE={rect:"Persegi",ellipse:"Elips",text:"Teks",image:"Gambar",path:"Kurva",line:"Garis",star:"Bintang",polygon:"Poligon"};
function stat(){const o=S.objects,c={};o.forEach(x=>{c[x.type]=(c[x.type]||0)+1;});
 const g=new Set(o.filter(x=>x.groupId).map(x=>x.groupId)).size,hid=o.filter(x=>x.hidden).length,lk=o.filter(x=>x.locked).length;
 return `<div class="p75st"><b>${o.length}</b> objek · <b>${g}</b> grup · ${hid} tersembunyi · ${lk} terkunci<br>Kanvas ${S.page.width} × ${S.page.height}<br>${Object.keys(c).map(k=>(TIPE[k]||k)+" "+c[k]).join(" · ")||"Kanvas kosong"}</div>`;}
function drawInfo(){const e=$("#p75stat");if(e)e.innerHTML=stat();}
function pilihTipe(t){const p=S.objects.filter(o=>!o.hidden&&!o.locked&&o.type===t);if(!p.length)return T("Tidak ada objek jenis itu");pick(p);T(p.length+" objek dipilih");}
function pilihNama(){const q=($("#p75q").value||"").trim().toLowerCase();if(!q)return T("Tulis nama atau isi teks dulu");
 const p=S.objects.filter(o=>!o.hidden&&!o.locked&&(String(o.name||"").toLowerCase().includes(q)||String(o.text||"").toLowerCase().includes(q)));if(!p.length)return T("Tidak ditemukan");pick(p);T(p.length+" objek dipilih");}
Object.assign(H,{pNama:pilihNama,pRect:()=>pilihTipe("rect"),pEl:()=>pilihTipe("ellipse"),pTeks:()=>pilihTipe("text"),pImg:()=>pilihTipe("image"),pPath:()=>pilihTipe("path"),pStar:()=>pilihTipe("star")});
P.addTab("gaya","Gaya",`<div class="p69row"><label>Nama gaya<input id="p75nm" type="text" placeholder="Gaya saya"></label></div>
 <div class="p69btns">${b("simpan","Simpan gaya objek pertama")}${b("terakhir","Terapkan gaya terakhir")}</div>
 <div class="p69h">Gaya tersimpan (ketuk untuk menerapkan)</div><div id="p75list" class="p75list"></div><div class="p69btns" style="margin-top:8px">${b("hapusSemua","Hapus semua gaya")}</div>
 <p class="muted" style="margin-top:8px">Gaya mencakup warna isi, garis, transparansi, sudut, bayangan, gradien, putus-putus, dan filter. Disimpan di perangkat ini.</p>`,proxyH);
P.addTab("info","Info",`<div id="p75stat"></div><div class="p69h">Pilih menurut jenis</div><div class="p69btns c4">${b("pRect","Persegi")}${b("pEl","Elips")}${b("pTeks","Teks")}${b("pImg","Gambar")}${b("pPath","Kurva")}${b("pStar","Bintang")}</div>
 <div class="p69h">Cari menurut nama / isi teks</div><div class="p69row"><label>Kata kunci<input id="p75q" type="text"></label></div><div class="p69btns">${b("pNama","Pilih yang cocok")}</div>`,proxyH);
document.addEventListener("click",e=>{const x=e.target.closest&&e.target.closest("#p75list [data-h]");if(!x)return;const f=proxyH[x.dataset.h];if(f)f();});
document.addEventListener("click",e=>{const t=e.target.closest&&e.target.closest(".p69 [data-t]");if(!t)return;if(t.dataset.t==="gaya")draw();if(t.dataset.t==="info")drawInfo();});
const rr=C.render;C.render=function(){const r=rr.apply(this,arguments);try{const on=$(".p69:not([hidden]) .p69tabs .on");if(on&&on.dataset.t==="info")drawInfo();}catch(e){}return r;};
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q5="simpan" title="Simpan gaya objek ini">${ic("save")}</button><button data-q5="terap" title="Terapkan gaya terakhir">${ic("color")}</button><button data-q5="info" title="Info & pilih">${ic("props")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q5]");if(!x)return;const k=x.dataset.q5;
  if(k==="simpan"){const s=ambil();if(!s)return;last=s;const v=load().filter(y=>y.n!=="Terakhir");v.push({n:"Terakhir",s});save(v.slice(-30));T("Gaya disimpan sebagai \"Terakhir\"");}
  else if(k==="terap"){if(last)terap(last);else{const v=load();if(v.length){last=v[v.length-1].s;terap(last);}else T("Belum ada gaya tersimpan");}}
  else{P.openTab("info");drawInfo();}});}
MENUS.penata75=()=>[{h:"Tab Penata",items:[it("Gaya tersimpan",()=>{P.openTab("gaya");draw();},"save"),it("Info & pilih menurut jenis/nama",()=>{P.openTab("info");drawInfo();},"props")]}];
BT.push(["penata75","panel","Penata 6"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata75");
})();
