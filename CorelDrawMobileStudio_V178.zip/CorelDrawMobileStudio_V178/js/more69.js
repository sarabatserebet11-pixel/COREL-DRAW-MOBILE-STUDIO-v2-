/* V80: tab baru Tabel (tabel dari teks koma/baris atau jumlah baris×kolom, header, warna selang-seling, otomatis muat halaman) dan Bagi (tata letak 2/3 kolom, 2/3 baris, grid 2×2/3×3, kombinasi besar+kecil; buat bingkai kosong atau tata objek terpilih ke dalam sel sebagai kolase) di panel Penata + tombol cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const uid=()=>crypto.randomUUID();
const val=(id,d)=>{const e=$("#"+id);return e&&e.value?e.value:d;};
const chk=(id,d)=>{const e=$("#"+id);return e?e.checked:d;};
const cl=(v,a,z)=>Math.max(a,Math.min(z,v));
const base=(t,x,y,w,h,f)=>({id:uid(),type:t,name:t[0].toUpperCase()+t.slice(1),x:Math.round(x),y:Math.round(y),w:Math.max(1,Math.round(w)),h:Math.max(1,Math.round(h)),fill:f,stroke:"#20243a",strokeWidth:0,opacity:100,rotation:0});
const bbox=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y));return{x,y,w:Math.max(...a.map(o=>o.x+(o.w||0)))-x,h:Math.max(...a.map(o=>o.y+(o.h||0)))-y};};
function units(){const seen=new Map();M.sels().forEach(o=>{if(o.locked)return;const k=o.groupId||o.id;if(!seen.has(k))seen.set(k,o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]);});return [...seen.values()].map(m=>({m,r:bbox(m)}));}
function ukur(o){const est=Math.round((o.text||"").length*o.fontSize*(o.bold?.6:.56)+8);try{if(CDMS.PusatTeks){const w=CDMS.PusatTeks.ukur(o);if(w>0)return w;}}catch(e){}return est;}
function txt(s,cx,cy,fs,col,bold,maxw){const o=base("text",0,0,10,Math.round(fs*1.3),col);o.text=s;o.fontSize=fs;o.bold=!!bold;let w=ukur(o);if(maxw&&w>maxw){o.fontSize=Math.max(8,Math.floor(fs*maxw/w));w=ukur(o);}o.h=Math.round(o.fontSize*1.3);o.w=Math.round(w);o.x=Math.round(cx-w/2);o.y=Math.round(cy-o.fontSize*.6);o.name="Teks sel";return o;}
/* ---- Tabel ---- */
function tabel(){const raw=(val("p80tx","")||"").trim();let rows,cols,data=null;
 if(raw){data=raw.split("\n").map(l=>l.split(",").map(s=>s.trim()));rows=data.length;cols=Math.max(...data.map(r=>r.length));}
 else{rows=cl(Math.round(num("p80r",4)),1,20);cols=cl(Math.round(num("p80c",3)),1,10);}
 if(rows*cols>400)return T("Terlalu banyak sel ("+rows*cols+"). Maks. 400");
 let cw=Math.max(20,num("p80cw",160)),ch=Math.max(16,num("p80ch",56)),fs=Math.max(8,num("p80fs",24));
 const k=Math.min(1,(S.page.width-60)/(cols*cw),(S.page.height-60)/(rows*ch));if(k<1){cw*=k;ch*=k;fs=Math.max(8,fs*k);}
 const hdr=chk("p80h",true)&&rows>1,cH=val("p80hd","#6d5dfc"),z1=val("p80z1","#ffffff"),z2=val("p80z2","#f1f2fb"),ln=val("p80ln","#20243a"),W=cols*cw,H=rows*ch,x0=(S.page.width-W)/2,y0=(S.page.height-H)/2,out=[],gid=uid();
 for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){const head=hdr&&r===0,f=head?cH:((r-(hdr?1:0))%2?z2:z1),x=x0+c*cw,y=y0+r*ch,cell=base("rect",x,y,cw,ch,f);cell.stroke=ln;cell.strokeWidth=2;cell.name="Sel "+(r+1)+"."+(c+1);out.push(cell);
  const s=data?(data[r][c]||""):"";if(s)out.push(txt(s,x+cw/2,y+ch/2,fs,head?"#ffffff":"#20243a",head,cw-12));}
 out.forEach(o=>{o.groupId=gid;});Hi.snapshot();S.objects.push(...out);pick(out);T("Tabel "+rows+"×"+cols+" dibuat (satu grup)"+(k<1?", dikecilkan agar muat":""));}
/* ---- Bagi ---- */
let tata="k2";
const LAY={k2:"2 kolom",k3:"3 kolom",b2:"2 baris",b3:"3 baris",g4:"Grid 2×2",g9:"Grid 3×3",m1:"Besar kiri + 2",m2:"Besar atas + 2"};
function sel(layout,A,g){const e=(n,t)=>{const s=(t-(n-1)*g)/n;return Array.from({length:n},(_,i)=>i*(s+g)).map(p=>[p,s]);};
 const col=n=>e(n,A.w).map(([p,s])=>({x:A.x+p,y:A.y,w:s,h:A.h})),row=n=>e(n,A.h).map(([p,s])=>({x:A.x,y:A.y+p,w:A.w,h:s}));
 if(layout==="k2")return col(2);if(layout==="k3")return col(3);if(layout==="b2")return row(2);if(layout==="b3")return row(3);
 if(layout==="g4"||layout==="g9"){const n=layout==="g4"?2:3,xs=e(n,A.w),ys=e(n,A.h),o=[];ys.forEach(([py,sh])=>xs.forEach(([px,sw])=>o.push({x:A.x+px,y:A.y+py,w:sw,h:sh})));return o;}
 if(layout==="m1"){const bw=(A.w-g)*.6,sw=A.w-g-bw,sh=(A.h-g)/2;return[{x:A.x,y:A.y,w:bw,h:A.h},{x:A.x+bw+g,y:A.y,w:sw,h:sh},{x:A.x+bw+g,y:A.y+sh+g,w:sw,h:sh}];}
 const bh=(A.h-g)*.6,sh=A.h-g-bh,sw=(A.w-g)/2;return[{x:A.x,y:A.y,w:A.w,h:bh},{x:A.x,y:A.y+bh+g,w:sw,h:sh},{x:A.x+sw+g,y:A.y+bh+g,w:sw,h:sh}];}
function area(pakaiPilihan){const mg=Math.max(0,num("p80mg",40));let A={x:mg,y:mg,w:S.page.width-mg*2,h:S.page.height-mg*2};
 if(pakaiPilihan&&val("p80ar","hal")==="pilih"){const u=units();if(u.length){const r=bbox(u.flatMap(x=>x.m));A={x:r.x,y:r.y,w:r.w,h:r.h};}}return A;}
const gapV=()=>Math.max(0,num("p80gp",20));
function bingkai(){const A=area(true),cs=sel(tata,A,gapV());if(A.w<40||A.h<40)return T("Area terlalu kecil");const f=val("p80f","#e4e6f5"),rx=Math.max(0,num("p80rx",16)),gid=uid(),out=cs.map((c,i)=>{const o=base("rect",c.x,c.y,c.w,c.h,f);o.rx=Math.round(Math.min(rx,c.w/2,c.h/2));o.name="Bingkai "+(i+1);o.groupId=gid;return o;});
 Hi.snapshot();const idx=val("p80ar","hal")==="pilih"?0:S.objects.length;S.objects.splice(idx,0,...out);pick(out);T(out.length+" bingkai kosong dibuat (satu grup)");}
function kolase(){const u=units();if(!u.length)return T("Pilih objek/gambar yang akan ditata ke sel");const cs=sel(tata,area(false),gapV());
 if(u.length>cs.length)T(u.length+" objek, tetapi layout hanya "+cs.length+" sel — sisanya tidak dipindah");
 Hi.snapshot();const n=Math.min(u.length,cs.length);
 for(let i=0;i<n;i++){const {m,r}=u[i],c=cs[i],k=Math.min(c.w/Math.max(1,r.w),c.h/Math.max(1,r.h)),nx=c.x+(c.w-r.w*k)/2,ny=c.y+(c.h-r.h*k)/2;
  m.forEach(o=>{o.x=Math.round(nx+(o.x-r.x)*k);o.y=Math.round(ny+(o.y-r.y)*k);if(o.w)o.w=Math.max(1,Math.round(o.w*k));if(o.h)o.h=Math.max(1,Math.round(o.h*k));if(o.fontSize)o.fontSize=Math.max(1,Math.round(o.fontSize*k));if(o.rx)o.rx=Math.round(o.rx*k);});}
 C.render();T(n+" objek ditata ke "+LAY[tata]);}
const H={tb:tabel,bg:bingkai,kl:kolase};
Object.keys(LAY).forEach(k=>{H["l_"+k]=()=>{tata=k;sUI();};});
function sUI(){document.querySelectorAll(".p69 [data-lay]").forEach(x=>x.classList.toggle("on",x.dataset.lay===tata));}
P.addTab("tabel","Tabel",`<label class="p69rg">Isi tabel (satu baris per baris, kolom dipisah koma; kosongkan untuk tabel kosong)<textarea id="p80tx" rows="4" style="width:100%;padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--panel2);color:var(--text);font:inherit;font-size:13px">Nama, Jumlah, Harga\nApel, 3, 12000\nJeruk, 5, 18000</textarea></label>
 <div class="p69row" style="margin-top:10px">${fld("p80r","Baris (jika kosong)",4,'min="1" max="20"')}${fld("p80c","Kolom (jika kosong)",3,'min="1" max="10"')}${fld("p80cw","Lebar sel",160,'min="20"')}${fld("p80ch","Tinggi sel",56,'min="16"')}${fld("p80fs","Ukuran huruf",24,'min="8"')}
 <label>Header<input id="p80hd" type="color" value="#6d5dfc"></label><label>Baris 1<input id="p80z1" type="color" value="#ffffff"></label><label>Baris 2<input id="p80z2" type="color" value="#f1f2fb"></label><label>Garis<input id="p80ln" type="color" value="#20243a"></label></div>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 8px"><input id="p80h" type="checkbox" checked> Baris pertama sebagai header</label>
 <div class="p69btns">${b("tb","Buat tabel")}</div><p class="muted" style="margin-top:8px">Tabel otomatis dikecilkan agar muat di halaman. Hasilnya satu grup (maks. 400 sel).</p>`,H);
P.addTab("bagi","Bagi",`<div class="p69btns c4">${Object.keys(LAY).map(k=>`<button data-h="l_${k}" data-lay="${k}"><span>${LAY[k]}</span></button>`).join("")}</div>
 <div class="p69row" style="margin-top:10px">${fld("p80mg","Margin",40,'min="0"')}${fld("p80gp","Jarak antar sel",20,'min="0"')}${fld("p80rx","Sudut",16,'min="0"')}<label>Warna bingkai<input id="p80f" type="color" value="#e4e6f5"></label>
 <label>Area bingkai<select id="p80ar"><option value="hal">Halaman (dengan margin)</option><option value="pilih">Objek terpilih</option></select></label></div>
 <div class="p69btns">${b("bg","Buat bingkai kosong")}${b("kl","Tata objek ke sel")}</div>
 <p class="muted" style="margin-top:8px">Kolase: pilih beberapa gambar/objek (urutan ketukan = urutan sel), pilih layout, lalu ketuk <b>Tata objek ke sel</b>. Objek diskalakan proporsional agar pas di tiap sel.</p>`,H);
document.addEventListener("click",e=>{if(e.target.closest&&e.target.closest(".p69 [data-t=bagi]"))sUI();});
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q10="tabel" title="Sisip tabel">${ic("grid")}</button><button data-q10="bagi" title="Bagi halaman">${ic("wide")}</button><button data-q10="kolase" title="Tata objek ke sel (kolase)">${ic("multi")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q10]");if(!x)return;const k=x.dataset.q10;
  if(k==="tabel")P.openTab("tabel");else if(k==="bagi"){P.openTab("bagi");sUI();}else{if(!$("#p80mg")){P.openTab("bagi");sUI();}kolase();}});}
MENUS.penata80=()=>[{h:"Tab Penata",items:[it("Tabel (dari teks atau kosong)",()=>P.openTab("tabel"),"grid"),it("Bagi (layout, bingkai, kolase)",()=>{P.openTab("bagi");sUI();},"wide")]},{h:"Cepat",items:[it("Buat tabel",tabel,"grid"),it("Buat bingkai kosong",bingkai,"wide"),it("Tata objek terpilih ke sel",kolase,"multi")]}];
BT.push(["penata80","panel","Penata 11"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata80");
})();
