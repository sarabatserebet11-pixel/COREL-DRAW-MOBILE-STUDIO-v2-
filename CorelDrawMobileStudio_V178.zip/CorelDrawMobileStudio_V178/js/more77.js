/* V89: grup menu baru "Varian" - Tema warna (8 palet; warna desain dipetakan menurut terang-gelapnya, bisa acak palet, termasuk latar halaman) dan
   Versi cepat (simpan/pulihkan/ganti nama/hapus snapshot seluruh desain di perangkat) + tab Tema & Versi di panel Penata + tombol cepat */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,P=CDMS.Penata,{MENUS,BT,it,sels,pick,T,cell}=M;
if(!M.HUBS||!P)return;
const addTab=(k,l,html,h)=>{const nh={};Object.keys(h).forEach(x=>{nh["x89_"+x]=h[x];});P.addTab(k,l,html.replace(/data-h="([^"]+)"/g,'data-h="x89_$1"'),nh);};
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),uid=()=>crypto.randomUUID(),KEY="cdms-versi-v89";
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const b=(k,l,i)=>`<button data-h="${k}">${i?ic(i):""}<span>${l}</span></button>`;
const klon=o=>JSON.parse(JSON.stringify(o));
const norm=c=>{if(typeof c!=="string")return null;c=c.trim().toLowerCase();if(/^#[0-9a-f]{6}$/.test(c))return c;if(/^#[0-9a-f]{3}$/.test(c))return"#"+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];return null;};
const rgb=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));
const lum=h=>{const p=rgb(h).map(v=>v/255).map(v=>v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4));return .2126*p[0]+.7152*p[1]+.0722*p[2];};
const expand=a=>{const g=new Set(a.filter(o=>o.groupId).map(o=>o.groupId)),s=new Set(a);S.objects.forEach(o=>{if(o.groupId&&g.has(o.groupId))s.add(o);});return[...s];};
/* ---- tema warna ---- */
const TEMA=[["Laut",["#03045e","#0077b6","#00b4d8","#90e0ef","#caf0f8"]],["Senja",["#2b0a3d","#7b2d8e","#e4572e","#ffa62b","#ffe8a3"]],["Hutan",["#1b3a2a","#2d6a4f","#52b788","#b7e4c7","#f1faee"]],["Mono",["#111111","#444444","#888888","#cccccc","#f5f5f5"]],
 ["Pastel",["#a2d2ff","#bde0fe","#ffc8dd","#ffafcc","#cdb4db"]],["Neon",["#0b0014","#7b2ff7","#f107a3","#00f5d4","#fee440"]],["Bumi",["#3d2b1f","#8c5a3c","#c68b59","#e6c9a8","#f6eedf"]],["Kontras",["#000000","#d00000","#ffba08","#3a86ff","#ffffff"]]];
let acak=false;
function sasaran(){const s=sels();if(s.length)return{objs:expand(s).filter(o=>!o.locked),halaman:false};return{objs:S.objects.filter(o=>!o.locked),halaman:true};}
function terap(idx){const{objs,halaman}=sasaran();const inc=document.getElementById("p89bg")?document.getElementById("p89bg").checked:true;
 const col=new Set();const kumpul=o=>{if(o.type==="image")return;["fill","stroke"].forEach(k=>{const c=norm(o[k]);if(c)col.add(c);});if(Array.isArray(o.grad)){[o.grad[0],o.grad[1]].forEach(c=>{c=norm(c);if(c)col.add(c);});}};
 objs.forEach(kumpul);const bg=halaman&&inc?norm(S.page.background):null;if(bg)col.add(bg);
 if(!col.size)return T("Tidak ada warna yang bisa diganti");
 let pal=[...TEMA[idx][1]];if(acak)pal.sort(()=>Math.random()-.5);else pal.sort((p,q)=>lum(p)-lum(q));
 const urut=[...col].sort((p,q)=>lum(p)-lum(q)),peta=new Map();
 urut.forEach((c,i)=>{const j=urut.length===1?Math.floor(pal.length/2):Math.round(i*(pal.length-1)/(urut.length-1));peta.set(c,acak?pal[i%pal.length]:pal[j]);});
 Hi.snapshot();let n=0;
 objs.forEach(o=>{if(o.type==="image")return;let ch=false;["fill","stroke"].forEach(k=>{const c=norm(o[k]);if(c&&peta.get(c)!==c){o[k]=peta.get(c);ch=true;}});
  if(Array.isArray(o.grad)){const g=o.grad.slice();[0,1].forEach(i=>{const c=norm(g[i]);if(c&&peta.get(c)!==c){g[i]=peta.get(c);ch=true;}});o.grad=g;}if(ch)n++;});
 if(bg&&peta.get(bg)!==bg)S.page.background=peta.get(bg);
 C.render();T("Tema “"+TEMA[idx][0]+(acak?" (acak)":"")+"” diterapkan pada "+n+" objek"+(halaman?" (seluruh desain)":""));}
function acakTema(){const i=Math.floor(Math.random()*TEMA.length),a=acak;acak=true;terap(i);acak=a;}
function drawTema(){const box=$("#p89tema");if(!box)return;box.innerHTML=TEMA.map((t,i)=>`<button data-p89t="${i}" title="${t[0]}"><span class="p89sw">${t[1].map(c=>`<i style="background:${c}"></i>`).join("")}</span><small>${t[0]}</small></button>`).join("");
 const a=$("#p89acak");if(a)a.checked=acak;}
/* ---- versi cepat ---- */
let mem=null;
const muat=()=>{if(mem)return mem;try{const j=JSON.parse(localStorage.getItem(KEY)||"[]");mem=Array.isArray(j)?j:[];}catch(e){mem=[];}return mem;};
function simpanDb(){try{localStorage.setItem(KEY,JSON.stringify(muat()));return true;}catch(e){T("Penyimpanan penuh: hapus versi lama dulu");return false;}}
function simpanVersi(){if(!S.objects.length)return T("Desain masih kosong");const nm=String(($("#p89name")||{}).value||"").trim()||"Versi "+new Date().toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit"});
 const db=muat();db.unshift({id:uid(),name:nm,t:Date.now(),n:S.objects.length,page:klon(S.page),objs:klon(S.objects.map(o=>{const c=klon(o);delete c.isoWas;return c;}))});
 const dibuang=db.length>12?db.pop():null;if(!simpanDb()){db.shift();if(dibuang)db.push(dibuang);return;}drawVersi();T("Versi “"+nm+"” disimpan"+(dibuang?" (versi terlama dibuang, maks 12)":""));}
function pulihVersi(id){const v=muat().find(x=>x.id===id);if(!v)return;Hi.snapshot();S.objects=klon(v.objs);S.page=klon(v.page);S.selected=null;S.selectedIds=[];C.render();T("Versi “"+v.name+"” dipulihkan (bisa di-undo)");}
function ubahVersi(id,fn,msg){const db=muat(),i=db.findIndex(x=>x.id===id);if(i<0)return;fn(db,i);if(simpanDb()){drawVersi();if(msg)T(msg);}}
function drawVersi(){const box=$("#p89list");if(!box)return;const db=muat();
 box.innerHTML=db.length?db.map(v=>`<div class="p89row"><div class="p89nm"><b>${esc(v.name)}</b><small>${v.n} objek · ${v.page.width}×${v.page.height} · ${new Date(v.t).toLocaleString("id-ID",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"})}</small></div><button data-p89v="load" data-i="${v.id}" title="Pulihkan">${ic("undo")}</button><button data-p89v="ren" data-i="${v.id}" title="Ganti nama (isi kolom Nama versi)">${ic("text")}</button><button data-p89v="del" data-i="${v.id}" title="Hapus">${ic("trash")}</button></div>`).join(""):'<div class="kosong">Belum ada versi. Ketuk Simpan versi untuk menyimpan keadaan desain sekarang.</div>';
 const inf=$("#p89info");if(inf)inf.textContent=db.length+"/12";}
document.addEventListener("click",e=>{const t=e.target.closest&&e.target.closest("[data-p89t]");if(t){terap(+t.dataset.p89t);return;}
 const v=e.target.closest&&e.target.closest("[data-p89v]");if(v){const id=v.dataset.i,k=v.dataset.p89v;if(k==="load")pulihVersi(id);else if(k==="del")ubahVersi(id,(d,i)=>d.splice(i,1),"Versi dihapus");
  else{const nm=String(($("#p89name")||{}).value||"").trim();if(!nm)return T("Isi Nama versi dulu");ubahVersi(id,(d,i)=>{d[i].name=nm;},"Nama diubah");}return;}
 if(e.target.closest&&e.target.closest(".p69 [data-t=tema89]"))setTimeout(drawTema,0);if(e.target.closest&&e.target.closest(".p69 [data-t=versi89]"))setTimeout(drawVersi,0);});
document.addEventListener("change",e=>{if(e.target&&e.target.id==="p89acak")acak=e.target.checked;});
const H={sv:simpanVersi,ac:acakTema,kl:()=>{const n=muat().length;if(!n)return T("Belum ada versi");if(!confirm("Hapus semua "+n+" versi tersimpan?"))return;mem=[];simpanDb();drawVersi();T("Semua versi dihapus");}};
addTab("tema89","Tema",`<p class="muted" style="margin:0 0 8px">Ketuk palet untuk mewarnai ulang pilihan, atau seluruh desain jika tidak ada pilihan. Warna dipetakan menurut terang-gelapnya sehingga kontras tetap terjaga.</p>
 <div id="p89tema" class="p89tema"></div>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:8px 0"><input id="p89acak" type="checkbox"> Acak penempatan warna palet</label>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 8px"><input id="p89bg" type="checkbox" checked> Ikut ubah latar halaman (saat seluruh desain)</label>
 <div class="p69btns">${b("ac","Tema acak","dice")}</div>`,H);
addTab("versi89","Versi",`<div class="p69h">Versi tersimpan <span id="p89info" class="muted" style="font-weight:400"></span></div>
 <div class="p69row"><label>Nama versi<input id="p89name" type="text" maxlength="40" placeholder="mis. Sebelum revisi"></label></div>
 <div class="p69btns">${b("sv","Simpan versi","save")}${b("kl","Hapus semua","trash")}</div>
 <div id="p89list" class="p89list" style="margin-top:10px"></div>
 <p class="muted" style="margin:0">Snapshot seluruh desain (objek dan halaman) tersimpan di browser perangkat ini, maksimum 12. Memulihkan bisa di-undo.</p>`,H);
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q89="tema" title="Tema warna">${ic("palette")}</button><button data-q89="acak" title="Tema acak">${ic("dice")}</button><button data-q89="versi" title="Simpan versi cepat">${ic("save")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q89]");if(!x)return;const k=x.dataset.q89;if(k==="tema"){P.openTab("tema89");drawTema();}else if(k==="acak")acakTema();else simpanVersi();});}
MENUS.var1=()=>[{h:"Tema warna",items:[...TEMA.map((t,i)=>it(t[0],()=>terap(i),"palette")),it("Tema acak",acakTema,"dice"),it("Panel Tema",()=>{P.openTab("tema89");drawTema();},"panel")]}];
MENUS.var2=()=>[{h:"Versi cepat",items:[it("Simpan versi sekarang",simpanVersi,"save"),it("Buka daftar versi",()=>{P.openTab("versi89");drawVersi();},"history"),...muat().slice(0,6).map(v=>it("Pulihkan: "+v.name,()=>pulihVersi(v.id),"undo"))]}];
BT.push(["var1","palette","Tema warna"],["var2","history","Versi cepat"]);
const VAR=["var1","var2"],ai=M.HUBS.findIndex(h=>h[0]==="koleksi");
M.HUBS.splice(ai<0?M.HUBS.length:ai+1,0,["varian","palette","Varian",VAR]);
MENUS.hub_varian=()=>[{h:"Varian",items:VAR.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($('[data-menu="hub_varian"]'),k),0));})}];
const ot=P.openTab;P.openTab=function(){const r=ot.apply(this,arguments);setTimeout(()=>{drawTema();drawVersi();},0);return r;};
})();
