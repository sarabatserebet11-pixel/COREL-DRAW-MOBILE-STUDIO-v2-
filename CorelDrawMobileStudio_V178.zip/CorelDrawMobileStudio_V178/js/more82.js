/* V94: dua grup menu baru.
   "Siap Cetak" (ikon printer): Kertas (ukuran kertas mm pada 72/96/150/300 dpi, potret/lanskap, skala isi), Tanda Potong (bleed + crop marks, bisa dihapus bersih),
   Ukuran Fisik (ukuran objek dalam mm/cm/inci, setel lebar/tinggi dalam mm).
   "Gema Warna" (ikon wavefx): Gema (salinan bertingkat membesar/mengecil/bergeser dengan opacity memudar), Tempel Grid (posisi/ukuran/titik tengah ke kelipatan grid),
   Kocok Warna (palet acak harmonis: analog, komplementer, triad, pastel, gelap, neon; putar warna antar objek). Semua aksi bisa di-undo. */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,tc,cell,sels,pick,T}=M;
if(!M.HUBS)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),uid=()=>crypto.randomUUID();
const dpi=()=>S.dpi94||150,mm=v=>v*dpi()/25.4,tomm=px=>px*25.4/dpi(),r1=v=>Math.round(v*10)/10;
const unitsOf=a=>{const seen=new Set(),out=[];a.forEach(o=>{if(seen.has(o.id))return;const m=o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o];m.forEach(p=>seen.add(p.id));out.push(m);});return out;};
const bb=a=>{let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;a.forEach(o=>{x0=Math.min(x0,o.x);y0=Math.min(y0,o.y);x1=Math.max(x1,o.x+(o.w||0));y1=Math.max(y1,o.y+(o.h||0));});return{x:x0,y:y0,w:x1-x0,h:y1-y0};};
const done=m=>{C.render();if(m)T(m);};

/* ================= SIAP CETAK ================= */
const PAPER=[["A2",420,594],["A3",297,420],["A4",210,297],["A5",148,210],["A6",105,148],["B5",176,250],["Letter",215.9,279.4],["Legal",215.9,355.6],["Kartu nama",90,55],["KTP / ID",85.6,54],["Foto 4R",101.6,152.4],["Foto 3×4",30,40],["Kartu pos",100,148],["Amplop DL",110,220]];
function setPaper(wmm,hmm){const land=!!S.land94,a=Math.min(wmm,hmm),b=Math.max(wmm,hmm),W=Math.round(mm(land?b:a)),H=Math.round(mm(land?a:b));
 if(W>8000||H>8000)return T("Terlalu besar pada "+dpi()+" dpi (maks 8000 px). Turunkan dpi.");
 Hi.snapshot();const ow=S.page.width,oh=S.page.height;
 if(S.skala94&&ow&&oh){const s=Math.min(W/ow,H/oh),dx=(W-ow*s)/2,dy=(H-oh*s)/2;S.objects.forEach(o=>{o.x=Math.round(o.x*s+dx);o.y=Math.round(o.y*s+dy);o.w=Math.max(1,Math.round(o.w*s));o.h=Math.round((o.h||0)*s);if(o.fontSize)o.fontSize=Math.max(1,Math.round(o.fontSize*s));if(o.strokeWidth)o.strokeWidth=+(o.strokeWidth*s).toFixed(2);});}
 S.page.width=W;S.page.height=H;done("Kertas "+r1(a)+" × "+r1(b)+" mm → "+W+" × "+H+" px ("+dpi()+" dpi)");}
const isMark=o=>o&&o.cm94;
function hapusTanda(diam){const mk=S.objects.filter(isMark);if(!mk.length){if(!diam)T("Tidak ada tanda potong");return false;}
 const pad=mk[0].cm94;Hi.snapshot();S.objects=S.objects.filter(o=>!isMark(o));S.objects.forEach(o=>{o.x=Math.round(o.x-pad);o.y=Math.round(o.y-pad);});S.page.width=Math.max(50,S.page.width-2*pad);S.page.height=Math.max(50,S.page.height-2*pad);S.selected=null;S.selectedIds=[];
 if(!diam)done("Tanda potong dihapus, kanvas dikembalikan");return true;}
function tandaPotong(bleedMm,garis){const had=S.objects.some(isMark);if(had)hapusTanda(true);else Hi.snapshot();
 const bleed=Math.round(mm(bleedMm)),off=Math.round(bleed+mm(.5)),len=Math.round(mm(5)),pad=Math.ceil(off+len+mm(1)),W=S.page.width,H=S.page.height,sw=Math.max(1,Math.round(dpi()/150));
 S.objects.forEach(o=>{o.x=Math.round(o.x+pad);o.y=Math.round(o.y+pad);});S.page.width=W+2*pad;S.page.height=H+2*pad;
 const x0=pad,y0=pad,x1=pad+W,y1=pad+H,mk=(x,y,w,h,n)=>({id:uid(),type:"line",name:n,x:Math.round(x),y:Math.round(y),w:Math.round(w),h:Math.round(h),stroke:"#000000",strokeWidth:sw,fill:"none",opacity:100,rotation:0,locked:true,cm94:pad}),L=[];
 [[x0,"l"],[x1,"r"]].forEach(([x,sx])=>[[y0,"t"],[y1,"b"]].forEach(([y,sy])=>{const hx=sx==="l"?x-off-len:x+off,vy=sy==="t"?y-off-len:y+off;L.push(mk(hx,y,len,0,"Tanda potong "+sy+sx+" H"));L.push(mk(x,vy,0,len,"Tanda potong "+sy+sx+" V"));}));
 if(garis)L.push({id:uid(),type:"rect",name:"Garis bleed",x:x0-bleed,y:y0-bleed,w:W+2*bleed,h:H+2*bleed,rx:0,fill:"none",stroke:"#ff2fa0",strokeWidth:sw,dash:"6 4",opacity:100,rotation:0,locked:true,cm94:pad});
 S.objects.push(...L);S.selected=null;S.selectedIds=[];done("Tanda potong dipasang · bleed "+bleedMm+" mm · kanvas +"+Math.round(pad*2)+" px");}
const fisik=px=>{const m=tomm(px);return r1(m)+" mm ("+r1(m/10)+" cm · "+r1(m/25.4)+" in)";};
function ukuranObjek(){const a=sels();if(!a.length)return T("Pilih objek dulu");const b=bb(a);T("Pilihan: "+fisik(b.w)+" × "+fisik(b.h)+" @ "+dpi()+" dpi");}
function ukuranKanvas(){T("Kanvas: "+fisik(S.page.width)+" × "+fisik(S.page.height)+" @ "+dpi()+" dpi");}
function setUkuran(mode){const a=sels();if(!a.length)return T("Pilih objek dulu");const b=bb(a);if(!(b.w>0||b.h>0))return T("Objek tidak punya ukuran");
 const q=prompt(mode==="wh"?"Lebar,tinggi dalam mm (mis. 90,55):":(mode==="w"?"Lebar baru (mm), tinggi mengikuti rasio:":"Tinggi baru (mm), lebar mengikuti rasio:"),"");if(q===null||!String(q).trim())return;
 const v=String(q).replace(",",".").split(/[;\s,x×]+/).map(parseFloat).filter(isFinite);if(!v.length||v.some(n=>n<=0))return T("Angka tidak valid");
 let fx,fy;if(mode==="wh"){if(v.length<2)return T("Isi lebar dan tinggi");fx=mm(v[0])/(b.w||1);fy=mm(v[1])/(b.h||1);}else if(mode==="w"){fx=fy=mm(v[0])/(b.w||1);}else{fx=fy=mm(v[0])/(b.h||1);}
 if(!isFinite(fx)||!isFinite(fy))return T("Tidak bisa diskalakan");Hi.snapshot();const f=Math.min(fx,fy);
 a.forEach(o=>{o.x=Math.round(b.x+(o.x-b.x)*fx);o.y=Math.round(b.y+(o.y-b.y)*fy);o.w=Math.max(1,Math.round(o.w*fx));o.h=Math.round((o.h||0)*fy);if(o.fontSize)o.fontSize=Math.max(1,Math.round(o.fontSize*f));});
 done("Ukuran diatur ("+dpi()+" dpi)");}
MENUS.kertas94=()=>[
 {h:"Resolusi (dpi)",items:[72,96,150,300].map(d=>tc(d+"",()=>{S.dpi94=d;},{keep:1,on:dpi()===d}))},
 {h:"Orientasi & isi",items:[tc("Potret",()=>{S.land94=false;},{keep:1,on:!S.land94}),tc("Lanskap",()=>{S.land94=true;},{keep:1,on:!!S.land94}),tc(S.skala94?"Isi ikut skala: ON":"Isi ikut skala: OFF",()=>{S.skala94=!S.skala94;},{keep:1,on:!!S.skala94})]},
 {h:"Ukuran kertas ("+dpi()+" dpi)",items:PAPER.map(p=>cell(`<span>${p[0]}</span><small>${p[1]}×${p[2]}</small>`,()=>setPaper(p[1],p[2])))},
 {h:"Kustom",items:[it("Ukuran kertas sendiri (mm)…",()=>{const q=prompt("Lebar,tinggi kertas dalam mm (mis. 100,150):","");if(q===null)return;const v=String(q).replace(",",".").split(/[;\s,x×]+/).map(parseFloat).filter(n=>isFinite(n)&&n>0);if(v.length<2)return T("Isi lebar dan tinggi");setPaper(v[0],v[1]);},"paper")]}];
MENUS.potong94=()=>[
 {h:"Tanda potong + bleed",items:[it("Tanda potong · bleed 3 mm",()=>tandaPotong(3,false),"cropmark"),it("Tanda potong · bleed 5 mm",()=>tandaPotong(5,false),"cropmark"),it("Tanda potong + garis bleed 3 mm",()=>tandaPotong(3,true),"cropmark"),it("Tanda potong + garis bleed 5 mm",()=>tandaPotong(5,true),"cropmark")]},
 {h:"Kembalikan",items:[it("Hapus tanda potong & kembalikan kanvas",()=>hapusTanda(false),"trash")]},
 {h:"Catatan",items:[it("Kanvas diperluas; isi desain dipindah ke tengah. Garis bleed berwarna magenta (hapus sebelum cetak final).",()=>{},"info",{keep:1})]}];
MENUS.fisik94=()=>[
 {h:"Ukur ("+dpi()+" dpi)",items:[it("Ukuran pilihan (mm · cm · in)",ukuranObjek,"caliper"),it("Ukuran kanvas (mm · cm · in)",ukuranKanvas,"canvas")]},
 {h:"Setel ukuran fisik",items:[it("Lebar (mm), rasio tetap…",()=>setUkuran("w"),"wide"),it("Tinggi (mm), rasio tetap…",()=>setUkuran("h"),"tall"),it("Lebar × tinggi (mm)…",()=>setUkuran("wh"),"resize")]}];

/* ================= GEMA WARNA ================= */
function gema(n){const a=sels().filter(o=>!o.locked);if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const ids=new Set(a.map(o=>o.id));S.objects=S.objects.filter(k=>!(k.gema94&&ids.has(k.gema94)));const dir=S.gemaDir94||"grow";let c=0;
 a.forEach(o=>{if(o.gema94)return;for(let i=n;i>=1;i--){const k=JSON.parse(JSON.stringify(o));k.id=uid();delete k.groupId;k.name=(o.name||o.type)+" gema "+i;k.gema94=o.id;k.locked=false;
  k.opacity=Math.max(3,Math.round((o.opacity??100)*(1-i/(n+1))*.7));const w=o.w||0,h=o.h||0,cx=o.x+w/2,cy=o.y+h/2;
  if(dir==="shift"){k.x=Math.round(o.x+16*i);k.y=Math.round(o.y+16*i);}
  else{const f=dir==="grow"?1+.14*i:Math.max(.12,1-.1*i);k.w=Math.max(1,Math.round(w*f));k.h=Math.round(h*f);k.x=Math.round(cx-k.w/2);k.y=Math.round(cy-k.h/2);if(k.fontSize)k.fontSize=Math.max(1,Math.round(k.fontSize*f));if(k.strokeWidth)k.strokeWidth=+(k.strokeWidth*f).toFixed(2);}
  S.objects.splice(S.objects.indexOf(o),0,k);c++;}});
 done(c?"Gema "+n+"× dibuat ("+c+" salinan)":"Pilih objek asli (bukan salinan gema)");}
function hapusGema(){const ids=new Set(sels().map(o=>o.id)),all=!ids.size,n=S.objects.filter(o=>o.gema94&&(all||ids.has(o.gema94)||ids.has(o.id))).length;if(!n)return T("Tidak ada gema");Hi.snapshot();
 S.objects=S.objects.filter(o=>!(o.gema94&&(all||ids.has(o.gema94)||ids.has(o.id))));S.selected=null;S.selectedIds=[];done(n+" salinan gema dihapus");}
const GR=[2,5,8,10,16,20,25,50];
const gr=()=>S.grid94||10;
function snapGrid(mode){const a=sels().filter(o=>!o.locked);if(!a.length)return T("Pilih objek dulu");const g=gr();Hi.snapshot();const q=v=>Math.round(v/g)*g;
 unitsOf(a).forEach(u=>{const b=bb(u);let dx=0,dy=0;
  if(mode==="center"){dx=q(b.x+b.w/2)-(b.x+b.w/2);dy=q(b.y+b.h/2)-(b.y+b.h/2);}else{dx=q(b.x)-b.x;dy=q(b.y)-b.y;}
  u.forEach(o=>{o.x=Math.round(o.x+dx);o.y=Math.round(o.y+dy);});
  if(mode==="size"&&u.length===1){const o=u[0];o.w=Math.max(g,q(o.w));o.h=o.h?Math.max(g,q(o.h)):0;}});
 done("Dirapikan ke grid "+g+" px"+(mode==="size"?" (grup hanya posisi)":""));}
MENUS.gema94=()=>[
 {h:"Arah gema",items:[["Membesar","grow"],["Mengecil","shrink"],["Bergeser","shift"]].map(x=>tc(x[0],()=>{S.gemaDir94=x[1];},{keep:1,on:(S.gemaDir94||"grow")===x[1]}))},
 {h:"Buat gema di belakang objek",items:[3,5,8].map(n=>tc(n+"×",()=>gema(n)))},
 {h:"Hapus",items:[it("Hapus gema (pilihan, atau semua)",hapusGema,"trash")]}];
MENUS.grid94=()=>[
 {h:"Kelipatan grid (px)",items:GR.map(g=>tc(g+"",()=>{S.grid94=g;},{keep:1,on:gr()===g}))},
 {h:"Tempel ke grid "+gr()+" px",items:[it("Posisi (pojok kiri-atas)",()=>snapGrid("pos"),"snapgrid"),it("Posisi + ukuran",()=>snapGrid("size"),"snapgrid"),it("Titik tengah objek",()=>snapGrid("center"),"target")]}];
const hex=(h,s,l)=>{h=((h%360)+360)%360;s/=100;l/=100;const k=n=>(n+h/30)%12,a=s*Math.min(l,1-l),f=n=>l-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)));return"#"+[f(0),f(8),f(4)].map(v=>Math.round(v*255).toString(16).padStart(2,"0")).join("");};
const rnd=(a,b)=>a+Math.random()*(b-a);
function palet(n,mode){const h=rnd(0,360),o=[];for(let i=0;i<n;i++){
 if(mode==="analog")o.push(hex(h+i*28,rnd(60,80),rnd(48,62)));
 else if(mode==="komp")o.push(hex(h+(i%2?180:0)+rnd(-10,10),rnd(55,80),rnd(42,66)));
 else if(mode==="triad")o.push(hex(h+(i%3)*120+rnd(-8,8),rnd(60,80),rnd(46,62)));
 else if(mode==="pastel")o.push(hex(h+i*47,rnd(60,78),rnd(80,88)));
 else if(mode==="gelap")o.push(hex(h+i*33,rnd(40,60),rnd(20,32)));
 else o.push(hex(h+i*61,100,rnd(52,58)));}return o;}
const MODE=[["Analog","analog"],["Komplementer","komp"],["Triad","triad"],["Pastel","pastel"],["Gelap","gelap"],["Neon","neon"]];
const mode=()=>S.palet94||"analog";
function kocok(sisi){const a=sels().filter(o=>o.type!=="image");if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const p=palet(a.length,mode());
 a.forEach((o,i)=>{if(sisi==="garis"){if(o.type==="text")return;o.stroke=p[i];if(!o.strokeWidth)o.strokeWidth=3;}else{if(o.type==="line"||o.type==="path"&&o.fill==="none"){o.stroke=p[i];}else{o.fill=p[i];delete o.grad;}}});
 done((sisi==="garis"?"Garis":"Isi")+" diacak · "+MODE.find(m=>m[1]===mode())[0]);}
function putar(){const a=sels().filter(o=>o.type!=="image"&&o.type!=="line");if(a.length<2)return T("Pilih 2 objek atau lebih");Hi.snapshot();const f=a.map(o=>o.fill);a.forEach((o,i)=>{o.fill=f[(i+1)%f.length];delete o.grad;});done("Warna isi diputar antar "+a.length+" objek");}
MENUS.kocok94=()=>[
 {h:"Gaya palet",items:MODE.map(m=>tc(m[0],()=>{S.palet94=m[1];},{keep:1,on:mode()===m[1]}))},
 {h:"Terapkan ke pilihan",items:[it("Kocok warna isi",()=>kocok("isi"),"shuffle"),it("Kocok warna garis",()=>kocok("garis"),"shuffle"),it("Putar warna isi antar objek",putar,"rotate")]}];

/* ================= daftar tombol & grup ================= */
BT.push(["kertas94","paper","Kertas"],["potong94","cropmark","Tanda Potong"],["fisik94","caliper","Ukuran Fisik"],["gema94","echo","Gema"],["grid94","snapgrid","Tempel Grid"],["kocok94","shuffle","Kocok Warna"]);
const defHub=(id,icon,nama,keys)=>{M.HUBS.splice(Math.max(M.HUBS.findIndex(h=>h[0]==="ritme")+1,0)||M.HUBS.length,0,[id,icon,nama,keys]);
 MENUS["hub_"+id]=()=>[{h:nama,items:keys.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($(`[data-menu="hub_${id}"]`),k),0));})}];};
defHub("gemawarna94","wavefx","Gema Warna",["gema94","grid94","kocok94"]);
defHub("cetak94","printer","Siap Cetak",["kertas94","potong94","fisik94"]);
CDMS.SiapCetak={setPaper,tandaPotong,hapusTanda,gema,snapGrid,kocok};
})();
