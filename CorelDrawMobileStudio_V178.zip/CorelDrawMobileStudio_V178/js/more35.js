/* V46: Bingkai (hiasan siap pakai), Layer+ (penataan lapisan), tema sistem, pasang aplikasi (PWA) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,sels,pick,T,it,tc}=M,uid=()=>crypto.randomUUID(),r0=Math.round;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const base=(t,o)=>({id:uid(),type:t,name:t,x:0,y:0,w:100,h:100,fill:"#6d5dfc",stroke:"none",strokeWidth:0,opacity:100,rotation:0,...o});
const hh=o=>o.h||0,W=()=>S.page.width,H=()=>S.page.height;
const add=(arr,msg,idx)=>{Hi.snapshot();if(idx==null)S.objects.push(...arr);else S.objects.splice(idx,0,...arr);pick(arr);if(msg)T(msg);};

/* ---- Bingkai & hiasan ---- */
const frame=(inset,w,color,rx,name)=>add([base("rect",{name:name||"Bingkai",x:inset,y:inset,w:W()-inset*2,h:H()-inset*2,fill:"none",stroke:color,strokeWidth:w,rx})],"Bingkai ditambahkan");
function card(){const a=sels();if(!a.length)return T("Pilih objek dulu");const p=28,x0=Math.min(...a.map(o=>o.x))-p,y0=Math.min(...a.map(o=>o.y))-p,x1=Math.max(...a.map(o=>o.x+o.w))+p,y1=Math.max(...a.map(o=>o.y+hh(o)))+p;
 const idx=Math.min(...a.map(o=>S.objects.indexOf(o)));const c=base("rect",{name:"Kartu",x:r0(x0),y:r0(y0),w:r0(x1-x0),h:r0(y1-y0),fill:"#ffffff",stroke:"#00000022",strokeWidth:2,rx:28});add([c],"Kartu dibuat di belakang objek",idx);pick(a);}
function badges(){const a=sels();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const z=48,out=[];
 [...a].sort((p,q)=>p.y-q.y||p.x-q.x).forEach((o,i)=>{const cx=o.x,cy=o.y;out.push(base("ellipse",{name:"Lencana "+(i+1),x:r0(cx-z/2),y:r0(cy-z/2),w:z,h:z,fill:"#ff6b6b",stroke:"#ffffff",strokeWidth:4}));
  out.push(base("text",{name:"Nomor "+(i+1),text:String(i+1),x:r0(cx-8),y:r0(cy-15),w:20,h:30,fontSize:26,fill:"#ffffff",bold:true,fontFamily:"Arial, sans-serif",_c:[cx,cy]}));});
 S.objects.push(...out);C.render();out.filter(o=>o._c).forEach(o=>{o.x=r0(o._c[0]-(o.w||0)/2);delete o._c;});C.render();pick(out);T(a.length+" lencana nomor dibuat");}
function corners(){const s=Math.round(Math.min(W(),H())*.09),m=Math.round(Math.min(W(),H())*.04),D=["M4 44V4H44","M56 4H96V44","M4 56V96H44","M96 56V96H56"],P=[[m,m],[W()-m-s,m],[m,H()-m-s],[W()-m-s,H()-m-s]];
 add(D.map((d,i)=>base("path",{name:"Sudut "+(i+1),x:P[i][0],y:P[i][1],w:s,h:s,vw:100,vh:100,d,fill:"none",stroke:"#00d6c9",strokeWidth:6})),"Sudut hiasan ditambahkan");}
function divider(v){const L=v?base("rect",{name:"Pemisah",x:r0(W()/2-2),y:r0(H()*.1),w:4,h:r0(H()*.8),fill:"#7b6cff"}):base("rect",{name:"Pemisah",x:r0(W()*.1),y:r0(H()/2-2),w:r0(W()*.8),h:4,fill:"#7b6cff"});add([L],"Garis pemisah ditambahkan");}
MENUS.bingkai=()=>[
 {h:"Bingkai halaman",items:[it("Tipis (24 px)",()=>frame(24,4,"#20243a",0),"rect"),it("Tebal (32 px)",()=>frame(32,16,"#7b6cff",0),"rect"),it("Membulat (40 px)",()=>frame(40,8,"#00d6c9",48),"rect"),it("Ganda",()=>{frame(24,3,"#20243a",0,"Bingkai luar");frame(44,3,"#20243a",0,"Bingkai dalam");},"rect")]},
 {h:"Hiasan",items:[it("Sudut siku di 4 pojok",corners,"star"),it("Garis pemisah horizontal",()=>divider(false),"line"),it("Garis pemisah vertikal",()=>divider(true),"line")]},
 {h:"Dari objek terpilih",items:[it("Kartu putih di belakang objek",card,"rect"),it("Lencana nomor di pojok kiri-atas",badges,"multi")]}];

/* ---- Layer+ ---- */
const LB={rect:"Kotak",ellipse:"Elips",text:"Teks",path:"Bentuk",image:"Gambar",line:"Garis",star:"Bintang",polygon:"Poligon",group:"Grup"};
const rename=()=>{Hi.snapshot();const n={};S.objects.forEach(o=>{const k=LB[o.type]||"Objek";n[k]=(n[k]||0)+1;o.name=k+" "+n[k];});C.render();T(S.objects.length+" objek diberi nama");};
const sortY=()=>{Hi.snapshot();S.objects=[...S.objects].sort((a,b)=>a.y+hh(a)/2-(b.y+hh(b)/2));C.render();T("Lapisan diurut dari atas ke bawah halaman");};
const rev=()=>{Hi.snapshot();S.objects=[...S.objects].reverse();C.render();T("Urutan tumpukan dibalik");};
function isolate(){const a=new Set(sels().map(o=>o.id));if(!a.size)return T("Pilih objek dulu");Hi.snapshot();S.objects.forEach(o=>{if(!a.has(o.id))o.hidden=true;});C.render();T("Mode isolasi: yang lain disembunyikan");}
function lockOthers(){const a=new Set(sels().map(o=>o.id));if(!a.size)return T("Pilih objek dulu");Hi.snapshot();S.objects.forEach(o=>{if(!a.has(o.id))o.locked=true;});C.render();T("Objek lain dikunci");}
MENUS.layer2=()=>[
 {h:"Penamaan & urutan",items:[it("Beri nama otomatis semua objek",rename,"layers"),it("Urutkan lapisan dari atas ke bawah",sortY,"layers"),it("Balik seluruh urutan tumpukan",rev,"layers")]},
 {h:"Fokus kerja",items:[it("Isolasi objek terpilih",isolate,"eye"),it("Kunci semua objek lain",lockOthers,"lock")]}];

/* ---- tema sistem & pasang aplikasi: ditambahkan ke menu yang sudah ada ---- */
const ak=MENUS.aksen;MENUS.aksen=()=>[...ak(),{h:"Tema",items:[it("Ikuti tema sistem (gelap/terang)",()=>{const t=matchMedia("(prefers-color-scheme: light)").matches?"light":"dark-neon";document.body.dataset.theme=t;try{localStorage.setItem("cdms-theme",t);}catch(e){}T("Tema: "+(t==="light"?"terang":"gelap"));},"eye")]}];
let ip=null;addEventListener("beforeinstallprompt",e=>{e.preventDefault();ip=e;});
const bn=MENUS.bantu2;MENUS.bantu2=()=>[...bn(),{h:"Aplikasi",items:[it("Pasang di layar utama (PWA)",()=>{if(ip){ip.prompt();ip=null;}else T("Buka lewat http/https, lalu pakai menu peramban: Tambahkan ke layar utama");},"save")]}];

BT.push(["bingkai","frame","Bingkai"],["layer2","layers","Layer+"]);
hubAdd("buat","bingkai");hubAdd("atur","layer2");
})();
