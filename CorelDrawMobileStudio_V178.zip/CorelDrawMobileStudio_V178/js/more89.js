/* V101: dua grup menu baru (helper bersama dari CDMS.Util97, tanpa kode duplikat).
   "Bagan" (ikon chart101): Batang (tegak / mendatar dari Nama=nilai), Progres (bilah persen), Tabel (header + baris selang-seling).
   "Pita & Tanda" (ikon deco101): Pita (banner dengan ekor + lipatan), Bintang Nilai (1-5 bintang), Panah (blok, 5 arah).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U||!U.poly||!U.ask||!U.wrap)return;
const{mix,ramp,grup,shape,text,line,finish,rnd,PAL,defHub,W,H,chips,poly}=U,R=Math.round,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const{ask,idx}=U;
/* pabrik palet: kunci state + palet bawaan -> {pal, menu}; dipakai juga oleh V102 */
const mkPal=(key,def)=>({pal:()=>PAL[PAL[S[key]]?S[key]:def],menu:()=>({h:"Palet",items:[def,...["laut","senja","hijau","biru","mono"].filter(k=>k!==def)].map(k=>tc(PAL[k].n,()=>{S[key]=k;},{keep:1,on:(S[key]||def)===k}))})}),PL=mkPal("pal101","laut"),pal=PL.pal,palMenu=PL.menu,pc=(P,t)=>ramp(P.c.slice(1),t);
/* Nama=nilai,Nama=nilai -> [[nama,angka]]; hanya angka positif yang dipakai */
const data=s=>String(s).split(",").map(p=>{const i=p.lastIndexOf("=");if(i<1)return null;const n=p.slice(0,i).trim().slice(0,10),v=parseFloat(p.slice(i+1).replace(",","."));return n&&isFinite(v)&&v>0?[n,v]:null;}).filter(Boolean);
const fmt=v=>String(Math.round(v*10)/10);
/* panel putih berpojok bulat sebagai alas agar teks selalu terbaca di latar apa pun */
const panel=(w,h)=>{const m=Math.min(w,h)*.06;return{x:m,y:m,w:w-2*m,h:h-2*m,o:shape("rect",m,m,w-2*m,h-2*m,"#ffffff",{name:"Panel",rx:R(m*.5),stroke:"#e5e7eb",strokeWidth:2})};};
const tx=(s,cx,y,fs,col,o)=>text(s,cx-s.length*fs*.3,y,fs,col,o);

/* ================= BAGAN ================= */
const ORI=[["Tegak","v"],["Mendatar","h"]];
function batang(){const q=ask("Data (Nama=nilai, pisahkan koma; 2-8 data):","Jan=40,Feb=65,Mar=50,Apr=80");if(q===null)return;const D=data(q).slice(0,8);if(D.length<2)return T("Butuh minimal 2 data (Nama=nilai)");Hi.snapshot();
 const P=pal(),w=W(),h=H(),pn=panel(w,h),n=D.length,mx=Math.max(...D.map(d=>d[1])),fs=R(clamp(Math.min(pn.w,pn.h)*.04,9,36)),pd=Math.min(pn.w,pn.h)*.06,hor=(S.bgO101||"v")==="h",out=[pn.o];
 if(!hor){const px=pn.x+pd,pw=pn.w-2*pd,base=pn.y+pn.h-pd-fs*1.6,top=pn.y+pd+fs*1.8,sl=pw/n,bw=sl*.6;
  out.push(line(px,base,pw,0,"#9ca3af",2,{name:"Sumbu"}));
  D.forEach((d,i)=>{const bh=Math.max(2,(base-top)*d[1]/mx),bx=px+i*sl+(sl-bw)/2,by=base-bh,col=pc(P,n>1?i/(n-1):0);
   out.push(shape("rect",bx,by,bw,bh,col,{name:"Batang "+(i+1),rx:R(bw*.12)}),tx(fmt(d[1]),bx+bw/2,by-fs*1.4,fs,"#1f2937",{name:"Nilai "+(i+1),bold:true}),tx(d[0],px+i*sl+sl/2,base+fs*.5,fs,"#374151",{name:"Label "+(i+1)}));});}
 else{const lw=Math.max(...D.map(d=>d[0].length))*fs*.6+fs*.6,px=pn.x+pd+lw,pw=pn.w-2*pd-lw-fs*3.2,py=pn.y+pd,ph=pn.h-2*pd,sl=ph/n,bh=sl*.6;
  out.push(line(px,py,0,ph,"#9ca3af",2,{name:"Sumbu"}));
  D.forEach((d,i)=>{const bw=Math.max(2,pw*d[1]/mx),by=py+i*sl+(sl-bh)/2,col=pc(P,n>1?i/(n-1):0);
   out.push(shape("rect",px,by,bw,bh,col,{name:"Batang "+(i+1),rx:R(bh*.12)}),text(fmt(d[1]),px+bw+fs*.4,by+bh/2-fs*.55,fs,"#1f2937",{name:"Nilai "+(i+1),bold:true}),text(d[0],px-fs*.4-d[0].length*fs*.6,by+bh/2-fs*.55,fs,"#374151",{name:"Label "+(i+1)}));});}
 finish(grup(out,"Bagan batang"),"Bagan batang "+n+" data ("+(hor?"mendatar":"tegak")+")");}
MENUS.brg101=()=>[palMenu(),{h:"Arah",items:ORI.map(x=>tc(x[0],()=>{S.bgO101=x[1];},{keep:1,on:(S.bgO101||"v")===x[1]}))},{h:"Buat",items:[it("Buat bagan batang dari data…",batang,"bar101")]}];

function progres(){const q=ask("Data persen (Nama=0-100, pisahkan koma; 1-6 data):","Desain=85,Kode=60,Tes=40");if(q===null)return;const D=data(q).slice(0,6).map(d=>[d[0],clamp(d[1],0,100)]);if(!D.length)return T("Data kosong (Nama=persen)");Hi.snapshot();
 const P=pal(),w=W(),h=H(),pn=panel(w,h),n=D.length,fs=R(clamp(Math.min(pn.w,pn.h)*.045,9,36)),pd=Math.min(pn.w,pn.h)*.07,x0=pn.x+pd,tw=pn.w-2*pd,rh=Math.min((pn.h-2*pd)/n,fs*4.2),y0=pn.y+(pn.h-rh*n)/2,th=Math.max(8,fs*.9),out=[pn.o];
 D.forEach((d,i)=>{const y=y0+i*rh+rh*.12,col=pc(P,n>1?i/(n-1):0),fw=tw*d[1]/100;
  out.push(text(d[0],x0,y,fs,"#1f2937",{name:"Label "+(i+1),bold:true}),tx(fmt(d[1])+"%",x0+tw-fs*1.2,y,fs,"#374151",{name:"Persen "+(i+1)}),
   shape("rect",x0,y+fs*1.5,tw,th,"#e5e7eb",{name:"Jalur "+(i+1),rx:R(th/2)}));
  if(fw>=2)out.push(shape("rect",x0,y+fs*1.5,Math.max(fw,th),th,col,{name:"Isi "+(i+1),rx:R(th/2)}));});
 finish(grup(out,"Bilah progres"),"Progres "+n+" bilah");}
MENUS.prg101=()=>[palMenu(),{h:"Buat",items:[it("Buat bilah progres dari data…",progres,"progress101")]}];

function tabel(){const P=pal(),w=W(),h=H(),r=S.tbR101||4,c=S.tbC101||3;Hi.snapshot();
 const pn=panel(w,h),pd=Math.min(pn.w,pn.h)*.05,tw=pn.w-2*pd,rh=Math.min((pn.h-2*pd)/r,tw/c*.6),th=rh*r,x0=pn.x+pd,y0=pn.y+(pn.h-th)/2,cw=tw/c,fs=R(clamp(Math.min(cw*.14,rh*.38),8,28)),out=[pn.o];
 for(let i=0;i<r;i++)out.push(shape("rect",x0,y0+i*rh,tw,rh,i===0?pc(P,0):i%2?"#f3f4f6":"#ffffff",{name:i===0?"Header":"Baris "+i}));
 for(let j=1;j<c;j++)out.push(line(x0+j*cw,y0,0,th,"#d1d5db",2,{name:"Kolom "+j}));
 for(let i=1;i<=r;i++)out.push(line(x0,y0+i*rh,tw,0,"#d1d5db",2,{name:"Garis "+i}));
 for(let j=0;j<c;j++)out.push(text("Kolom "+(j+1),x0+j*cw+cw*.1,y0+rh/2-fs*.55,fs,"#ffffff",{name:"Judul "+(j+1),bold:true}));
 for(let i=1;i<r;i++)out.push(text("Baris "+i,x0+cw*.1,y0+i*rh+rh/2-fs*.55,fs,"#374151",{name:"Sel "+i+".1"}));
 finish(grup(out,"Tabel"),"Tabel "+r+"×"+c+" (isi sel lewat Teks)");}
MENUS.tbl101=()=>[palMenu(),chips("Baris",[3,4,6,8],"tbR101",4),chips("Kolom",[2,3,4,5],"tbC101",3),{h:"Buat",items:[it("Buat tabel di tengah halaman",tabel,"table101")]}];

/* ================= PITA & TANDA ================= */
const PW=[["Merah","#dc2626"],["Biru","#2563eb"],["Hijau","#16a34a"],["Emas","#d97706"]];
function pita(){const q=ask("Teks pita (maks 24 huruf):","PROMO SPESIAL");if(q===null)return;const t=q.slice(0,24);if(!t)return T("Teks kosong");Hi.snapshot();
 const w=W(),h=H(),col=PW[S.ptW101||0][1],dk=mix(col,"#000000",.25),dk2=mix(col,"#000000",.42),L=t.length,
  fs=Math.max(8,Math.min(Math.min(w,h)*.07,w*.92/(L*.6+5.48))),bw=L*fs*.6+fs*2.4,bh=fs*2.2,tl=bh*.7,of=bh*.28,fold=of*.9,
  x0=w/2-bw/2,y0=h/2-bh/2-of/2,out=[];
 out.push(poly([[x0-tl,y0+of],[x0+fold,y0+of],[x0+fold,y0+bh+of],[x0-tl,y0+bh+of],[x0-tl+tl*.38,y0+bh/2+of]],dk,"Ekor kiri"),
  poly([[x0+bw+tl,y0+of],[x0+bw-fold,y0+of],[x0+bw-fold,y0+bh+of],[x0+bw+tl,y0+bh+of],[x0+bw+tl-tl*.38,y0+bh/2+of]],dk,"Ekor kanan"),
  poly([[x0,y0+bh],[x0+fold,y0+bh],[x0+fold,y0+bh+of]],dk2,"Lipatan kiri"),
  poly([[x0+bw,y0+bh],[x0+bw-fold,y0+bh],[x0+bw-fold,y0+bh+of]],dk2,"Lipatan kanan"),
  shape("rect",x0,y0,bw,bh,col,{name:"Pita"}),
  tx(t,w/2,y0+bh/2-fs*.55,fs,"#ffffff",{name:"Teks pita",bold:true}));
 finish(grup(out,"Pita"),"Pita dipasang: "+t);}
MENUS.pit101=()=>[idx("Warna",PW,"ptW101",0),{h:"Buat",items:[it("Buat pita di tengah halaman…",pita,"banner101")]}];

function bintang(){const w=W(),h=H(),n=S.bnN101??4,sz=Math.min(w*.84/5,h*.5),gap=sz*.08,tot=5*sz+4*gap,x0=(w-tot)/2,cy=h/2-sz*.15,out=[];Hi.snapshot();
 for(let i=0;i<5;i++){const cx=x0+i*(sz+gap)+sz/2,ro=sz/2,ri=ro*.42,pts=[];
  for(let k=0;k<10;k++){const a=-Math.PI/2+k*Math.PI/5,r=k%2?ri:ro;pts.push([cx+r*Math.cos(a),cy+r*Math.sin(a)*1+ro*.06]);}
  out.push(poly(pts,i<n?"#fbbf24":"#d1d5db","Bintang "+(i+1),{stroke:i<n?"#d97706":"#9ca3af",strokeWidth:Math.max(2,R(sz*.03))}));}
 const fs=R(Math.max(10,sz*.32)),s=n+" dari 5";out.push(tx(s,w/2,cy+sz*.62,fs,"#374151",{name:"Nilai",bold:true}));
 finish(grup(out,"Bintang nilai"),"Bintang nilai "+n+"/5");}
MENUS.bnt101=()=>[chips("Nilai (bintang)",[1,2,3,4,5],"bnN101",4),{h:"Buat",items:[it("Pasang bintang nilai di tengah",bintang,"star101")]}];

const AG=[["Kanan",0],["Bawah",90],["Kiri",180],["Atas",270],["Ganda","d"]],AW=[["Merah","#ef4444"],["Biru","#3b82f6"],["Hijau","#22c55e"],["Hitam","#111827"]],AZ=[["Kecil",.3],["Sedang",.5],["Besar",.75]];
function panah(){const w=W(),h=H(),g=AG[S.pnG101??0][1],col=AW[S.pnW101||0][1],ang=(g==="d"?0:g)*Math.PI/180,L=Math.min(w,h)*AZ[S.pnZ101??1][1]*1.3,t=L*.28,
  loc=g==="d"?[[-L/2,0],[-L*.25,-t],[-L*.25,-t*.5],[L*.25,-t*.5],[L*.25,-t],[L/2,0],[L*.25,t],[L*.25,t*.5],[-L*.25,t*.5],[-L*.25,t]]
   :[[-L/2,-t*.5],[L*.1,-t*.5],[L*.1,-t],[L/2,0],[L*.1,t],[L*.1,t*.5],[-L/2,t*.5]],
  ca=Math.cos(ang),sa=Math.sin(ang),pts=loc.map(p=>[w/2+p[0]*ca-p[1]*sa,h/2+p[0]*sa+p[1]*ca]);Hi.snapshot();
 finish(grup([poly(pts,col,"Panah")],"Panah"),"Panah "+AG[S.pnG101??0][0].toLowerCase()+" dipasang");}
MENUS.pnh101=()=>[idx("Arah",AG,"pnG101",0),idx("Warna",AW,"pnW101",0),idx("Ukuran",AZ,"pnZ101",1),{h:"Buat",items:[it("Pasang panah di tengah halaman",panah,"arrow101")]}];

/* ================= tombol & grup ================= */
BT.push(["brg101","bar101","Batang"],["prg101","progress101","Progres"],["tbl101","table101","Tabel"],["pit101","banner101","Pita"],["bnt101","star101","Bintang Nilai"],["pnh101","arrow101","Panah"]);
defHub("bagan101","chart101","Bagan",["brg101","prg101","tbl101"]);
defHub("tanda101","deco101","Pita & Tanda",["pit101","bnt101","pnh101"]);
Object.assign(U,{data,fmt,panel,tx,clamp,mkPal});
CDMS.Bagan101={batang,progres,tabel,pita,bintang,panah};
})();
