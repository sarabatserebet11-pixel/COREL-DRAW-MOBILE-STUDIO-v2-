window.CDMS = window.CDMS || {};
CDMS.state = {mode:"mobile",theme:"dark-neon",tool:"select",selected:null,objects:[],zoom:100,history:[],future:[],page:{width:1080,height:1080,background:"#ffffff"},projectName:"Desain tanpa judul",drag:null};
document.addEventListener("DOMContentLoaded",()=>{
  const bar=document.getElementById("loadingBar"); let n=0;
  const timer=setInterval(()=>{n+=10;bar.style.width=n+"%";if(n>=100){clearInterval(timer);document.getElementById("splash").classList.add("hidden");document.getElementById("app").classList.remove("hidden");CDMS.Storage.init();CDMS.Canvas.init();CDMS.Navigation.init();CDMS.Tools.init();CDMS.Layers.render();CDMS.Navigation.renderRecents();}},55);
});
