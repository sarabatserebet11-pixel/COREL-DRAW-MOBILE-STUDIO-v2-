/* V40 (2/2): Tampil+, Lanjutan, Cari & Favorit, perbaikan */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,sels,pick,T,it,tc,cell,box,nr}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;
function ask(title,html,cb,label){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">${label||"Buat"}</button></div>`);$("#aOk").onclick=cb;}
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);

/* ---- Tampil+ : mode lihat (tidak ikut ekspor) ---- */
const CM={cvdP:".567 .433 0 0 0 .558 .442 0 0 0 0 .242 .758 0 0 0 0 0 1 0",cvdD:".625 .375 0 0 0 .7 .3 0 0 0 0 .3 .7 0 0 0 0 0 1 0",cvdT:".95 .05 0 0 0 0 .433 .567 0 0 0 .475 .525 0 0 0 0 0 1 0",cvdG:".33 .33 .33 0 0 .33 .33 .33 0 0 .33 .33 .33 0 0 0 0 0 1 0",cvdK:"1.6 0 0 0 -.3 0 1.6 0 0 -.3 0 0 1.6 0 -.3 0 0 0 1 0"};
function setV(m){if(!$("#cdCvd"))document.body.insertAdjacentHTML("beforeend",`<svg id="cdCvd" width="0" height="0" style="position:absolute" aria-hidden="true">${Object.keys(CM).map(k=>`<filter id="${k}" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="${CM[k]}"/></filter>`).join("")}</svg>`);
 const w=$("#cdWire");if(w)w.remove();C.svg.style.filter="";S.viewMode=m;
 if(m==="wire")document.head.insertAdjacentHTML("beforeend",'<style id="cdWire">#designObjects *{fill:none!important;stroke:#00d6c9!important;stroke-width:1.5px!important;vector-effect:non-scaling-stroke}#designObjects image{opacity:.18}#pageBackground{fill:#0b1020!important}</style>');
 else if(CM[m])C.svg.style.filter=`url(#${m})`;}
const VM=[["Normal","normal"],["Kerangka (wireframe)","wire"],["Abu-abu","cvdG"],["Kontras tinggi","cvdK"],["Buta warna merah (protan)","cvdP"],["Buta warna hijau (deutan)","cvdD"],["Buta warna biru (tritan)","cvdT"]];
MENUS.view2=()=>[{h:"Mode lihat (hanya di layar, tidak ikut ekspor)",items:VM.map(v=>tc(v[0],()=>setV(v[1]),{keep:1,on:(S.viewMode||"normal")===v[1]}))},{h:"Gunanya",items:[it("Uji apakah desain tetap terbaca tanpa warna",()=>{},"eye")]}];

/* ---- Lanjutan ---- */
const mk=(t,o)=>({id:uid(),type:t,name:t,x:0,y:0,w:100,h:100,fill:"#6d5dfc",stroke:"none",strokeWidth:0,opacity:100,rotation:0,...o});
function dupAdv(){const a=sels();if(!a.length)return T("Pilih objek dulu");
 ask("Duplikat lanjutan",`<div class="st-grid"><label>Jumlah salinan<input id="dN" type="number" value="5" min="1" max="60"></label><label>Geser X<input id="dX" type="number" value="60"></label><label>Geser Y<input id="dY" type="number" value="0"></label><label>Putar per salinan (°)<input id="dR" type="number" value="0"></label></div><label>Skala per salinan (%)<input id="dS" type="number" value="100"></label>`,()=>{
 const n=Math.min(60,Math.max(1,+$("#dN").value||1)),dx=+$("#dX").value||0,dy=+$("#dY").value||0,dr=+$("#dR").value||0,sc=Math.max(.05,(+$("#dS").value||100)/100);N.closeModal();Hi.snapshot();const out=[];
 for(let i=1;i<=n;i++){const f=Math.pow(sc,i),gm={};a.forEach(o=>{const c={...o,id:uid()};if(c.groupId)c.groupId=gm[c.groupId]||(gm[c.groupId]=uid());const cx=o.x+o.w/2+dx*i,cy=o.y+(o.h||0)/2+dy*i;c.w=Math.max(1,Math.round(o.w*f));if(o.h)c.h=Math.round(o.h*f);if(o.fontSize)c.fontSize=Math.max(4,Math.round(o.fontSize*f));c.x=Math.round(cx-c.w/2);c.y=Math.round(cy-(c.h||0)/2);c.rotation=nr((o.rotation||0)+dr*i);out.push(c);});}
 S.objects.push(...out);pick(out);T(out.length+" salinan dibuat");},"Buat salinan");}
function wrap(kind){const a=sels();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const b=box(a),p=36,w=b.x1-b.x0+p*2,h=b.y1-b.y0+p*2,z=Math.round(Math.max(w,h));
 const o=kind==="circle"?mk("ellipse",{x:Math.round((b.x0+b.x1)/2-z/2),y:Math.round((b.y0+b.y1)/2-z/2),w:z,h:z}):mk("rect",{x:b.x0-p,y:b.y0-p,w:Math.round(w),h:Math.round(h),rx:kind==="pill"?Math.round(h/2):28});
 Object.assign(o,{name:"Kartu pembungkus",fill:"#f1f3ff",stroke:"#6d5dfc",strokeWidth:3});S.objects.splice(Math.min(...a.map(x=>S.objects.indexOf(x))),0,o);pick([o,...a]);}
function fit(m){const a=sels();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const b=box(a),bw=b.x1-b.x0||1,bh=b.y1-b.y0||1,f=m==="w"?W()/bw:m==="h"?H()/bh:m==="cover"?Math.max(W()/bw,H()/bh):Math.min(W()*.9/bw,H()*.9/bh),bx=(b.x0+b.x1)/2,by=(b.y0+b.y1)/2;
 a.forEach(o=>{const cx=W()/2+(o.x+o.w/2-bx)*f,cy=H()/2+(o.y+(o.h||0)/2-by)*f;o.w=Math.max(1,Math.round(o.w*f));if(o.h)o.h=Math.round(o.h*f);if(o.fontSize)o.fontSize=Math.max(4,Math.round(o.fontSize*f));o.x=Math.round(cx-o.w/2);o.y=Math.round(cy-(o.h||0)/2);});C.render();}
MENUS.adv=()=>[{h:"Duplikat dengan pola",items:[it("Duplikat lanjutan… (jumlah, geser, putar, skala)",dupAdv,"dup")]},{h:"Bungkus objek terpilih dengan latar",items:[it("Kartu sudut halus",()=>wrap("card"),"rect"),it("Kartu pil",()=>wrap("pill"),"rect"),it("Lingkaran",()=>wrap("circle"),"shapes")]},{h:"Skala terpilih ke halaman (jaga rasio, dipusatkan)",items:[it("Penuhi lebar halaman",()=>fit("w"),"transform"),it("Penuhi tinggi halaman",()=>fit("h"),"transform"),it("Isi seluruh halaman (cover)",()=>fit("cover"),"transform"),it("Muat dengan margin 5%",()=>fit("fit"),"transform")]}];

/* ---- Cari & Favorit ---- */
const LS=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d;}catch(e){return d;}},SV=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}};
const has=k=>BT.some(b=>b[0]===k),lab=k=>(BT.find(b=>b[0]===k)||[])[2]||k,anchor=()=>$('[data-menu="hub_cari"]');
const rec=k=>{if(has(k))SV("cdms_recent",[k,...LS("cdms_recent",[]).filter(x=>x!==k)].slice(0,8));};
document.addEventListener("click",e=>{const b=e.target.closest("[data-menu]");if(b&&!/^hub_/.test(b.dataset.menu))return rec(b.dataset.menu);const c=e.target.closest(".mn-pop .mn-cell"),h=document.querySelector(".has-menu.open");
 if(c&&h&&/^hub_/.test(h.dataset.menu)&&h.dataset.menu!=="hub_cari"){const t=((c.querySelector("span")||{}).textContent||"").trim(),f=BT.find(x=>x[2]===t);if(f)rec(f[0]);}},true);
const opener=k=>()=>{rec(k);setTimeout(()=>M.openMenu(anchor(),k),0);};
const mcell=k=>cell(`${CDMS.Icons.svg(BT.find(b=>b[0]===k)[1])}<span>${lab(k)}</span>`,opener(k));
function index(){const r=[];BT.forEach(b=>{r.push({k:b[0],t:b[2],m:1});try{MENUS[b[0]]().forEach(s=>s.items.forEach(x=>{const t=(x.l||(x.cell||"").replace(/<[^>]+>/g,"")).trim();if(t&&t.length<56)r.push({k:b[0],t,s:b[2]});}));}catch(e){}});return r;}
function search(){const idx=index();N.openModal("Cari fitur",`<div class="st-pane"><input id="qS" type="search" placeholder="Contoh: bayangan, QR, pola, filter…" autocomplete="off"><div id="qR" class="st-grid" style="grid-template-columns:1fr"></div></div>`);
 const inp=$("#qS"),box_=$("#qR");let res=[];
 const draw=()=>{const q=inp.value.trim().toLowerCase(),pins=LS("cdms_pins",[]);res=(q?idx.filter(x=>x.t.toLowerCase().includes(q)||(x.s||"").toLowerCase().includes(q)).sort((a,b)=>(b.m?1:0)-(a.m?1:0)):idx.filter(x=>x.m)).slice(0,40);
  box_.innerHTML=res.map((x,i)=>`<div style="display:flex;gap:6px"><button class="btn subtle" data-i="${i}" style="flex:1;justify-content:flex-start;text-align:left">${x.m?"▣ ":""}${x.t}${x.s?` <small style="opacity:.6">· ${x.s}</small>`:""}</button>${x.m?`<button class="btn subtle" data-p="${x.k}" style="width:48px" aria-label="Sematkan">${pins.includes(x.k)?"★":"☆"}</button>`:""}</div>`).join("")||'<p class="st-note">Tidak ditemukan.</p>';};
 box_.onclick=e=>{const p=e.target.closest("[data-p]"),b=e.target.closest("[data-i]");if(p){const a=LS("cdms_pins",[]),k=p.dataset.p;SV("cdms_pins",a.includes(k)?a.filter(x=>x!==k):[...a,k]);draw();}else if(b){const x=res[+b.dataset.i];N.closeModal();rec(x.k);setTimeout(()=>M.openMenu(anchor(),x.k),0);}};
 inp.oninput=draw;draw();inp.focus();}
MENUS.hub_cari=()=>{const pin=LS("cdms_pins",[]).filter(has),rc=LS("cdms_recent",[]).filter(has),s=[{h:"Cari",items:[it("Cari fitur atau menu…",()=>setTimeout(search,0),"search")]},{h:"Disematkan (☆ di hasil pencarian)",items:pin.length?pin.map(mcell):[it("Belum ada, sematkan lewat pencarian",()=>setTimeout(search,0),"star")]}];if(rc.length)s.push({h:"Terakhir dipakai",items:rc.map(mcell)});return s;};
M.HUBS.splice(0,0,["cari","search","Cari",[]]);

BT.push(["view2","eye","Tampil+"],["adv","tools","Lanjutan"]);hubAdd("kanvas","view2");hubAdd("atur","adv");

/* ---- perbaikan: pemandu & mode lihat tidak bocor ke desain/proyek lain ---- */
["newDocument","loadProject"].forEach(n=>{const f=C[n];if(typeof f!=="function")return;C[n]=function(){S.guidesU=[];if(S.viewMode&&S.viewMode!=="normal")setV("normal");return f.apply(this,arguments);};});
})();
