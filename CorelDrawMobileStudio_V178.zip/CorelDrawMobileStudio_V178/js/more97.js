/* V109: tampilan gaya Office (Word / Excel / PowerPoint): bilah judul, tab pita, satu baris tombol per tab.
   Tombol dan menu lama tidak diubah; hanya dikelompokkan ke tab. Grup yang belum terdaftar masuk tab "Lainnya". */
(()=>{
const TABS=[
 ["beranda","Beranda",["tool:select","tool:rect","tool:ellipse","tool:star","tool:line","tool:polygon","tool:pen","tool:text","tool:image","tool:eraser","tool:pan","act:arrange","act:toggleMulti","hub:atur","hub:kelompok","hub:warna","hub:teks"]],
 ["sisip","Sisip",["hub:buat","hub:pustaka","hub:ilustrasi105","hub:tanda101","hub:kartu99","hub:hiasbingkai98","hub:aksenteks97","hub:alat105","hub:catatan100","hub:seru100"]],
 ["grafik","Grafik",["hub:bagan101","hub:grafik106","hub:datavisual96","hub:infog99","hub:struktur107","hub:diagram102","hub:media108","hub:geometri96","hub:pola106","hub:polalatar98","hub:polalembar95","hub:lanskap97"]],
 ["dokumen","Dokumen",["hub:dokumen108","hub:perencana104","hub:umum104","hub:acara107","hub:sosmed103","hub:perangkat103","hub:tipo102","hub:anotasi95","hub:cetak94"]],
 ["tampilan","Tampilan",["act:toggleGrid","hub:kanvas","hub:isolasi","hub:cari","hub:periksa","hub:gemawarna94","hub:berkas"]]
];
const keyOf=e=>e.dataset.tool?"tool:"+e.dataset.tool:e.dataset.action?"act:"+e.dataset.action:(e.dataset.menu||"").startsWith("hub_")?"hub:"+e.dataset.menu.slice(4):"";
const get=()=>{try{return localStorage.getItem("cdms-tab")||"beranda";}catch(e){return "beranda";}};
function build(){const ed=document.querySelector(".editor"),tb=document.querySelector(".editor-toolbar");if(!ed||!tb||ed.querySelector(".ribbon-tabs"))return;
 const kids=[...tb.children].filter(e=>keyOf(e)),known=new Set(TABS.flatMap(t=>t[2])),rest=kids.filter(e=>!known.has(keyOf(e))&&e.dataset.menu&&e.dataset.menu.startsWith("hub_")).map(keyOf),tabs=TABS.map(t=>[t[0],t[1],t[2]]);
 if(rest.length)tabs.push(["lainnya","Lainnya",rest]);
 const bar=document.createElement("div");bar.className="ribbon-tabs";bar.setAttribute("role","tablist");
 bar.innerHTML=tabs.map(t=>`<button class="ribbon-tab" role="tab" data-rtab="${t[0]}">${t[1]}</button>`).join("");
 ed.insertBefore(bar,tb);document.body.classList.add("office");
 const show=id=>{if(!tabs.find(t=>t[0]===id))id="beranda";const t=tabs.find(x=>x[0]===id),idx={};t[2].forEach((k,i)=>idx[k]=i);
  [...tb.children].forEach(e=>{if(e.classList.contains("tb-sep")){e.classList.add("rb-off");return;}const k=keyOf(e),on=k&&k in idx;e.classList.toggle("rb-off",!on);if(on)e.style.order=idx[k];});
  bar.querySelectorAll(".ribbon-tab").forEach(b=>{const a=b.dataset.rtab===id;b.classList.toggle("active",a);b.setAttribute("aria-selected",a);});
  tb.dataset.tab=id;tb.scrollLeft=0;try{localStorage.setItem("cdms-tab",id);}catch(e){}};
 bar.addEventListener("click",e=>{const b=e.target.closest(".ribbon-tab");if(b)show(b.dataset.rtab);});
 show(get());}
/* tema terang sebagai bawaan bila pengguna belum memilih tema */
try{if(!localStorage.getItem("cdms-theme"))document.body.dataset.theme="light";}catch(e){}
const ti=CDMS.Tools.init;CDMS.Tools.init=function(){ti.call(this);build();};
if(document.querySelector(".editor-toolbar .hub"))build();
})();
