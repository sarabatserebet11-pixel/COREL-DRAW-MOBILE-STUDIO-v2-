/* V22: menu Konektor, Filter (SVG filter + mode campur), Kode (barcode, penomoran, tanggal) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;
function ask(title,html,cb){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">Buat</button></div>`);$("#aOk").onclick=cb;}
const txt=(text,x,y,size,fill,x2)=>({type:"text",name:"Teks",text,x:Math.round(x),y:Math.round(y),w:50,h:30,fontSize:Math.round(size),fill,...x2});
function grp(arr,post){Hi.snapshot();const g=uid();arr.forEach(o=>Object.assign(o,{id:uid(),groupId:g,opacity:o.opacity??100,rotation:o.rotation||0,stroke:o.stroke||"none",strokeWidth:o.strokeWidth||0}));S.objects.push(...arr);pick(arr);if(post){post();C.render();}}

/* ---- renderer: filter SVG & mode campur ---- */
const F=(id,body)=>`<filter id="${id}" x="-20%" y="-20%" width="140%" height="140%">${body}</filter>`,CT=v=>`<feComponentTransfer><feFuncR type="discrete" tableValues="${v}"/><feFuncG type="discrete" tableValues="${v}"/><feFuncB type="discrete" tableValues="${v}"/></feComponentTransfer>`;
const FXS={
 sketch:id=>F(id,'<feTurbulence type="fractalNoise" baseFrequency=".035" numOctaves="2" seed="3" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="7" xChannelSelector="R" yChannelSelector="G"/>'),
 ripple:id=>F(id,'<feTurbulence type="fractalNoise" baseFrequency=".012" numOctaves="1" seed="8" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="22" xChannelSelector="R" yChannelSelector="G"/>'),
 poster:id=>F(id,CT("0 .33 .66 1")),
 duo:id=>F(id,'<feColorMatrix type="matrix" values=".33 .33 .33 0 0 .33 .33 .33 0 0 .33 .33 .33 0 0 0 0 0 1 0"/><feComponentTransfer><feFuncR type="table" tableValues="0.2 1"/><feFuncG type="table" tableValues="0.05 0.45"/><feFuncB type="table" tableValues="0.5 0.8"/></feComponentTransfer>'),
 emboss:id=>F(id,'<feConvolveMatrix order="3" kernelMatrix="-2 -1 0 -1 1 1 0 1 2" preserveAlpha="true"/>'),
 mblur:id=>F(id,'<feGaussianBlur stdDeviation="10 0"/>'),
 grain:id=>F(id,'<feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" result="n"/><feColorMatrix in="n" type="saturate" values="0"/><feComponentTransfer result="g"><feFuncA type="linear" slope=".3"/></feComponentTransfer><feComposite in="g" in2="SourceGraphic" operator="in" result="gi"/><feMerge><feMergeNode in="SourceGraphic"/><feMergeNode in="gi"/></feMerge>')};
M.FXS=FXS;
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);const k=o.svgfx;
 if(k&&FXS[k]){const id="sf-"+o.id;s=s.includes('style="filter:')?s.replace('style="filter:',`style="filter:url(#${id}) `):s.replace('style="cursor:',`style="filter:url(#${id});cursor:`);s=s.replace(">",`><defs>${FXS[k](id)}</defs>`);}
 if(o.bm&&o.bm!=="normal")s=s.replace('style="',`style="mix-blend-mode:${o.bm};`);
 return s;};
MENUS.sfx=()=>[
 {h:"Filter SVG (objek terpilih)",items:[["Sketsa tangan","sketch"],["Riak air","ripple"],["Posterisasi","poster"],["Duotone","duo"],["Emboss","emboss"],["Blur gerak","mblur"],["Grain film","grain"]].map(x=>it(x[0],()=>edit(o=>{o.svgfx=x[1];},"Filter diterapkan"),"studio")).concat([it("Hapus filter SVG",()=>edit(o=>{delete o.svgfx;},"Filter dihapus"),"trash")])},
 {h:"Mode campur",items:[["Normal","normal"],["Multiply","multiply"],["Screen","screen"],["Overlay","overlay"],["Soft light","soft-light"],["Difference","difference"],["Exclusion","exclusion"],["Hue","hue"],["Luminosity","luminosity"],["Darken","darken"],["Lighten","lighten"]].map(x=>tc(x[0],()=>edit(o=>{if(x[1]==="normal")delete o.bm;else o.bm=x[1];})))}];

/* ---- konektor ---- */
S.connArrow=true;
function connect(kind){const a=sels();if(a.length<2)return T("Pilih 2 objek (tombol Multi): dari → ke");const A=a[0],B=a[1],ac=[A.x+A.w/2,A.y+(A.h||0)/2],bc=[B.x+B.w/2,B.y+(B.h||0)/2],dx=bc[0]-ac[0],dy=bc[1]-ac[1],horiz=Math.abs(dx)>=Math.abs(dy);
 const p0=horiz?[dx>0?A.x+A.w:A.x,ac[1]]:[ac[0],dy>0?A.y+(A.h||0):A.y],p1=horiz?[dx>0?B.x:B.x+B.w,bc[1]]:[bc[0],dy>0?B.y:B.y+(B.h||0)],mx=(p0[0]+p1[0])/2,my=(p0[1]+p1[1])/2;
 let pts=[p0,p1],dir=[p0,p1],cmd;
 if(kind==="elbow"){pts=horiz?[p0,[mx,p0[1]],[mx,p1[1]],p1]:[p0,[p0[0],my],[p1[0],my],p1];dir=[pts[2],p1];}
 if(kind==="curve"){const c1=horiz?[mx,p0[1]]:[p0[0],my],c2=horiz?[mx,p1[1]]:[p1[0],my];pts=[p0,c1,c2,p1];dir=[c2,p1];}
 const ang=Math.atan2(dir[1][1]-dir[0][1],dir[1][0]-dir[0][0]),hd=[ang+Math.PI-.45,ang+Math.PI+.45].map(t=>[p1[0]+26*Math.cos(t),p1[1]+26*Math.sin(t)]),all=S.connArrow?[...pts,...hd]:pts,
 minX=Math.min(...all.map(p=>p[0])),minY=Math.min(...all.map(p=>p[1])),w=Math.max(1,Math.round(Math.max(...all.map(p=>p[0]))-minX)),h=Math.max(1,Math.round(Math.max(...all.map(p=>p[1]))-minY)),r=p=>(p[0]-minX).toFixed(1)+" "+(p[1]-minY).toFixed(1);
 if(kind==="curve")cmd=`M${r(p0)}C${r(pts[1])} ${r(pts[2])} ${r(p1)}`;else cmd="M"+pts.map(r).join("L");
 if(S.connArrow)cmd+=`M${r(hd[0])}L${r(p1)}L${r(hd[1])}`;
 Hi.snapshot();const o={id:uid(),type:"path",name:"Konektor",x:Math.round(minX),y:Math.round(minY),w,h,vw:w,vh:h,d:cmd,fill:"none",stroke:"#20243a",strokeWidth:4,opacity:100,rotation:0};S.objects.push(o);pick([o]);}
MENUS.conn=()=>[{h:"Hubungkan objek 1 → objek 2",items:[it("Garis lurus",()=>connect("line"),"line"),it("Garis siku",()=>connect("elbow"),"line"),it("Garis lengkung",()=>connect("curve"),"line")]},
 {h:"Ujung",items:[it((S.connArrow?"✓ ":"")+"Kepala panah",()=>{S.connArrow=!S.connArrow;T(S.connArrow?"Panah aktif":"Panah mati");},"redo")]}];

/* ---- kode: barcode, penomoran, tanggal ---- */
const L=["0001101","0011001","0010011","0111101","0100011","0110001","0101111","0111011","0110111","0001011"],G=["0100111","0110011","0011011","0100001","0011101","0111001","0000101","0010001","0001001","0010111"],R=L.map(s=>[...s].map(c=>c==="0"?"1":"0").join("")),PAR=["LLLLLL","LLGLGG","LLGGLG","LLGGGL","LGLLGG","LGGLLG","LGGGLL","LGLGLG","LGLGGL","LGGLGL"];
function ean(){const d=String($("#bcN").value).replace(/\D/g,"");if(d.length<12)return T("Isi 12 atau 13 angka");const b12=d.slice(0,12),sum=[...b12].reduce((a,c,i)=>a+(+c)*(i%2?3:1),0),full=b12+((10-sum%10)%10);N.closeModal();
 let bits="101";const par=PAR[+full[0]];for(let i=1;i<=6;i++)bits+=(par[i-1]==="L"?L:G)[+full[i]];bits+="01010";for(let i=7;i<=12;i++)bits+=R[+full[i]];bits+="101";
 const bw=Math.round(W()*.5),m=bw/113,h=Math.round(bw*.4),x0=Math.round((W()-bw)/2),y0=Math.round((H()-h*1.4)/2),bx=x0+9*m,arr=[{type:"rect",name:"Latar barcode",x:x0,y:y0,w:bw,h:Math.round(h*1.4),fill:"#ffffff"}];
 for(let i=0;i<bits.length;){if(bits[i]==="1"){let j=i;while(j<bits.length&&bits[j]==="1")j++;arr.push({type:"rect",name:"Bar",x:Math.round((bx+i*m)*10)/10,y:Math.round(y0+h*.08),w:Math.max(1,Math.round((j-i)*m*10)/10),h:Math.round(h*.9),fill:"#111111"});i=j;}else i++;}
 const t=txt(full[0]+" "+full.slice(1,7)+" "+full.slice(7),0,0,m*10,"#111111",{fontFamily:"'Courier New', monospace",bold:true});arr.push(t);
 grp(arr,()=>{t.x=Math.round(x0+(bw-t.w)/2);t.y=Math.round(y0+h*1.02);});T("Barcode EAN-13: "+full);}
function numbers(){const n=Math.max(1,Math.min(12,+$("#nN").value||5));N.closeModal();const d=Math.round(W()*.09),gap=Math.round(d*.35),x0=Math.round((W()-(n*d+(n-1)*gap))/2),y=Math.round(H()/2-d/2),arr=[],pairs=[];
 for(let i=0;i<n;i++){const e={type:"ellipse",name:"Nomor "+(i+1),x:x0+i*(d+gap),y,w:d,h:d,fill:"#6d5dfc"},t=txt(String(i+1),0,0,d*.5,"#ffffff",{bold:true});arr.push(e,t);pairs.push([t,e]);}
 grp(arr,()=>pairs.forEach(p=>{p[0].x=Math.round(p[1].x+(p[1].w-p[0].w)/2);p[0].y=Math.round(p[1].y+(p[1].h-p[0].h)/2);}));}
function addText(t){Hi.snapshot();const o=txt(t,0,0,Math.round(W()*.06),"#20243a",{id:uid(),name:"Tanggal",bold:true,stroke:"none",strokeWidth:0,opacity:100,rotation:0});S.objects.push(o);pick([o]);o.x=Math.round((W()-o.w)/2);o.y=Math.round((H()-o.h)/2);C.render();}
const D=()=>new Date(),id=(o)=>D().toLocaleDateString("id-ID",o);
MENUS.code=()=>[
 {h:"Kode & nomor",items:[it("Barcode EAN-13…",()=>ask("Barcode EAN-13",'<label>12 atau 13 angka (digit cek dihitung otomatis)<input id="bcN" inputmode="numeric" value="590123412345"></label>',ean),"barcode"),it("Penomoran 1 sampai N…",()=>ask("Penomoran",'<label>Jumlah (1-12)<input id="nN" type="number" min="1" max="12" value="5"></label>',numbers),"multi")]},
 {h:"Sisipkan tanggal & waktu",items:[it("Tanggal lengkap",()=>addText(id({weekday:"long",day:"numeric",month:"long",year:"numeric"})),"text"),it("Tanggal singkat",()=>addText(id({day:"2-digit",month:"2-digit",year:"numeric"})),"text"),it("Bulan & tahun",()=>addText(id({month:"long",year:"numeric"})),"text"),it("Jam sekarang",()=>addText(D().toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit"})),"text")]}];

BT.push(["conn","connector","Konektor"],["sfx","filter","Filter"],["code","barcode","Kode"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("atur").push("conn");hub("warna").push("sfx");hub("buat").push("code");
})();
