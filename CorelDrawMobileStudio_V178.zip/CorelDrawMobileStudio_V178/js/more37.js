/* V48: menu Halaman+ - salin/pindah objek antar halaman, gandakan halaman, lompat halaman */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,P=CDMS.Pages,{MENUS,BT,sels,pick,T,it}=M,uid=()=>crypto.randomUUID();
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const clone=a=>a.map(o=>{const c=JSON.parse(JSON.stringify(o));c.id=uid();return c;});
/* salin (atau pindah) objek terpilih ke halaman target (indeks) */
function send(targets,move){const a=sels();if(!a.length)return T("Pilih objek dulu");
 P.sync();const n=S.pages.length,t=targets.filter(i=>i>=0&&i<n&&i!==S.pageIdx);if(!t.length)return T("Tidak ada halaman tujuan");
 Hi.snapshot();
 t.forEach(i=>{const pg=S.pages[i];pg.objects=pg.objects||[];pg.objects.push(...clone(a));});
 if(move){const ids=new Set(a.map(o=>o.id));S.objects=S.objects.filter(o=>!ids.has(o.id));S.selectedIds=[];S.selected=null;}
 C.render();P.sync();T((move?"Dipindah":"Disalin")+" ke "+t.length+" halaman");}
const cur=()=>S.pageIdx,last=()=>S.pages.length-1;
function dupN(k){P.sync();for(let i=0;i<k;i++)P.add(true);T(k+" halaman digandakan, total "+S.pages.length);}
const go=i=>{P.go(i);};
MENUS.halaman2=()=>[
 {h:"Objek terpilih → halaman lain",items:[
  it("Salin ke halaman berikutnya",()=>send([cur()+1]),"copy"),
  it("Salin ke halaman sebelumnya",()=>send([cur()-1]),"copy"),
  it("Salin ke semua halaman",()=>send(S.pages.map((_,i)=>i)),"copy"),
  it("Pindah ke halaman berikutnya",()=>send([cur()+1],true),"arrange"),
  it("Pindah ke halaman sebelumnya",()=>send([cur()-1],true),"arrange")]},
 {h:"Gandakan halaman",items:[it("Gandakan 1×",()=>dupN(1),"copy"),it("Gandakan 3×",()=>dupN(3),"copy"),it("Gandakan 5×",()=>dupN(5),"copy")]},
 {h:"Lompat",items:[it("Halaman pertama",()=>go(0),"pages"),it("Halaman terakhir",()=>go(last()),"pages"),it("Halaman berikutnya",()=>go(cur()+1),"pages"),it("Halaman sebelumnya",()=>go(cur()-1),"pages")]}];
BT.push(["halaman2","pages","Halaman+"]);
hubAdd("atur","halaman2");
})();
