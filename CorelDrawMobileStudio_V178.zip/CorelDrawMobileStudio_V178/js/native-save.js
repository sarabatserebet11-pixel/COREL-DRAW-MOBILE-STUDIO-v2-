/* V151 — Penyimpanan file & cetak di Android WebView (aktif hanya jika bridge AndroidAppPanel.saveFile ada).
   - a[download] berisi blob:/data: → disimpan ke folder Download lewat bridge.
   - window.print() pada iframe cetak (Word/Excel/PPT) → dialog cetak Android (bisa "Simpan sebagai PDF"). */
(() => {
  'use strict';
  const b = window.AndroidAppPanel;
  if (!b || typeof b.saveFile !== 'function') return;
  const MAX = 25 * 1024 * 1024;
  function toast(msg) {
    let t = document.getElementById('appPanelToast');
    if (!t) { t = document.createElement('div'); t.id = 'appPanelToast'; t.className = 'app-panel-toast'; document.body.appendChild(t); }
    t.textContent = msg; t.classList.add('show'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('show'), 3200);
  }
  const toB64 = blob => new Promise((res, rej) => {
    const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = rej; r.readAsDataURL(blob);
  });
  async function save(name, href) {
    const safe = String(name || 'file').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').slice(0, 100) || 'file';
    try {
      const blob = await (await fetch(href)).blob();
      if (blob.size > MAX) { toast('File terlalu besar untuk disimpan (maks. 25 MB).'); return; }
      const where = b.saveFile(safe, blob.type || 'application/octet-stream', await toB64(blob));
      toast(where ? 'Tersimpan di ' + where + ': ' + safe : 'Gagal menyimpan file.');
    } catch (_) { toast('Gagal menyimpan file.'); }
  }
  const isLocal = a => a && a.hasAttribute && a.hasAttribute('download') && /^(blob:|data:)/.test(a.href);
  // Unduhan yang dipicu program: a.click()
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (isLocal(this)) { save(this.download, this.href); return; }
    return origClick.call(this);
  };
  // Unduhan lewat ketukan pengguna pada tautan di halaman
  document.addEventListener('click', e => {
    const a = e.target.closest && e.target.closest('a[download]');
    if (a && isLocal(a)) { e.preventDefault(); save(a.download, a.href); }
  }, true);
  // Cetak: iframe.contentWindow.print() → dialog cetak Android
  if (typeof b.printHtml === 'function') {
    const d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'contentWindow');
    if (d && d.get) {
      Object.defineProperty(HTMLIFrameElement.prototype, 'contentWindow', {
        configurable: true,
        get() {
          const w = d.get.call(this);
          try {
            if (w && !w.__cdmsPrint) {
              w.__cdmsPrint = true;
              const frame = this;
              w.print = () => {
                try {
                  const html = '<!doctype html>' + frame.contentDocument.documentElement.outerHTML;
                  if (html.length > 12e6 || !b.printHtml(html)) toast('Cetak tidak tersedia / dokumen terlalu besar.');
                } catch (_) { toast('Cetak tidak tersedia di perangkat ini.'); }
              };
            }
          } catch (_) { /* iframe lintas-origin: biarkan */ }
          return w;
        }
      });
    }
  }
})();
