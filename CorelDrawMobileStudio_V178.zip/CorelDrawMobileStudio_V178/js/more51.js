/* V62: menu Toko (gratis ongkir, terlaris, harga coret, tombol beli, pita diskon, garansi, COD, stok terbatas) dan Kontak (footer kontak, jam buka, pin lokasi, ajakan hubungi, kartu tautan) */
(()=>{
const M=CDMS.Menus,{MENUS,BT,it}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,STAR,AC,INK,MUTE,LINE}=K;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const WHT="#ffffff",RED="#ef4444",GRN="#16a34a",ORG="#f59e0b";
const PIN="M50 0C25 0 8 18 8 42C8 72 50 100 50 100C50 100 92 72 92 42C92 18 75 0 50 0Z";
/* ---------- Toko ---------- */
Object.assign(COMP,{
 "Gratis ongkir":()=>({w:420,h:110,a:[R(0,0,420,110,GRN,{rx:55,name:"Gratis ongkir"}),R(34,36,64,38,WHT,{rx:8}),R(98,48,24,26,WHT,{rx:6}),E(44,66,22,22,GRN,{stroke:WHT,strokeWidth:4}),E(94,66,22,22,GRN,{stroke:WHT,strokeWidth:4}),X("GRATIS ONGKIR",262,55,30,WHT,{bold:1})]}),
 "Terlaris":()=>({w:260,h:260,a:[P(0,0,260,260,"M50 0L61 12L77 8L82 24L98 28L94 44L100 50L94 56L98 72L82 76L77 92L61 88L50 100L39 88L23 92L18 76L2 72L6 56L0 50L6 44L2 28L18 24L23 8L39 12Z",ORG,{name:"Terlaris"}),E(30,30,200,200,"none",{stroke:WHT,strokeWidth:4}),P(105,50,50,50,STAR,WHT),X("TERLARIS",130,142,30,WHT,{bold:1}),X("No. 1",130,184,28,"#fff3d6",{bold:1})]}),
 "Harga coret":()=>({w:420,h:190,a:[R(0,0,420,190,WHT,{rx:28,stroke:"#00000018",strokeWidth:3,name:"Harga coret"}),X("Rp 250.000",32,52,34,MUTE,{left:1}),R(32,52,184,4,RED,{rx:2}),X("Rp 149.000",32,118,60,RED,{left:1,bold:1}),R(32,150,150,26,"#fdeaea",{rx:13}),X("HEMAT 40%",107,163,18,RED,{bold:1})]}),
 "Tombol beli":()=>({w:420,h:100,a:[R(0,0,420,100,RED,{rx:50,name:"Tombol beli"}),E(38,28,44,44,WHT),R(54,22,12,6,WHT,{rx:3}),X("BELI SEKARANG",250,50,32,WHT,{bold:1})]}),
 "Pita diskon":()=>({w:300,h:300,a:[P(0,0,300,300,"M0 0L55 0L100 45L100 100Z",RED,{name:"Pita diskon"}),X("50% OFF",192,108,38,WHT,{bold:1,rotation:45})]}),
 "Garansi":()=>({w:260,h:300,a:[P(0,0,260,300,"M50 2L92 16V50C92 74 74 92 50 98C26 92 8 74 8 50V16Z","#2f80ed",{name:"Garansi"}),X("✓",130,100,100,WHT,{bold:1}),X("GARANSI",130,196,36,WHT,{bold:1}),X("1 TAHUN",130,238,28,"#cfe2ff",{bold:1})]}),
 "Bayar di tempat":()=>({w:420,h:110,a:[R(0,0,420,110,INK,{rx:20,name:"COD"}),E(26,25,60,60,ORG),X("Rp",56,55,26,INK,{bold:1}),X("BAYAR DI TEMPAT",250,40,30,WHT,{bold:1}),X("(COD) tersedia",250,80,22,"#c8cee6")]}),
 "Stok terbatas":()=>({w:420,h:150,a:[R(0,0,420,150,"#fff5e0",{rx:24,stroke:ORG,strokeWidth:4,name:"Stok terbatas"}),X("STOK TERBATAS!",210,48,36,"#b45309",{bold:1}),R(40,86,340,18,"#f5dca8",{rx:9}),R(40,86,100,18,ORG,{rx:9}),X("Sisa 12 pcs lagi",210,126,22,"#b45309",{bold:1})]})
});
MENUS.toko=()=>[
 {h:"Lencana",items:["Terlaris","Garansi","Pita diskon"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Penawaran",items:["Gratis ongkir","Bayar di tempat","Stok terbatas","Harga coret","Tombol beli"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["toko","store","Toko"]);
hubAdd("pustaka","toko");
/* ---------- Kontak ---------- */
Object.assign(COMP,{
 "Footer kontak":()=>({w:900,h:200,a:[R(0,0,900,200,INK,{rx:28,name:"Footer kontak"}),E(36,34,40,40,AC),X("Telepon: 0812-3456-7890",96,54,26,WHT,{left:1}),E(36,92,40,40,"#00c9a7"),X("Email: halo@merek.id",96,112,26,WHT,{left:1}),E(36,150,40,40,"#ffb020"),X("Jl. Contoh No. 12, Jakarta",96,170,26,WHT,{left:1}),X("Hubungi Kami",864,54,34,AC,{bold:1,x:640,left:1})].map(o=>o)}),
 "Jam buka":()=>({w:420,h:330,a:[R(0,0,420,330,WHT,{rx:28,stroke:"#00000018",strokeWidth:3,name:"Jam buka"}),X("Jam Buka",32,48,34,INK,{left:1,bold:1}),R(32,76,80,5,AC,{rx:3}),...[["Senin – Jumat","08.00 – 17.00"],["Sabtu","09.00 – 15.00"],["Minggu","Tutup"]].flatMap((r,i)=>{const y=130+i*64;return [X(r[0],32,y,24,MUTE,{left:1}),X(r[1],388,y,26,i===2?RED:INK,{bold:1,left:1,x:240})];})]}),
 "Pin lokasi":()=>({w:460,h:200,a:[R(0,0,460,200,"#eef0fa",{rx:28,name:"Pin lokasi"}),P(32,30,80,110,PIN,RED),E(58,56,28,28,WHT),X("Toko Utama",140,70,34,INK,{left:1,bold:1}),X("Jl. Contoh No. 12",140,114,24,MUTE,{left:1}),X("Jakarta Selatan",140,148,24,MUTE,{left:1})]}),
 "Ajakan hubungi":()=>({w:520,h:130,a:[R(0,0,520,130,GRN,{rx:65,name:"Ajakan hubungi"}),E(30,25,80,80,WHT),P(52,48,36,36,"M5 5Q5 60 40 95Q60 95 95 70L75 50L55 62Q40 55 38 40L50 25Z",GRN),X("Chat Kami",130,48,32,WHT,{left:1,bold:1}),X("Balasan cepat setiap hari",130,92,22,"#d6f5e0",{left:1})]}),
 "Kartu tautan":()=>({w:480,h:520,a:[R(0,0,480,520,WHT,{rx:36,stroke:"#00000018",strokeWidth:3,name:"Kartu tautan"}),E(180,36,120,120,"#ece9ff"),E(210,62,60,60,AC),P(195,124,90,30,"M0 100Q0 10 50 10Q100 10 100 100Z",AC),X("@namaanda",240,196,34,INK,{bold:1}),X("Kreator · Desainer · Pemula",240,240,22,MUTE),...["Portofolio","Toko Online","Kontak Kerja Sama"].flatMap((t,i)=>{const y=290+i*70;return [R(40,y,400,56,i===0?AC:"#f1f3fa",{rx:28}),X(t,240,y+28,24,i===0?WHT:INK,{bold:1})];})]})
});
MENUS.kontak=()=>[
 {h:"Info usaha",items:["Footer kontak","Jam buka","Pin lokasi"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Ajakan",items:["Ajakan hubungi","Kartu tautan"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["kontak","contact","Kontak"]);
hubAdd("pustaka","kontak");
})();
