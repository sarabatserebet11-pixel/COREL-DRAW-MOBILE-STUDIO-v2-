/* V106: dua grup menu baru (helper bersama dari CDMS.Util97, tanpa kode duplikat).
   "Grafik Data" (ikon chart106): Batang (tegak / mendatar), Pai (pai / donat + legenda), Progres (bilah persentase).
   "Pola" (ikon pattern106): Garis Pola (diagonal, tegak, mendatar, kotak-kotak), Titik Kisi (titik / plus), Konfeti (acak), Mandala (kelopak berlapis).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U||!U.kartu||!U.seg||!U.mkPal||!U.poly||!U.chips||!U.idx)return;
const{ramp,grup,shape,text,line,path,finish,defHub,W,H,poly,ask,idx,tx,clamp,mkPal,chips,kartu,seg,mix}=U,R=Math.round;
const PL=mkPal("pal106","laut"),pal=PL.pal,palMenu=PL.menu,pc=(P,t)=>ramp(P.c.slice(1),t);
/* "Label:nilai, Label:nilai" -> [[label,nilai],...] ; null bila format atau jumlah item salah */
const nilai=(s,a,b)=>{const o=[];for(const x of String(s).split(/[,;\n]+/).map(v=>v.trim()).filter(Boolean)){const m=x.match(/^(.+?)\s*[:=]\s*(\d+(?:[.,]\d+)?)\s*%?$/);if(!m)return null;o.push([m[1].trim().slice(0,10),parseFloat(m[2].replace(",","."))]);}return o.length>=a&&o.length<=b?o:null;};
const fm=v=>String(R(v*10)/10),rt=(s,xr,y,fs,col,o)=>text(s,xr-s.length*fs*.6,y,fs,col,o),t1=(n,t)=>n>1?t/(n-1):0;
const FMT="Format: Label:nilai dipisah koma, mis. Jan:40, Feb:65";

/* ================= GRAFIK DATA ================= */
function batang(){const q=ask("Data (Label:nilai, 2-7 item):",S.btD106||"Jan:40, Feb:65, Mar:50, Apr:80");if(q===null)return;const d=nilai(q,2,7);if(!d)return T(FMT);S.btD106=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),mend=(S.btO106||"t")==="m",cw=Math.min(w*.9,h*.75*1.5),ch=cw*.65,x=(w-cw)/2,y=(h-ch)/2,pd=cw*.07,fs=R(clamp(cw*.04,8,26)),n=d.length,mx=Math.max(...d.map(v=>v[1]))||1,out=[kartu(x,y,cw,ch,cw*.03)];
 if(!mend){const ix=x+pd,iy=y+pd+fs*1.6,iw=cw-2*pd,ih=ch-2*pd-fs*3.4,slot=iw/n,bw=slot*.6,base=iy+ih;
  for(let k=1;k<=4;k++)out.push(line(ix,base-ih*k/4,iw,0,"#e5e7eb",2,{name:"Garis kisi "+k}));
  d.forEach((v,i)=>{const bh=Math.max(1,ih*v[1]/mx),cx=ix+slot*(i+.5);
   out.push(shape("rect",cx-bw/2,base-bh,bw,bh,pc(P,t1(n,i)),{name:"Batang "+v[0],rx:R(bw*.12)}),U.tx(fm(v[1]),cx,base-bh-fs*1.5,fs,"#374151",{name:"Nilai "+(i+1),bold:true}),U.tx(v[0],cx,base+fs*.5,fs,"#6b7280",{name:"Label "+(i+1)}));});
  out.push(line(ix,base,iw,0,"#9ca3af",3,{name:"Sumbu"}));}
 else{const ix=x+pd,iy=y+pd,iw=cw-2*pd,ih=ch-2*pd,lw=Math.min(iw*.3,Math.max(...d.map(v=>v[0].length))*fs*.6+fs*.6),vw=fs*3.8,ax=ix+lw,len=iw-lw-vw,slot=ih/n,bh=slot*.6;
  d.forEach((v,i)=>{const bl=Math.max(1,len*v[1]/mx),cy=iy+slot*(i+.5);
   out.push(shape("rect",ax,cy-bh/2,bl,bh,pc(P,t1(n,i)),{name:"Batang "+v[0],rx:R(bh*.15)}),rt(v[0],ax-fs*.5,cy-fs*.6,fs,"#6b7280",{name:"Label "+(i+1)}),text(fm(v[1]),ax+bl+fs*.5,cy-fs*.6,fs,"#374151",{name:"Nilai "+(i+1),bold:true}));});
  out.push(line(ax,iy,0,ih,"#9ca3af",3,{name:"Sumbu"}));}
 finish(grup(out,"Diagram batang"),"Diagram batang "+n+" data ("+(mend?"mendatar":"tegak")+")");}
MENUS.btg106=()=>[{h:"Arah",items:[["Tegak","t"],["Mendatar","m"]].map(x=>tc(x[0],()=>{S.btO106=x[1];},{keep:1,on:(S.btO106||"t")===x[1]}))},palMenu(),{h:"Buat",items:[it("Buat diagram batang…",batang,"bar106")]}];

function pai(){const q=ask("Data (Label:nilai, 2-8 item):",S.paD106||"Sewa:40, Makan:30, Transport:20, Lain:10");if(q===null)return;const d=nilai(q,2,8);if(!d)return T(FMT);const tot=d.reduce((a,v)=>a+v[1],0);if(tot<=0)return T("Total nilai harus lebih dari 0");S.paD106=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),donat=(S.paB106||"p")==="d",cw=Math.min(w*.92,h*.8*1.6),ch=Math.min(h*.8,cw*.6),x=(w-cw)/2,y=(h-ch)/2,pd=cw*.05,r=Math.min(ch*.38,cw*.24),cx=x+pd+r*1.1,cy=y+ch/2,n=d.length,fs=R(clamp(Math.min(cw*.035,ch/(n*2.4)),7,24)),out=[kartu(x,y,cw,ch,cw*.03)],pt=(a,rad)=>(r+rad*Math.cos(a)).toFixed(1)+" "+(r+rad*Math.sin(a)).toFixed(1);
 let a=-Math.PI/2;
 d.forEach((v,i)=>{const f=v[1]/tot,col=pc(P,t1(n,i));if(f<=0)return;const b=a+f*2*Math.PI;
  if(f>=.9999)out.push(shape("ellipse",cx-r,cy-r,r*2,r*2,col,{name:"Irisan "+v[0],stroke:"#ffffff",strokeWidth:3}));
  else out.push(path(cx-r,cy-r,r*2,r*2,r*2,r*2,"M"+r+" "+r+"L"+pt(a,r)+"A"+r+" "+r+" 0 "+(f>.5?1:0)+" 1 "+pt(b,r)+"Z",col,"#ffffff",3,{name:"Irisan "+v[0]}));
  a=b;});
 if(donat)out.push(shape("ellipse",cx-r*.55,cy-r*.55,r*1.1,r*1.1,"#ffffff",{name:"Lubang donat"}),U.tx(fm(tot),cx,cy-fs*.9,fs*1.6,"#374151",{name:"Total",bold:true}));
 const lx=cx+r+pd*1.2,ly=cy-n*fs*2/2;
 d.forEach((v,i)=>{const yy=ly+i*fs*2;out.push(shape("rect",lx,yy+fs*.1,fs,fs,pc(P,t1(n,i)),{name:"Kotak legenda "+(i+1),rx:R(fs*.2)}),text(v[0]+"  "+R(v[1]/tot*100)+"%",lx+fs*1.6,yy,fs,"#374151",{name:"Legenda "+(i+1)}));});
 finish(grup(out,donat?"Diagram donat":"Diagram pai"),(donat?"Diagram donat ":"Diagram pai ")+n+" data");}
MENUS.pai106=()=>[{h:"Bentuk",items:[["Pai","p"],["Donat","d"]].map(x=>tc(x[0],()=>{S.paB106=x[1];},{keep:1,on:(S.paB106||"p")===x[1]}))},palMenu(),{h:"Buat",items:[it("Buat diagram pai + legenda…",pai,"pie106")]}];

function progres(){const q=ask("Progres (Label:persen, 1-6 item):",S.prD106||"Desain:80, Kode:55, Tes:30");if(q===null)return;const d=nilai(q,1,6);if(!d)return T("Format: Label:persen, mis. Desain:80, Kode:55");S.prD106=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=d.length,fs=R(clamp(w*.03,9,24)),cw=Math.min(w*.88,fs*30),pd=fs*1.2,rh=fs*3.4,ch=n*rh+pd*2-fs*.6,x=(w-cw)/2,y=(h-ch)/2,tw=cw-2*pd,out=[kartu(x,y,cw,ch,fs*.8)];
 d.forEach((v,i)=>{const p=clamp(v[1],0,100),ry=y+pd+i*rh,col=pc(P,t1(n,i));
  out.push(text(v[0],x+pd,ry,fs,"#374151",{name:"Label "+(i+1),bold:true}),rt(R(p)+"%",x+cw-pd,ry,fs,"#6b7280",{name:"Persen "+(i+1)}),
   shape("rect",x+pd,ry+fs*1.5,tw,fs*.9,"#e5e7eb",{name:"Jalur "+(i+1),rx:R(fs*.45)}));
  if(p>0)out.push(shape("rect",x+pd,ry+fs*1.5,Math.max(fs*.9,tw*p/100),fs*.9,col,{name:"Isi "+(i+1),rx:R(fs*.45)}));});
 finish(grup(out,"Progres"),n+" bilah progres");}
MENUS.prg106=()=>[palMenu(),{h:"Buat",items:[it("Buat bilah progres…",progres,"progress106")]}];

/* ================= POLA ================= */
const GP=[["Diagonal /","a"],["Diagonal \\","b"],["Tegak","v"],["Mendatar","m"],["Kotak-kotak","k"]];
function garis(){const P=pal(),w=W(),h=H(),bw=R(w*.8),bh=R(h*.7),bx=(w-bw)/2,by=(h-bh)/2,g=S.gpG106||"a",st=Math.max(S.gpJ106||24,Math.ceil((bw+bh)/160)),sw=S.gpT106||3,out=[kartu(bx,by,bw,bh,Math.min(bw,bh)*.03)];Hi.snapshot();
 const cs=[];let nn=0;
 const dg=(flip)=>{for(let c=st;c<bw+bh;c+=st){const x1=Math.max(0,c-bh),x2=Math.min(bw,c);if(x2-x1<2)continue;const y1=c-x1,y2=c-x2;
   out.push(seg(bx+(flip?bw-x1:x1),by+y1,bx+(flip?bw-x2:x2),by+y2,pc(P,Math.min(1,c/(bw+bh))),sw,"Garis "+(++nn)));}};
 const vt=()=>{for(let x=st;x<bw;x+=st)out.push(seg(bx+x,by,bx+x,by+bh,pc(P,x/bw),sw,"Garis tegak "+(++nn)));};
 const mt=()=>{for(let y=st;y<bh;y+=st)out.push(seg(bx,by+y,bx+bw,by+y,pc(P,y/bh),sw,"Garis datar "+(++nn)));};
 if(g==="a")dg(false);else if(g==="b")dg(true);else if(g==="v")vt();else if(g==="m")mt();else{vt();mt();}
 finish(grup(out,"Pola garis"),"Pola garis "+GP.find(x=>x[1]===g)[0]+" ("+(out.length-1)+" garis)");}
MENUS.gar106=()=>[{h:"Gaya",items:GP.map(x=>tc(x[0],()=>{S.gpG106=x[1];},{keep:1,on:(S.gpG106||"a")===x[1]}))},chips("Jarak (px)",[12,24,40],"gpJ106",24),chips("Tebal (px)",[2,3,5],"gpT106",3),palMenu(),{h:"Buat",items:[it("Pasang pola garis di tengah halaman",garis,"stripes106")]}];

function titik(){const P=pal(),w=W(),h=H(),bw=R(w*.8),bh=R(h*.7),bx=(w-bw)/2,by=(h-bh)/2,plus=(S.tkB106||"t")==="p",st=Math.max(S.tkJ106||32,Math.ceil(Math.sqrt(bw*bh/320))),cols=Math.max(1,Math.floor(bw/st)),rows=Math.max(1,Math.floor(bh/st)),x0=bx+(bw-(cols-1)*st)/2,y0=by+(bh-(rows-1)*st)/2,r=Math.max(2,st*.1),out=[kartu(bx,by,bw,bh,Math.min(bw,bh)*.03)];Hi.snapshot();
 for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){const x=x0+i*st,y=y0+j*st,col=pc(P,t1(rows,j)),k=i+","+j;
  if(plus){const l=st*.22;out.push(seg(x-l,y,x+l,y,col,Math.max(2,R(r*.7)),"Plus "+k+" a"),seg(x,y-l,x,y+l,col,Math.max(2,R(r*.7)),"Plus "+k+" b"));}
  else out.push(shape("ellipse",x-r,y-r,r*2,r*2,col,{name:"Titik "+k}));}
 finish(grup(out,"Titik kisi"),"Kisi "+cols+" × "+rows+(plus?" tanda plus":" titik"));}
MENUS.kis106=()=>[{h:"Bentuk",items:[["Titik","t"],["Plus","p"]].map(x=>tc(x[0],()=>{S.tkB106=x[1];},{keep:1,on:(S.tkB106||"t")===x[1]}))},chips("Jarak (px)",[20,32,48],"tkJ106",32),palMenu(),{h:"Buat",items:[it("Pasang kisi titik di tengah halaman",titik,"dots106")]}];

function konfeti(){const P=pal(),w=W(),h=H(),n=S.kfN106||60,sz=Math.min(w,h)*.035,rn=(a,b)=>a+Math.random()*(b-a),out=[];Hi.snapshot();
 for(let i=0;i<n;i++){const x=rn(0,w),y=rn(0,h),s=sz*rn(.6,1.5),col=pc(P,Math.random()),k=Math.floor(Math.random()*3),nm="Konfeti "+(i+1);
  if(k===0)out.push(shape("rect",x,y,s*1.6,s*.7,col,{name:nm,rotation:R(rn(0,180))}));
  else if(k===1)out.push(shape("ellipse",x,y,s,s,col,{name:nm}));
  else out.push(poly([[x+s/2,y],[x+s,y+s],[x,y+s]],col,nm));}
 finish(grup(out,"Konfeti"),n+" keping konfeti acak");}
MENUS.knf106=()=>[chips("Jumlah",[30,60,100],"kfN106",60),palMenu(),{h:"Buat",items:[it("Taburkan konfeti di halaman (acak)",konfeti,"confetti106")]}];

const MK=[[ "6 kelopak",6],["8 kelopak",8],["12 kelopak",12]],MU=[["Kecil",.25],["Sedang",.35],["Besar",.45]];
function mandala(){const P=pal(),w=W(),h=H(),n=MK[S.mdK106??1][1],L=S.mdL106||3,Rr=Math.min(w,h)*MU[S.mdU106??1][1],cx=w/2,cy=h/2,ox=cx-Rr,oy=cy-Rr,f=v=>v.toFixed(1),out=[];Hi.snapshot();
 for(let k=0;k<L;k++){const Rk=Rr*(1-k*.27),off=k%2?Math.PI/n:0,col=pc(P,t1(L,k));
  for(let i=0;i<n;i++){const a=off+i*2*Math.PI/n,c=Math.cos(a),s=Math.sin(a),tx_=Rr+Rk*c,ty=Rr+Rk*s,m=Rk*.55,q=Rk*.38,
    c1=f(Rr+c*m-s*q)+" "+f(Rr+s*m+c*q),c2=f(Rr+c*m+s*q)+" "+f(Rr+s*m-c*q);
   out.push(path(ox,oy,Rr*2,Rr*2,Rr*2,Rr*2,"M"+Rr+" "+Rr+"Q"+c1+" "+f(tx_)+" "+f(ty)+"Q"+c2+" "+Rr+" "+Rr+"Z",col,"#ffffff",2,{name:"Kelopak "+(k+1)+"."+(i+1),opacity:85}));}}
 out.push(shape("ellipse",cx-Rr*.1,cy-Rr*.1,Rr*.2,Rr*.2,"#fde68a",{name:"Pusat",stroke:"#ffffff",strokeWidth:2}));
 finish(grup(out,"Mandala"),"Mandala "+n+" kelopak, "+L+" lapis");}
MENUS.mnd106=()=>[idx("Kelopak",MK,"mdK106",1),chips("Lapis",[2,3,4],"mdL106",3),idx("Ukuran",MU,"mdU106",1),palMenu(),{h:"Buat",items:[it("Pasang mandala di tengah halaman",mandala,"mandala106")]}];

/* ================= tombol & grup ================= */
BT.push(["btg106","bar106","Batang"],["pai106","pie106","Pai"],["prg106","progress106","Progres"],["gar106","stripes106","Garis Pola"],["kis106","dots106","Titik Kisi"],["knf106","confetti106","Konfeti"],["mnd106","mandala106","Mandala"]);
defHub("grafik106","chart106","Grafik Data",["btg106","pai106","prg106"]);
defHub("pola106","pattern106","Pola",["gar106","kis106","knf106","mnd106"]);
CDMS.Grafik106={batang,pai,progres,garis,titik,konfeti,mandala};
})();
