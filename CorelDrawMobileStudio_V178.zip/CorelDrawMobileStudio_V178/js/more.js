/* V14: menu Gaya, Sisip, Duplikat, Proyek + perluasan menu Warna & Teks, edit teks dengan klik ganda */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),{MENUS,BT,edit,sels,pick,T,it,tc,cell,nr}=M;
const W=()=>S.page.width,H=()=>S.page.height,SHAPES=["rect","ellipse","star","polygon"];

/* ---- renderer: garis putus-putus & pola isi ---- */
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);
 if(o.dash&&o.type!=="text"&&o.type!=="image")s=s.replace(/(stroke="(?!transparent)[^"]*" stroke-width="([^"]*)" stroke-linejoin="round")/g,(m,a,w)=>`${m} stroke-dasharray="${o.dash.split(" ").map(n=>+(n*Math.max(+w||2,2)).toFixed(2)).join(" ")}"`);
 if(o.pat&&!o.grad&&[...SHAPES,"path"].includes(o.type)){const id="pt-"+o.id,bg=o.fill&&o.fill!=="none"&&!String(o.fill).startsWith("url")?o.fill:"#6d5dfc",b=`<rect width="24" height="24" fill="${bg}"/>`;
  const P={stripe:b+'<rect width="10" height="24" fill="#fff" fill-opacity=".4"/>',dot:b+'<circle cx="12" cy="12" r="5" fill="#fff" fill-opacity=".5"/>',grid:b+'<path d="M0 0H24V24H0Z" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="2"/>',check:b+'<rect width="12" height="12" fill="#fff" fill-opacity=".4"/><rect x="12" y="12" width="12" height="12" fill="#fff" fill-opacity=".4"/>'}[o.pat];
  if(P)s=s.replace(/fill="[^"]*"/,`fill="url(#${id})"`).replace(">",`><defs><pattern id="${id}" width="24" height="24" patternUnits="userSpaceOnUse"${o.pat==="stripe"?' patternTransform="rotate(45)"':""}>${P}</pattern></defs>`);}
 return s;};

/* ---- helpers ---- */
const dupe=(o,dx,dy,gm)=>{const c={...o,id:uid(),x:Math.round(o.x+dx),y:Math.round(o.y+dy)};if(c.groupId)c.groupId=gm[c.groupId]||(gm[c.groupId]=uid());return c;};
function dupFlow(mk,msg){const a=sels();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const gm={},out=[];mk(a,out,gm);S.objects.push(...out);pick(out);T(out.length+" salinan dibuat");}
const bb=a=>({w:Math.max(...a.map(o=>o.x+o.w))-Math.min(...a.map(o=>o.x)),h:Math.max(...a.map(o=>o.y+(o.h||0)))-Math.min(...a.map(o=>o.y))});
const gridCopy=(r,c)=>dupFlow((a,out,gm)=>{const b=bb(a),g=Math.round(Math.min(W(),H())*.02);for(let i=0;i<r;i++)for(let j=0;j<c;j++)if(i||j)a.forEach(o=>out.push(dupe(o,j*(b.w+g),i*(b.h+g),gm)));});
const side=k=>dupFlow((a,out,gm)=>{const b=bb(a),g=20;a.forEach(o=>out.push(dupe(o,k==="x"?b.w+g:0,k==="y"?b.h+g:0,gm)));});
const radial=n=>dupFlow((a,out,gm)=>{const px=W()/2,py=H()/2;for(let k=1;k<n;k++){const an=2*Math.PI*k/n,cs=Math.cos(an),sn=Math.sin(an);a.forEach(o=>{const cx=o.x+o.w/2-px,cy=o.y+(o.h||0)/2-py,c=dupe(o,0,0,gm);c.x=Math.round(px+cx*cs-cy*sn-o.w/2);c.y=Math.round(py+cx*sn+cy*cs-(o.h||0)/2);c.rotation=nr((o.rotation||0)+an*180/Math.PI);out.push(c);});}});
const mirror=k=>dupFlow((a,out,gm)=>a.forEach(o=>{const c=dupe(o,0,0,gm);if(k==="h"){c.x=Math.round(W()-o.x-o.w);c.flipH=!o.flipH;}else{c.y=Math.round(H()-o.y-(o.h||0));c.flipV=!o.flipV;}c.rotation=-(o.rotation||0);out.push(c);}));
function t3d(depth,long){const a=sels().filter(o=>o.type==="text");if(!a.length)return T("Pilih objek teks dulu");Hi.snapshot();
 a.forEach(o=>{const g=o.groupId||(o.groupId=uid()),cp=[];for(let i=depth;i>=1;i--){const c={...o,id:uid(),groupId:g,x:o.x+i,y:o.y+i,fill:long?"#000000":"#1b1f33",opacity:long?Math.max(6,Math.round(55-i*2)):100};delete c.fx;delete c.v7Effect;cp.push(c);}S.objects.splice(S.objects.indexOf(o),0,...cp);});C.render();}
const hex=(h,s,l)=>{s/=100;l/=100;const f=n=>{const k=(n+h/30)%12,a=s*Math.min(l,1-l),v=l-a*Math.max(-1,Math.min(k-3,9-k,1));return Math.round(255*v).toString(16).padStart(2,"0");};return"#"+f(0)+f(8)+f(4);};
function rainbow(){const a=sels();if(a.length<2)return T("Pilih 2 objek atau lebih");Hi.snapshot();a.forEach((o,i)=>{if(o.type!=="image"&&o.type!=="line"){o.fill=hex(i*360/a.length,80,60);delete o.grad;delete o.pat;}});C.render();}
function contrast(){const bg=String(S.page.background||"");if(!/^#[0-9a-f]{6}$/i.test(bg))return T("Latar harus warna polos");const n=parseInt(bg.slice(1),16),l=.299*(n>>16)+.587*((n>>8)&255)+.114*(n&255);edit(o=>{o.fill=l>150?"#111111":"#ffffff";},"Warna teks disesuaikan",o=>o.type==="text");}

/* ---- komponen siap pakai ---- */
function grp(arr,post){Hi.snapshot();const g=uid();arr.forEach(o=>Object.assign(o,{id:uid(),groupId:g,opacity:o.opacity??100,rotation:0,stroke:o.stroke||"none",strokeWidth:o.strokeWidth||0}));S.objects.push(...arr);pick(arr);if(post){post();C.render();}}
const mid=(t,r)=>{t.x=Math.round(r.x+(r.w-t.w)/2);t.y=Math.round(r.y+(r.h-t.h)/2);};
const txt=(text,x,y,size,fill,x2)=>({type:"text",name:"Teks",text,x:Math.round(x),y:Math.round(y),w:50,h:30,fontSize:Math.round(size),fill,...x2});
const btn=col=>()=>{const w=Math.round(W()*.4),h=Math.round(w*.26),r={type:"rect",name:"Tombol",x:Math.round(W()/2-w/2),y:Math.round(H()/2-h/2),w,h,rx:h/2,fill:col},t=txt("MULAI",r.x,r.y,h*.36,"#ffffff",{bold:true});grp([r,t],()=>mid(t,r));};
const card=()=>{const w=Math.round(W()*.5),h=Math.round(w*.62),x=Math.round((W()-w)/2),y=Math.round((H()-h)/2),p=Math.round(w*.07);grp([{type:"rect",name:"Kartu",x,y,w,h,rx:28,fill:"#ffffff",stroke:"#d9deea",strokeWidth:2,fx:"shadow",fxAmount:18},txt("Judul kartu",x+p,y+p,w*.09,"#20243a",{bold:true}),txt("Deskripsi singkat\ndi sini.",x+p,y+p+w*.16,w*.05,"#68728a")]);};
const badge=()=>{const d=Math.round(W()*.14),r={type:"ellipse",name:"Lencana",x:Math.round((W()-d)/2),y:Math.round((H()-d)/2),w:d,h:d,fill:"#6d5dfc"},t=txt("1",r.x,r.y,d*.5,"#ffffff",{bold:true});grp([r,t],()=>mid(t,r));};
const stars=()=>{const d=Math.round(W()*.075),g=Math.round(d*.2),x0=Math.round((W()-(5*d+4*g))/2);grp([0,1,2,3,4].map(i=>({type:"star",name:"Bintang",x:x0+i*(d+g),y:Math.round(H()/2-d/2),w:d,h:d,fill:"#ffc857"})));};
const sale=()=>{const d=Math.round(W()*.3),r={type:"star",name:"Label diskon",x:Math.round((W()-d)/2),y:Math.round((H()-d)/2),w:d,h:d,fill:"#ff4f6d"},t=txt("-50%",r.x,r.y,d*.22,"#ffffff",{bold:true,fontFamily:"Impact, 'Arial Black', sans-serif"});grp([r,t],()=>mid(t,r));};
const polaroid=()=>{const w=Math.round(W()*.36),h=Math.round(w*1.2),x=Math.round((W()-w)/2),y=Math.round((H()-h)/2),p=Math.round(w*.08);grp([{type:"rect",name:"Bingkai",x,y,w,h,rx:6,fill:"#ffffff",fx:"shadow",fxAmount:20},{type:"rect",name:"Area foto",x:x+p,y:y+p,w:w-2*p,h:Math.round(h*.74),rx:4,fill:"#c9d3e6"},txt("Kenangan",x+p,y+h*.84,w*.09,"#20243a",{fontFamily:"'Comic Sans MS', cursive"})]);};
const divider=()=>{const w=Math.round(W()*.6),x=Math.round((W()-w)/2),y=Math.round(H()/2),d=Math.round(W()*.04);grp([{type:"line",name:"Garis kiri",x,y,w:Math.round(w*.42),h:0,stroke:"#8a93aa",strokeWidth:4,fill:"none"},{type:"star",name:"Ornamen",x:Math.round(W()/2-d/2),y:Math.round(y-d/2),w:d,h:d,fill:"#ffc857"},{type:"line",name:"Garis kanan",x:Math.round(W()/2+w*.08),y,w:Math.round(w*.42),h:0,stroke:"#8a93aa",strokeWidth:4,fill:"none"}]);};

/* ---- menu baru ---- */
const PAL=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4f83ff","#ff7ac8","#3ddc84","#ff9a3c"];
const fillable=o=>SHAPES.includes(o.type)||o.type==="path";
MENUS.style=()=>[
 {h:"Ketebalan garis",items:[0,1,2,4,8,16].map(w=>tc(w?w+" px":"Tanpa",()=>edit(o=>{o.strokeWidth=w;if(w&&(!o.stroke||o.stroke==="none"))o.stroke="#20243a";},"",o=>o.type!=="text"&&o.type!=="image")))},
 {h:"Gaya garis",items:[["Solid",""],["Putus-putus","4 3"],["Titik","1 2"],["Garis-titik","5 2 1 2"]].map(x=>tc(x[0],()=>edit(o=>{if(x[1])o.dash=x[1];else delete o.dash;if(x[1]&&!o.strokeWidth)o.strokeWidth=3;if(x[1]&&(!o.stroke||o.stroke==="none"))o.stroke="#20243a";},"",o=>o.type!=="text"&&o.type!=="image")))},
 {h:"Pola isi",items:[["Polos",""],["Garis","stripe"],["Titik","dot"],["Kotak","grid"],["Papan","check"]].map(x=>tc(x[0],()=>edit(o=>{if(x[1])o.pat=x[1];else delete o.pat;delete o.grad;},"",fillable)))}];
MENUS.insert=()=>[
 {h:"Komponen UI",items:[it("Tombol ungu",btn("#6d5dfc"),"rect"),it("Tombol cyan",btn("#00b8c9"),"rect"),it("Kartu",card,"rect"),it("Lencana angka",badge,"ellipse")]},
 {h:"Dekorasi",items:[it("Rating bintang",stars,"star"),it("Label diskon",sale,"star"),it("Polaroid",polaroid,"image"),it("Pembatas ornamen",divider,"line")]}];
MENUS.dup=()=>[
 {h:"Salin cepat",items:[it("Salin ke kanan",()=>side("x"),"copy"),it("Salin ke bawah",()=>side("y"),"copy"),it("Grid 2 × 2",()=>gridCopy(2,2),"dup"),it("Grid 3 × 3",()=>gridCopy(3,3),"dup"),it("Grid 4 × 4",()=>gridCopy(4,4),"dup")]},
 {h:"Melingkar (pusat halaman)",items:[6,8,12,16].map(n=>tc(n+"×",()=>radial(n)))},
 {h:"Cermin",items:[it("Cermin horizontal",()=>mirror("h"),"flipH"),it("Cermin vertikal",()=>mirror("v"),"flipV")]}];
MENUS.proj=()=>[
 {h:"Proyek",items:[it("Simpan sekarang",()=>CDMS.Storage.save(),"save",{s:"Ctrl+S"}),it("Ekspor desain…",()=>CDMS.Export.open(),"export"),it("Buka Studio",()=>{const b=$('[data-action="studio"]');if(b)b.click();},"studio"),it("Impor gambar",()=>$("#imageInput").click(),"image"),it("Desain baru 1080 × 1080",()=>N.action("new"),"plus")]},
 {h:"Info",items:[it(S.objects.length+" objek · "+W()+" × "+H()+" px",()=>{},"layers")]}];
const oc=MENUS.color;MENUS.color=()=>[...oc(),{h:"Warna cepat",items:[
 it("Acak warna isi",()=>edit(o=>{o.fill=PAL[Math.random()*8|0];delete o.grad;delete o.pat;},"",o=>o.type!=="image"&&o.type!=="line"),"color"),
 it("Pelangi antar objek",rainbow,"color"),
 it("Tukar isi ↔ garis",()=>edit(o=>{const f=o.fill;o.fill=o.stroke;o.stroke=f;},"",o=>SHAPES.includes(o.type)&&o.stroke&&o.stroke!=="none"),"redo"),
 it("Isi transparan",()=>edit(o=>{o.fill="none";delete o.grad;delete o.pat;},"",o=>SHAPES.includes(o.type)),"eyeoff"),
 it("Samakan dgn objek pertama",()=>{const a=sels();if(a.length<2)return T("Pilih 2 objek atau lebih");Hi.snapshot();a.slice(1).forEach(o=>{o.fill=a[0].fill;o.stroke=a[0].stroke;o.grad=a[0].grad;o.pat=a[0].pat;});C.render();},"copy"),
 it("Teks kontras otomatis",contrast,"text")]}];
const ot=MENUS.text;MENUS.text=()=>[...ot(),{h:"Efek teks",items:[it("Teks 3D",()=>t3d(8),"text"),it("Bayangan panjang",()=>t3d(26,true),"text"),it("Rata tengah halaman",()=>edit(o=>{o.x=Math.round((W()-o.w)/2);},"",o=>o.type==="text"),"arrange")]}];
BT.push(["style","strokeI","Gaya"],["insert","insert","Sisip"],["dup","dup","Duplikat"],["proj","open","Proyek"]);

/* ---- klik ganda pada teks = edit isi ---- */
document.addEventListener("dblclick",e=>{const g=e.target.closest&&e.target.closest("#designCanvas [data-id]"),o=g&&S.objects.find(x=>x.id===g.dataset.id);if(!o||o.type!=="text"||o.locked)return;pick([o]);
 N.openModal("Edit teks",'<textarea id="dbT" rows="4" style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--line);background:var(--panel2);color:var(--text)"></textarea><button class="btn primary" id="dbOk" style="width:100%;margin-top:10px">Simpan teks</button>');
 $("#dbT").value=o.text;$("#dbOk").onclick=()=>{Hi.snapshot();o.text=$("#dbT").value||" ";N.closeModal();C.render();};});
})();
