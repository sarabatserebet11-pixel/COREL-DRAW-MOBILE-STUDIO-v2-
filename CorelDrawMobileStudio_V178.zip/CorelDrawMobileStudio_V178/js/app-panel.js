/* Panel Aplikasi Lain — V156 (Chrome lembar untuk situs login: Google dll.); V154 (semua aplikasi bisa mengambang: URL katalog otomatis, pop-up untuk situs anti-iframe); V153 (panel & aplikasi benar-benar mengambang, tanpa pindah halaman); V150 (jendela mengambang native + izin overlay); V146 (urutan, multi-jendela); V145: dialog Tambah Aplikasi (katalog + manual), edit, jendela mengambang,
   ekspor/impor, plus Android WebView bridge opsional.
   Bridge: AndroidAppPanel.getInstalledApps() / launchFreeform(pkg,ratio) / launchNormal(pkg) */
(() => {
  'use strict';
  const STORE='cms.appPanel.v1';
  const bridge=()=>window.AndroidAppPanel||null;
  const $=id=>document.getElementById(id);
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeParse=v=>{try{const r=JSON.parse(v);return Array.isArray(r)?r:[]}catch(_){return []}};
  const COLORS=['#2563eb','#7c3aed','#db2777','#ea580c','#16a34a','#0891b2','#ca8a04','#475569'];
  const colorFor=s=>{let h=0;for(const c of String(s))h=(h*31+c.charCodeAt(0))>>>0;return COLORS[h%COLORS.length]};
  const CATALOG=[
    ['WhatsApp','com.whatsapp','https://web.whatsapp.com'],['YouTube','com.google.android.youtube','https://m.youtube.com'],
    ['Instagram','com.instagram.android','https://www.instagram.com'],['Facebook','com.facebook.katana','https://m.facebook.com'],
    ['TikTok','com.zhiliaoapp.musically','https://www.tiktok.com'],['Telegram','org.telegram.messenger','https://web.telegram.org'],
    ['X (Twitter)','com.twitter.android','https://x.com'],['Chrome','com.android.chrome','https://www.google.com'],
    ['Gmail','com.google.android.gm','https://mail.google.com'],['Google Maps','com.google.android.apps.maps','https://maps.google.com'],
    ['Google Drive','com.google.android.apps.docs','https://drive.google.com'],['Google Foto','com.google.android.apps.photos','https://photos.google.com'],
    ['Spotify','com.spotify.music','https://open.spotify.com'],['YouTube Music','com.google.android.apps.youtube.music','https://music.youtube.com'],
    ['Canva','com.canva.editor','https://www.canva.com'],['Pinterest','com.pinterest','https://www.pinterest.com'],
    ['Roblox','com.roblox.client','https://www.roblox.com'],['Netflix','com.netflix.mediaclient','https://www.netflix.com'],
    ['Discord','com.discord','https://discord.com/app'],['Shopee','com.shopee.id','https://shopee.co.id'],
    ['Tokopedia','com.tokopedia.tkpd','https://www.tokopedia.com'],['Gojek','com.gojek.app','https://www.gojek.com'],
    ['ChatGPT','com.openai.chatgpt','https://chatgpt.com'],['Claude','com.anthropic.claude','https://claude.ai'],
    ['Kalkulator','com.google.android.calculator',''],['Kamera','',''],['Kalender','com.google.android.calendar','https://calendar.google.com'],
    ['Translate','com.google.android.apps.translate','https://translate.google.com']
  ].filter(x=>x[1]||x[2]).map(([name,pkg,url])=>({name,pkg,url}));
  const BLOCK=/(^|\.)(whatsapp|youtube|youtu|instagram|facebook|fb|tiktok|telegram|twitter|x|google|gmail|spotify|canva|pinterest|roblox|netflix|discord|shopee|tokopedia|gojek|openai|chatgpt|claude|anthropic|linkedin|amazon|github|reddit|twitch|apple|microsoft|live|office|bing|yahoo|paypal|dropbox|zoom|slack|notion|figma)\.[a-z.]+$/i;
  const isBlocked=u=>{try{return BLOCK.test(new URL(u).hostname)}catch(_){return false}};
  const isMobileUA=()=>/Android|iPhone|iPad|iPod|Mobi/i.test(navigator.userAgent);
  const urlFor=a=>a.url||((CATALOG.find(c=>c.pkg&&c.pkg===a.packageName)||{}).url)||'';
  const repo={
    all(){return safeParse(localStorage.getItem(STORE)||'[]').filter(x=>x&&x.id&&x.name)},
    save(items){try{localStorage.setItem(STORE,JSON.stringify(items))}catch(e){toast('Penyimpanan penuh/tidak tersedia')}},
    add(items){const old=this.all();const seen=new Set(old.map(x=>x.id));let n=0;items.forEach(x=>{if(!seen.has(x.id)){old.push({pinned:false,widthRatio:.6,...x});seen.add(x.id);n++}});this.save(old);return n},
    remove(id){this.save(this.all().filter(x=>x.id!==id))},
    update(id,patch){this.save(this.all().map(x=>x.id===id?{...x,...patch}:x))},
    get(id){return this.all().find(x=>x.id===id)}
  };
  const overlay=$('appPanelOverlay'), picker=$('appPickerOverlay');
  if(!overlay||!picker)return;
  let sortMode=localStorage.getItem('cms.appPanel.sort')||'az', installed=[], selected=new Set(), pressTimer=null, longPressed=false, catSel=new Set(), tab='cat', editingId=null;
  const isNative=()=>!!(bridge()&&typeof bridge().getInstalledApps==='function');
  const isAndroid=()=>/Android/i.test(navigator.userAgent);
  const nf=()=>!!(bridge()&&typeof bridge().openFloatingWeb==='function');
  const overlayOk=()=>{try{return !!bridge().hasOverlayPermission()}catch(_){return false}};
  let pendingFloat=null;   // V164: item yang menunggu izin overlay; dibuka otomatis setelah pengguna kembali dari Pengaturan
  function nativeFloat(app){
    const b=bridge();
    // V164: bawaan = jendela mengambang (overlay). Lembar Chrome hanya bila dipilih eksplisit (cara buka "Chrome asli") atau lewat tombol G di jendela.
    if(app.openMode==='chrome'&&typeof b.openChromeSheet==='function'){
      let ok=false;try{ok=!!b.openChromeSheet(app.url,.75)}catch(_){}
      if(ok)return;
    }
    if(!overlayOk()){
      pendingFloat=app;
      if(confirm('Agar jendela bisa mengambang di atas aplikasi lain, aktifkan izin "Tampil di atas aplikasi lain" untuk aplikasi ini. Buka pengaturannya sekarang?\n\nSetelah diaktifkan, kembali ke sini dan jendela akan terbuka otomatis.'))b.requestOverlayPermission();
      else{pendingFloat=null;toast('Izin "Tampil di atas aplikasi lain" diperlukan agar jendela mengambang.')}
      return;
    }
    pendingFloat=null;
    let ok=false,n0=0;try{n0=b.floatCount?b.floatCount():0;ok=!!b.openFloatingWeb(app.url,app.name,app.widthRatio||.6)}catch(_){}
    if(!ok)return toast('Gagal membuka jendela mengambang (hanya http/https yang didukung).');
    // V165: Service berjalan terpisah; periksa hasilnya dan tampilkan alasan bila jendela tidak muncul
    setTimeout(()=>{try{
      if(typeof b.floatCount!=='function')return;
      if(b.floatCount()>n0)return;
      const why=b.floatStatus?b.floatStatus():'';
      toast('Jendela mengambang tidak muncul'+(why?': '+why:'. Di HP Xiaomi/Oppo/Vivo aktifkan juga "Tampilkan jendela pop-up" di izin aplikasi.')+' — dibuka di Chrome.');
      if(typeof b.openChromeSheet==='function')b.openChromeSheet(app.url,.75);   // V166: cadangan agar tetap tampil
    }catch(_){}},1800);
  }
  function resumePending(){
    if(pendingFloat&&nf()&&overlayOk()){const a=pendingFloat;pendingFloat=null;nativeFloat(a)}
  }
  function floatPermUI(){
    let el=$('appFloatPerm');
    if(!nf()){if(el)el.remove();return}
    if(!el){el=document.createElement('button');el.id='appFloatPerm';el.type='button';el.className='btn subtle app-float-perm';
      $('appPanelStatus').after(el);
      el.addEventListener('click',()=>{const b=bridge();if(!overlayOk())b.requestOverlayPermission();else if(typeof b.closeAllFloating==='function'){b.closeAllFloating();toast('Semua jendela mengambang ditutup')}});}
    el.textContent=overlayOk()?'Jendela mengambang aktif • ketuk untuk tutup semua':'⚠ Izinkan "Tampil di atas aplikasi lain"';
  }
  const iconHTML=a=>a.icon?`<img src="${esc(a.icon)}" alt="">`:`<span>${esc((a.name||'?').trim().slice(0,1).toUpperCase())}</span>`;
  const iconStyle=a=>a.icon?'':` style="background:${colorFor(a.name)}"`;
  function toast(msg){let t=$('appPanelToast');if(!t){t=document.createElement('div');t.id='appPanelToast';t.className='app-panel-toast';document.body.appendChild(t)}
    t.textContent=msg;t.classList.add('show');clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove('show'),2600)}
  function normUrl(u){u=(u||'').trim();if(!u)return '';if(!/^[a-z][a-z0-9+.-]*:/i.test(u))u='https://'+u;
    try{const x=new URL(u);return /^https?:$/.test(x.protocol)?x.href:''}catch(_){return ''}}
  const normPkg=p=>{p=(p||'').trim();return /^[a-zA-Z][\w]*(\.[a-zA-Z][\w]*)+$/.test(p)?p:''};
  function status(){floatPermUI();$('appPanelStatus').textContent=isNative()?'Aplikasi terinstal • mode jendela bergantung dukungan Android'
    :(isAndroid()?'Mode web Android: aplikasi dibuka lewat package/URL':'Mode web: shortcut URL & jendela mengambang');}
  function render(){
    const q=($('appPanelSearch').value||'').toLowerCase();
    const items=repo.all().filter(x=>x.name.toLowerCase().includes(q)||(x.url||'').toLowerCase().includes(q)||(x.packageName||'').toLowerCase().includes(q)).sort((a,b)=>(!!b.pinned-!!a.pinned)||(sortMode==='recent'?(b.lastOpened||0)-(a.lastOpened||0):sortMode==='freq'?(b.opens||0)-(a.opens||0):0)||a.name.localeCompare(b.name));
    document.querySelectorAll('#appPanelSort [data-sort]').forEach(b=>b.classList.toggle('is-active',b.dataset.sort===sortMode));
    $('appPanelGrid').innerHTML=items.length?items.map(a=>`<button class="app-panel-item ${a.pinned?'is-pinned':''}" data-app-id="${esc(a.id)}" type="button"><span class="app-panel-icon"${iconStyle(a)}>${iconHTML(a)}</span><span class="app-panel-name">${esc(a.name)}</span>${a.pinned?'<i>PIN</i>':''}</button>`).join('')
      :`<div class="app-panel-empty">${q?'Tidak ada yang cocok.':'Belum ada aplikasi.<br>Tekan <b>＋ Tambah Aplikasi</b> untuk memulai.'}</div>`;
    status();
  }
  /* ---------- Panel mengambang (geser, kecilkan) ---------- */
  const sheet=overlay.querySelector('.app-panel-sheet');
  const POS='cms.appPanel.pos';
  const clampPos=(x,y)=>{const w=sheet.offsetWidth||320,vw=window.innerWidth,vh=window.innerHeight;
    return {x:Math.round(Math.min(vw-60,Math.max(60-w,x))),y:Math.round(Math.min(vh-48,Math.max(0,y)))}};
  function placeSheet(reset){
    let p=null;if(!reset){try{p=JSON.parse(localStorage.getItem(POS)||'null')}catch(_){}}
    const w=sheet.offsetWidth||320;
    if(!p||typeof p.x!=='number')p={x:(window.innerWidth-w)/2,y:Math.max(8,window.innerHeight*.08)};
    p=clampPos(p.x,p.y);sheet.style.left=p.x+'px';sheet.style.top=p.y+'px';
  }
  function setMin(on){sheet.classList.toggle('is-min',on);const b=$('appPanelMin');if(b){b.textContent=on?'▢':'–';b.title=on?'Perbesar':'Kecilkan'}}
  (function dragInit(){
    const handles=sheet.querySelectorAll('.app-panel-grabber,.app-panel-head');
    handles.forEach(h=>h.addEventListener('pointerdown',ev=>{
      if(ev.target.closest('button,input,select,a'))return;
      ev.preventDefault();h.setPointerCapture(ev.pointerId);
      const sx=ev.clientX,sy=ev.clientY,ox=parseFloat(sheet.style.left)||0,oy=parseFloat(sheet.style.top)||0;sheet.classList.add('is-moving');
      const mv=e=>{const p=clampPos(ox+e.clientX-sx,oy+e.clientY-sy);sheet.style.left=p.x+'px';sheet.style.top=p.y+'px'};
      const up=()=>{sheet.classList.remove('is-moving');h.removeEventListener('pointermove',mv);h.removeEventListener('pointerup',up);h.removeEventListener('pointercancel',up);
        try{localStorage.setItem(POS,JSON.stringify({x:parseFloat(sheet.style.left),y:parseFloat(sheet.style.top)}))}catch(_){}};
      h.addEventListener('pointermove',mv);h.addEventListener('pointerup',up);h.addEventListener('pointercancel',up);
    }));
    const mb=$('appPanelMin');if(mb)mb.addEventListener('click',()=>setMin(!sheet.classList.contains('is-min')));
    window.addEventListener('resize',()=>{if(overlay.classList.contains('is-open'))placeSheet(false)});
  })();
  function openPanel(){overlay.classList.add('is-open');overlay.setAttribute('aria-hidden','false');setMin(false);render();placeSheet(false)}
  function closePanel(){overlay.classList.remove('is-open');overlay.setAttribute('aria-hidden','true')}
  async function getInstalled(){
    if(!isNative())return [];
    try{let r=bridge().getInstalledApps();if(typeof r==='string')r=JSON.parse(r);return Array.isArray(r)?r:[]}catch(e){console.error(e);return []}
  }
  /* ---------- Dialog Tambah (web) ---------- */
  function buildAddDialog(){
    if($('appAddOverlay'))return;
    const d=document.createElement('div');d.id='appAddOverlay';d.className='app-picker-overlay';d.setAttribute('aria-hidden','true');
    d.innerHTML=`<section class="app-picker-dialog" role="dialog" aria-modal="true">
      <header class="app-panel-head"><div><h2 id="appAddTitle">Tambah Aplikasi</h2><p>Pilih dari katalog atau isi manual.</p></div><button type="button" class="app-panel-close" data-add-close aria-label="Tutup">×</button></header>
      <div class="app-add-tabs"><button type="button" data-tab="cat" class="is-active">Katalog</button><button type="button" data-tab="man">Manual</button><button type="button" data-tab="data">Cadangan</button></div>
      <div data-pane="cat"><input id="appCatSearch" type="search" placeholder="Cari di katalog..."><div id="appCatList" class="app-picker-list"></div>
        <div class="app-picker-actions"><span id="appCatCount" class="app-add-count">0 dipilih</span><button type="button" class="btn subtle" data-add-close>Batal</button><button type="button" class="btn primary" id="appCatSave">Tambahkan</button></div></div>
      <form data-pane="man" class="app-add-form" hidden autocomplete="off">
        <label>Nama aplikasi<input id="appFName" maxlength="40" placeholder="mis. WhatsApp"></label>
        <label>Package Android (opsional)<input id="appFPkg" placeholder="mis. com.whatsapp" autocapitalize="off" spellcheck="false"></label>
        <label>URL / website (opsional)<input id="appFUrl" placeholder="mis. https://web.whatsapp.com" autocapitalize="off" spellcheck="false" inputmode="url"></label>
        <label>Ikon (opsional, URL gambar)<input id="appFIcon" placeholder="https://.../ikon.png" autocapitalize="off"></label>
        <label>Cara buka<select id="appFMode"><option value="auto">Otomatis (mengambang di atas layar)</option><option value="float">Jendela mengambang (URL)</option><option value="chrome">Chrome asli, lembar di atas aplikasi (login Google)</option><option value="app">Aplikasi Android (package, keluar dari sini)</option><option value="tab">Tab baru (URL)</option></select></label>
        <p id="appFErr" class="app-add-err" role="alert"></p>
        <div class="app-picker-actions"><button type="button" class="btn subtle" data-add-close>Batal</button><button type="submit" class="btn primary">Simpan</button></div></form>
      <div data-pane="data" hidden class="app-add-data"><p>Simpan daftar aplikasi ke file, atau muat dari file cadangan.</p>
        <div class="app-picker-actions" style="justify-content:flex-start"><button type="button" class="btn primary" id="appExport">⬇ Ekspor JSON</button><button type="button" class="btn subtle" id="appImport">⬆ Impor JSON</button></div>
        <input type="file" id="appImportFile" accept=".json,application/json" hidden></div>
    </section>`;
    document.body.appendChild(d);
    d.addEventListener('click',e=>{if(e.target===d||e.target.closest('[data-add-close]'))closeAdd();const t=e.target.closest('[data-tab]');if(t)setTab(t.dataset.tab)});
    $('appCatSearch').addEventListener('input',renderCat);
    $('appCatList').addEventListener('change',e=>{const i=e.target.dataset.cat;if(i==null)return;e.target.checked?catSel.add(i):catSel.delete(i);$('appCatCount').textContent=catSel.size+' dipilih'});
    $('appCatSave').addEventListener('click',saveCat);
    d.querySelector('form').addEventListener('submit',e=>{e.preventDefault();saveManual()});
    $('appExport').addEventListener('click',exportJSON);
    $('appImport').addEventListener('click',()=>$('appImportFile').click());
    $('appImportFile').addEventListener('change',importJSON);
  }
  function setTab(t){tab=t;const d=$('appAddOverlay');d.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('is-active',b.dataset.tab===t));
    d.querySelectorAll('[data-pane]').forEach(p=>p.hidden=p.dataset.pane!==t)}
  function renderCat(){
    const q=($('appCatSearch').value||'').toLowerCase(), have=new Set(repo.all().map(x=>x.id));
    const list=CATALOG.map((a,i)=>({...a,i})).filter(a=>a.name.toLowerCase().includes(q));
    $('appCatList').innerHTML=list.length?list.map(a=>{const id=a.pkg||'url:'+a.url,dup=have.has(id);
      return `<label class="app-picker-row${dup?' is-added':''}"><input type="checkbox" data-cat="${a.i}" ${dup?'disabled checked':catSel.has(String(a.i))?'checked':''}><span class="app-panel-icon" style="background:${colorFor(a.name)}"><span>${esc(a.name[0])}</span></span><span><b>${esc(a.name)}</b><small>${dup?'Sudah ditambahkan':esc(a.pkg||a.url)}</small></span></label>`}).join('')
      :'<div class="app-panel-empty">Tidak ada di katalog. Gunakan tab Manual.</div>';
    $('appCatCount').textContent=catSel.size+' dipilih';
  }
  function openAdd(item){
    buildAddDialog();editingId=item?item.id:null;catSel.clear();$('appCatSearch').value='';renderCat();
    $('appAddTitle').textContent=item?'Edit Aplikasi':'Tambah Aplikasi';
    $('appAddOverlay').querySelector('[data-tab="cat"]').hidden=!!item;$('appAddOverlay').querySelector('[data-tab="data"]').hidden=!!item;
    $('appFName').value=item?item.name:'';$('appFPkg').value=item?(item.packageName||''):'';$('appFUrl').value=item?(item.url||''):'';
    $('appFIcon').value=item&&item.icon&&!/^data:/.test(item.icon)?item.icon:'';$('appFMode').value=item?(item.openMode||'auto'):'auto';$('appFErr').textContent='';
    setTab(item?'man':'cat');
    const d=$('appAddOverlay');d.classList.add('is-open');d.setAttribute('aria-hidden','false');
  }
  function closeAdd(){const d=$('appAddOverlay');if(!d)return;d.classList.remove('is-open');d.setAttribute('aria-hidden','true');editingId=null}
  function saveCat(){
    const chosen=[...catSel].map(i=>CATALOG[Number(i)]).filter(Boolean).map(a=>({id:a.pkg||'url:'+a.url,name:a.name,packageName:a.pkg,url:a.url,kind:a.pkg?'app':'shortcut',openMode:'auto'}));
    if(!chosen.length){toast('Pilih minimal satu aplikasi');return}
    const n=repo.add(chosen);closeAdd();render();toast(n+' aplikasi ditambahkan');
  }
  function saveManual(){
    const name=$('appFName').value.trim(), pkgRaw=$('appFPkg').value.trim(), urlRaw=$('appFUrl').value.trim(), icRaw=$('appFIcon').value.trim();
    const pkg=normPkg(pkgRaw), url=normUrl(urlRaw), icon=icRaw?normUrl(icRaw):'', err=$('appFErr');
    if(!name){err.textContent='Nama wajib diisi.';return}
    if(pkgRaw&&!pkg){err.textContent='Package tidak valid. Contoh: com.whatsapp';return}
    if(urlRaw&&!url){err.textContent='URL tidak valid. Gunakan http:// atau https://';return}
    if(icRaw&&!icon){err.textContent='URL ikon tidak valid.';return}
    if(!pkg&&!url){err.textContent='Isi package Android atau URL (minimal salah satu).';return}
    const data={name,packageName:pkg,url,icon,openMode:$('appFMode').value,kind:pkg?'app':'shortcut'};
    if(editingId){const old=repo.get(editingId);repo.update(editingId,{...data,kind:old&&old.kind==='native'&&pkg?'native':data.kind});toast('Perubahan disimpan')}
    else{const id=pkg||'url:'+url;if(repo.get(id)){err.textContent='Aplikasi ini sudah ada di panel.';return}repo.add([{id,...data}]);toast('Aplikasi ditambahkan')}
    closeAdd();render();
  }
  function exportJSON(){
    const blob=new Blob([JSON.stringify({type:'cdms-app-panel',v:1,items:repo.all()},null,2)],{type:'application/json'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='panel-aplikasi.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000);
  }
  function importJSON(e){
    const f=e.target.files&&e.target.files[0];e.target.value='';if(!f)return;
    if(f.size>2e6){toast('File terlalu besar');return}
    const r=new FileReader();r.onload=()=>{
      try{const j=JSON.parse(r.result);const arr=Array.isArray(j)?j:j.items;if(!Array.isArray(arr))throw 0;
        const items=arr.filter(x=>x&&typeof x.name==='string'&&x.name.trim()).slice(0,300).map(x=>{
          const pkg=normPkg(x.packageName),url=normUrl(x.url);if(!pkg&&!url)return null;
          return {id:pkg||'url:'+url,name:x.name.trim().slice(0,40),packageName:pkg,url,icon:/^https?:\/\//.test(x.icon||'')?x.icon:'',kind:pkg?'app':'shortcut',openMode:['auto','float','tab','app','chrome'].includes(x.openMode)?x.openMode:'auto',pinned:!!x.pinned,widthRatio:Math.min(.8,Math.max(.4,Number(x.widthRatio)||.6))}}).filter(Boolean);
        const n=repo.add(items);closeAdd();render();toast(n+' aplikasi diimpor')}
      catch(_){toast('File tidak valid')}};
    r.readAsText(f);
  }
  /* ---------- Jendela mengambang ---------- */
  let zTop=10070;
  function floatWin(app){
    if(nf())return nativeFloat(app);   // APK: overlay native di atas semua aplikasi (tidak memakai iframe)
    if(isBlocked(app.url)&&!isMobileUA()){   // situs melarang iframe → jendela pop-up mengambang sungguhan
      const vw=screen.availWidth,vh=screen.availHeight,w=Math.round(Math.max(420,vw*Math.min(.8,Math.max(.4,app.widthRatio||.6)))),h=Math.round(vh*.75);
      const pw=window.open(app.url,'cdms_'+String(app.id).replace(/[^\w]/g,'_'),`popup=yes,width=${w},height=${h},left=${Math.round((vw-w)/2)},top=${Math.round(vh*.1)}`);
      if(!pw)toast('Pop-up diblokir browser. Izinkan pop-up untuk situs ini.');
      return;
    }
    const blocked=isBlocked(app.url);
    const wid='appFloat-'+String(app.id).replace(/[^\w-]/g,'_');
    const same=document.getElementById(wid);if(same){same.style.zIndex=++zTop;same.classList.remove('is-min');return}
    const open=[...document.querySelectorAll('.app-float')];
    if(open.length>=3){open[0].remove();toast('Maksimal 3 jendela; yang tertua ditutup')}
    const n=document.querySelectorAll('.app-float').length;
    const ratio=Math.min(.8,Math.max(.4,app.widthRatio||.6)), vw=window.innerWidth, vh=window.innerHeight;
    const w=Math.min(Math.max(280,Math.round(vw*ratio)),vw-8), h=Math.min(Math.round(vh*.6),vh-8);
    const el=document.createElement('div');el.id=wid;el.className='app-float';
    let top0=Math.round(vh*.1),h2=h;
    if(overlay.classList.contains('is-open')){const pb=sheet.getBoundingClientRect().bottom+8;if(vh-pb>=220){top0=Math.round(pb);h2=Math.min(h,vh-top0-8);}}   // jangan menutupi panel yang sedang terbuka
    el.style.cssText=`width:${w}px;height:${h2}px;left:${Math.max(4,Math.round((vw-w)/2)+n*18)}px;top:${top0+n*26}px;z-index:${++zTop}`;
    el.innerHTML=`<div class="app-float-bar"><b>${esc(app.name)}</b><span><button type="button" data-f="reload" title="Muat ulang">⟳</button><button type="button" data-f="snap" title="Tata letak cepat">⬒</button><button type="button" data-f="min" title="Kecilkan">–</button><button type="button" data-f="open" title="Buka di tab baru">↗</button><button type="button" data-f="close" title="Tutup">×</button></span></div>
      ${blocked?`<div class="app-float-blocked"><p><b>${esc(app.name)}</b> melarang tampil di dalam jendela browser.</p><p>Pasang APK (folder <code>android/</code>) dan izinkan "Tampil di atas aplikasi lain" agar semua aplikasi bisa mengambang.</p><button type="button" class="btn primary" data-f="open">Buka di tab baru</button></div>`
        :`<iframe src="${esc(app.url)}" referrerpolicy="no-referrer" sandbox="allow-scripts allow-same-origin allow-forms allow-popups" title="${esc(app.name)}"></iframe>`}
      <p class="app-float-note">Jika kosong, situs ini melarang ditampilkan di jendela. Ketuk ↗ untuk membuka di tab baru.</p><i class="app-float-grip"></i>`;
    document.body.appendChild(el);
    const fr=el.querySelector('iframe')||{set src(v){}};
    el.addEventListener('pointerdown',()=>{el.style.zIndex=++zTop},true);
    el.querySelector('[data-f="close"]').onclick=()=>el.remove();
    el.querySelectorAll('[data-f="open"]').forEach(b=>b.onclick=()=>window.open(app.url,'_blank','noopener'));
    el.querySelector('[data-f="reload"]').onclick=()=>{fr.src=app.url};
    el.querySelector('[data-f="min"]').onclick=()=>el.classList.toggle('is-min');
    // V176: tata letak cepat (sama seperti APK): kiri → kanan → atas → bawah → penuh → semula
    let snapStep=0,orig=null;
    el.querySelector('[data-f="snap"]').onclick=()=>{
      const W=window.innerWidth,H=window.innerHeight,t=8,g=4;el.classList.remove('is-min');
      if(!orig)orig={l:el.style.left,t:el.style.top,w:el.style.width,h:el.style.height};
      const L=[[0,t,W/2-g,H-t-8],[W/2+g,t,W/2-g,H-t-8],[0,t,W,H/2-t-g],[0,H/2+g,W,H/2-g-8],[0,t,W,H-t-8]];
      const i=snapStep%6;
      if(i===5){el.style.left=orig.l;el.style.top=orig.t;el.style.width=orig.w;el.style.height=orig.h;orig=null}
      else{const r=L[i];el.style.left=Math.round(r[0])+'px';el.style.top=Math.round(r[1])+'px';el.style.width=Math.round(r[2])+'px';el.style.height=Math.round(r[3])+'px'}
      snapStep++;
    };
    // ketuk dua kali bilah judul = layar penuh ↔ semula
    let lastTap=0;el.querySelector('.app-float-bar').addEventListener('pointerup',ev=>{
      if(ev.target.closest('button'))return;const n=Date.now();
      if(n-lastTap<350){lastTap=0;const sb=el.querySelector('[data-f="snap"]');if(orig){snapStep=5;sb.onclick();snapStep=0}else{snapStep=4;sb.onclick();snapStep=5}}else lastTap=n});
    const bar=el.querySelector('.app-float-bar'), grip=el.querySelector('.app-float-grip');
    const drag=(handle,fn)=>handle.addEventListener('pointerdown',ev=>{if(ev.target.closest('button'))return;ev.preventDefault();handle.setPointerCapture(ev.pointerId);
      const sx=ev.clientX,sy=ev.clientY,r=el.getBoundingClientRect();el.classList.add('is-moving');
      const mv=e=>fn(e.clientX-sx,e.clientY-sy,r);const up=()=>{el.classList.remove('is-moving');handle.removeEventListener('pointermove',mv);handle.removeEventListener('pointerup',up);handle.removeEventListener('pointercancel',up)};
      handle.addEventListener('pointermove',mv);handle.addEventListener('pointerup',up);handle.addEventListener('pointercancel',up)});
    drag(bar,(dx,dy,r)=>{el.style.left=Math.min(window.innerWidth-60,Math.max(-r.width+60,r.left+dx))+'px';el.style.top=Math.min(window.innerHeight-40,Math.max(0,r.top+dy))+'px'});
    drag(grip,(dx,dy,r)=>{el.style.width=Math.max(240,Math.min(window.innerWidth,r.width+dx))+'px';el.style.height=Math.max(180,Math.min(window.innerHeight,r.height+dy))+'px'});
  }
  /* ---------- Buka aplikasi ---------- */
  function openPackage(app){
    const pkg=app.packageName, play='https://play.google.com/store/apps/details?id='+encodeURIComponent(pkg);
    if(isAndroid()){
      // Chrome/Android: buka aplikasi terpasang lewat intent; jika tidak ada → Play Store.
      const fb=encodeURIComponent(app.url||play);
      location.href=`intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${pkg};S.browser_fallback_url=${fb};end`;
      return true;
    }
    return false;
  }
  async function launch(app){
    const u0=urlFor(app);if(u0&&!app.url)app={...app,url:u0};
    repo.update(app.id,{lastOpened:Date.now(),opens:(app.opens||0)+1});
    // V164: item yang punya URL (milik sendiri atau dari katalog) dibuka sebagai jendela web mengambang (overlay) — pasti mengambang.
    // Freeform bawaan Android sering mengabaikan ukuran jendela sehingga aplikasi terbuka layar penuh.
    if(isNative()&&app.url&&nf()&&app.openMode!=='app'&&app.openMode!=='tab')return nativeFloat(app);
    if(isNative()&&app.packageName&&(app.kind==='native'||app.kind==='app')){
      try{if(bridge().launchFreeform(app.packageName,app.widthRatio||.6)===true)return;
        if(app.url&&nf())return nativeFloat(app);   // freeform tidak ada → tetap mengambang lewat overlay
        const b=bridge();let supported=true;try{if(typeof b.freeformSupported==='function')supported=!!b.freeformSupported()}catch(_){}
        if(!supported&&typeof b.openFreeformSettings==='function'){
          if(confirm('Perangkat ini belum mengaktifkan "Jendela freeform". Buka Opsi Pengembang untuk mengaktifkannya?\n\n(Batal = buka aplikasi secara normal)')){b.openFreeformSettings();return}
        }else if(!confirm('Mode jendela gagal untuk aplikasi ini. Buka secara normal?'))return;
        if(b.launchNormal)b.launchNormal(app.packageName);return}
      catch(e){if(bridge().launchNormal)bridge().launchNormal(app.packageName);return}
    }
    const mode=app.openMode||'auto';
    // 'app' = pilihan eksplisit membuka aplikasi Android lewat package (meninggalkan halaman ini)
    if(mode==='app'&&app.packageName&&openPackage(app))return;
    if(app.url){
      if(mode==='tab'){window.open(app.url,'_blank','noopener');return}
      return floatWin(app);   // bawaan: jendela mengambang di atas layar, tidak berpindah ke tautan
    }
    if(app.packageName&&openPackage(app))return;
    toast(app.packageName?'Pembukaan aplikasi lewat package hanya di Android. Tambahkan URL untuk dibuka di sini.':'Aplikasi ini belum punya URL/package.');
  }
  /* ---------- Menu item (ganti prompt) ---------- */
  function itemMenu(app){
    let m=$('appItemMenu');if(m)m.remove();
    m=document.createElement('div');m.id='appItemMenu';m.className='app-picker-overlay is-open';
    m.innerHTML=`<section class="app-picker-dialog app-item-menu"><header class="app-panel-head"><div><h2>${esc(app.name)}</h2><p>${esc(app.packageName||app.url||'')}</p></div><button type="button" class="app-panel-close" data-m="x">×</button></header>
      <button data-m="open">▶ Buka</button>${app.url?'<button data-m="float">🗗 Buka di jendela mengambang</button>':''}
      ${app.url?'<button data-m="copy">📋 Salin URL</button>':''}<button data-m="dup">⧉ Duplikat</button>
      <button data-m="pin">${app.pinned?'📌 Lepas pin':'📌 Pin ke atas'}</button><button data-m="edit">✏ Edit</button>
      <label class="app-item-size">Lebar jendela: <b id="appSizeVal">${Math.round((app.widthRatio||.6)*100)}%</b><input type="range" id="appSize" min="40" max="80" step="5" value="${Math.round((app.widthRatio||.6)*100)}"></label>
      <button data-m="del" class="danger">🗑 Hapus dari panel</button></section>`;
    document.body.appendChild(m);
    const close=()=>m.remove();
    m.querySelector('#appSize').addEventListener('input',e=>{$('appSizeVal').textContent=e.target.value+'%';repo.update(app.id,{widthRatio:Number(e.target.value)/100})});
    m.addEventListener('click',e=>{
      if(e.target===m)return close();const b=e.target.closest('[data-m]');if(!b)return;const k=b.dataset.m;
      if(k==='x')close();
      else if(k==='open'){close();launch(repo.get(app.id)||app)}
      else if(k==='float'){close();floatWin(repo.get(app.id)||app)}
      else if(k==='pin'){repo.update(app.id,{pinned:!app.pinned});close();render()}
      else if(k==='edit'){close();openAdd(repo.get(app.id)||app)}
      else if(k==='copy'){close();const u=app.url||'';
        const ok=()=>toast('URL disalin');
        try{navigator.clipboard.writeText(u).then(ok,()=>toast(u))}catch(_){toast(u)}}
      else if(k==='dup'){close();const id='dup:'+Date.now().toString(36);
        repo.add([{...app,id,name:(app.name+' (salinan)').slice(0,40),pinned:false,packageName:app.packageName&&!app.url?app.packageName:'',kind:app.url?'shortcut':app.kind,lastOpened:0,opens:0}]);render();toast('Diduplikasi')}
      else if(k==='del'){if(confirm(`Hapus ${app.name} dari panel?`)){repo.remove(app.id);close();render();toast('Dihapus')}}
    });
  }
  /* ---------- Picker native (bridge) ---------- */
  function renderPicker(){
    const q=($('appPickerSearch').value||'').toLowerCase();
    const list=installed.filter(a=>(a.name||'').toLowerCase().includes(q)&&!repo.all().some(x=>x.id===(a.packageName||a.id)));
    $('appPickerList').innerHTML=list.length?list.map((a,i)=>`<label class="app-picker-row"><input type="checkbox" data-picker-index="${installed.indexOf(a)}" ${selected.has(a.packageName||a.id)?'checked':''}><span class="app-panel-icon">${iconHTML(a)}</span><span><b>${esc(a.name||a.packageName||'Aplikasi')}</b><small>${esc(a.packageName||'')}</small></span></label>`).join(''):'<div class="app-panel-empty">Tidak ada aplikasi yang cocok.</div>';
  }
  async function showPicker(){
    if(!isNative())return openAdd(null);
    installed=await getInstalled();
    if(!installed.length){toast('Daftar aplikasi native tidak tersedia; memakai katalog.');return openAdd(null)}
    selected.clear();$('appPickerSearch').value='';renderPicker();picker.classList.add('is-open');picker.setAttribute('aria-hidden','false');
  }
  function closePicker(){picker.classList.remove('is-open');picker.setAttribute('aria-hidden','true')}
  function savePicker(){
    const chosen=[...selected].map(id=>installed.find(a=>(a.packageName||a.id)===id)).filter(Boolean).map(a=>({id:a.packageName||a.id,name:a.name||a.packageName,packageName:a.packageName||a.id,icon:a.icon||'',kind:'native'}));
    const n=repo.add(chosen);closePicker();render();toast(n+' aplikasi ditambahkan');
  }
  document.addEventListener('click',e=>{
    if(e.target.closest('[data-action="openAppPanel"]'))openPanel();
    if(e.target.closest('[data-app-panel-close]'))closePanel();
    if(e.target.closest('[data-picker-close]'))closePicker();
    const item=e.target.closest('.app-panel-item');
    if(item&&!longPressed){const app=repo.get(item.dataset.appId);if(app)launch(app)}
    longPressed=false;
  });
  $('appPanelSort').addEventListener('click',e=>{const b=e.target.closest('[data-sort]');if(!b)return;sortMode=b.dataset.sort;try{localStorage.setItem('cms.appPanel.sort',sortMode)}catch(_){}render()});
  $('appPanelAdd').addEventListener('click',showPicker);
  // V167: buka semua aplikasi ber-PIN yang punya URL sekaligus (maks. 3 jendela), mis. ruang kerja favorit
  // V174: ketik alamat (atau kata pencarian) -> langsung jadi jendela mengambang, tanpa menambah item
  const quick=$('appPanelQuick');
  if(quick)quick.addEventListener('submit',e=>{
    e.preventDefault();const inp=$('appPanelQuickUrl');let v=(inp.value||'').trim();if(!v)return;
    const looksUrl=/^[a-z][a-z0-9+.-]*:\/\//i.test(v)||(/^[^\s]+\.[a-z]{2,}([/:?#].*)?$/i.test(v)&&!/\s/.test(v));
    const url=looksUrl?normUrl(v):'https://duckduckgo.com/?q='+encodeURIComponent(v);
    if(!url)return toast('Alamat tidak valid (hanya http/https).');
    let host='';try{host=new URL(url).hostname.replace(/^www\./,'')}catch(_){}
    floatWin({id:'quick:'+url,name:looksUrl?host:'Cari: '+v.slice(0,24),url,widthRatio:.6,openMode:'float'});
    inp.value='';
  });
  const openRecent=$('appPanelOpenRecent');   // V168: buka 3 aplikasi terakhir dipakai
  if(openRecent)openRecent.addEventListener('click',()=>{
    const rec=repo.all().filter(a=>a.lastOpened&&urlFor(a)).sort((a,b)=>b.lastOpened-a.lastOpened).slice(0,3);
    if(!rec.length)return toast('Belum ada aplikasi yang pernah dibuka.');
    rec.forEach((a,i)=>setTimeout(()=>floatWin(a.url?a:{...a,url:urlFor(a)}),i*350));
    toast('Membuka '+rec.length+' jendela…');
  });
  const openPins=$('appPanelOpenPins');
  if(openPins)openPins.addEventListener('click',()=>{
    const pins=repo.all().filter(a=>a.pinned&&urlFor(a)).slice(0,3);
    if(!pins.length)return toast('Belum ada aplikasi ber-PIN yang punya URL. Tekan lama ikon lalu pilih Pin.');
    pins.forEach((a,i)=>setTimeout(()=>floatWin(a.url?a:{...a,url:urlFor(a)}),i*350));
    toast('Membuka '+pins.length+' jendela…');
  });
  $('appPanelSearch').addEventListener('input',render);
  $('appPickerSearch').addEventListener('input',renderPicker);
  $('appPickerList').addEventListener('change',e=>{const i=Number(e.target.dataset.pickerIndex);if(!Number.isNaN(i)&&installed[i]){const id=installed[i].packageName||installed[i].id;e.target.checked?selected.add(id):selected.delete(id)}});
  $('appPickerSave').addEventListener('click',savePicker);
  $('appPanelGrid').addEventListener('contextmenu',e=>{const item=e.target.closest('.app-panel-item');if(!item)return;e.preventDefault();const app=repo.get(item.dataset.appId);if(app)itemMenu(app)});
  $('appPanelGrid').addEventListener('touchstart',e=>{const item=e.target.closest('.app-panel-item');if(!item)return;longPressed=false;pressTimer=setTimeout(()=>{longPressed=true;const app=repo.get(item.dataset.appId);if(app)itemMenu(app)},550)},{passive:true});
  ['touchend','touchmove','touchcancel'].forEach(ev=>$('appPanelGrid').addEventListener(ev,()=>clearTimeout(pressTimer),{passive:true}));
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&overlay.classList.contains('is-open'))render()});
  picker.addEventListener('click',e=>{if(e.target===picker)closePicker()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeAdd();closePicker();closePanel();const m=$('appItemMenu');if(m)m.remove()}});
  async function validate(){if(!isNative())return;const apps=await getInstalled();if(!apps.length)return;const pk=new Set(apps.map(a=>a.packageName||a.id));
    repo.all().forEach(a=>{if(a.kind==='native'&&!pk.has(a.packageName))repo.remove(a.id)});}
  window.PanelAppDrawer={open:openPanel,close:closePanel,refresh:()=>{render();resumePending()},repository:repo,openAdd};
  validate();
})();
