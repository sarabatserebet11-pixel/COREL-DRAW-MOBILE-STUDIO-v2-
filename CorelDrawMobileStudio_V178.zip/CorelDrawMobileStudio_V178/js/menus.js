/* V13: tombol menu (dropdown) berisi tombol-tombol turunan + fitur baru */
(()=>{
const S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),T=m=>CDMS.toast(m);
const sels=()=>(S.selectedIds&&S.selectedIds.length?S.selectedIds:(S.selected?[S.selected]:[])).map(id=>S.objects.find(o=>o.id===id)).filter(Boolean);
const pick=a=>{S.selectedIds=a.map(o=>o.id);S.selected=a[0]?a[0].id:null;C.render();};
const edit=(fn,msg,filter)=>{const a=sels().filter(filter||(()=>true));if(!a.length)return T("Pilih objek dulu");Hi.snapshot();a.forEach(fn);C.render();if(msg)T(msg);};
const tx=fn=>edit(fn,"",o=>o.type==="text");
const nr=v=>((v+540)%360)-180;

/* ---- data ---- */
const SHP=[["Segitiga","M50 8L94 90H6Z"],["Belah ketupat","M50 4L96 50L50 96L4 50Z"],["Hati","M50 88C10 58 6 34 22 20C34 10 46 16 50 28C54 16 66 10 78 20C94 34 90 58 50 88Z"],["Panah","M6 38H60V14L94 50L60 86V62H6Z"],["Dua panah","M4 50L28 26V42H72V26L96 50L72 74V58H28V74Z"],["Awan","M26 78A20 20 0 0 1 22 40A26 26 0 0 1 72 34A22 22 0 0 1 76 78Z"],["Bubble chat","M10 14H90V66H48L26 88V66H10Z"],["Segi enam","M50 4L91 27V73L50 96L9 73V27Z"],["Trapesium","M24 20H76L96 80H4Z"],["Tetes air","M50 6C22 42 18 54 18 64A32 32 0 0 0 82 64C82 54 78 42 50 6Z"],["Setengah","M6 70A44 44 0 0 1 94 70Z"],["Cincin","M50 6A44 44 0 1 0 50 94A44 44 0 1 0 50 6ZM50 24A26 26 0 1 1 50 76A26 26 0 1 1 50 24Z"],["Bingkai","M6 6H94V94H6ZM26 26V74H74V26Z"],["Bintang 8","M50 4L60 24L82 18L76 40L96 50L76 60L82 82L60 76L50 96L40 76L18 82L24 60L4 50L24 40L18 18L40 24Z"]];
const COL=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4f83ff","#ff7ac8"];let ci=0;
const GR=[["Sunset","#ff9966","#ff5e62"],["Ocean","#00c6ff","#0072ff"],["Neon","#00d6c9","#7b6cff"],["Mint","#a8ff78","#00b09b"],["Api","#f12711","#f5af19"],["Royal","#4b1fa8","#c471f5"],["Emas","#f9d423","#c79100"],["Mono","#434343","#d0d0d0"]];
const FLT=[["Hitam putih","grayscale(1)"],["Sepia","sepia(.9)"],["Vintage","sepia(.5) contrast(1.1) saturate(1.3)"],["Cerah","brightness(1.25)"],["Gelap","brightness(.7)"],["Kontras","contrast(1.4)"],["Warna hidup","saturate(1.8)"],["Dingin","hue-rotate(180deg) saturate(1.2)"],["Invert","invert(1)"],["Blur","blur(4px)"]];
const FAM=[["Arial","Arial, sans-serif"],["Georgia","Georgia, serif"],["Impact","Impact, 'Arial Black', sans-serif"],["Courier","'Courier New', monospace"],["Comic","'Comic Sans MS', cursive"],["Trebuchet","'Trebuchet MS', sans-serif"]];

/* ---- fungsi ---- */
function addShape(n,d){Hi.snapshot();const W=S.page.width,H=S.page.height,z=Math.round(Math.min(W,H)*.25),o={id:uid(),type:"path",name:n,x:Math.round((W-z)/2),y:Math.round((H-z)/2),w:z,h:z,vw:100,vh:100,d,fill:COL[ci++%COL.length],stroke:"none",strokeWidth:0,opacity:100,rotation:0};S.objects.push(o);pick([o]);}
function z(k){const a=sels();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const set=new Set(a.map(o=>o.id));let r=S.objects;
 if(k==="front")S.objects=[...r.filter(o=>!set.has(o.id)),...r.filter(o=>set.has(o.id))];
 else if(k==="back")S.objects=[...r.filter(o=>set.has(o.id)),...r.filter(o=>!set.has(o.id))];
 else if(k==="up"){for(let i=r.length-2;i>=0;i--)if(set.has(r[i].id)&&!set.has(r[i+1].id))[r[i],r[i+1]]=[r[i+1],r[i]];}
 else{for(let i=1;i<r.length;i++)if(set.has(r[i].id)&&!set.has(r[i-1].id))[r[i],r[i-1]]=[r[i-1],r[i]];}
 C.render();}
const box=a=>({x0:Math.min(...a.map(o=>o.x)),x1:Math.max(...a.map(o=>o.x+o.w)),y0:Math.min(...a.map(o=>o.y)),y1:Math.max(...a.map(o=>o.y+(o.h||0)))});
function alignTo(k){const a=sels();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const b=box(a),W=S.page.width,H=S.page.height;let dx=0,dy=0;
 if(k==="l")dx=-b.x0;if(k==="c")dx=W/2-(b.x0+b.x1)/2;if(k==="r")dx=W-b.x1;if(k==="t")dy=-b.y0;if(k==="m")dy=H/2-(b.y0+b.y1)/2;if(k==="b")dy=H-b.y1;
 a.forEach(o=>{o.x=Math.round(o.x+dx);o.y=Math.round(o.y+dy);});C.render();}
function dist(ax){const a=sels();if(a.length<3)return T("Pilih 3 objek atau lebih");Hi.snapshot();const kx=ax==="h"?"x":"y",sz=ax==="h"?"w":"h",s=[...a].sort((p,q)=>p[kx]-q[kx]),f=s[0][kx],l=s[s.length-1],end=l[kx]+(l[sz]||0),tot=s.reduce((t,o)=>t+(o[sz]||0),0),gap=(end-f-tot)/(s.length-1);let p=f;s.forEach(o=>{o[kx]=Math.round(p);p+=(o[sz]||0)+gap;});C.render();}
const flip=k=>edit(o=>o[k]=!o[k]);
function scale(f){edit(o=>{const cx=o.x+o.w/2,cy=o.y+(o.h||0)/2;o.w=Math.max(1,Math.round(o.w*f));o.h=Math.round((o.h||0)*f);o.x=Math.round(cx-o.w/2);o.y=Math.round(cy-o.h/2);if(o.fontSize)o.fontSize=Math.max(8,Math.round(o.fontSize*f));});}
function match(){const a=sels();if(a.length<2)return T("Pilih 2 objek atau lebih");Hi.snapshot();a.slice(1).forEach(o=>{o.w=a[0].w;o.h=a[0].h;});C.render();}
const grad=(a,b)=>edit(o=>{o.grad=[a,b,S.gradMode||"d"];},"Gradien diterapkan",o=>!["image","line"].includes(o.type));
const CK="cdms-clip";
function copy(){const a=sels();if(!a.length)return T("Pilih objek dulu");try{localStorage.setItem(CK,JSON.stringify(a));T(a.length+" objek disalin");}catch(e){T("Gagal menyalin (objek terlalu besar)");}}
function paste(){let a=null;try{a=JSON.parse(localStorage.getItem(CK)||"null");}catch(e){}if(!a||!a.length)return T("Clipboard kosong");Hi.snapshot();const gm={},n=a.map(o=>{const c={...o,id:uid(),x:o.x+30,y:o.y+30};if(c.groupId)c.groupId=gm[c.groupId]||(gm[c.groupId]=uid());return c;});S.objects.push(...n);pick(n);}
function cut(){const a=sels();if(!a.length)return T("Pilih objek dulu");copy();Hi.snapshot();const set=new Set(a.map(o=>o.id));S.objects=S.objects.filter(o=>!set.has(o.id));S.selected=null;S.selectedIds=[];C.render();}
function exportSel(){const a=sels();if(!a.length)return T("Pilih objek dulu");let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
 a.forEach(o=>{const w=o.w||0,h=o.h||0,cx=o.x+w/2,cy=o.y+h/2,r=o.rotation?Math.hypot(w,h)/2:0;x0=Math.min(x0,r?cx-r:o.x);y0=Math.min(y0,r?cy-r:o.y);x1=Math.max(x1,r?cx+r:o.x+w);y1=Math.max(y1,r?cy+r:o.y+h);});
 x0-=16;y0-=16;x1+=16;y1+=16;const w=x1-x0,h=y1-y0,sc=Math.min(3,Math.max(1,2000/Math.max(w,h)));
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${x0} ${y0} ${w} ${h}" width="${w}" height="${h}">${a.map(o=>C.objMarkup(o)).join("")}</svg>`,url=URL.createObjectURL(new Blob([svg],{type:"image/svg+xml;charset=utf-8"})),im=new Image();
 im.onload=()=>{const c=document.createElement("canvas");c.width=Math.round(w*sc);c.height=Math.round(h*sc);c.getContext("2d").drawImage(im,0,0,c.width,c.height);c.toBlob(b=>{URL.revokeObjectURL(url);b?CDMS.Export.download(b,"objek.png"):T("Gagal ekspor");},"image/png");};
 im.onerror=()=>{URL.revokeObjectURL(url);T("Gagal ekspor");};im.src=url;}
const theme=t=>{document.body.dataset.theme=t;try{localStorage.setItem("cdms-theme",t);}catch(e){}};
function focus(){const b=document.body;if(b.dataset.mode==="minimal"){b.dataset.mode=S._mode||"classic";}else{S._mode=b.dataset.mode;b.dataset.mode="minimal";}}

/* ---- isi menu ---- */
const it=(l,f,i,x)=>({l,f,i,...x}),cell=(h,f,x)=>({cell:h,f,...x}),tc=(l,f,x)=>cell(`<span>${l}</span>`,f,x);
const MENUS={
shapes:()=>[{h:"Pustaka bentuk",items:SHP.map((s,i)=>cell(`<svg class="s" viewBox="0 0 100 100"><path d="${s[1]}" fill="${COL[i%6]}" fill-rule="evenodd"/></svg><span>${s[0]}</span>`,()=>addShape(s[0],s[1])))}],
arrange:()=>[{h:"Urutan tumpukan",items:[it("Ke paling depan",()=>z("front"),"front"),it("Naik satu",()=>z("up"),"front"),it("Turun satu",()=>z("down"),"back"),it("Ke paling belakang",()=>z("back"),"back")]},
 {h:"Rata ke halaman",items:[["Kiri","l"],["Tengah","c"],["Kanan","r"],["Atas","t"],["Tengah V","m"],["Bawah","b"]].map(x=>tc(x[0],()=>alignTo(x[1])))},
 {h:"Distribusi & balik",items:[it("Distribusi horizontal",()=>dist("h"),"arrange"),it("Distribusi vertikal",()=>dist("v"),"arrange"),it("Balik horizontal",()=>flip("flipH"),"flipH"),it("Balik vertikal",()=>flip("flipV"),"flipV")]}],
transform:()=>[{h:"Putar & skala",items:[it("Putar 90° kanan",()=>edit(o=>o.rotation=nr((o.rotation||0)+90)),"redo"),it("Putar 90° kiri",()=>edit(o=>o.rotation=nr((o.rotation||0)-90)),"undo"),it("Reset rotasi",()=>edit(o=>o.rotation=0),"select"),it("Perbesar 2×",()=>scale(2),"plus"),it("Perkecil 50%",()=>scale(.5),"transform"),it("Samakan ukuran",match,"copy")]},
 {h:"Sudut persegi",items:[["Siku",0],["Halus",24],["Bulat",60],["Pil",9999]].map(x=>tc(x[0],()=>edit(o=>{o.rx=x[1];},"",o=>o.type==="rect")))},
 {h:"Kunci",items:[it("Kunci objek",()=>edit(o=>o.locked=true,"Objek dikunci"),"lock"),it("Buka kunci",()=>edit(o=>o.locked=false,"Kunci dibuka"),"unlock")]}],
color:()=>[{h:"Arah gradien",items:[["Horizontal","h"],["Vertikal","v"],["Diagonal","d"],["Radial","r"]].map(x=>tc(x[0],()=>{S.gradMode=x[1];},{keep:1,on:(S.gradMode||"d")===x[1]}))},
 {h:"Gradien objek",items:[...GR.map(g=>cell(`<i style="background:linear-gradient(135deg,${g[1]},${g[2]})"></i><span>${g[0]}</span>`,()=>grad(g[1],g[2]))),tc("Hapus",()=>edit(o=>{delete o.grad;},"Gradien dihapus"))]},
 {h:"Filter foto & efek",items:[...FLT.map(f=>it(f[0],()=>edit(o=>{o.imgFx=f[1];}),"color")),it("Hapus filter",()=>edit(o=>{delete o.imgFx;},"Filter dihapus"),"trash")]}],
text:()=>[{h:"Huruf",items:[it("HURUF BESAR",()=>tx(o=>o.text=String(o.text).toUpperCase()),"text"),it("huruf kecil",()=>tx(o=>o.text=String(o.text).toLowerCase()),"text"),it("Kapital Tiap Kata",()=>tx(o=>o.text=String(o.text).toLowerCase().replace(/\b\w/g,c=>c.toUpperCase())),"text")]},
 {h:"Gaya",items:[it("Tebal",()=>tx(o=>o.bold=!o.bold),"text"),it("Miring",()=>tx(o=>o.italic=!o.italic),"text"),it("Spasi huruf +",()=>tx(o=>o.spacing=(o.spacing||0)+2),"text"),it("Spasi huruf −",()=>tx(o=>o.spacing=(o.spacing||0)-2),"text")]},
 {h:"Font cepat",items:FAM.map(f=>tc(f[0],()=>tx(o=>o.fontFamily=f[1])))}],
edit:()=>[{h:"Seleksi & clipboard",items:[it("Pilih semua",()=>pick(S.objects.filter(o=>!o.hidden&&!o.locked)),"multi",{s:"Ctrl+A"}),it("Batal pilih",()=>pick([]),"select",{s:"Esc"}),it("Salin",copy,"copy",{s:"Ctrl+C"}),it("Potong",cut,"trash",{s:"Ctrl+X"}),it("Tempel",paste,"plus",{s:"Ctrl+V"}),it("Hapus",()=>C.deleteSelected(),"trash",{s:"Del"})]},
 {h:"Ekspor",items:[it("Ekspor objek terpilih (PNG)",exportSel,"export")]}],
view:()=>[{h:"Zoom",items:[["50%",50],["100%",100],["200%",200]].map(x=>tc(x[0],()=>C.setZoom(x[1]))).concat([tc("Pas",()=>N.action("fit"))])},
 {h:"Bantuan",items:[it("Grid kanvas",()=>N.action("toggleGrid"),"grid"),it("Snap magnet: "+(S.snapOn===false?"MATI":"AKTIF"),()=>{S.snapOn=S.snapOn===false;},"multi",{keep:1}),it("Mode fokus",focus,"eye"),it("Layar penuh",()=>{const d=document.documentElement;if(document.fullscreenElement)document.exitFullscreen();else if(d.requestFullscreen)d.requestFullscreen();},"settings")]},
 {h:"Tema",items:[["Gelap","dark-neon"],["Terang","light"],["Hitam","black"],["Ungu","purple"]].map(x=>tc(x[0],()=>theme(x[1])))}]
};

/* ---- popover ---- */
let pop=null,items=[],cur=null;
const mob=()=>matchMedia("(max-width:720px)").matches;
function closeMenu(){if(pop){pop.remove();pop=null;}document.querySelectorAll(".has-menu.open").forEach(b=>b.classList.remove("open"));}
function openMenu(btn,name){closeMenu();cur=[btn,name];items=[];
 const html=MENUS[name]().map(s=>{const g=s.items[0]&&s.items[0].cell,body=s.items.map(x=>{items.push(x);const k=items.length-1;
  return x.cell?`<button class="mn-cell${x.on?" on":""}" data-k="${k}">${x.cell}</button>`:`<button class="mn-item" data-k="${k}">${x.i?CDMS.Icons.svg(x.i):""}<span>${x.l}</span>${x.s?`<small>${x.s}</small>`:""}</button>`;}).join("");
  return `<div class="mn-h">${s.h}</div><div class="${g?"mn-grid":"mn-list"}">${body}</div>`;}).join("");
 pop=document.createElement("div");pop.className="mn-pop";pop.innerHTML=html;document.body.appendChild(pop);btn.classList.add("open");
 if(!mob()){const r=btn.getBoundingClientRect();pop.style.maxHeight=Math.max(200,innerHeight-r.bottom-16)+"px";pop.style.top=r.bottom+6+"px";pop.style.left=Math.max(8,Math.min(r.left,innerWidth-pop.offsetWidth-8))+"px";}
 pop.onclick=e=>{const b=e.target.closest("[data-k]");if(!b)return;const x=items[+b.dataset.k];if(!x)return;x.f();if(x.keep)openMenu(cur[0],cur[1]);else closeMenu();};}
document.addEventListener("pointerdown",e=>{if(pop&&!pop.contains(e.target)&&!e.target.closest("[data-menu]"))closeMenu();},true);

/* ---- gradien objek, snap magnet, keyboard ---- */
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);
 if(o.grad&&o.type!=="image"&&o.type!=="line"){const[a,b,m]=o.grad,id="gr-"+o.id,st=`<stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/>`;
  const d=m==="r"?`<radialGradient id="${id}" cx=".5" cy=".5" r=".7">${st}</radialGradient>`:`<linearGradient id="${id}" x1="0" y1="0" x2="${m==="v"?0:1}" y2="${m==="h"?0:1}">${st}</linearGradient>`;
  s=s.replace(/fill="[^"]*"/,`fill="url(#${id})"`).replace(">","><defs>"+d+"</defs>");}
 if(o.imgFx)s=s.includes('style="filter:')?s.replace('style="filter:',`style="filter:${o.imgFx} `):s.replace('style="cursor:',`style="filter:${o.imgFx};cursor:`);
 return s;};
const pm=C.pointerMove;
C.pointerMove=function(e){pm.call(this,e);const d=S.drag;if(S.snapOn===false||!d||d.mode!=="move"||!d.moved)return;const a=sels();if(!a.length)return;
 const k=Math.max(.3,S.page.width/(this.svg.getBoundingClientRect().width||S.page.width)),TH=8*k,b=box(a),xs=[0,S.page.width/2,S.page.width],ys=[0,S.page.height/2,S.page.height];
 S.objects.forEach(o=>{if(a.includes(o)||o.hidden)return;xs.push(o.x,o.x+o.w/2,o.x+o.w);ys.push(o.y,o.y+(o.h||0)/2,o.y+(o.h||0));});
 const best=(pts,c)=>{let r=0,bd=TH+1;pts.forEach(p=>c.forEach(q=>{const dd=Math.abs(q-p);if(dd<bd){bd=dd;r=q-p;}}));return bd<=TH?r:0;};
 const dx=best([b.x0,(b.x0+b.x1)/2,b.x1],xs),dy=best([b.y0,(b.y0+b.y1)/2,b.y1],ys);
 if(dx||dy){a.forEach(o=>{o.x=Math.round(o.x+dx);o.y=Math.round(o.y+dy);});this.render();}};
let kb=0;
document.addEventListener("keydown",e=>{const ed=$("#editor");if(!ed||ed.classList.contains("hidden")||!$("#modalBackdrop").classList.contains("hidden"))return;if(/INPUT|TEXTAREA|SELECT/.test((document.activeElement&&document.activeElement.tagName)||""))return;
 const m=e.ctrlKey||e.metaKey,k=e.key.toLowerCase();
 if(m&&k==="a"){e.preventDefault();pick(S.objects.filter(o=>!o.hidden&&!o.locked));}
 else if(m&&k==="c")copy();else if(m&&k==="x")cut();else if(m&&k==="v")paste();
 else if(m&&k==="g"){e.preventDefault();N.groupSelected();}
 else if(e.key==="Escape"){closeMenu();pick([]);}
 else if(e.key.startsWith("Arrow")){const a=sels();if(!a.length)return;e.preventDefault();const st=e.shiftKey?10:1,dx=e.key==="ArrowLeft"?-st:e.key==="ArrowRight"?st:0,dy=e.key==="ArrowUp"?-st:e.key==="ArrowDown"?st:0;if(Date.now()-kb>500)Hi.snapshot();kb=Date.now();a.forEach(o=>{o.x+=dx;o.y+=dy;});C.render();}});

/* ---- pasang tombol menu di toolbar ---- */
const BT=[["shapes","shapes","Bentuk"],["arrange","arrange","Susun"],["transform","transform","Ubah"],["color","color","Warna"],["text","text","Teks"],["edit","clipboard","Edit"],["view","eye","Tampilan"]];
const ti=CDMS.Tools.init;
CDMS.Tools.init=function(){ti.call(this);
 const tb=$(".editor-toolbar");
 if(tb&&!tb.querySelector("[data-menu]")){tb.insertAdjacentHTML("beforeend",'<i class="tb-sep"></i>'+BT.map(b=>`<button class="tool has-menu" data-menu="${b[0]}" title="${b[2]}">${CDMS.Icons.svg(b[1])}<span>${b[2]}</span><i class="chev"></i></button>`).join(""));
  tb.addEventListener("click",e=>{const b=e.target.closest("[data-menu]");if(!b)return;b.classList.contains("open")?closeMenu():openMenu(b,b.dataset.menu);});}
 try{const t=localStorage.getItem("cdms-theme");if(t)document.body.dataset.theme=t;}catch(e){}
};
CDMS.Menus={MENUS,BT,edit,sels,pick,T,it,tc,cell,box,nr,openMenu,closeMenu,copy,cut,paste};
})();
