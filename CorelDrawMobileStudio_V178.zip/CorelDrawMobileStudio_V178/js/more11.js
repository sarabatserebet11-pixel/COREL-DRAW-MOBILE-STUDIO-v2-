/* V24: grup Pustaka + menu Ikon (16 ikon garis), 3D (isometrik), Infografis */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,pick,T,it,tc,cell}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;
const PAL=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4f83ff","#ff7ac8"];
function ask(title,html,cb){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">Buat</button></div>`);$("#aOk").onclick=cb;}
const txt=(text,x,y,size,fill,x2)=>({type:"text",name:"Teks",text,x:Math.round(x),y:Math.round(y),w:50,h:30,fontSize:Math.round(size),fill,...x2});
function grp(arr,post){Hi.snapshot();const g=uid();arr.forEach(o=>Object.assign(o,{id:uid(),groupId:g,opacity:o.opacity??100,rotation:o.rotation||0,stroke:o.stroke||"none",strokeWidth:o.strokeWidth||0}));S.objects.push(...arr);pick(arr);if(post){post();C.render();}}
const isHex=c=>/^#[0-9a-f]{6}$/i.test(String(c)),rgb=c=>[1,3,5].map(i=>parseInt(c.substr(i,2),16)),hx=a=>"#"+a.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0")).join("");
const shade=(c,f)=>{if(!isHex(c))return c;const a=rgb(c);return hx(f>1?a.map(v=>v+(255-v)*(f-1)):a.map(v=>v*f));};
const ctr=(t,r)=>{t.x=Math.round(r.x+(r.w-t.w)/2);t.y=Math.round(r.y+((r.h||0)-t.h)/2);};

/* ---- ikon garis ---- */
const ICON={home:"M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z",heart:"M12 21s-8-5.5-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.5-8 11-8 11z",star:"M12 2l3 6.5 7 1-5 5 1.2 7L12 18l-6.2 3.5L7 14.5l-5-5 7-1z",mail:"M3 5h18v14H3zM3 5l9 8 9-8",bell:"M6 17V11a6 6 0 0 1 12 0v6l2 2H4zM10 21a2 2 0 0 0 4 0",user:"M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0",search:"M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-5-5",camera:"M3 8h4l2-3h6l2 3h4v12H3zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",phone:"M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2z",cart:"M3 4h3l2.5 11h10L21 7H7M10 20a1 1 0 1 1-2 0a1 1 0 0 1 2 0zM19 20a1 1 0 1 1-2 0a1 1 0 0 1 2 0z",check:"M4 12l5 5L20 6",cloud:"M7 18a4 4 0 0 1-.5-8A6 6 0 0 1 18 9a4.5 4.5 0 0 1-.5 9z",pin:"M12 22s7-6.5 7-12a7 7 0 0 0-14 0c0 5.5 7 12 7 12zM12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z",lock:"M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4",play:"M6 4l14 8-14 8z",music:"M9 18V5l11-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM20 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"};
const IL=[["home","Beranda"],["heart","Hati"],["star","Bintang"],["mail","Surel"],["bell","Lonceng"],["user","Pengguna"],["search","Cari"],["camera","Kamera"],["phone","Telepon"],["cart","Keranjang"],["check","Centang"],["cloud","Awan"],["pin","Lokasi"],["lock","Gembok"],["play","Putar"],["music","Musik"]];
function addIcon(k,l){Hi.snapshot();const w=Math.round(W()*.12),o={id:uid(),type:"path",name:"Ikon "+l,x:Math.round((W()-w)/2),y:Math.round((H()-w)/2),w,h:w,vw:24,vh:24,d:ICON[k],fill:"none",stroke:"#20243a",strokeWidth:Math.round(w*.08),opacity:100,rotation:0};S.objects.push(o);pick([o]);}
MENUS.ico=()=>[{h:"Ikon garis (ubah warna dan tebal di panel properti)",items:IL.map(x=>cell(`<svg class="s" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="${ICON[x[0]]}"/></svg><span>${x[1]}</span>`,()=>addIcon(x[0],x[1])))}];

/* ---- 3D isometrik ---- */
let isoC="#6d5dfc";
const CUBE=[["M50 5L95 28L50 51L5 28Z",1.28],["M5 28L50 51V95L5 72Z",1],["M95 28L50 51V95L95 72Z",.68]],
 SHP={cube:CUBE,cyl:[["M10 25V75A40 15 0 0 0 90 75V25Z",1],["M10 25A40 15 0 0 1 90 25A40 15 0 0 1 10 25Z",1.3]],pyr:[["M50 6L8 78L50 94Z",1],["M50 6L92 78L50 94Z",.68]]};
function iso(kind,col,ox,oy,sz){const s=sz||Math.round(Math.min(W(),H())*.3),x=Math.round((ox??(W()-s)/2)),y=Math.round(oy??(H()-s)/2);return SHP[kind].map(f=>({type:"path",name:kind,x,y,w:s,h:s,vw:100,vh:100,d:f[0],fill:shade(col,f[1])}));}
const addIso=k=>grp(iso(k,isoC));
function threeCubes(){const s=Math.round(Math.min(W(),H())*.22),cx=Math.round(W()/2),cy=Math.round(H()/2),cols=[isoC,PAL[1],PAL[2]];grp([...iso("cube",cols[0],cx-s*1.05,cy-s*.2,s),...iso("cube",cols[1],cx-s*.05,cy-s*.2,s),...iso("cube",cols[2],cx-s*.55,cy-s*.62,s)]);}
MENUS.iso=()=>[{h:"Bentuk 3D (isometrik)",items:[it("Kubus",()=>addIso("cube"),"rect"),it("Silinder",()=>addIso("cyl"),"rect"),it("Piramida",()=>addIso("pyr"),"polygon"),it("3 kubus bertumpuk",threeCubes,"layers")]},
 {h:"Warna dasar",items:PAL.map(c=>cell(`<i style="background:${c}"></i>`,()=>{isoC=c;T("Warna 3D diatur");}))}];

/* ---- infografis ---- */
function timeline(){const n=4,w=Math.round(W()*.8),x0=Math.round((W()-w)/2),y=Math.round(H()/2),d=Math.round(W()*.045),arr=[{type:"line",name:"Garis waktu",x:x0,y,w,h:0,stroke:"#aab3cc",strokeWidth:6,fill:"none"}],pr=[];
 for(let i=0;i<n;i++){const cx=x0+w*(i+.5)/n,t=txt("Tahap "+(i+1),0,0,W()*.032,"#20243a",{bold:true}),s=txt("Deskripsi",0,0,W()*.024,"#68728a");arr.push({type:"ellipse",name:"Titik "+(i+1),x:Math.round(cx-d/2),y:Math.round(y-d/2),w:d,h:d,fill:PAL[i]},t,s);pr.push([t,s,cx]);}
 grp(arr,()=>pr.forEach(p=>{p[0].x=Math.round(p[2]-p[0].w/2);p[0].y=Math.round(y-d-p[0].h);p[1].x=Math.round(p[2]-p[1].w/2);p[1].y=Math.round(y+d);}));}
function steps(){const n=3,cw=Math.round(W()*.26),ch=Math.round(cw*1.15),gap=Math.round(W()*.03),x0=Math.round((W()-(n*cw+(n-1)*gap))/2),y0=Math.round((H()-ch)/2),arr=[],pr=[];
 for(let i=0;i<n;i++){const x=x0+i*(cw+gap),card={type:"rect",name:"Kartu "+(i+1),x,y:y0,w:cw,h:ch,rx:22,fill:"#ffffff",stroke:"#d9deea",strokeWidth:2},dd=Math.round(cw*.28),c={type:"ellipse",name:"Nomor",x:Math.round(x+(cw-dd)/2),y:Math.round(y0+ch*.1),w:dd,h:dd,fill:PAL[i]},nt=txt(String(i+1),0,0,dd*.55,"#ffffff",{bold:true}),tt=txt("Langkah "+(i+1),0,0,cw*.11,"#20243a",{bold:true}),ds=txt("Isi deskripsi",0,0,cw*.08,"#68728a");arr.push(card,c,nt,tt,ds);pr.push([card,c,nt,tt,ds]);}
 grp(arr,()=>pr.forEach(p=>{ctr(p[2],p[1]);p[3].x=Math.round(p[0].x+(p[0].w-p[3].w)/2);p[3].y=Math.round(p[0].y+p[0].h*.5);p[4].x=Math.round(p[0].x+(p[0].w-p[4].w)/2);p[4].y=Math.round(p[0].y+p[0].h*.7);}));}
function stat(){const v=($("#stV").value||"87%").trim(),l=($("#stL").value||"Pengguna puas").trim();N.closeModal();const a=txt(v,0,0,W()*.2,"#6d5dfc",{bold:true,fontFamily:"Impact, 'Arial Black', sans-serif"}),b=txt(l,0,0,W()*.045,"#68728a",{});grp([a,b],()=>{a.x=Math.round((W()-a.w)/2);a.y=Math.round(H()/2-a.h*.8);b.x=Math.round((W()-b.w)/2);b.y=Math.round(a.y+a.h+8);});}
function progress(){const p=Math.max(0,Math.min(100,+$("#pgV").value||0));N.closeModal();const w=Math.round(W()*.6),h=Math.round(W()*.05),x=Math.round((W()-w)/2),y=Math.round(H()/2),t=txt("Progres "+Math.round(p)+"%",x,y-W()*.06,W()*.035,"#20243a",{bold:true});
 grp([{type:"rect",name:"Jalur",x,y,w,h,rx:h/2,fill:"#e3e7f2"},...(p>0?[{type:"rect",name:"Isi progres",x,y,w:Math.max(h,Math.round(w*p/100)),h,rx:h/2,fill:"#6d5dfc"}]:[]),t]);}
function checklist(){const n=4,rw=Math.round(W()*.55),x0=Math.round((W()-rw)/2),rh=Math.round(W()*.08),y0=Math.round((H()-n*rh)/2),arr=[];
 for(let i=0;i<n;i++){const y=y0+i*rh,ic=Math.round(rh*.55);arr.push({type:"path",name:"Centang",x:x0,y:Math.round(y+(rh-ic)/2),w:ic,h:ic,vw:24,vh:24,d:ICON.check,fill:"none",stroke:"#3ddc84",strokeWidth:Math.round(ic*.16)},txt("Item daftar "+(i+1),x0+ic*1.5,y+(rh-W()*.035*1.2)/2,W()*.035,"#20243a",{}));}
 grp(arr);}
MENUS.info=()=>[{h:"Infografis siap edit",items:[it("Timeline 4 tahap",timeline,"line"),it("Langkah 1-2-3",steps,"rect"),it("Daftar centang",checklist,"layers")]},
 {h:"Dengan data",items:[it("Statistik besar…",()=>ask("Statistik besar",'<label>Angka<input id="stV" value="87%"></label><label>Label<input id="stL" value="Pengguna puas"></label>',stat),"text"),it("Progress bar…",()=>ask("Progress bar",'<label>Persen (0-100)<input id="pgV" type="number" min="0" max="100" value="72"></label>',progress),"grid")]}];

BT.push(["ico","icongrid","Ikon"],["iso","cube","3D"],["info","infograph","Infografis"]);
/* ---- grup baru: Pustaka ---- */
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];["emo","deco","seal","mock","chart"].forEach(k=>{const b=hub("buat"),i=b.indexOf(k);if(i>=0)b.splice(i,1);});
M.HUBS.splice(1,0,["pustaka","sticker","Pustaka",["ico","iso","info","emo","mock","chart","seal","deco"]]);
})();
