/* V26: menu Rata (rata ke objek acuan, jarak tetap), Crop (rasio, potong grid, palet dari foto) + cek kontras */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height,E=CDMS.escape;
const isHex=c=>/^#[0-9a-f]{6}$/i.test(String(c)),hx=a=>"#"+a.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0")).join("");

/* ---- rata ke objek acuan ---- */
function alignTo(m){const a=sels();if(a.length<2)return T("Pilih 2 objek atau lebih. Objek pertama jadi acuan.");const r=a[0],rh=r.h||0;Hi.snapshot();
 a.slice(1).forEach(o=>{const h=o.h||0;if(m==="l")o.x=r.x;if(m==="r")o.x=r.x+r.w-o.w;if(m==="cx")o.x=Math.round(r.x+r.w/2-o.w/2);if(m==="t")o.y=r.y;if(m==="b")o.y=r.y+rh-h;if(m==="cy")o.y=Math.round(r.y+rh/2-h/2);});C.render();}
function gap(axis,g){const a=sels();if(a.length<2)return T("Pilih 2 objek atau lebih");Hi.snapshot();const k=axis==="x"?"x":"y",d=axis==="x"?"w":"h";a.sort((p,q)=>p[k]-q[k]);let v=a[0][k];a.forEach(o=>{o[k]=Math.round(v);v+=(o[d]||0)+g;});C.render();}
function same(k){const a=sels();if(a.length<2)return T("Pilih 2 objek atau lebih");Hi.snapshot();a.slice(1).forEach(o=>{o[k]=a[0][k];});C.render();}
MENUS.align2=()=>[
 {h:"Rata ke objek pertama",items:[["Kiri","l"],["Tengah H","cx"],["Kanan","r"],["Atas","t"],["Tengah V","cy"],["Bawah","b"]].map(x=>tc(x[0],()=>alignTo(x[1])))},
 {h:"Jarak tetap antar objek",items:[0,10,20,40].map(g=>tc("Mendatar "+g,()=>gap("x",g))).concat([0,10,20,40].map(g=>tc("Tegak "+g,()=>gap("y",g))))},
 {h:"Samakan dengan objek pertama",items:[it("Samakan lebar",()=>same("w"),"arrange"),it("Samakan tinggi",()=>same("h"),"arrange")]}];

/* ---- crop foto ---- */
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);
 if(o.type==="image"&&o.crop){const f=o.crop;s=s.replace(/<image ([^>]*?)\/>/,(m,at)=>{const clip=(at.match(/clip-path="[^"]*"/)||[""])[0];at=at.replace(/clip-path="[^"]*"\s*/,"").replace(/width="[\d.]+"/,'width="1"').replace(/height="[\d.]+"/,'height="1"').replace(/preserveAspectRatio="[^"]*"/,'preserveAspectRatio="none"');
  return `<svg ${clip} x="0" y="0" width="${o.w}" height="${o.h}" viewBox="${f[0]} ${f[1]} ${f[2]} ${f[3]}" preserveAspectRatio="none" overflow="hidden"><image ${at}/></svg>`;});}
 return s;};
const img=o=>o.type==="image";
function cropTo(t){edit(o=>{const ar=o.natAR||(o.natAR=o.w/o.h),cx=o.x+o.w/2,cy=o.y+o.h/2;let f=[0,0,1,1];if(t<ar){const fw=t/ar;f=[(1-fw)/2,0,fw,1];}else{const fh=ar/t;f=[0,(1-fh)/2,1,fh];}
  o.crop=f;o.h=Math.round(o.w/t);o.y=Math.round(cy-o.h/2);o.x=Math.round(cx-o.w/2);},"Gambar di-crop",img);}
function cropReset(){edit(o=>{if(o.natAR){const cy=o.y+o.h/2;o.h=Math.round(o.w/o.natAR);o.y=Math.round(cy-o.h/2);}delete o.crop;delete o.natAR;},"Crop dihapus",img);}
function slice(c,r){const o=sels()[0];if(!o||!img(o))return T("Pilih satu gambar");if(o.rotation)return T("Gambar harus tanpa rotasi");Hi.snapshot();
 const f=o.crop||[0,0,1,1],g=uid(),ar=o.natAR||o.w/o.h,out=[];
 for(let j=0;j<r;j++)for(let i=0;i<c;i++){const n={...o,id:uid(),groupId:g,name:"Potongan "+(j*c+i+1),natAR:ar,crop:[f[0]+i*f[2]/c,f[1]+j*f[3]/r,f[2]/c,f[3]/r],x:Math.round(o.x+i*o.w/c),y:Math.round(o.y+j*o.h/r),w:Math.round(o.w/c),h:Math.round(o.h/r)};delete n.mask;delete n.fit;out.push(n);}
 S.objects.splice(S.objects.indexOf(o),1,...out);pick(out);T(out.length+" potongan dibuat");}
function strip(cols){S.lastPalette=cols;Hi.snapshot();const g=uid(),side=Math.round(W()*.14),gp=Math.round(W()*.02),x0=Math.round((W()-(cols.length*side+(cols.length-1)*gp))/2),y0=Math.round(H()/2-side/2),fs=Math.round(side*.16),arr=[],pr=[];
 cols.forEach((c,i)=>{const r={type:"rect",name:"Warna "+c,x:x0+i*(side+gp),y:y0,w:side,h:side,rx:16,fill:c},t={type:"text",name:"Kode "+c,text:c.toUpperCase(),x:r.x,y:y0+side+fs*.6,w:50,h:30,fontSize:fs,fill:"#68728a",bold:true};arr.push(r,t);pr.push([t,r]);});
 arr.forEach(o=>Object.assign(o,{id:uid(),groupId:g,opacity:100,rotation:0,stroke:"none",strokeWidth:0}));S.objects.push(...arr);pick(arr);pr.forEach(p=>{p[0].x=Math.round(p[1].x+(p[1].w-p[0].w)/2);});C.render();}
function photoPalette(){const o=sels().find(img);if(!o)return T("Pilih gambar dulu");const im=new Image();
 im.onload=()=>{const c=document.createElement("canvas");c.width=c.height=48;const x=c.getContext("2d");x.drawImage(im,0,0,48,48);let d;try{d=x.getImageData(0,0,48,48).data;}catch(e){return T("Gambar tidak bisa dibaca");}
  const bins={};for(let i=0;i<d.length;i+=4){if(d[i+3]<128)continue;const k=((d[i]>>5)<<6)|((d[i+1]>>5)<<3)|(d[i+2]>>5),b=bins[k]||(bins[k]={n:0,r:0,g:0,b:0});b.n++;b.r+=d[i];b.g+=d[i+1];b.b+=d[i+2];}
  const all=Object.values(bins).sort((a,b)=>b.n-a.n).map(b=>[b.r/b.n,b.g/b.n,b.b/b.n]),ch=[];for(const c of all){if(ch.every(p=>Math.hypot(p[0]-c[0],p[1]-c[1],p[2]-c[2])>55))ch.push(c);if(ch.length===5)break;}
  if(!ch.length)return T("Warna tidak ditemukan");strip(ch.map(hx));T("Palet dari foto dibuat");};
 im.onerror=()=>T("Gambar gagal dimuat");im.src=o.href;}
MENUS.crop=()=>[
 {h:"Crop rasio (dari tengah)",items:[["1:1",1],["4:5",.8],["16:9",16/9],["9:16",9/16],["3:2",1.5]].map(x=>tc(x[0],()=>cropTo(x[1])))},
 {h:"Potong jadi bagian",items:[it("Grid 2 × 2",()=>slice(2,2),"dup"),it("Grid 3 × 3",()=>slice(3,3),"dup"),it("Carousel 3 panel (1 × 3)",()=>slice(3,1),"dup"),it("Carousel 2 panel (1 × 2)",()=>slice(2,1),"dup")]},
 {h:"Lainnya",items:[it("Hapus crop",cropReset,"undo"),it("Palet warna dari foto",photoPalette,"color")]}];

/* ---- cek kontras (aksesibilitas) ---- */
const lum=h=>{const c=[1,3,5].map(i=>parseInt(h.substr(i,2),16)/255).map(v=>v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4));return .2126*c[0]+.7152*c[1]+.0722*c[2];};
function contrast(){const bg=S.page.background;if(!isHex(bg))return T("Latar harus warna polos untuk cek kontras");const a=sels().filter(o=>o.type==="text"&&isHex(o.fill));if(!a.length)return T("Pilih teks berwarna polos dulu");
 const L=lum(bg),rows=a.map(o=>{const l=lum(o.fill),r=(Math.max(L,l)+.05)/(Math.min(L,l)+.05),big=(o.fontSize||0)>=W()*.03,lv=r>=7?"AAA":(r>=(big?3:4.5)?"AA":"Kurang");return `<p class="st-note" style="color:${lv==="Kurang"?"#ffc857":"var(--text)"}">${lv==="Kurang"?"⚠":"✔"} <b>${E(String(o.text||"").slice(0,24))}</b>: rasio ${r.toFixed(1)}:1 (${lv})</p>`;}).join("");
 N.openModal("Cek kontras teks",`<div class="st-pane">${rows}<p class="st-note">Standar WCAG: AA butuh 4,5:1 (teks besar 3:1), AAA butuh 7:1. Latar yang dipakai: ${bg}.</p><button class="btn primary" id="ctFix">Perbaiki otomatis</button></div>`);
 $("#ctFix").onclick=()=>{Hi.snapshot();a.forEach(o=>{o.fill=L>.4?"#111111":"#ffffff";});N.closeModal();C.render();T("Warna teks diperbaiki");};}
const oh=MENUS.help;MENUS.help=()=>[...oh(),{h:"Aksesibilitas",items:[it("Cek kontras teks terpilih",contrast,"eye")]}];

BT.push(["align2","align","Rata"],["crop","crop","Potong"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("atur").push("align2");hub("warna").push("crop");
})();
