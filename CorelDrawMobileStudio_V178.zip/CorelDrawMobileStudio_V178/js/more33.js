/* V44: perbaikan menu Pustaka + menu baru Gaya+, Tata+, Ukuran+, Pilih+, Pola, Bantu+ */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,sels,pick,T,it,tc,cell,edit}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID();
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const r0=Math.round,hh=o=>o.h||0,free=()=>sels().filter(o=>!o.locked);
const bb=a=>({x0:Math.min(...a.map(o=>o.x)),y0:Math.min(...a.map(o=>o.y)),x1:Math.max(...a.map(o=>o.x+o.w)),y1:Math.max(...a.map(o=>o.y+hh(o)))});
const need=(n,msg)=>{const a=free();if(a.length<n){T(msg||(n>1?"Pilih "+n+" objek atau lebih":"Pilih objek dulu"));return null;}return a;};

/* ---- perbaikan: grup menu tanpa daftar (mis. Pustaka) dibuatkan otomatis ---- */
M.HUBS.forEach(h=>{if(!MENUS["hub_"+h[0]])MENUS["hub_"+h[0]]=()=>[{h:h[2],items:h[3].filter(k=>BT.some(b=>b[0]===k)).map(k=>{const b=BT.find(x=>x[0]===k);return cell(`${CDMS.Icons.svg(b[1])}<span>${b[2]}</span>`,()=>setTimeout(()=>M.openMenu($(`[data-menu="hub_${h[0]}"]`),k),0));})}];});

/* ---- warna ---- */
const HEX=/^#([0-9a-f]{3}|[0-9a-f]{6})$/i;
const rgb=h=>{h=h.slice(1);if(h.length===3)h=[...h].map(c=>c+c).join("");return[0,2,4].map(i=>parseInt(h.substr(i,2),16));};
const toHex=v=>"#"+v.map(x=>Math.max(0,Math.min(255,r0(x))).toString(16).padStart(2,"0")).join("");
const hsl=([r,g,b])=>{r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2,d=mx-mn;let h=0,s=0;if(d){s=d/(1-Math.abs(2*l-1));h=mx===r?((g-b)/d)%6:mx===g?(b-r)/d+2:(r-g)/d+4;h=(h*60+360)%360;}return[h,s,l];};
const fromHsl=(h,s,l)=>{s=Math.min(1,Math.max(0,s));l=Math.min(1,Math.max(0,l));const k=n=>(n+h/30)%12,a=s*Math.min(l,1-l),f=n=>l-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)));return toHex([f(0)*255,f(8)*255,f(4)*255]);};
const tint=(c,dl,ds)=>{if(!HEX.test(c||""))return c;const[h,s,l]=hsl(rgb(c));return fromHsl(h,s+ds,l+dl);};
const colorEdit=(fn,msg)=>edit(o=>{["fill","stroke"].forEach(k=>{if(HEX.test(o[k]||""))o[k]=fn(o[k]);});if(o.grad)o.grad=[fn(o.grad[0]),fn(o.grad[1]),o.grad[2]];},msg,o=>o.type!=="image");
let clip=null;
const STY=["fill","stroke","strokeWidth","opacity","grad","rx"];
function copyStyle(){const o=sels()[0];if(!o)return T("Pilih objek dulu");clip={};STY.forEach(k=>{if(o[k]!==undefined)clip[k]=JSON.parse(JSON.stringify(o[k]));});T("Gaya disalin");}
function pasteStyle(){if(!clip)return T("Belum ada gaya yang disalin");edit(o=>{STY.forEach(k=>{if(o.type==="image"&&k!=="opacity")return;if(clip[k]===undefined)delete o[k];else o[k]=JSON.parse(JSON.stringify(clip[k]));});},"Gaya ditempel");}
MENUS.gaya2=()=>[
 {h:"Pemindah gaya",items:[it("Salin gaya objek pertama",copyStyle,"copy",{s:"Ctrl+Shift+C"}),it("Tempel gaya ke terpilih",pasteStyle,"copy",{s:"Ctrl+Shift+V"}),it("Tukar warna isi ↔ garis",()=>edit(o=>{const f=o.fill;o.fill=o.stroke&&o.stroke!=="none"?o.stroke:"#6d5dfc";o.stroke=f&&f!=="none"?f:"#20243a";if(!o.strokeWidth)o.strokeWidth=2;delete o.grad;},"Warna ditukar",o=>["rect","ellipse","path","star","polygon"].includes(o.type)),"redo")]},
 {h:"Tone warna",items:[it("Lebih terang +10%",()=>colorEdit(c=>tint(c,.1,0),"Lebih terang"),"color"),it("Lebih gelap −10%",()=>colorEdit(c=>tint(c,-.1,0),"Lebih gelap"),"color"),it("Lebih jenuh +15%",()=>colorEdit(c=>tint(c,0,.15),"Lebih jenuh"),"color"),it("Kurangi jenuh −15%",()=>colorEdit(c=>tint(c,0,-.15),"Kurang jenuh"),"color"),it("Balik warna (negatif)",()=>colorEdit(c=>toHex(rgb(c).map(v=>255-v)),"Warna dibalik"),"color"),it("Jadi abu-abu",()=>colorEdit(c=>{const g=rgb(c);const y=.3*g[0]+.59*g[1]+.11*g[2];return toHex([y,y,y]);},"Abu-abu"),"color")]},
 {h:"Transparansi",items:[25,50,75,100].map(v=>tc(v+"%",()=>edit(o=>{o.opacity=v;})))},
 {h:"Tebal garis",items:[0,1,2,4,8,16].map(v=>tc(v?v+" px":"Tanpa",()=>edit(o=>{o.strokeWidth=v;if(v&&(!o.stroke||o.stroke==="none"))o.stroke="#20243a";if(!v)o.stroke="none";},"",o=>o.type!=="image")))}];

/* ---- tata letak ---- */
function gridLayout(n){const a=need(2);if(!a)return;Hi.snapshot();const b=bb(a),cw=Math.max(...a.map(o=>o.w))+20,ch=Math.max(...a.map(hh))+20;[...a].sort((p,q)=>p.y-q.y||p.x-q.x).forEach((o,i)=>{o.x=r0(b.x0+(i%n)*cw+(cw-20-o.w)/2);o.y=r0(b.y0+Math.floor(i/n)*ch+(ch-20-hh(o))/2);});C.render();T("Disusun "+n+" kolom");}
function radial(){const a=need(3,"Pilih 3 objek atau lebih");if(!a)return;Hi.snapshot();const b=bb(a),cx=(b.x0+b.x1)/2,cy=(b.y0+b.y1)/2,R=Math.max(120,a.length*Math.max(...a.map(o=>o.w))/6.2);a.forEach((o,i)=>{const t=i/a.length*Math.PI*2-Math.PI/2;o.x=r0(cx+Math.cos(t)*R-o.w/2);o.y=r0(cy+Math.sin(t)*R-hh(o)/2);});C.render();T("Disusun melingkar");}
function stack(ax,gap){const a=need(2);if(!a)return;Hi.snapshot();const k=ax==="h"?"x":"y",z=ax==="h"?(o=>o.w):hh;let p=Math.min(...a.map(o=>o[k]));[...a].sort((s,t)=>s[k]-t[k]).forEach(o=>{o[k]=r0(p);p+=z(o)+gap;});C.render();T("Ditumpuk dengan jarak "+gap);}
function alignKey(k){const a=need(2);if(!a)return;Hi.snapshot();const f=a[0];a.slice(1).forEach(o=>{if(k==="l")o.x=f.x;if(k==="r")o.x=r0(f.x+f.w-o.w);if(k==="c")o.x=r0(f.x+f.w/2-o.w/2);if(k==="t")o.y=f.y;if(k==="b")o.y=r0(f.y+hh(f)-hh(o));if(k==="m")o.y=r0(f.y+hh(f)/2-hh(o)/2);});C.render();T("Rata ke objek pertama");}
function jitter(){const a=need(1);if(!a)return;Hi.snapshot();a.forEach(o=>{o.x=r0(o.x+(Math.random()-.5)*60);o.y=r0(o.y+(Math.random()-.5)*60);o.rotation=r0(Math.max(-180,Math.min(180,(o.rotation||0)+(Math.random()-.5)*30)));});C.render();}
MENUS.susun2=()=>[
 {h:"Grid otomatis",items:[2,3,4,5,6].map(n=>tc(n+" kolom",()=>gridLayout(n)))},
 {h:"Susunan lain",items:[it("Melingkar",radial,"arrange"),it("Tumpuk horizontal (jarak 20)",()=>stack("h",20),"arrange"),it("Tumpuk vertikal (jarak 20)",()=>stack("v",20),"arrange"),it("Rapatkan horizontal",()=>stack("h",0),"arrange"),it("Rapatkan vertikal",()=>stack("v",0),"arrange"),it("Acak posisi sedikit",jitter,"redo")]},
 {h:"Rata ke objek pertama dipilih",items:[["Kiri","l"],["Tengah","c"],["Kanan","r"],["Atas","t"],["Tengah V","m"],["Bawah","b"]].map(x=>tc(x[0],()=>alignKey(x[1])))}];

/* ---- ukuran ---- */
function fitPage(cover){const a=need(1);if(!a)return;Hi.snapshot();const W=S.page.width,H=S.page.height;a.forEach(o=>{if(!o.w||!hh(o))return;const k=(cover?Math.max:Math.min)(W/o.w,H/hh(o));o.w=r0(o.w*k);o.h=r0(hh(o)*k);o.x=r0((W-o.w)/2);o.y=r0((H-o.h)/2);});C.render();T(cover?"Mengisi halaman":"Pas di halaman");}
function pageDim(d){const a=need(1);if(!a)return;Hi.snapshot();a.forEach(o=>{const k=d==="w"?S.page.width/o.w:S.page.height/(hh(o)||1);o.w=r0(o.w*k);o.h=r0(hh(o)*k);if(d==="w")o.x=0;else o.y=0;});C.render();}
function same(d){const a=need(2);if(!a)return;Hi.snapshot();a.slice(1).forEach(o=>{if(d!=="h")o.w=a[0].w;if(d!=="w")o.h=a[0].h;});C.render();}
function pct(f){edit(o=>{const cx=o.x+o.w/2,cy=o.y+hh(o)/2;o.w=Math.max(1,r0(o.w*f));o.h=r0(hh(o)*f);o.x=r0(cx-o.w/2);o.y=r0(cy-hh(o)/2);if(o.fontSize)o.fontSize=Math.max(8,r0(o.fontSize*f));},"",o=>!o.locked);}
MENUS.ukuran2=()=>[
 {h:"Terhadap halaman",items:[it("Pas di halaman (contain)",()=>fitPage(false),"transform"),it("Penuhi halaman (cover)",()=>fitPage(true),"transform"),it("Lebar = lebar halaman",()=>pageDim("w"),"wide"),it("Tinggi = tinggi halaman",()=>pageDim("h"),"tall")]},
 {h:"Skala (dari tengah)",items:[[.25,"25%"],[.5,"50%"],[.75,"75%"],[1.25,"125%"],[1.5,"150%"],[2,"200%"]].map(x=>tc(x[1],()=>pct(x[0])))},
 {h:"Samakan dengan objek pertama",items:[it("Lebar saja",()=>same("w"),"copy"),it("Tinggi saja",()=>same("h"),"copy"),it("Lebar dan tinggi",()=>same("wh"),"copy"),it("Jadikan persegi (tinggi = lebar)",()=>edit(o=>{o.h=o.w;},"",o=>o.type!=="text"&&!o.locked),"rect")]}];

/* ---- seleksi cerdas & pembersihan ---- */
const selBy=(pred,msg)=>{const f=sels()[0];if(!f)return T("Pilih objek dulu");const a=S.objects.filter(o=>!o.hidden&&!o.locked&&pred(o,f));pick(a);T(a.length+" objek dipilih"+(msg?" ("+msg+")":""));};
function clean(kind){Hi.snapshot();const n0=S.objects.length;let seen=new Set;
 S.objects=S.objects.filter(o=>{if(kind==="hid")return !o.hidden;if(kind==="out")return !(o.x+o.w<0||o.y+hh(o)<0||o.x>S.page.width||o.y>S.page.height);
  const k=[o.type,o.x,o.y,o.w,o.h,o.fill,o.stroke,o.text,o.d].join("|");if(seen.has(k))return false;seen.add(k);return true;});
 S.selected=null;S.selectedIds=[];C.render();T((n0-S.objects.length)+" objek dibersihkan");}
MENUS.pilih2=()=>[
 {h:"Pilih yang sama dengan objek pertama",items:[it("Warna isi sama",()=>selBy((o,f)=>o.fill===f.fill),"multi"),it("Jenis sama",()=>selBy((o,f)=>o.type===f.type),"multi"),it("Warna garis sama",()=>selBy((o,f)=>o.stroke===f.stroke),"multi"),it("Ukuran sama",()=>selBy((o,f)=>o.w===f.w&&hh(o)===hh(f)),"multi")]},
 {h:"Seleksi",items:[it("Balik pilihan",()=>{const cur=new Set(sels().map(o=>o.id));pick(S.objects.filter(o=>!o.hidden&&!o.locked&&!cur.has(o.id)));},"multi"),it("Buka kunci semua objek",()=>{Hi.snapshot();S.objects.forEach(o=>{o.locked=false;});C.render();T("Semua kunci dibuka");},"unlock"),it("Tampilkan semua yang tersembunyi",()=>{Hi.snapshot();S.objects.forEach(o=>{o.hidden=false;});C.render();T("Semua ditampilkan");},"eye")]},
 {h:"Bersihkan dokumen",items:[it("Hapus objek tersembunyi",()=>clean("hid"),"trash"),it("Hapus objek di luar halaman",()=>clean("out"),"trash"),it("Hapus duplikat persis",()=>clean("dup"),"trash")]}];

/* ---- pola: grid & melingkar dari objek terpilih ---- */
function clone(a,dx,dy,rot,cx,cy){const gm={};return a.map(o=>{const c=JSON.parse(JSON.stringify(o));c.id=uid();c.x=r0(o.x+dx);c.y=r0(o.y+dy);if(rot!=null)c.rotation=((r0((o.rotation||0)+rot)+540)%360)-180;if(c.groupId)c.groupId=gm[c.groupId]||(gm[c.groupId]=uid());return c;});}
function gridPattern(r,c,gx,gy){const a=need(1);if(!a)return;if(r*c>400)return T("Maksimum 400 salinan");Hi.snapshot();const b=bb(a),w=b.x1-b.x0,h=b.y1-b.y0,add=[];for(let i=0;i<r;i++)for(let j=0;j<c;j++)if(i||j)add.push(...clone(a,j*(w+gx),i*(h+gy)));S.objects.push(...add);pick([...a,...add]);T(add.length+" salinan dibuat");}
function ringPattern(n,R,turn){const a=need(1);if(!a)return;Hi.snapshot();const b=bb(a),add=[];for(let i=1;i<n;i++){const t=i/n*Math.PI*2,cx=Math.cos(t)*R-R,cy=Math.sin(t)*R;add.push(...clone(a,cx,cy,turn?t*180/Math.PI:null));}S.objects.push(...add);pick([...a,...add]);T(add.length+" salinan dibuat");}
const num=(id,v)=>`<label>${id[1]}<input id="${id[0]}" type="number" value="${v}"></label>`;
function patternModal(){if(!sels().length)return T("Pilih objek dulu");N.openModal("Pola dari objek terpilih",`<div class="st-pane"><b>Grid</b>${num(["pR","Baris"],3)}${num(["pC","Kolom"],3)}${num(["pGx","Jarak X"],20)}${num(["pGy","Jarak Y"],20)}<button class="btn primary" id="pGo">Buat grid</button><b>Melingkar</b>${num(["pN","Jumlah"],8)}${num(["pRad","Radius"],200)}<label><input id="pTurn" type="checkbox" checked> Ikut berputar</label><button class="btn primary" id="pRing">Buat lingkaran</button></div>`);
 const v=i=>Math.max(1,+$("#"+i).value||1);$("#pGo").onclick=()=>{N.closeModal();gridPattern(v("pR"),v("pC"),+$("#pGx").value||0,+$("#pGy").value||0);};$("#pRing").onclick=()=>{const t=$("#pTurn").checked,n=v("pN"),R=v("pRad");N.closeModal();ringPattern(n,R,t);};}
MENUS.klon=()=>[{h:"Perbanyak objek terpilih",items:[it("Panel pola (grid / lingkaran)…",()=>setTimeout(patternModal,0),"copy"),it("Grid 3 × 3 cepat",()=>gridPattern(3,3,20,20),"grid"),it("Baris 5 cepat",()=>gridPattern(1,5,20,0),"copy"),it("Lingkaran 8 cepat",()=>ringPattern(8,200,true),"star"),it("Lingkaran 12 cepat",()=>ringPattern(12,260,true),"star")]}];

/* ---- bantu: info dokumen ---- */
function info(){const c={};S.objects.forEach(o=>{c[o.type]=(c[o.type]||0)+1;});const cols=[...new Set(S.objects.map(o=>o.fill).filter(x=>HEX.test(x||"")))].slice(0,24);
 N.openModal("Info dokumen",`<div class="st-pane"><p>Halaman <b>${S.page.width} × ${S.page.height}</b> px · <b>${S.objects.length}</b> objek</p><p>${Object.keys(c).map(k=>`${k}: <b>${c[k]}</b>`).join(" · ")||"Belum ada objek"}</p><small>Warna isi dipakai (ketuk untuk memilih semua objek berwarna itu)</small><div class="v44-sw">${cols.map(x=>`<button data-c="${x}" style="background:${x}" aria-label="${x}"></button>`).join("")}</div></div>`);
 $("#modalBody").querySelectorAll("[data-c]").forEach(b=>b.onclick=()=>{N.closeModal();pick(S.objects.filter(o=>o.fill===b.dataset.c&&!o.locked&&!o.hidden));});}
MENUS.bantu2=()=>[{h:"Bantuan kerja",items:[it("Info dokumen & palet",()=>setTimeout(info,0),"eye")]}];
document.addEventListener("keydown",e=>{if(!(e.ctrlKey||e.metaKey)||!e.shiftKey||/INPUT|TEXTAREA|SELECT/.test((document.activeElement||{}).tagName||""))return;const ed=$("#editor");if(!ed||ed.classList.contains("hidden"))return;const k=e.key.toLowerCase();if(k==="c"){e.preventDefault();copyStyle();}else if(k==="v"){e.preventDefault();pasteStyle();}});

BT.push(["gaya2","color","Gaya+"],["susun2","arrange","Tata+"],["ukuran2","resize","Ukuran+"],["pilih2","multi","Pilih+"],["klon","copy","Klon"],["bantu2","guides","Bantu+"]);
hubAdd("warna","gaya2");hubAdd("atur","susun2","ukuran2","pilih2");hubAdd("buat","klon");hubAdd("kanvas","bantu2");
})();
