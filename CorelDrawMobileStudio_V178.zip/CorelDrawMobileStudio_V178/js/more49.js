/* V60: menu Jajar (rapikan objek terpilih: baris/kolom dengan jarak, tumpuk di tengah, urut tumpukan) dan Callout (kotak info, balon obrolan, catatan, kutipan, pita) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,it,tc,sels,T}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,AC,INK,MUTE}=K;
const $=s=>document.querySelector(s);
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const WHT="#ffffff";
/* ---------- Jajar ---------- */
/* unit = satu grup (groupId sama) atau satu objek */
function units(){const a=sels(),m=new Map();a.forEach(o=>{const k=o.groupId||o.id;if(!m.has(k))m.set(k,[]);m.get(k).push(o);});
 return [...m.values()].map(ms=>{const x1=Math.min(...ms.map(o=>o.x)),y1=Math.min(...ms.map(o=>o.y)),x2=Math.max(...ms.map(o=>o.x+(o.w||0))),y2=Math.max(...ms.map(o=>o.y+(o.h||0)));return {ms,x:x1,y:y1,w:x2-x1,h:y2-y1};});}
const mv=(u,dx,dy)=>u.ms.forEach(o=>{o.x=Math.round(o.x+dx);o.y=Math.round(o.y+dy);});
function need(){const u=units();if(u.length<2){T("Pilih 2 objek atau lebih (Shift + klik)");return null;}return u;}
function jajar(axis,gap,cross){const u=need();if(!u)return;Hi.snapshot();
 const H=axis==="h",pos=v=>H?v.x:v.y,len=v=>H?v.w:v.h;u.sort((a,b)=>pos(a)-pos(b));
 let cur=pos(u[0]);const c0=u[0],cs=H?c0.y:c0.x,cl=H?c0.h:c0.w;
 u.forEach(v=>{const dp=cur-pos(v);let dc=0;if(cross==="start")dc=cs-(H?v.y:v.x);else if(cross==="center")dc=cs+cl/2-((H?v.y:v.x)+(H?v.h:v.w)/2);
  mv(v,H?dp:dc,H?dc:dp);cur+=len(v)+gap;});
 C.render();T(u.length+" objek dijajarkan "+(H?"mendatar":"menurun")+" · jarak "+gap+" px");}
function tumpuk(){const u=need();if(!u)return;Hi.snapshot();const c=u[0],cx=c.x+c.w/2,cy=c.y+c.h/2;u.forEach(v=>mv(v,cx-(v.x+v.w/2),cy-(v.y+v.h/2)));C.render();T(u.length+" objek ditumpuk di tengah");}
function reorder(cmp,msg){const u=need();if(!u)return;Hi.snapshot();const idx=[];S.objects.forEach((o,i)=>{if(u.some(v=>v.ms.includes(o)))idx.push(i);});
 const ord=[...u].sort(cmp).flatMap(v=>S.objects.filter(o=>v.ms.includes(o)));idx.forEach((i,k)=>{S.objects[i]=ord[k];});C.render();T(msg);}
function dlg(){N.openModal("Jajar objek",`<div class="st-pane"><div class="st-grid"><label>Arah<select id="jaA"><option value="h">Mendatar</option><option value="v">Menurun</option></select></label><label>Jarak (px)<input id="jaG" type="number" value="24" min="-500" max="500"></label><label>Perataan<select id="jaC"><option value="none">Tidak diubah</option><option value="start">Rata awal</option><option value="center">Rata tengah</option></select></label></div><p class="muted">Objek dalam satu grup bergerak bersama.</p><button class="btn primary" id="aOk">Jajarkan</button></div>`);
 $("#aOk").onclick=()=>{const g=Math.max(-500,Math.min(500,+$("#jaG").value||0)),a=$("#jaA").value,c=$("#jaC").value;N.closeModal();jajar(a,g,c);};}
const area=v=>v.w*v.h;
MENUS.jajar=()=>[
 {h:"Jajarkan",items:[it("Jajar kustom…",dlg,"arrange"),tc("→ Mendatar rapat",()=>jajar("h",0,"center")),tc("→ Mendatar 24 px",()=>jajar("h",24,"center")),tc("↓ Menurun rapat",()=>jajar("v",0,"center")),tc("↓ Menurun 24 px",()=>jajar("v",24,"center"))]},
 {h:"Susun",items:[tc("Tumpuk di tengah",tumpuk)]},
 {h:"Urutan tumpukan",items:[tc("Besar di belakang",()=>reorder((a,b)=>area(b)-area(a),"Objek besar dipindah ke belakang")),tc("Kecil di belakang",()=>reorder((a,b)=>area(a)-area(b),"Objek kecil dipindah ke belakang")),tc("Kiri → kanan",()=>reorder((a,b)=>a.x-b.x,"Ditumpuk dari kiri ke kanan")),tc("Atas → bawah",()=>reorder((a,b)=>a.y-b.y,"Ditumpuk dari atas ke bawah"))]}];
BT.push(["jajar","distribute","Jajar"]);
hubAdd("atur","jajar");
/* ---------- Callout ---------- */
const alertBox=(c,bg,ic,t,s)=>()=>({w:560,h:130,a:[R(0,0,560,130,bg,{rx:24,name:t}),R(0,0,14,130,c,{rx:7}),E(36,37,56,56,c),X(ic,64,66,32,WHT,{bold:1}),X(t,116,48,30,INK,{left:1,bold:1}),X(s,116,92,22,MUTE,{left:1})]});
Object.assign(COMP,{
 "Info":alertBox("#2f80ed","#e8f1fe","i","Informasi","Detail tambahan untuk pembaca."),
 "Sukses":alertBox("#16a34a","#e6f7ec","✓","Berhasil","Perubahan sudah disimpan."),
 "Peringatan":alertBox("#f59e0b","#fff5e0","!","Perhatian","Periksa lagi sebelum lanjut."),
 "Bahaya":alertBox("#ef4444","#fdeaea","×","Gagal","Terjadi kesalahan, coba lagi."),
 "Balon obrolan kiri":()=>({w:460,h:150,a:[R(30,0,430,120,"#eef0fa",{rx:36,name:"Balon kiri"}),P(0,70,60,60,"M100 0L100 100L0 100Z","#eef0fa"),X("Halo! Ada yang bisa dibantu?",60,60,28,INK,{left:1,bold:1})]}),
 "Balon obrolan kanan":()=>({w:460,h:150,a:[R(0,0,430,120,AC,{rx:36,name:"Balon kanan"}),P(400,70,60,60,"M0 0L100 100L0 100Z",AC),X("Mau lihat daftar harga.",30,60,28,WHT,{left:1,bold:1})]}),
 "Catatan tempel":()=>({w:360,h:360,a:[R(0,0,360,360,"#ffe27a",{rx:6,name:"Catatan tempel"}),R(0,300,360,60,"#f5cf4e",{rx:6}),R(130,-14,100,36,"#ffffff90",{rx:4,rotation:-4}),X("Catatan",36,86,38,INK,{left:1,bold:1}),X("Tulis ide atau pengingat",36,150,26,"#5b4a10",{left:1}),X("di sini.",36,190,26,"#5b4a10",{left:1})]}),
 "Kutipan blok":()=>({w:560,h:260,a:[R(0,0,560,260,"#f6f7fc",{rx:24,name:"Kutipan blok"}),R(0,0,12,260,AC,{rx:6}),X("“",52,70,110,AC,{left:1,bold:1}),X("Tulis kutipan yang kuat di sini.",52,140,32,INK,{left:1,bold:1}),X("— Nama Sumber",52,208,24,MUTE,{left:1})]}),
 "Pita judul":()=>({w:560,h:110,a:[P(0,20,90,90,"M0 0L100 0L60 50L100 100L0 100Z","#4b3fd1"),P(470,20,90,90,"M0 0L100 0L100 100L0 100L40 50Z","#4b3fd1"),R(60,0,440,90,AC,{rx:6,name:"Pita judul"}),X("JUDUL PITA",280,45,38,WHT,{bold:1})]})
});
MENUS.callout=()=>[
 {h:"Kotak pesan",items:["Info","Sukses","Peringatan","Bahaya"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Obrolan",items:["Balon obrolan kiri","Balon obrolan kanan"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Penekanan",items:["Catatan tempel","Kutipan blok","Pita judul"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["callout","callout","Callout"]);
hubAdd("pustaka","callout");
CDMS.Jajar={units};
})();
