/* V99: dua grup menu baru (helper bersama dari CDMS.Util97, tanpa kode duplikat).
   "Kartu" (ikon card99): Tiket (tiket berlubang + garis perforasi + nomor), Kartu Nama (nama, jabatan, kontak; terang/gelap), Label Harga (tag bergantungan dengan lubang).
   "Infografis" (ikon info99): Langkah (lingkaran bernomor 2–6 langkah), Garis Waktu (tahun + keterangan 2–8 titik), Donat (diagram donat + legenda persen dari Nama=nilai).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U||!U.chips)return;
const{parse,ramp,grup,shape,text,line,path,gelap,finish,rnd,PAL,defHub,W,H}=U,R=Math.round;
const bgc=()=>parse(S.page.background||"")?S.page.background:"#ffffff";
const ask=(m,d)=>{const q=prompt(m,d);return q===null?null:String(q).trim();};
const items=s=>String(s).split(/[,;\n]+/).map(x=>x.trim()).filter(Boolean);
const pairs=s=>items(s).map(x=>{const i=x.indexOf("=");return i>0?[x.slice(0,i).trim(),x.slice(i+1).trim()]:null;});
const ink=()=>gelap()?"#f1f3ff":"#20243a";
const pal=()=>PAL[PAL[S.pal99]?S.pal99:"laut"],cc=(t)=>ramp(pal().c.slice(1),t);
const palMenu=()=>({h:"Palet",items:["laut","senja","hijau","biru","mono"].map(k=>tc(PAL[k].n,()=>{S.pal99=k;},{keep:1,on:(S.pal99||"laut")===k}))});
const warnaMenu=(arr,key)=>({h:"Warna",items:arr.map((x,i)=>tc(x[0],()=>{S[key]=i;},{keep:1,on:(S[key]||0)===i}))});
const arahMenu=key=>({h:"Arah",items:[["Mendatar","h"],["Menurun","v"]].map(x=>tc(x[0],()=>{S[key]=x[1];},{keep:1,on:(S[key]||"h")===x[1]}))});

/* ================= KARTU ================= */
const TC=[["Merah","#e11d48"],["Biru","#2563eb"],["Hijau","#16a34a"],["Ungu","#7c3aed"]];
function tiket(){const q=ask("Judul=Subjudul (maks 28 / 40 huruf):","KONSER MUSIK=Sabtu 12 Des · 19.00 WIB");if(q===null)return;
 const i=q.indexOf("="),jd=(i>0?q.slice(0,i):q).trim().slice(0,28),sj=(i>0?q.slice(i+1):"").trim().slice(0,40);if(!jd)return T("Judul kosong");Hi.snapshot();
 const w=W(),h=H(),col=TC[S.tkC99||0][1],tw=R(w*.86),th=R(Math.min(h*.34,tw*.4)),x=R((w-tw)/2),y=R((h-th)/2),bg=bgc(),nr=th*.09,sx=x+tw*.74,sc=(sx+x+tw)/2,
 fs=R(Math.max(8,Math.min(th*.2,tw*.62/(jd.length*.6)))),fs2=R(Math.max(7,Math.min(th*.095,tw*.62/(Math.max(1,sj.length)*.6)))),f3=R(Math.max(7,th*.13)),f4=R(Math.max(6,th*.09)),no="No. "+(100+Math.floor(rnd(0,900))),
 out=[shape("rect",x,y,tw,th,col,{name:"Tiket",rx:R(th*.08)}),shape("ellipse",x-nr,y+th/2-nr,nr*2,nr*2,bg,{name:"Lubang kiri"}),shape("ellipse",x+tw-nr,y+th/2-nr,nr*2,nr*2,bg,{name:"Lubang kanan"}),
 line(sx,y+th*.08,0,th*.84,"#ffffff",3,{name:"Perforasi",dash:"4 4",opacity:70}),
 text(jd,x+tw*.06,y+th*.3,fs,"#ffffff",{name:"Judul tiket",bold:true}),
 text("TIKET",sc-5*f3*.3,y+th*.34,f3,"#ffffff",{name:"Stub",bold:true}),text(no,sc-no.length*f4*.3,y+th*.34+f3*1.5,f4,"#ffffff",{name:"Nomor",opacity:85})];
 if(sj)out.splice(5,0,text(sj,x+tw*.06,y+th*.3+fs*1.5,fs2,"#ffffff",{name:"Subjudul tiket",opacity:90}));
 finish(grup(out,"Tiket"),"Tiket \""+jd+"\" dipasang");}
MENUS.tkt99=()=>[warnaMenu(TC,"tkC99"),{h:"Buat",items:[it("Buat tiket di tengah halaman…",tiket,"ticket99")]}];

const NC=[["Biru","#2563eb"],["Merah","#e11d48"],["Hijau","#16a34a"],["Emas","#d4a017"]];
function kartu(){const q=ask("Nama, Jabatan, Telepon, Email (pisahkan koma; belakang boleh kosong):","Rina Putri, Desainer Grafis, 0812-3456-7890, rina@contoh.id");if(q===null)return;
 const a=items(q).slice(0,5);if(!a.length)return T("Isi minimal nama");Hi.snapshot();
 const w=W(),h=H(),gl=S.kgl99===true,cw=R(Math.min(w*.9,h*.9*1.75)),ch=R(cw/1.75),x=R((w-cw)/2),y=R((h-ch)/2),ac=NC[S.kC99||0][1],fg=gl?"#f1f3ff":"#1f2937",
 nm=a[0].slice(0,30),fn=R(Math.max(8,Math.min(ch*.13,cw*.7/(nm.length*.6)))),px=x+cw*.09,
 out=[shape("rect",x,y,cw,ch,gl?"#171a2b":"#ffffff",{name:"Kartu",stroke:gl?"#2c3150":"#e5e7eb",strokeWidth:2}),shape("rect",x,y,R(cw*.03),ch,ac,{name:"Aksen"}),text(nm,px,y+ch*.2,fn,fg,{name:"Nama",bold:true})];
 if(a[1]){const jb=a[1].slice(0,36),fj=R(Math.max(7,Math.min(fn*.55,cw*.7/(jb.length*.6))));out.push(text(jb,px,y+ch*.2+fn*1.35,fj,ac,{name:"Jabatan"}));}
 const k=a.slice(2,5);if(k.length){const f3=R(Math.max(7,Math.min(ch*.065,cw*.78/(Math.max(...k.map(s=>s.length))*.6+2)))),r=f3*.2;out.push(line(px,y+ch*.5,cw*.25,0,ac,3,{name:"Garis"}));
  k.forEach((s,i)=>{const yy=y+ch*.58+i*f3*1.9;out.push(shape("ellipse",px,yy+f3*.6-r,r*2,r*2,ac,{name:"Titik "+(i+1)}),text(s,px+f3*.9,yy,f3,fg,{name:"Kontak "+(i+1)}));});}
 finish(grup(out,"Kartu nama"),"Kartu nama "+(gl?"gelap":"terang")+" dipasang");}
MENUS.kar99=()=>[{h:"Gaya",items:[tc(S.kgl99===true?"Gelap":"Terang",()=>{S.kgl99=S.kgl99!==true;},{keep:1})]},warnaMenu(NC,"kC99"),{h:"Buat",items:[it("Buat kartu nama di tengah halaman…",kartu,"namecard99")]}];

const PT=[["Merah","#e11d48","#ffffff"],["Kuning","#facc15","#3b2a00"],["Hijau","#16a34a","#ffffff"],["Hitam","#111827","#ffffff"]];
function tag(){const q=ask("Teks tag (maks 16 huruf):","DISKON 50%");if(q===null)return;const t=q.slice(0,16);if(!t)return T("Teks kosong");Hi.snapshot();
 const w=W(),h=H(),L=PT[S.tgC99||0],tw=R(Math.min(w*.76,h*.9*2.4)),th=R(tw*.38),x=R((w-tw)/2),y=R((h-th)/2),pt=R(th*.38),hr=th*.07,
 bx=x+pt+th*.12,bw=tw-pt-th*.24,fs=R(Math.max(8,Math.min(th*.3,bw/(t.length*.6))));
 const out=[path(x,y,tw,th,tw,th,`M0 ${R(th/2)}L${pt} 0L${tw} 0L${tw} ${th}L${pt} ${th}Z`,L[1],"none",0,{name:"Tag"}),
 shape("ellipse",x+pt*.85-hr,y+th/2-hr,hr*2,hr*2,bgc(),{name:"Lubang"}),
 text(t,bx+(bw-t.length*fs*.6)/2,y+th/2-fs*.6,fs,L[2],{name:"Teks tag",bold:true})];
 finish(grup(out,"Label harga"),"Label harga \""+t+"\" dipasang");}
MENUS.tag99=()=>[warnaMenu(PT,"tgC99"),{h:"Buat",items:[it("Buat label harga di tengah halaman…",tag,"pricetag99")]}];

/* ================= INFOGRAFIS ================= */
function langkah(){const q=ask("2–6 langkah, pisahkan dengan koma:","Rencana, Desain, Kembangkan, Uji, Rilis");if(q===null)return;const a=items(q).map(s=>s.slice(0,18));if(a.length<2||a.length>6)return T("Isi 2–6 langkah");Hi.snapshot();
 const w=W(),h=H(),n=a.length,v=S.lgA99==="v",tcol=ink(),out=[],gl="#cbd5e1";
 const slot=(v?h:w)/n,r=R(Math.max(8,Math.min(slot*.3,v?w*.07:h*.08))),cx0=w*.24,cy0=h*.45;
 out.push(v?line(cx0,slot*.5,0,slot*(n-1),gl,Math.max(3,R(r*.18)),{name:"Garis"}):line(slot*.5,cy0,slot*(n-1),0,gl,Math.max(3,R(r*.18)),{name:"Garis"}));
 a.forEach((t,i)=>{const cx=v?cx0:slot*(i+.5),cy=v?slot*(i+.5):cy0,fn=R(r*.95),num=String(i+1);
  out.push(shape("ellipse",cx-r,cy-r,r*2,r*2,cc(i/(n-1)),{name:"Langkah "+num,stroke:bgc(),strokeWidth:3}),text(num,cx-fn*.3,cy-fn*.6,fn,"#ffffff",{name:"Nomor "+num,bold:true}));
  if(v){const fs=R(Math.max(8,Math.min(r*.8,w*.62/(t.length*.6))));out.push(text(t,cx+r*1.6,cy-fs*.6,fs,tcol,{name:"Label "+num}));}
  else{const fs=R(Math.max(8,Math.min(r*.52,slot*.9/(t.length*.6))));out.push(text(t,cx-t.length*fs*.3,cy+r*1.45,fs,tcol,{name:"Label "+num}));}});
 finish(grup(out,"Langkah"),n+" langkah ("+(v?"menurun":"mendatar")+")");}
MENUS.lgk99=()=>[palMenu(),arahMenu("lgA99"),{h:"Buat",items:[it("Buat langkah bernomor (2–6)…",langkah,"steps99")]}];

function garisWaktu(){const q=ask("2–8 peristiwa, format Tahun=Keterangan (pisahkan koma):","2020=Mulai, 2021=Tim bertambah, 2023=Produk rilis, 2025=Ekspansi");if(q===null)return;
 const rows=pairs(q);if(rows.length<2||rows.length>8||rows.some(r=>!r||!r[1]))return T("Isi 2–8 baris berformat Tahun=Keterangan");rows.forEach(r=>{r[0]=r[0].slice(0,10);r[1]=r[1].slice(0,26);});Hi.snapshot();
 const w=W(),h=H(),n=rows.length,v=S.gwA99==="v",tcol=ink(),out=[],ax="#cbd5e1";
 if(!v){const slot=w*.84/n,x0=w*.08,cy=h/2,r=R(Math.max(6,Math.min(slot*.12,h*.022))),fy=R(Math.max(10,Math.min(slot*.3,h*.04))),gap=r*4;
  out.push(line(x0,cy,w*.84,0,ax,Math.max(3,R(r*.5)),{name:"Sumbu"}));
  rows.forEach((rw,i)=>{const cx=x0+slot*(i+.5),up=i%2===0,col=cc(i/(n-1)),ft=R(Math.max(8,Math.min(fy*.7,slot*1.7/(rw[1].length*.6)))),yy=up?cy-gap-ft*1.3-fy*1.3:cy+gap;
   out.push(line(cx,up?cy-gap:cy,0,gap,col,Math.max(2,R(r*.3)),{name:"Tangkai "+(i+1)}),shape("ellipse",cx-r,cy-r,r*2,r*2,col,{name:"Titik "+(i+1),stroke:bgc(),strokeWidth:3}),
    text(rw[0],cx-rw[0].length*fy*.3,yy,fy,col,{name:"Tahun "+rw[0],bold:true}),text(rw[1],cx-rw[1].length*ft*.3,yy+fy*1.3,ft,tcol,{name:"Ket "+rw[0]}));});}
 else{const slot=h*.84/n,y0=h*.08,cx=w/2,r=R(Math.max(6,Math.min(slot*.14,w*.025))),fy=R(Math.max(10,Math.min(slot*.3,w*.05))),gap=r*3.5;
  out.push(line(cx,y0,0,h*.84,ax,Math.max(3,R(r*.5)),{name:"Sumbu"}));
  rows.forEach((rw,i)=>{const cy=y0+slot*(i+.5),rt=i%2===0,col=cc(i/(n-1)),ft=R(Math.max(8,Math.min(fy*.7,w*.35/(rw[1].length*.6)))),
   tx=y=>rt?cx+gap+r:cx-gap-r-y;
   out.push(line(rt?cx:cx-gap,cy,gap,0,col,Math.max(2,R(r*.3)),{name:"Tangkai "+(i+1)}),shape("ellipse",cx-r,cy-r,r*2,r*2,col,{name:"Titik "+(i+1),stroke:bgc(),strokeWidth:3}),
    text(rw[0],tx(rw[0].length*fy*.6),cy-fy*.95,fy,col,{name:"Tahun "+rw[0],bold:true}),text(rw[1],tx(rw[1].length*ft*.6),cy+fy*.35,ft,tcol,{name:"Ket "+rw[0]}));});}
 finish(grup(out,"Garis waktu"),"Garis waktu "+n+" titik ("+(v?"menurun":"mendatar")+")");}
MENUS.gwk99=()=>[palMenu(),arahMenu("gwA99"),{h:"Buat",items:[it("Buat garis waktu (2–8 titik)…",garisWaktu,"timeline99")]}];

function donat(){const q=ask("2–8 data, format Nama=nilai:","Desain=40, Kode=30, Uji=20, Rilis=10");if(q===null)return;
 const rows=pairs(q),vals=rows.map(r=>r?parseFloat(r[1].replace(",",".")):NaN);
 if(rows.length<2||rows.length>8||vals.some(v=>!isFinite(v)||v<=0))return T("Isi 2–8 baris Nama=nilai (angka positif)");Hi.snapshot();
 const w=W(),h=H(),n=rows.length,tot=vals.reduce((a,b)=>a+b,0),Ro=R(Math.min(w*.32,h*.22)),Ri=R(Ro*(S.dnR99||.55)),cx=w/2,cy=h*.1+Ro,D=Ro*2,bg=bgc(),tcol=ink(),out=[],pc=vals.map(v=>R(100*v/tot));
 let a0=-Math.PI/2;
 vals.forEach((v,i)=>{const a1=a0+2*Math.PI*v/tot,st=Math.max(2,Math.ceil((a1-a0)/(Math.PI/60))),pt=(rad,a)=>R(Ro+rad*Math.cos(a))+" "+R(Ro+rad*Math.sin(a));let d="";
  for(let k=0;k<=st;k++)d+=(k?"L":"M")+pt(Ro,a0+(a1-a0)*k/st);for(let k=st;k>=0;k--)d+="L"+pt(Ri,a0+(a1-a0)*k/st);
  out.push(path(cx-Ro,cy-Ro,D,D,D,D,d+"Z",cc(i/(n-1)),bg,3,{name:"Irisan "+rows[i][0]}));a0=a1;});
 const mx=vals.indexOf(Math.max(...vals)),ps=pc[mx]+"%",nm=rows[mx][0].slice(0,14),fs=R(Math.max(8,Math.min(Ri*.5,Ri*1.5/(ps.length*.6)))),f2=R(Math.max(7,Math.min(fs*.38,Ri*1.6/(nm.length*.6))));
 out.push(text(ps,cx-ps.length*fs*.3,cy-fs*.6,fs,tcol,{name:"Persen utama",bold:true}),text(nm,cx-nm.length*f2*.3,cy+fs*.55,f2,tcol,{name:"Nama utama",opacity:80}));
 const y0=cy+Ro+h*.04,lh=Math.max(10,Math.min(h*.05,(h-y0-h*.03)/n)),lf=R(Math.max(8,lh*.6));
 rows.forEach((r,i)=>{const yy=y0+i*lh;out.push(shape("rect",w*.2,yy,lf,lf,cc(i/(n-1)),{name:"Kunci "+(i+1)}),text(r[0].slice(0,20)+"  "+pc[i]+"%",w*.2+lf*1.6,yy-lf*.1,lf,tcol,{name:"Legenda "+(i+1)}));});
 finish(grup(out,"Donat"),"Donat "+n+" irisan");}
MENUS.dnt99=()=>[palMenu(),{h:"Lubang tengah",items:[["Lebar",.45],["Sedang",.55],["Tipis",.7]].map(x=>tc(x[0],()=>{S.dnR99=x[1];},{keep:1,on:(S.dnR99||.55)===x[1]}))},{h:"Buat",items:[it("Buat diagram donat (Nama=nilai)…",donat,"donut99")]}];

/* ================= tombol & grup ================= */
BT.push(["tkt99","ticket99","Tiket"],["kar99","namecard99","Kartu Nama"],["tag99","pricetag99","Label Harga"],["lgk99","steps99","Langkah"],["gwk99","timeline99","Garis Waktu"],["dnt99","donut99","Donat"]);
defHub("infog99","info99","Infografis",["lgk99","gwk99","dnt99"]);
defHub("kartu99","card99","Kartu",["tkt99","kar99","tag99"]);
CDMS.Kartu99={tiket,kartu,tag,langkah,garisWaktu,donat};
})();
