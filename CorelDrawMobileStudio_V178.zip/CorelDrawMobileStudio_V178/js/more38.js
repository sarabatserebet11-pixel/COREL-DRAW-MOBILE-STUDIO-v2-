/* V49: menu Periksa - pemeriksa desain (preflight): temukan masalah, pilih objeknya, perbaiki sekali ketuk */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,pick,T,it}=M;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const hh=o=>o.h||0,W=()=>S.page.width,H=()=>S.page.height;
const lum=h=>{const m=/^#?([0-9a-f]{6})$/i.exec(h||"");if(!m)return null;const v=[0,2,4].map(i=>{const c=parseInt(m[1].substr(i,2),16)/255;return c<=.03928?c/12.92:Math.pow((c+.055)/1.055,2.4);});return .2126*v[0]+.7152*v[1]+.0722*v[2];};
const cr=(a,b)=>{const x=lum(a),y=lum(b);if(x==null||y==null)return null;return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
const bg=()=>S.page.background||S.page.bg||"#ffffff";
/* tiap aturan: nama, fungsi uji, perbaikan (opsional) */
const RULES=[
 {n:"Di luar halaman",t:o=>o.x+o.w<=0||o.y+hh(o)<=0||o.x>=W()||o.y>=H(),fix:o=>{o.x=Math.min(Math.max(o.x,0),Math.max(0,W()-o.w));o.y=Math.min(Math.max(o.y,0),Math.max(0,H()-hh(o)));},fl:"Tarik ke dalam halaman"},
 {n:"Teks kecil (< 14 px)",t:o=>o.type==="text"&&(o.fontSize||0)<14,fix:o=>{o.fontSize=14;},fl:"Naikkan ke 14 px"},
 {n:"Teks kontras rendah (< 3:1)",t:o=>{if(o.type!=="text")return false;const r=cr(o.fill,bg());return r!=null&&r<3;}},
 {n:"Teks kosong",t:o=>o.type==="text"&&!String(o.text||"").trim(),fix:o=>{o._del=1;},fl:"Hapus"},
 {n:"Objek tersembunyi",t:o=>!!o.hidden,fix:o=>{o.hidden=false;},fl:"Tampilkan"},
 {n:"Hampir transparan (< 10%)",t:o=>(o.opacity??100)<10,fix:o=>{o.opacity=100;},fl:"Pulihkan 100%"},
 {n:"Ukuran terlalu kecil (< 4 px)",t:o=>o.type!=="line"&&(o.w<4||(o.h!=null&&o.h<4)),fix:o=>{o._del=1;},fl:"Hapus"}];
const scan=()=>RULES.map(r=>({r,list:S.objects.filter(o=>{try{return r.t(o);}catch(e){return false;}})}));
function fixAll(list,r){Hi.snapshot();list.forEach(r.fix);S.objects=S.objects.filter(o=>!o._del);C.render();T("Diperbaiki: "+list.length+" objek");}
MENUS.periksa=()=>{const res=scan(),bad=res.filter(x=>x.list.length),tot=bad.reduce((a,x)=>a+x.list.length,0);
 const head={h:tot?"Ditemukan "+tot+" masalah (ketuk untuk memilih objeknya)":"Tidak ada masalah ditemukan ✓",items:res.map(x=>it(x.r.n+": "+x.list.length,()=>{if(!x.list.length)return T("Aman");pick(x.list);T(x.list.length+" objek dipilih");},x.list.length?"eye":"eye"))};
 const fixes={h:"Perbaiki sekali ketuk",items:bad.filter(x=>x.r.fix).map(x=>it(x.r.fl+" ("+x.list.length+")",()=>fixAll(x.list,x.r),"layers"))};
 const info={h:"Ringkasan",items:[it("Objek: "+S.objects.length+" · halaman "+W()+"×"+H()+" px",()=>T("Objek: "+S.objects.length),"info")]};
 return [head,...(fixes.items.length?[fixes]:[]),info];};
BT.push(["periksa","inspect","Periksa"]);
hubAdd("kanvas","periksa");
})();
