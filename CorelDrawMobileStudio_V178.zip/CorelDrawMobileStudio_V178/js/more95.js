/* V107: dua grup menu baru (helper bersama dari CDMS.Util97, tanpa kode duplikat).
   "Struktur" (ikon struct107): Peta Pikiran (pusat + 3-8 cabang), Hierarki (atasan + 2-5 bawahan), Matriks (kotak 2x2 / SWOT), Pro-Kontra (dua kolom poin).
   "Acara & Niaga" (ikon event107): Papan Skor, Hitung Mundur, Harga (2-3 paket), Menu (daftar + harga).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U||!U.kartu||!U.seg||!U.mkPal||!U.chips||!U.idx||!U.kontras)return;
const{ramp,grup,shape,text,line,finish,defHub,W,H,ask,idx,tx,clamp,mkPal,chips,kartu,seg,kontras,mix}=U,R=Math.round;
const PL=mkPal("pal107","biru"),pal=PL.pal,palMenu=PL.menu,pc=(P,t)=>ramp(P.c.slice(1),t);
const t1=(n,t)=>n>1?t/(n-1):0,rt=(s,xr,y,fs,col,o)=>text(s,xr-s.length*fs*.6,y,fs,col,o),mx=a=>Math.max(...a.map(s=>String(s).length));
/* pil berisi teks, dipusatkan di (cx,cy) */
const pill=(cx,cy,s,fs,col,nm)=>{const w=s.length*fs*.6+fs*1.8,h=fs*2.2;return[shape("rect",cx-w/2,cy-h/2,w,h,col,{name:nm,rx:R(h/2)}),tx(s,cx,cy-fs*.6,fs,kontras(col),{name:nm+" teks",bold:true})];};
/* "a, b, c" -> [a,b,c] ; null bila jumlah di luar a..b */
const list=(s,a,b,m)=>{const o=String(s).split(/[,;\n]+/).map(v=>v.trim().slice(0,m)).filter(Boolean);return o.length>=a&&o.length<=b?o:null;};
/* "Nama:nilai, Nama:nilai" -> [[nama,nilai]] ; null bila format atau jumlah salah */
const kv=(s,a,b,ml,mv)=>{const o=[];for(const x of String(s).split(/[,;\n]+/).map(v=>v.trim()).filter(Boolean)){const i=x.lastIndexOf(":");if(i<1||i===x.length-1)return null;o.push([x.slice(0,i).trim().slice(0,ml),x.slice(i+1).trim().slice(0,mv)]);}return o.length>=a&&o.length<=b?o:null;};
/* "Judul | isi" -> [judul,isi] ; tanpa "|" judulnya kosong */
const ju=q=>{const i=q.indexOf("|");return i<0?["",q.trim()]:[q.slice(0,i).trim().slice(0,24),q.slice(i+1).trim()];};

/* ================= STRUKTUR ================= */
function peta(){const q=ask("Peta (Pusat | Cabang, Cabang; 3-8 cabang):",S.mpD107||"Proyek | Ide, Desain, Kode, Tes, Rilis");if(q===null)return;const[c,b]=ju(q),d=list(b,3,8,12);if(!c||!d)return T("Format: Pusat | Cabang1, Cabang2, Cabang3");S.mpD107=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),cw=w*.94,ch=h*.9,x=(w-cw)/2,y=(h-ch)/2,cx=w/2,cy=h/2,n=d.length,ax=cw*.3,ay=ch*.3,fs=R(clamp(Math.min(cw*.04,ch*.06,ax*.8/(mx(d)*.6+1.8)),7,26)),out=[kartu(x,y,cw,ch,cw*.03)],nd=[];
 d.forEach((s,i)=>{const a=-Math.PI/2+i*2*Math.PI/n,px=cx+ax*Math.cos(a),py=cy+ay*Math.sin(a);out.push(seg(cx,cy,px,py,"#9ca3af",3,"Hubungan "+(i+1)));nd.push([s,px,py,pc(P,t1(n,i))]);});
 nd.forEach(v=>out.push(...pill(v[1],v[2],v[0],fs,v[3],"Cabang "+v[0])));
 const f2=fs*1.2,rw=Math.max(c.length*f2*.6+f2*2,f2*5),rh=f2*3,cc=mix(pc(P,0),"#000000",.35);
 out.push(shape("ellipse",cx-rw/2,cy-rh/2,rw,rh,cc,{name:"Pusat",stroke:"#ffffff",strokeWidth:3}),tx(c,cx,cy-f2*.6,f2,kontras(cc),{name:"Pusat teks",bold:true}));
 finish(grup(out,"Peta pikiran"),"Peta pikiran dengan "+n+" cabang");}
MENUS.pta107=()=>[palMenu(),{h:"Buat",items:[it("Buat peta pikiran…",peta,"mind107")]}];

function hierarki(){const q=ask("Hierarki (Atasan | Bawahan, Bawahan; 2-5):",S.hiD107||"Direktur | Desain, Teknik, Pemasaran");if(q===null)return;const[c,b]=ju(q),d=list(b,2,5,12);if(!c||!d)return T("Format: Atasan | Bawahan1, Bawahan2");S.hiD107=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=d.length,cw=w*.94,ch=Math.min(h*.7,cw*.7),x=(w-cw)/2,y=(h-ch)/2,cx=w/2,slot=cw*.92/n,bw=slot*.86,fs=R(clamp(Math.min(bw*.9/(mx(d)*.6),ch*.07),7,24)),bh=fs*2.6,
  ry=y+ch*.14,cy2=y+ch*.62,rw=Math.max(c.length*fs*.6+fs*2.4,bw*.8),mid=(ry+bh+cy2)/2,xs=d.map((_,i)=>x+cw*.04+slot*(i+.5)),out=[kartu(x,y,cw,ch,cw*.03)],rc=mix(pc(P,0),"#000000",.35);
 out.push(seg(cx,ry+bh,cx,mid,"#9ca3af",3,"Penghubung atas"),seg(xs[0],mid,xs[n-1],mid,"#9ca3af",3,"Penghubung datar"));
 xs.forEach((px,i)=>out.push(seg(px,mid,px,cy2,"#9ca3af",3,"Penghubung "+(i+1))));
 out.push(shape("rect",cx-rw/2,ry,rw,bh,rc,{name:"Atasan",rx:R(bh*.25)}),tx(c,cx,ry+bh/2-fs*.6,fs,kontras(rc),{name:"Atasan teks",bold:true}));
 d.forEach((s,i)=>{const col=pc(P,t1(n,i));out.push(shape("rect",xs[i]-bw/2,cy2,bw,bh,col,{name:"Bawahan "+s,rx:R(bh*.25)}),tx(s,xs[i],cy2+bh/2-fs*.6,fs,kontras(col),{name:"Bawahan teks "+(i+1),bold:true}));});
 finish(grup(out,"Hierarki"),"Hierarki 1 + "+n+" bawahan");}
MENUS.hir107=()=>[palMenu(),{h:"Buat",items:[it("Buat bagan hierarki…",hierarki,"tree107")]}];

function matriks(){const q=ask("Matriks (Judul | 4 kotak, pisah koma):",S.mtD107||"SWOT | Kekuatan, Kelemahan, Peluang, Ancaman");if(q===null)return;const[t,b]=ju(q),d=list(b,4,4,14);if(!d)return T("Format: Judul | Kotak1, Kotak2, Kotak3, Kotak4 (tepat 4)");S.mtD107=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),cw=w*.94,ch=Math.min(h*.9,cw*.85),x=(w-cw)/2,y=(h-ch)/2,pd=cw*.04,gap=pd*.6,fs=R(clamp(Math.min(cw*.2/(mx(d)*.6)*1.6,cw*.04),8,26)),th=t?fs*2.4:0,qw=(cw-2*pd-gap)/2,qh=(ch-2*pd-gap-th)/2,hh=fs*2.6,out=[kartu(x,y,cw,ch,cw*.03)];
 if(t)out.push(tx(t,w/2,y+pd*.7,fs*1.3,"#1f2937",{name:"Judul",bold:true}));
 d.forEach((s,i)=>{const col=pc(P,t1(4,i)),qx=x+pd+(i%2)*(qw+gap),qy=y+pd+th+Math.floor(i/2)*(qh+gap);
  out.push(shape("rect",qx,qy,qw,qh,mix(col,"#ffffff",.82),{name:"Kotak "+s,rx:R(fs*.6),stroke:col,strokeWidth:3}),shape("rect",qx,qy,qw,hh,col,{name:"Kepala "+s,rx:R(fs*.6)}),tx(s,qx+qw/2,qy+hh/2-fs*.6,fs,kontras(col),{name:"Label "+(i+1),bold:true}));});
 finish(grup(out,"Matriks 2x2"),"Matriks 2x2 dipasang (isi kotak dengan alat Teks)");}
MENUS.mtr107=()=>[palMenu(),{h:"Buat",items:[it("Buat matriks 2x2…",matriks,"matrix107")]}];

function proKontra(){const a=ask("Kolom kiri (Judul | poin, poin; 1-4):",S.pkA107||"Kelebihan | Cepat, Murah, Mudah");if(a===null)return;const b=ask("Kolom kanan (Judul | poin, poin; 1-4):",S.pkB107||"Kekurangan | Rapuh, Berat");if(b===null)return;
 const[ta,ia]=ju(a),[tb,ib]=ju(b),L=list(ia,1,4,16),Rg=list(ib,1,4,16);if(!L||!Rg)return T("Format tiap kolom: Judul | poin1, poin2 (1-4 poin)");S.pkA107=a;S.pkB107=b;Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=Math.max(L.length,Rg.length),cw=w*.94,pd=cw*.04,colw=(cw-3*pd)/2,fs=R(clamp(Math.min(colw*.85/(Math.max(mx(L),mx(Rg),mx([ta||"Kelebihan",tb||"Kekurangan"]))*.6+1.6),cw*.04),8,24)),hh=fs*3,ch=Math.min(h*.9,pd*2+hh+n*fs*2.4+fs),x=(w-cw)/2,y=(h-ch)/2,out=[kartu(x,y,cw,ch,cw*.03)];
 [[ta||"Kelebihan",L,pc(P,0)],[tb||"Kekurangan",Rg,pc(P,1)]].forEach((k,j)=>{const cx0=x+pd+j*(colw+pd);
  out.push(shape("rect",cx0,y+pd,colw,hh,k[2],{name:"Kepala "+(j+1),rx:R(fs*.6)}),tx(k[0],cx0+colw/2,y+pd+hh/2-fs*.6,fs*1.1,kontras(k[2]),{name:"Judul "+(j+1),bold:true}));
  k[1].forEach((s,i)=>{const yy=y+pd+hh+fs*1.1+i*fs*2.4;out.push(shape("ellipse",cx0+fs*.4,yy+fs*.25,fs*.7,fs*.7,k[2],{name:"Titik "+(j+1)+"."+(i+1)}),text(s,cx0+fs*1.6,yy,fs,"#374151",{name:"Poin "+(j+1)+"."+(i+1)}));});});
 out.push(seg(x+cw/2,y+pd+hh+fs*.6,x+cw/2,y+ch-pd,"#e5e7eb",2,"Pembatas"));
 finish(grup(out,"Pro dan kontra"),"Pro-Kontra "+L.length+" dan "+Rg.length+" poin");}
MENUS.prk107=()=>[palMenu(),{h:"Buat",items:[it("Buat kolom pro-kontra…",proKontra,"proscon107")]}];

/* ================= ACARA & NIAGA ================= */
function skor(){const q=ask("Skor (Tim A | skor | skor | Tim B):",S.skD107||"Garuda | 3 | 2 | Macan");if(q===null)return;const p=q.split("|").map(v=>v.trim());if(p.length!==4||!p[0]||!p[3]||!/^\d{1,3}$/.test(p[1])||!/^\d{1,3}$/.test(p[2]))return T("Format: Tim A | skor | skor | Tim B (skor angka)");S.skD107=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),cw=Math.min(w*.92,h*.8*1.8),ch=cw*.5,x=(w-cw)/2,y=(h-ch)/2,cx=w/2,sb=Math.min(cw*.24,ch*.5),dk="#111827",out=[shape("rect",x,y,cw,ch,dk,{name:"Papan",rx:R(cw*.03),stroke:"#374151",strokeWidth:3})];
 const nm=(s,mxc)=>s.slice(0,mxc),fn=R(clamp(Math.min(cw*.3/(Math.max(p[0].length,p[3].length)*.6),ch*.1),8,28));
 out.push(tx("SKOR",cx,y+ch*.08,fn*.9,"#9ca3af",{name:"Judul",bold:true}));
 [[p[0],p[1],cx-cw*.22,pc(P,0)],[p[3],p[2],cx+cw*.22,pc(P,1)]].forEach((k,j)=>{const col=k[3],fs=sb*.6<sb*.85/(k[1].length*.6)?sb*.6:sb*.85/(k[1].length*.6);
  out.push(tx(nm(k[0],10),k[2],y+ch*.22,fn,"#ffffff",{name:"Tim "+(j+1),bold:true}),shape("rect",k[2]-sb/2,y+ch*.4,sb,sb,col,{name:"Kotak skor "+(j+1),rx:R(sb*.15)}),tx(k[1],k[2],y+ch*.4+sb/2-fs*.6,fs,kontras(col),{name:"Skor "+(j+1),bold:true}));});
 const r=sb*.07,my=y+ch*.4+sb/2;out.push(shape("ellipse",cx-r,my-sb*.18-r,r*2,r*2,"#ffffff",{name:"Titik dua atas"}),shape("ellipse",cx-r,my+sb*.18-r,r*2,r*2,"#ffffff",{name:"Titik dua bawah"}));
 finish(grup(out,"Papan skor"),"Papan skor "+p[0]+" "+p[1]+" : "+p[2]+" "+p[3]);}
MENUS.skr107=()=>[palMenu(),{h:"Buat",items:[it("Buat papan skor…",skor,"score107")]}];

const HL=["HARI","JAM","MENIT","DETIK"];
function hitung(){const q=ask("Nilai (Hari | Jam | Menit | Detik; 2-4 angka):",S.hmD107||"10 | 04 | 25 | 12");if(q===null)return;const v=q.split(/[|,]/).map(s=>s.trim()).filter(Boolean);if(v.length<2||v.length>4||v.some(s=>!/^\d{1,3}$/.test(s)))return T("Format: 10 | 04 | 25 | 12 (2-4 angka, maks 3 digit)");S.hmD107=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=v.length,g=.22,ts=Math.min(w*.92/(n+(n-1)*g),h*.4,220),th=ts*1.2,gp=ts*g,tot=n*ts+(n-1)*gp,x0=(w-tot)/2,y0=(h-th)/2,out=[];
 v.forEach((s,i)=>{const sv=s.length<2?"0"+s:s,col=pc(P,t1(n,i)),tx0=x0+i*(ts+gp),fs=Math.min(ts*.5,ts*.85/(sv.length*.6)),f2=Math.max(7,ts*.13);
  out.push(shape("rect",tx0,y0,ts,th,mix(col,"#000000",.25),{name:"Kotak "+HL[i],rx:R(ts*.12),stroke:col,strokeWidth:3}),tx(sv,tx0+ts/2,y0+th*.3-fs*.2,fs,"#ffffff",{name:"Angka "+HL[i],bold:true}),tx(HL[i],tx0+ts/2,y0+th*.8,f2,"#e5e7eb",{name:"Label "+HL[i]}));
  if(i<n-1){const r=Math.max(2,ts*.035),cx=tx0+ts+gp/2;out.push(shape("ellipse",cx-r,y0+th*.4-r,r*2,r*2,"#6b7280",{name:"Titik dua "+(i+1)+"a"}),shape("ellipse",cx-r,y0+th*.6-r,r*2,r*2,"#6b7280",{name:"Titik dua "+(i+1)+"b"}));}});
 finish(grup(out,"Hitung mundur"),"Hitung mundur "+v.join(":")+" dipasang");}
MENUS.hmd107=()=>[palMenu(),{h:"Buat",items:[it("Buat hitung mundur…",hitung,"count107")]}];

function harga(){const q=ask("Paket (Nama:harga, 2-3 paket):",S.hgD107||"Basic:50rb, Pro:120rb, Bisnis:300rb");if(q===null)return;const d=kv(q,2,3,10,9);if(!d)return T("Format: Basic:50rb, Pro:120rb (2-3 paket)");S.hgD107=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=d.length,g=w*.02,cw=(w*.94-(n-1)*g)/n,ch=Math.min(h*.78,cw*2.1),x0=(w-(n*cw+(n-1)*g))/2,y0=(h-ch)/2,hot=n===3?1:n-1,out=[];
 d.forEach((s,i)=>{const e=i===hot?ch*.05:0,x=x0+i*(cw+g),y=y0-e,hh=ch+2*e,col=pc(P,t1(n,i)),fn=R(clamp(cw*.8/(s[0].length*.6),8,22)),fp=R(clamp(Math.min(cw*.85/(s[1].length*.6),cw*.24),8,40)),bh=hh*.22;
  out.push(shape("rect",x,y,cw,hh,"#ffffff",{name:"Kartu "+s[0],rx:R(cw*.07),stroke:i===hot?col:"#e5e7eb",strokeWidth:i===hot?4:2}),shape("rect",x,y,cw,bh,col,{name:"Kepala "+s[0],rx:R(cw*.07)}),tx(s[0],x+cw/2,y+bh/2-fn*.6,fn,kontras(col),{name:"Nama "+s[0],bold:true}),
   tx(s[1],x+cw/2,y+bh+hh*.07,fp,"#1f2937",{name:"Harga "+s[0],bold:true}));
  [.7,.55,.65].forEach((f,k)=>out.push(shape("rect",x+cw*(1-f)/2,y+hh*.5+k*hh*.08,cw*f,Math.max(4,hh*.025),"#e5e7eb",{name:"Baris isi "+(k+1),rx:3})));
  out.push(...pill(x+cw/2,y+hh*.86,"Pilih",R(clamp(cw*.1,8,20)),col,"Tombol "+s[0]));
  if(i===hot)out.push(...pill(x+cw/2,y,"POPULER",R(clamp(cw*.07,7,14)),"#f59e0b","Lencana"));});
 finish(grup(out,"Daftar harga"),"Daftar harga "+n+" paket (isi baris abu-abu dengan alat Teks)");}
MENUS.hrg107=()=>[palMenu(),{h:"Buat",items:[it("Buat kartu harga…",harga,"price107")]}];

function menu(){const q=ask("Menu (Judul | Nama:harga, ...; 3-8 item):",S.mnD107||"MENU | Nasi Goreng:25, Mie Ayam:20, Es Teh:8, Kopi:12");if(q===null)return;const[t0,b]=ju(q),d=kv(b,3,8,18,8);if(!d)return T("Format: Judul | Nasi Goreng:25, Es Teh:8 (3-8 item)");S.mnD107=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=d.length,t=t0||"MENU",cw=Math.min(w*.9,h*.85),pd=cw*.06;let fs=R(clamp(cw*.05,9,26));fs=Math.min(fs,(h*.9-2*pd)/(3.6+n*2.4));
 const hh=fs*3.6,ch=hh+n*fs*2.4+pd*1.4,x=(w-cw)/2,y=(h-ch)/2,col=pc(P,0),out=[kartu(x,y,cw,ch,cw*.03),shape("rect",x,y,cw,hh,col,{name:"Kepala",rx:R(cw*.03)}),tx(t,w/2,y+hh/2-fs*.8,fs*1.6,kontras(col),{name:"Judul",bold:true})];
 d.forEach((s,i)=>{const yy=y+hh+pd*.7+i*fs*2.4,l=x+pd+s[0].length*fs*.6+fs*.6,r=x+cw-pd-s[1].length*fs*.6-fs*.6;
  out.push(text(s[0],x+pd,yy,fs,"#1f2937",{name:"Nama "+(i+1),bold:true}),rt(s[1],x+cw-pd,yy,fs,pc(P,.2),{name:"Harga "+(i+1),bold:true}));
  if(r-l>fs)out.push(line(l,yy+fs*.95,r-l,0,"#d1d5db",2,{name:"Garis titik "+(i+1)}));});
 finish(grup(out,"Menu"),"Menu "+n+" item dipasang");}
MENUS.mnu107=()=>[palMenu(),{h:"Buat",items:[it("Buat daftar menu…",menu,"menu107")]}];

/* ================= tombol & grup ================= */
BT.push(["pta107","mind107","Peta Pikiran"],["hir107","tree107","Hierarki"],["mtr107","matrix107","Matriks"],["prk107","proscon107","Pro-Kontra"],["skr107","score107","Papan Skor"],["hmd107","count107","Hitung Mundur"],["hrg107","price107","Harga"],["mnu107","menu107","Menu"]);
defHub("struktur107","struct107","Struktur",["pta107","hir107","mtr107","prk107"]);
defHub("acara107","event107","Acara & Niaga",["skr107","hmd107","hrg107","mnu107"]);
Object.assign(U,{pill,list,kv,ju,rt,t1,mx});
CDMS.Struktur107={peta,hierarki,matriks,proKontra,skor,hitung,harga,menu};
})();
