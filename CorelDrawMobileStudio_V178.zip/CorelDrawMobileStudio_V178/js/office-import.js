/* V162: Impor file PowerPoint (.pptx) dan PDF ke mode Excel, Word, dan PowerPoint.
   Pustaka dibundel offline (lib/jszip.min.js, lib/pdfjs/*) dan baru dimuat saat dipakai.
   Mode-mode mengekspos pengait lewat window.CDMS_OFFICE.{excel,word,ppt}. */
(()=>{
 const $=s=>document.querySelector(s);
 const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const tick=()=>new Promise(r=>setTimeout(r,0));
 const MAXFILE=80*1024*1024;
 const HANDLE='<span class="ppt-h" contenteditable="false">✥</span>';

 /* ---------- Pemuat pustaka (malas) ---------- */
 const base=(()=>{try{const s=document.currentScript&&document.currentScript.src;return s?new URL('../',s).href:document.baseURI;}catch(_){return document.baseURI;}})();
 let zipP=null,pdfP=null;
 function needZip(){
  if(window.JSZip)return Promise.resolve(window.JSZip);
  return zipP||(zipP=new Promise((ok,no)=>{const s=document.createElement('script');s.src=base+'lib/jszip.min.js';s.onload=()=>window.JSZip?ok(window.JSZip):no(new Error('JSZip'));s.onerror=()=>{zipP=null;no(new Error('Pustaka PPTX gagal dimuat'));};document.head.appendChild(s);}));
 }
 function needPdf(){
  return pdfP||(pdfP=import(base+'lib/pdfjs/pdf.min.mjs').then(m=>{m.GlobalWorkerOptions.workerSrc=base+'lib/pdfjs/pdf.worker.min.mjs';return m;}).catch(e=>{pdfP=null;throw new Error('Pustaka PDF gagal dimuat'+(e&&e.message?' ('+e.message+')':''));}));
 }

 /* ---------- Util umum ---------- */
 function parseRange(s,max){
  s=String(s||'').trim();if(!s)return [...Array(max).keys()];
  const set=new Set();
  for(const part of s.split(/[,;\s]+/).filter(Boolean)){
   const m=/^(\d+)(?:-(\d+))?$/.exec(part);if(!m)throw new Error('Rentang tidak valid: "'+part+'". Contoh: 1-3,5');
   let a=+m[1],b=m[2]?+m[2]:a;if(a>b)[a,b]=[b,a];
   for(let i=Math.max(1,a);i<=Math.min(max,b);i++)set.add(i-1);
  }
  if(!set.size)throw new Error('Rentang di luar jumlah halaman (1-'+max+').');
  return [...set].sort((x,y)=>x-y);
 }
 const hex2=n=>Math.max(0,Math.min(255,Math.round(n))).toString(16).padStart(2,'0');
 function lum(h){const m=/^#?([0-9a-f]{6})$/i.exec(h||'');if(!m)return 1;const n=parseInt(m[1],16);return(.299*(n>>16)+.587*((n>>8)&255)+.114*(n&255))/255;}
 function rgb2hsl(r,g,b){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b);let h=0,s=0;const l=(mx+mn)/2;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h/=6;}return[h,s,l];}
 function hsl2rgb(h,s,l){if(!s){const v=l*255;return[v,v,v];}const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q,f=t=>{t=(t+1)%1;return t<1/6?p+(q-p)*6*t:t<.5?q:t<2/3?p+(q-p)*(2/3-t)*6:p;};return[f(h+1/3)*255,f(h)*255,f(h-1/3)*255];}
 function adjustLum(hex,mod,off){const n=parseInt(hex.slice(1),16);const[h,s,l]=rgb2hsl(n>>16,(n>>8)&255,n&255);const nl=Math.max(0,Math.min(1,l*mod+off)),c=hsl2rgb(h,s,nl);return'#'+hex2(c[0])+hex2(c[1])+hex2(c[2]);}
 function canvasToUrl(cv,png){try{return cv.toDataURL(png?'image/png':'image/jpeg',.8);}catch(_){return null;}}

 function imgLoader(zip,o){
  const imgCache={};
  return async function imgData(path){
   if(!o.images||!path)return null;if(path in imgCache)return imgCache[path];
   imgCache[path]=null;const f=zip.file(path);if(!f)return null;
   const ext=(path.split('.').pop()||'').toLowerCase();const mime={png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',bmp:'image/bmp',svg:'image/svg+xml'}[ext];if(!mime){o.warn.imgFmt++;return null;}
   try{
    const u8=await f.async('uint8array');const url=URL.createObjectURL(new Blob([u8],{type:mime}));
    const im=new Image();await new Promise((ok,no)=>{im.onload=ok;im.onerror=no;im.src=url;});
    const w0=im.naturalWidth||800,h0=im.naturalHeight||600,kk=Math.min(1,(o.maxImg||1000)/Math.max(w0,h0));
    const cv=document.createElement('canvas');cv.width=Math.max(1,Math.round(w0*kk));cv.height=Math.max(1,Math.round(h0*kk));const g=cv.getContext('2d');
    const png=ext==='png'||ext==='svg'||ext==='gif';if(!png){g.fillStyle='#fff';g.fillRect(0,0,cv.width,cv.height);}
    g.drawImage(im,0,0,cv.width,cv.height);URL.revokeObjectURL(url);
    imgCache[path]=canvasToUrl(cv,png&&u8.length<300000)||canvasToUrl(cv,false);
   }catch(_){o.warn.imgFmt++;}
   return imgCache[path];
  };
 }
 /* ============================================================
    PPTX
    ============================================================ */
 const EMU=12700, SW=960, SH=540;
 const kids=(el,n)=>el?[...el.children].filter(c=>c.nodeName===n):[];
 const kid=(el,n)=>kids(el,n)[0]||null;
 const attr=(el,a)=>el?el.getAttribute(a):null;
 const xmlDoc=s=>{if(s==null)return null;const d=new DOMParser().parseFromString(s,'application/xml');return d.getElementsByTagName('parsererror').length?null:d;};
 function resolve(dir,t){if(!t)return'';if(t[0]==='/')return t.slice(1);const out=dir.split('/').filter(Boolean);for(const p of t.split('/')){if(p==='..')out.pop();else if(p&&p!=='.')out.push(p);}return out.join('/');}
 const dirOf=p=>p.slice(0,p.lastIndexOf('/'));

 async function parsePptx(buf,o){
  const JSZip=await needZip();
  let zip;try{zip=await JSZip.loadAsync(buf);}catch(_){throw new Error('File .pptx rusak atau bukan PowerPoint.');}
  const rd=async p=>{const f=zip.file(p);return f?await f.async('string'):null;};
  const rels=async p=>{const d=xmlDoc(await rd(dirOf(p)+'/_rels/'+p.slice(p.lastIndexOf('/')+1)+'.rels'));const m={};if(d)[...d.getElementsByTagName('Relationship')].forEach(r=>{m[r.getAttribute('Id')]={type:r.getAttribute('Type')||'',target:resolve(dirOf(p),r.getAttribute('Target')),ext:r.getAttribute('TargetMode')==='External'};});return m;};
  const pres=xmlDoc(await rd('ppt/presentation.xml'));if(!pres)throw new Error('Bukan file .pptx yang valid (presentation.xml tidak ada).');
  const sz=pres.getElementsByTagName('p:sldSz')[0];const cx=+attr(sz,'cx')||9144000,cy=+attr(sz,'cy')||5143500;
  const k=Math.min(SW/cx,SH/cy),ox=(SW-cx*k)/2,oy=(SH-cy*k)/2;
  const prel=await rels('ppt/presentation.xml');
  const ids=[...pres.getElementsByTagName('p:sldId')].map(e=>prel[e.getAttribute('r:id')]).filter(Boolean).map(r=>r.target);
  /* tema */
  const scheme={};
  try{const th=xmlDoc(await rd('ppt/theme/theme1.xml'));if(th)['dk1','lt1','dk2','lt2','accent1','accent2','accent3','accent4','accent5','accent6','hlink'].forEach(n=>{const e=th.getElementsByTagName('a:'+n)[0];const c=e&&e.firstElementChild;if(c){const v=c.getAttribute('val')||c.getAttribute('lastClr');if(/^[0-9a-f]{6}$/i.test(v||''))scheme[n]='#'+v.toLowerCase();}});}catch(_){}
  Object.assign(scheme,{tx1:scheme.dk1||'#000000',bg1:scheme.lt1||'#ffffff',tx2:scheme.dk2||'#44546a',bg2:scheme.lt2||'#e7e6e6'});
  function color(parent){
   if(!parent)return null;
   const c=[...parent.children].find(x=>/^a:(srgbClr|schemeClr|sysClr|prstClr)$/.test(x.nodeName));if(!c)return null;
   let h=null;
   if(c.nodeName==='a:srgbClr')h='#'+c.getAttribute('val').toLowerCase();
   else if(c.nodeName==='a:schemeClr')h=scheme[c.getAttribute('val')]||null;
   else if(c.nodeName==='a:sysClr')h='#'+(c.getAttribute('lastClr')||'000000').toLowerCase();
   else if(c.nodeName==='a:prstClr')h={black:'#000000',white:'#ffffff',red:'#ff0000',blue:'#0000ff',green:'#008000',yellow:'#ffff00'}[c.getAttribute('val')]||null;
   if(!h||!/^#[0-9a-f]{6}$/.test(h))return null;
   const lm=kid(c,'a:lumMod'),lo=kid(c,'a:lumOff');
   if(lm||lo)h=adjustLum(h,lm?+lm.getAttribute('val')/1e5:1,lo?+lo.getAttribute('val')/1e5:0);
   return h;
  }
  const fillOf=sp=>{const f=kid(sp,'a:solidFill');return f?color(f):null;};
  const imgData=imgLoader(zip,o);
  /* xfrm: langsung, atau dari placeholder tata letak/master */
  const xfrmOf=e=>{if(!e)return null;const x=e.getElementsByTagName('a:xfrm')[0]||kid(e,'p:xfrm');if(!x)return null;const off=kid(x,'a:off'),ext=kid(x,'a:ext');if(!off||!ext)return null;return{x:+off.getAttribute('x'),y:+off.getAttribute('y'),w:+ext.getAttribute('cx'),h:+ext.getAttribute('cy'),rot:+(x.getAttribute('rot')||0)/60000};};
  const phOf=sp=>{const nv=kid(sp,'p:nvSpPr');const pr=nv&&kid(nv,'p:nvPr');const ph=pr&&kid(pr,'p:ph');return ph?{type:ph.getAttribute('type')||'',idx:ph.getAttribute('idx')}:null;};
  const norm=t=>({ctrTitle:'title',title:'title',subTitle:'body',body:'body','':'body',obj:'body'}[t]||t);
  function findPh(doc,ph){
   if(!doc||!ph)return null;const sps=[...doc.getElementsByTagName('p:sp')];
   let m=null;
   if(ph.idx!=null)m=sps.find(s=>{const p=phOf(s);return p&&p.idx===ph.idx&&norm(p.type)===norm(ph.type);})||sps.find(s=>{const p=phOf(s);return p&&p.idx===ph.idx;});
   if(!m)m=sps.find(s=>{const p=phOf(s);return p&&norm(p.type)===norm(ph.type)&&(norm(ph.type)==='title'||p.idx==null||p.idx==='0'||p.idx===ph.idx);});
   return m?xfrmOf(kid(m,'p:spPr')):null;
  }
  const slides=[];
  const want=o.sel||null;
  for(let si=0;si<ids.length;si++){
   if(want&&!want.has(si))continue;
   if(o.abort&&o.abort())throw new Error('Dibatalkan');
   o.progress('Membaca slide '+(si+1)+' dari '+ids.length+'…');await tick();
   const path=ids[si],doc=xmlDoc(await rd(path));if(!doc)continue;
   const sr=await rels(path);
   let layout=null,master=null,notes=null;
   for(const r of Object.values(sr)){if(/\/slideLayout$/.test(r.type))layout=xmlDoc(await rd(r.target));if(/\/notesSlide$/.test(r.type))notes=xmlDoc(await rd(r.target));}
   const lrel=layout?await(async()=>{const lp=Object.values(sr).find(r=>/\/slideLayout$/.test(r.type));return rels(lp.target);})():{};
   for(const r of Object.values(lrel)){if(/\/slideMaster$/.test(r.type))master=xmlDoc(await rd(r.target));}
   /* latar */
   const bgOf=d=>{const bg=d&&d.getElementsByTagName('p:bg')[0];if(!bg)return null;const pr=kid(bg,'p:bgPr');if(pr){const f=kid(pr,'a:solidFill');if(f)return color(f);const gf=kid(pr,'a:gradFill');if(gf){const gs=gf.getElementsByTagName('a:gs')[0];return gs?color(gs):null;}}const rf=kid(bg,'p:bgRef');return rf?color(rf):null;};
   const bg=bgOf(doc)||bgOf(layout)||bgOf(master)||'#ffffff';
   const S={bg,shapes:[],title:'',notes:''};
   const tree=doc.getElementsByTagName('p:spTree')[0];
   const textOf=tx=>{
    const paras=[];if(!tx)return paras;
    for(const p of kids(tx,'a:p')){
     const pr=kid(p,'a:pPr');const lvl=+(attr(pr,'lvl')||0);const al=attr(pr,'algn')||'';
     let bullet=null;if(pr){if(kid(pr,'a:buChar'))bullet='dot';else if(kid(pr,'a:buAutoNum'))bullet='num';else if(kid(pr,'a:buNone'))bullet='none';}
     const runs=[];
     for(const r of p.children){
      if(r.nodeName==='a:br'){runs.push({t:'\n'});continue;}
      if(r.nodeName!=='a:r'&&r.nodeName!=='a:fld')continue;
      const t=kid(r,'a:t');if(!t)continue;const rp=kid(r,'a:rPr');
      runs.push({t:t.textContent,b:attr(rp,'b')==='1',i:attr(rp,'i')==='1',u:!!rp&&attr(rp,'u')&&attr(rp,'u')!=='none',sz:rp&&attr(rp,'sz')?+attr(rp,'sz')/100:0,color:rp?fillOf(rp):null});
     }
     paras.push({runs,al,lvl,bullet});
    }
    return paras;
   };
   const plain=paras=>paras.map(p=>p.runs.map(r=>r.t).join('')).join('\n');
   function pushShape(el,tf,kind){
    const spPr=kid(el,'p:spPr');let x=xfrmOf(spPr);const ph=kind==='sp'?phOf(el):null;
    if(!x&&ph)x=findPh(layout,ph)||findPh(master,ph);
    if(!x&&kind==='gf')x=xfrmOf(el);
    if(!x)x={x:0,y:0,w:cx*.6,h:cy*.2,rot:0};
    const px=ox+(tf.tx+tf.sx*x.x)*k,py=oy+(tf.ty+tf.sy*x.y)*k,pw=x.w*tf.sx*k,pheight=x.h*tf.sy*k;
    return{x:px,y:py,w:pw,h:pheight,rot:x.rot,ph};
   }
   async function walk(parent,tf){
    for(const el of parent.children){
     const n=el.nodeName;
     if(n==='mc:AlternateContent'){const ch=el.getElementsByTagName('mc:Choice')[0];if(ch)await walk(ch,tf);continue;}
     if(n==='p:grpSp'){
      const gp=kid(el,'p:grpSpPr'),xf=gp&&kid(gp,'a:xfrm');
      if(xf){const off=kid(xf,'a:off'),ext=kid(xf,'a:ext'),co=kid(xf,'a:chOff'),ce=kid(xf,'a:chExt');
       if(off&&ext&&co&&ce&&+ce.getAttribute('cx')&&+ce.getAttribute('cy')){const gx=+ext.getAttribute('cx')/+ce.getAttribute('cx'),gy=+ext.getAttribute('cy')/+ce.getAttribute('cy');
        await walk(el,{sx:tf.sx*gx,sy:tf.sy*gy,tx:tf.tx+tf.sx*(+off.getAttribute('x')-+co.getAttribute('x')*gx),ty:tf.ty+tf.sy*(+off.getAttribute('y')-+co.getAttribute('y')*gy)});continue;}}
      await walk(el,tf);continue;
     }
     if(n==='p:sp'){
      const g=pushShape(el,tf,'sp'),spPr=kid(el,'p:spPr'),paras=textOf(kid(el,'p:txBody'));
      const fill=fillOf(spPr);const geomEl=spPr&&kid(spPr,'a:prstGeom'),geom=attr(geomEl,'prst')||'rect';
      const ln=spPr&&kid(spPr,'a:ln'),lnc=ln?fillOf(ln):null;
      const bp=kid(kid(el,'p:txBody'),'a:bodyPr'),af=bp&&kid(bp,'a:normAutofit'),fs=af&&attr(af,'fontScale')?+attr(af,'fontScale')/1e5:1;
      const hasText=paras.some(p=>p.runs.some(r=>r.t.trim()));
      if(!hasText&&!fill&&!lnc)continue;
      if(g.ph&&/^(title|ctrTitle)$/.test(g.ph.type)&&hasText&&!S.title)S.title=plain(paras).replace(/\s+/g,' ').trim();
      S.shapes.push({kind:'text',...g,paras:hasText?paras:[],fill,geom,ln:lnc,fs,anchor:attr(bp,'anchor')||''});
      continue;
     }
     if(n==='p:cxnSp'){
      const spPr=kid(el,'p:spPr'),g=pushShape(el,tf,'sp'),ln=spPr&&kid(spPr,'a:ln'),c=(ln&&fillOf(ln))||'#7f7f7f';
      S.shapes.push({kind:'line',...g,fill:c,w:Math.max(g.w,2),h:Math.max(g.h,2)});continue;
     }
     if(n==='p:pic'){
      const g=pushShape(el,tf,'sp'),bl=el.getElementsByTagName('a:blip')[0],id=bl&&bl.getAttribute('r:embed'),r=id&&sr[id];
      const d=r?await imgData(r.target):null;
      if(d)S.shapes.push({kind:'img',...g,img:d});else if(o.images)o.warn.imgSkip++;
      continue;
     }
     if(n==='p:graphicFrame'){
      const gd=el.getElementsByTagName('a:graphicData')[0],uri=attr(gd,'uri')||'';
      const g=pushShape(el,tf,'gf');
      const tbl=el.getElementsByTagName('a:tbl')[0];
      if(tbl){
       const rows=kids(tbl,'a:tr').map(tr=>kids(tr,'a:tc').map(tc=>plain(textOf(kid(tc,'a:txBody'))).trim()));
       const w=Math.max(0,...rows.map(r=>r.length));rows.forEach(r=>{while(r.length<w)r.push('');});
       const fs0=tbl.getElementsByTagName('a:rPr')[0],fsz=fs0&&attr(fs0,'sz')?+attr(fs0,'sz')/100*EMU*k:0;
       if(rows.length&&w)S.shapes.push({kind:'tbl',...g,rows,fsz});
      }else if(/chart/.test(uri))o.warn.chart++;else o.warn.other++;
      continue;
     }
    }
   }
   if(tree)await walk(tree,{sx:1,sy:1,tx:0,ty:0});
   if(notes){const sps=[...notes.getElementsByTagName('p:sp')].filter(s=>{const p=phOf(s);return p&&p.type==='body';});S.notes=sps.map(s=>plain(textOf(kid(s,'p:txBody')))).join('\n').trim().slice(0,1800);}
   if(!S.title){const t=S.shapes.find(s=>s.kind==='text'&&s.paras.length);if(t){const pt=plain(t.paras).trim();S.title=pt.split('\n')[0].trim().slice(0,100);if(t.paras.length===1)S.titleShape=t;}}
   slides.push(S);
  }
  return{total:ids.length,slides,k};
 }

 /* PPTX -> HTML slide PowerPoint (objek terposisi) */
 function runHtml(r,k0,defPx,fs){
  if(r.t==='\n')return'<br>';
  const st=[];const px=r.sz?r.sz*EMU*k0*fs:defPx*fs;st.push('font-size:'+Math.max(8,Math.round(px))+'px');
  if(r.b)st.push('font-weight:700');if(r.i)st.push('font-style:italic');if(r.u)st.push('text-decoration:underline');if(r.color)st.push('color:'+r.color);
  return'<span style="'+st.join(';')+'">'+esc(r.t)+'</span>';
 }
 function parasHtml(paras,k0,defPx,fs,bulletBody){
  let h='',cur=null;
  const close=()=>{if(cur){h+='</'+cur+'>';cur=null;}};
  for(const p of paras){
   const txt=p.runs.map(r=>r.t).join('');const al=({ctr:'center',r:'right',just:'justify'}[p.al])||'left';
   const isBullet=p.bullet==='dot'||p.bullet==='num'||(bulletBody&&p.bullet!=='none');
   const inner=p.runs.length?p.runs.map(r=>runHtml(r,k0,defPx,fs)).join(''):'<br>';
   if(isBullet&&txt.trim()){const tag=p.bullet==='num'?'ol':'ul';if(cur!==tag){close();h+='<'+tag+' style="margin:0;padding-left:'+Math.round(defPx*1.1)+'px">';cur=tag;}h+='<li style="text-align:'+al+(p.lvl?';margin-left:'+p.lvl*22+'px':'')+'">'+inner+'</li>';}
   else{close();h+='<div style="text-align:'+al+(p.lvl?';margin-left:'+p.lvl*22+'px':'')+'">'+inner+'</div>';}
  }
  close();return h;
 }
 function pptxSlideToPpt(S,k0){
  const dark=lum(S.bg)<.45,fg=dark?'#ffffff':'#1f2430';let html='';
  for(const s of S.shapes){
   let st='left:'+Math.round(s.x)+'px;top:'+Math.round(s.y)+'px;width:'+Math.max(10,Math.round(s.w))+'px';
   if(s.rot)st+=';transform:rotate('+Math.round(s.rot)+'deg)';
   if(s.kind==='img'){html+='<div class="ppt-obj" style="'+st+'">'+HANDLE+'<img alt="Gambar" src="'+s.img+'" style="width:100%;height:auto"></div>';continue;}
   if(s.kind==='line'){html+='<div class="ppt-obj" data-shape="line" style="left:'+Math.round(s.x)+'px;top:'+Math.round(s.y)+'px;width:'+Math.round(s.w)+'px;height:'+Math.round(s.h)+'px;background:'+s.fill+'"></div>';continue;}
   if(s.kind==='tbl'){
    const n=s.rows.length,fz=Math.round(s.fsz||(n>10?13:n>6?16:20));
    html+='<div class="ppt-obj" data-table="1" style="'+st+'">'+HANDLE+'<table class="ppt-tbl" style="font-size:'+Math.max(9,fz)+'px"><tbody>'+s.rows.map(r=>'<tr>'+r.map(c=>'<td contenteditable="true">'+esc(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';continue;
   }
   /* teks / bentuk */
   const title=s.ph&&/^(title|ctrTitle)$/.test(s.ph.type),sub=s.ph&&s.ph.type==='subTitle',bodyPh=s.ph&&!title&&!sub;
   const defPx=title?40:sub?26:bodyPh?24:18;
   if(s.fill){st+=';background:'+s.fill;if(s.geom==='ellipse')st+=';border-radius:50%';else if(/round/i.test(s.geom))st+=';border-radius:24px';st+=';min-height:'+Math.max(6,Math.round(s.h))+'px';}
   if(s.ln&&s.fill)st+=';border:2px solid '+s.ln;
   const attrs=s.fill&&!s.paras.length?' data-shape="rect"':'';
   if(!s.paras.length){html+='<div class="ppt-obj"'+attrs+' style="'+st+'">'+HANDLE+'</div>';continue;}
   const bold=title?'font-weight:700;':'';
   html+='<div class="ppt-obj" style="'+st+'">'+HANDLE+'<div class="ppt-ot" contenteditable="true" style="'+bold+'line-height:1.2;padding:2px 6px">'+parasHtml(s.paras,k0,defPx,s.fs||1,bodyPh&&!/^subTitle$/.test(s.ph.type))+'</div></div>';
  }
  return{html,bg:S.bg,fg,notes:S.notes};
 }
 /* PPTX -> HTML Word */
 function pptxSlideToWord(S,n,k0,withImg){
  let h='<h2>Slide '+n+(S.title?': '+esc(S.title):'')+'</h2>';
  const items=S.shapes.filter(s=>s.kind==='text'&&s.paras.length||s.kind==='img'&&withImg||s.kind==='tbl');
  items.sort((a,b)=>(a.ph&&/title/i.test(a.ph.type)?-1:0)-(b.ph&&/title/i.test(b.ph.type)?-1:0));
  let titleSkipped=false;
  for(const s of items){
   if(s.kind==='img'){h+='<p><img alt="Gambar slide '+n+'" src="'+s.img+'" style="max-width:'+Math.min(100,Math.max(25,Math.round(s.w/SW*100)))+'%"></p>';continue;}
   if(s.kind==='tbl'){h+='<table style="border-collapse:collapse;width:100%"><tbody>'+s.rows.map((r,i)=>'<tr>'+r.map(c=>'<td style="border:1px solid #888;padding:4px 8px'+(i===0?';font-weight:700;background:#eef2f8':'')+'">'+esc(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table><p><br></p>';continue;}
   const isTitle=(s.ph&&/^(title|ctrTitle)$/.test(s.ph.type))||s===S.titleShape;
   if(isTitle&&!titleSkipped){titleSkipped=true;continue;}
   let cur=null;
   const close=()=>{if(cur){h+='</'+cur+'>';cur=null;}};
   for(const p of s.paras){
    const txt=p.runs.map(r=>r.t).join('').trim();if(!txt)continue;
    const inner=p.runs.map(r=>{if(r.t==='\n')return'<br>';let t=esc(r.t);if(r.b)t='<b>'+t+'</b>';if(r.i)t='<i>'+t+'</i>';if(r.u)t='<u>'+t+'</u>';return t;}).join('');
    const bullet=p.bullet==='dot'||p.bullet==='num'||(s.ph&&s.ph.type!=='subTitle'&&!isTitle&&p.bullet!=='none'&&s.ph.type!=='');
    if(bullet){const tag=p.bullet==='num'?'ol':'ul';if(cur!==tag){close();h+='<'+tag+'>';cur=tag;}h+='<li>'+inner+'</li>';}
    else{close();h+='<p>'+inner+'</p>';}
   }
   close();
  }
  if(S.notes)h+='<blockquote><b>Catatan:</b> '+esc(S.notes).replace(/\n/g,'<br>')+'</blockquote>';
  return h;
 }
 /* PPTX -> baris Excel */
 function pptxToSheets(P,sel){
  const rows=[['No','Judul','Isi','Catatan']],tables=[];
  P.slides.forEach(S=>{
   const n=S.no;
   const body=[];
   S.shapes.forEach(s=>{if(s.kind==='text'&&s.paras.length){const isT=(s.ph&&/^(title|ctrTitle)$/.test(s.ph.type))||s===S.titleShape;if(isT)return;s.paras.forEach(p=>{const t=p.runs.map(r=>r.t==='\n'?' ':r.t).join('').trim();if(t)body.push(t);});}if(s.kind==='tbl')tables.push({n,rows:s.rows});});
   rows.push([String(n),S.title||'',body.join(' • '),S.notes?S.notes.replace(/\s*\n\s*/g,' '):'']);
  });
  const out=[{name:'Slide PPT',rows,widths:{1:50,2:220,3:460,4:260}}];
  tables.forEach(t=>out.push({name:'Tabel S'+t.n,rows:t.rows}));
  return out;
 }

 /* ============================================================
    PDF
    ============================================================ */
 async function openPdf(buf,o){
  const lib=await needPdf();
  let doc;
  try{doc=await lib.getDocument({data:new Uint8Array(buf),isEvalSupported:false,useSystemFonts:true}).promise;}
  catch(e){const nm=e&&e.name||'';if(/Password/i.test(nm))throw new Error('PDF terkunci kata sandi. Buka kuncinya dulu lalu coba lagi.');throw new Error('PDF tidak bisa dibaca (rusak atau bukan PDF).');}
  return doc;
 }
 async function pageLines(page){
  const tc=await page.getTextContent();
  const it=[];
  for(const t of tc.items){if(typeof t.str!=='string'||!t.str.trim()&&!t.hasEOL)continue;if(!t.str.trim())continue;const tr=t.transform,h=Math.hypot(tr[2],tr[3])||t.height||10;it.push({s:t.str,x:tr[4],y:tr[5],h,w:t.width||0});}
  it.sort((a,b)=>b.y-a.y||a.x-b.x);
  const lines=[];
  for(const e of it){
   const L=lines[lines.length-1];
   if(L&&Math.abs(e.y-L.y)<=Math.max(2,.45*Math.min(e.h,L.h))){L.items.push(e);L.h=Math.max(L.h,e.h);}
   else lines.push({y:e.y,h:e.h,items:[e]});
  }
  for(const L of lines){
   L.items.sort((a,b)=>a.x-b.x);
   let txt='',prevEnd=null,cells=[],cur=null;
   for(const e of L.items){
    const gap=prevEnd==null?0:e.x-prevEnd;
    if(cur&&gap>1.4*L.h){cells.push(cur);cur=null;}
    if(!cur)cur={x:e.x,t:''};
    if(prevEnd!=null&&gap>.12*L.h&&!/\s$/.test(cur.t)&&!/^\s/.test(e.s))cur.t+=' ';
    cur.t+=e.s;
    if(prevEnd!=null&&gap>.12*L.h&&!/\s$/.test(txt)&&!/^\s/.test(e.s))txt+=' ';
    txt+=e.s;
    prevEnd=e.x+e.w;
   }
   if(cur)cells.push(cur);
   L.text=txt.replace(/\s+/g,' ').trim();L.x=L.items[0].x;L.x1=Math.max(...L.items.map(e=>e.x+e.w));L.cells=cells.map(c=>({x:c.x,t:c.t.replace(/\s+/g,' ').trim()})).filter(c=>c.t);
  }
  return lines.filter(l=>l.text);
 }
 function median(a){if(!a.length)return 10;const b=[...a].sort((x,y)=>x-y);return b[b.length>>1];}
 /* baris -> paragraf/judul/daftar/tabel */
 function linesToBlocks(lines,bodyH){
  const blocks=[];let cur=null,tbl=null;
  const flush=()=>{if(cur){blocks.push(cur);cur=null;}};
  const flushT=()=>{if(!tbl)return;if(tbl.rows.length>=2)blocks.push({t:'table',rows:tbl.rows});else tbl.rows.forEach(r=>blocks.push({t:'p',text:r.join(' ')}));tbl=null;};
  const Lm=lines.length?Math.min(...lines.map(l=>l.x)):0,R=lines.length?Math.max(...lines.map(l=>l.x1||0)):0;
  let prev=null;
  for(const L of lines){
   const ratio=L.h/bodyH;
   if(L.cells.length>=2&&ratio<1.2){flush();if(!tbl)tbl={rows:[]};tbl.rows.push(L.cells.map(c=>c.t));prev=L;continue;}
   flushT();
   const bullet=/^([•●▪■◦·\-–—*]|\d{1,3}[.)])\s+/.test(L.text);
   if(ratio>=1.2&&L.text.length<=110){flush();blocks.push({t:ratio>=1.7?'h1':ratio>=1.4?'h2':'h3',text:L.text});prev=L;continue;}
   if(bullet){flush();const num=/^\d/.test(L.text);cur={t:'li',num,text:L.text.replace(/^([•●▪■◦·\-–—*]|\d{1,3}[.)])\s+/,'')};prev=L;continue;}
   const gap=prev?prev.y-L.y:0;
   const ended=prev&&prev.x1!=null&&R>Lm&&prev.x1<Lm+.75*(R-Lm);   /* baris sebelumnya pendek = paragraf selesai */
   if(cur&&cur.t==='p'&&!ended&&gap<=1.7*Math.max(L.h,prev.h)&&Math.abs(L.x-prev.x)<3*bodyH+20){if(/[a-z][-‐]$/.test(cur.text)&&/^[a-z]/.test(L.text))cur.text=cur.text.slice(0,-1)+L.text;else cur.text+=' '+L.text;}
   else if(cur&&cur.t==='li'&&!ended&&gap<=1.7*Math.max(L.h,prev.h)&&L.x>prev.x-2){cur.text+=' '+L.text;}
   else{flush();cur={t:'p',text:L.text};}
   prev=L;
  }
  flush();flushT();return blocks;
 }
 function blocksToHtml(bl){
  let h='',cur=null;const close=()=>{if(cur){h+='</'+cur+'>';cur=null;}};
  for(const b of bl){
   if(b.t==='li'){const tag=b.num?'ol':'ul';if(cur!==tag){close();h+='<'+tag+'>';cur=tag;}h+='<li>'+(b.html||esc(b.text))+'</li>';continue;}
   close();
   if(b.t==='img'){h+='<p><img alt="Gambar" src="'+b.src+'" style="max-width:100%"></p>';continue;}
   if(b.t==='table'){h+='<table style="border-collapse:collapse;width:100%"><tbody>'+b.rows.map((r,i)=>'<tr>'+r.map(c=>'<td style="border:1px solid #888;padding:4px 8px'+(i===0?';font-weight:700;background:#eef2f8':'')+'">'+esc(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table><p><br></p>';continue;}
   h+='<'+b.t+'>'+(b.html||esc(b.text).replace(/\n/g,'<br>'))+'</'+b.t+'>';
  }
  close();return h;
 }
 async function renderPage(page,maxW,maxH,q){
  const v0=page.getViewport({scale:1});const sc=Math.min(maxW/v0.width,maxH/v0.height);
  const vp=page.getViewport({scale:sc});
  const cv=document.createElement('canvas');cv.width=Math.max(1,Math.round(vp.width));cv.height=Math.max(1,Math.round(vp.height));
  const g=cv.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,cv.width,cv.height);
  await page.render({canvasContext:g,canvas:cv,viewport:vp}).promise;
  const url=cv.toDataURL('image/jpeg',q||.62);cv.width=cv.height=1;
  return{url,w:vp.width,h:vp.height};
 }
 /* kolom Excel dari posisi x */
 function linesToRows(lines){
  const xs=[];lines.forEach(L=>{if(L.cells.length>=2)L.cells.forEach(c=>xs.push(c.x));});
  const x0=lines.length?Math.min(...lines.map(l=>l.x)):0;xs.push(x0);xs.sort((a,b)=>a-b);
  const anchors=[];xs.forEach(x=>{const A=anchors[anchors.length-1];if(A!=null&&x-A<18)return;anchors.push(x);});
  const useAnch=anchors.length<=26;
  return lines.map(L=>{
   const row=[];let last=-1;
   L.cells.forEach((c,i)=>{
    let col;
    if(useAnch){let best=0,bd=1e9;anchors.forEach((a,j)=>{const d=Math.abs(a-c.x);if(d<bd){bd=d;best=j;}});if(L.cells.length<2&&bd>18)best=0;col=Math.max(best,last+1);}else col=i;
    if(col>25)col=25;row[col]=(row[col]?row[col]+' ':'')+c.t;last=col;
   });
   return[...row].map(v=>v==null?'':v);
  });
 }


 /* ============================================================
    DOCX / XLSX
    ============================================================ */
 const wOn=(rp,n)=>{const e=rp&&kid(rp,n);return !!e&&!/^(0|false|none)$/i.test(e.getAttribute('w:val')||'');};
 async function parseDocx(buf,o){
  const JSZip=await needZip();let zip;try{zip=await JSZip.loadAsync(buf);}catch(_){throw new Error('File .docx rusak.');}
  const rd=async p=>{const f=zip.file(p);return f?await f.async('string'):null;};
  const doc=xmlDoc(await rd('word/document.xml'));if(!doc)throw new Error('Bukan file .docx yang valid.');
  const rel={};const rr=xmlDoc(await rd('word/_rels/document.xml.rels'));if(rr)[...rr.getElementsByTagName('Relationship')].forEach(r=>{rel[r.getAttribute('Id')]=resolve('word',r.getAttribute('Target'));});
  const sname={};const st=xmlDoc(await rd('word/styles.xml'));if(st)[...st.getElementsByTagName('w:style')].forEach(x=>{const n=kid(x,'w:name');sname[x.getAttribute('w:styleId')]=((n&&n.getAttribute('w:val'))||'').toLowerCase();});
  const numFmt={};const nm=xmlDoc(await rd('word/numbering.xml'));
  if(nm){const abs={};[...nm.getElementsByTagName('w:abstractNum')].forEach(a=>{const l=kids(a,'w:lvl')[0],f=l&&kid(l,'w:numFmt');abs[a.getAttribute('w:abstractNumId')]=f?f.getAttribute('w:val'):'bullet';});[...nm.getElementsByTagName('w:num')].forEach(n=>{const a=kid(n,'w:abstractNumId');numFmt[n.getAttribute('w:numId')]=a?abs[a.getAttribute('w:val')]:'bullet';});}
  const imgData=imgLoader(zip,o);
  const runs=p=>[...p.getElementsByTagName('w:r')];
  const ptext=p=>runs(p).map(r=>[...r.children].map(c=>c.nodeName==='w:t'?c.textContent:(c.nodeName==='w:tab'||c.nodeName==='w:br')?' ':'').join('')).join('').replace(/\s+/g,' ').trim();
  const blocks=[];const body=doc.getElementsByTagName('w:body')[0];
  if(!body)throw new Error('Dokumen kosong.');
  let n=0;
  for(const el of body.children){
   if(o.abort&&o.abort())throw new Error('Dibatalkan');
   if(++n%200===0){o.progress('Membaca dokumen… ('+n+' bagian)');await tick();}
   if(el.nodeName==='w:tbl'){
    const rows=kids(el,'w:tr').map(tr=>kids(tr,'w:tc').map(tc=>kids(tc,'w:p').map(ptext).filter(Boolean).join(' ')));
    const w=Math.max(0,...rows.map(r=>r.length));rows.forEach(r=>{while(r.length<w)r.push('');});
    if(rows.length&&w)blocks.push({t:'table',rows});continue;
   }
   if(el.nodeName!=='w:p')continue;
   const ppr=kid(el,'w:pPr'),sid=attr(ppr&&kid(ppr,'w:pStyle'),'w:val'),name=sname[sid]||(sid||'').toLowerCase();
   let t='p',num=false;const m=/^(heading|judul)\s*([1-9])/.exec(name.replace(/([a-z])(\d)/,'$1 $2'));
   if(m)t='h'+Math.min(3,+m[2]);else if(/^(title|subtitle)$|^judul$/.test(name))t='h1';
   const np=ppr&&kid(ppr,'w:numPr');if(np&&t==='p'){const id=attr(kid(np,'w:numId'),'w:val');if(id&&id!=='0'){t='li';num=/decimal|roman|letter/i.test(numFmt[id]||'');}}
   let html='';
   for(const r of runs(el)){
    const rp=kid(r,'w:rPr');
    let tx=[...r.children].map(c=>c.nodeName==='w:t'?esc(c.textContent):c.nodeName==='w:tab'?'&nbsp;&nbsp;&nbsp;&nbsp;':c.nodeName==='w:br'?'<br>':'').join('');
    if(!tx)continue;
    if(t==='p'||t==='li'){if(wOn(rp,'w:b'))tx='<b>'+tx+'</b>';if(wOn(rp,'w:i'))tx='<i>'+tx+'</i>';if(wOn(rp,'w:u'))tx='<u>'+tx+'</u>';}
    html+=tx;
   }
   const text=ptext(el);
   if(text)blocks.push({t,num,text,html});
   if(o.images)for(const bl of el.getElementsByTagName('a:blip')){const id=bl.getAttribute('r:embed'),d=id&&rel[id]?await imgData(rel[id]):null;if(d)blocks.push({t:'img',src:d});}
  }
  return{blocks};
 }
 const DATEFMT=new Set([14,15,16,17,18,19,20,21,22,27,28,29,30,31,32,33,34,35,36,45,46,47,50,51,52,53,54,55,56,57,58]);
 const serial=v=>{const ms=Math.round((+v-25569)*864e5),d=new Date(ms);if(isNaN(d))return String(v);const p=n=>String(n).padStart(2,'0'),day=d.getUTCFullYear()+'-'+p(d.getUTCMonth()+1)+'-'+p(d.getUTCDate());return(+v%1)?day+' '+p(d.getUTCHours())+':'+p(d.getUTCMinutes()):day;};
 async function parseXlsx(buf,o){
  const JSZip=await needZip();let zip;try{zip=await JSZip.loadAsync(buf);}catch(_){throw new Error('File .xlsx rusak.');}
  const rd=async p=>{const f=zip.file(p);return f?await f.async('string'):null;};
  const wb=xmlDoc(await rd('xl/workbook.xml'));if(!wb)throw new Error('Bukan file .xlsx yang valid.');
  const rel={};const rr=xmlDoc(await rd('xl/_rels/workbook.xml.rels'));if(rr)[...rr.getElementsByTagName('Relationship')].forEach(r=>{rel[r.getAttribute('Id')]=resolve('xl',r.getAttribute('Target'));});
  const sheets=[...wb.getElementsByTagName('sheet')].map(x=>({name:x.getAttribute('name')||'Lembar',path:rel[x.getAttribute('r:id')]})).filter(x=>x.path);
  const ss=[];const sst=xmlDoc(await rd('xl/sharedStrings.xml'));
  if(sst)[...sst.getElementsByTagName('si')].forEach(si=>ss.push([...si.getElementsByTagName('t')].filter(t=>t.parentNode.nodeName!=='rPh').map(t=>t.textContent).join('')));
  /* format tanggal */
  const isDate=[];const sty=xmlDoc(await rd('xl/styles.xml'));
  if(sty){const custom={};[...sty.getElementsByTagName('numFmt')].forEach(f=>{custom[f.getAttribute('numFmtId')]=f.getAttribute('formatCode')||'';});
   const cx=sty.getElementsByTagName('cellXfs')[0];if(cx)kids(cx,'xf').forEach((x,i)=>{const id=+x.getAttribute('numFmtId');isDate[i]=DATEFMT.has(id)||(custom[id]!=null&&/[ymd]/i.test(custom[id].replace(/"[^"]*"|\[[^\]]*\]|\\./g,''))&&!/0\.0|#/.test(custom[id]));});}
  const colIdx=r=>{let c=0;for(const ch of r)c=c*26+ch.charCodeAt(0)-64;return c;};
  const want=o.sel||null,out=[];let formulas=0;
  for(let si=0;si<sheets.length;si++){
   if(want&&!want.has(si))continue;
   if(o.abort&&o.abort())throw new Error('Dibatalkan');
   o.progress('Membaca lembar '+(si+1)+' dari '+sheets.length+'…');await tick();
   const d=xmlDoc(await rd(sheets[si].path));if(!d)continue;
   const rows=[];
   for(const c of d.getElementsByTagName('c')){
    const m=/^([A-Z]+)(\d+)$/.exec(c.getAttribute('r')||'');if(!m)continue;
    const ci=colIdx(m[1]),ri=+m[2];if(ri>300||ci>60)continue;
    const t=c.getAttribute('t'),v=kid(c,'v'),f=kid(c,'f');if(f)formulas++;
    let val='';
    if(t==='s')val=ss[+(v&&v.textContent)]||'';
    else if(t==='inlineStr')val=[...c.getElementsByTagName('t')].map(x=>x.textContent).join('');
    else if(t==='b')val=v&&v.textContent==='1'?'TRUE':'FALSE';
    else if(v){const raw=v.textContent;if(t==='str'||t==='e')val=raw;else{val=isDate[+c.getAttribute('s')||0]&&isFinite(raw)?serial(raw):String(+(+raw).toPrecision(12));}}
    if(val==='')continue;
    (rows[ri-1]=rows[ri-1]||[])[ci-1]=val;
   }
   const dense=[];for(let i=0;i<rows.length;i++)dense.push([...(rows[i]||[])].map(x=>x==null?'':x));
   out.push({name:sheets[si].name,rows:dense,no:si+1});
  }
  return{sheets:out,total:sheets.length,formulas};
 }
 const tableHtml=rows=>'<table style="border-collapse:collapse;width:100%"><tbody>'+rows.map((r,i)=>'<tr>'+r.map(c=>'<td style="border:1px solid #888;padding:4px 8px'+(i===0?';font-weight:700;background:#eef2f8':'')+'">'+esc(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table><p><br></p>';
 /* blok teks (PDF/DOCX) -> slide PowerPoint teks */
 function blocksToSlides(bl,ttl,note){
  bl=bl.filter(b=>b.t!=='img');const slides=[];
  const len=b=>(b.t==='table'?b.rows.reduce((a,r)=>a+r.join(' | ').length,0):b.text.length);
  const groups=[];let g=[],n=0;
  bl.forEach(b=>{const l=len(b)+20;if(g.length&&n+l>900){groups.push(g);g=[];n=0;}g.push(b);n+=l;});
  if(g.length||!groups.length)groups.push(g);
  groups.forEach((gr,gi)=>{
   const body=gr.reduce((a,b)=>a+len(b),0),px=body<=350?28:body<=650?23:body<=900?19:16;
   const html='<div class="ppt-ph ppt-t2" contenteditable="true" data-ph="Judul slide">'+esc(ttl+(gi?' (lanjutan)':''))+'</div><div class="ppt-ph ppt-body" contenteditable="true" data-ph="Tulis isi di sini" style="font-size:'+px+'px">'+blocksToHtml(gr.map(b=>b.t==='table'?{t:'p',text:b.rows.map(r=>r.join(' | ')).join('\n')}:/^h/.test(b.t)?{t:'p',text:b.text}:b))+'</div>';
   slides.push({bg:'#ffffff',fg:'#1f2430',notes:note||'',html});
  });
  return slides;
 }
 function tableSlides(title,rows,note){
  const W=Math.min(8,Math.max(0,...rows.map(r=>r.length))),slides=[],per=11;if(!W)return slides;
  const head=rows[0]||[];
  for(let i=0;i<Math.max(1,rows.length);i+=per){
   const part=rows.slice(i,i+per);const chunk=i?[head].concat(part):part;
   const fz=chunk.length>8?15:18;
   const t='<table class="ppt-tbl" style="font-size:'+fz+'px"><tbody>'+chunk.map(r=>'<tr>'+Array.from({length:W},(_,j)=>'<td contenteditable="true">'+esc(r[j]||'')+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
   slides.push({bg:'#ffffff',fg:'#1f2430',notes:note||'',html:'<div class="ppt-ph ppt-t2" contenteditable="true" data-ph="Judul slide">'+esc(title+(i?' (lanjutan)':''))+'</div><div class="ppt-obj" data-table="1" style="left:40px;top:120px;width:880px">'+HANDLE+t+'</div>'});
  }
  return slides;
 }
 /* ============================================================
    Konversi per target
    ============================================================ */
 const TARGET={
  excel:{name:'Excel',hook:()=>window.CDMS_OFFICE&&window.CDMS_OFFICE.excel},
  word:{name:'Word',hook:()=>window.CDMS_OFFICE&&window.CDMS_OFFICE.word},
  ppt:{name:'PowerPoint',hook:()=>window.CDMS_OFFICE&&window.CDMS_OFFICE.ppt}
 };
 function modesFor(target,kind){
  if(kind==='docx'){if(target==='word')return[['gambar','Teks + gambar'],['teks','Teks saja']];if(target==='excel')return[['teks','Paragraf per baris + tabel jadi lembar']];return[['teks','Slide teks per judul (tabel jadi teks)']];}
  if(kind==='xlsx'){if(target==='excel')return[['teks','Lembar dan nilai sel (rumus jadi nilai)']];if(target==='word')return[['teks','Tabel per lembar']];return[['teks','Slide tabel per lembar']];}
  if(kind==='pptx'){
   if(target==='excel')return[['teks','Daftar slide (No, Judul, Isi, Catatan) + tabel']];
   if(target==='word')return[['gambar','Teks + gambar (jadi dokumen)'],['teks','Teks saja']];
   return[['gambar','Slide dengan gambar'],['teks','Slide tanpa gambar (lebih ringan)']];
  }
  if(target==='excel')return[['tabel','Tabel dari teks halaman (kolom dideteksi)']];
  if(target==='word')return[['teks','Teks yang bisa diedit'],['gambar','Gambar halaman (tampilan persis)']];
  return[['gambar','Gambar halaman (tampilan persis)'],['teks','Teks yang bisa diedit']];
 }

 async function runImport(c){
  const{target,kind,buf,name,mode,range,place}=c;
  const hook=TARGET[target].hook();if(!hook)throw new Error('Mode '+TARGET[target].name+' belum siap. Muat ulang halaman.');
  const replace=place==='replace';
  const title=name.replace(/\.[^.]+$/,'').slice(0,60)||'Impor';
  const o={images:mode==='gambar',warn:{chart:0,other:0,imgFmt:0,imgSkip:0},abort:()=>c.aborted,progress:c.progress,maxImg:target==='ppt'?1000:800};
  const notes=[];
  /* ---- PPTX ---- */
  if(kind==='pptx'){
   /* hitung total dulu (ringan) lalu pilih rentang */
   const total=await(async()=>{const JSZip=await needZip();const z=await JSZip.loadAsync(buf);const d=xmlDoc(await z.file('ppt/presentation.xml').async('string'));return d.getElementsByTagName('p:sldId').length;})();
   const idx=parseRange(range,total);const cap=target==='ppt'?60:target==='word'?60:60;
   const sel=new Set(idx.slice(0,cap));if(idx.length>cap)notes.push('Dibatasi '+cap+' slide pertama dari rentang.');
   o.sel=sel;
   const P=await parsePptx(buf,o);
   P.slides.forEach((S,i)=>{S.no=[...sel][i]+1;});
   if(!P.slides.length)throw new Error('Tidak ada slide yang bisa dibaca.');
   if(target==='ppt'){
    const slides=P.slides.map(S=>pptxSlideToPpt(S,P.k));
    const r=await hook.apply(slides,{title,replace});
    notes.unshift(P.slides.length+' slide dibaca; '+r.added+' ditambahkan'+(r.saved?'':' — tetapi penyimpanan perangkat penuh, kurangi gambar/slide'));
   }else if(target==='word'){
    const html=P.slides.map(S=>pptxSlideToWord(S,S.no,P.k,mode==='gambar')).join('<hr>');
    const r=await hook.apply(html,{replace});notes.unshift(P.slides.length+' slide dimasukkan sebagai dokumen'+(r.saved?'':' — tetapi penyimpanan perangkat penuh, coba "Teks saja"'));
   }else{
    const sheets=pptxToSheets(P);const r=await hook.apply(sheets,{replace});
    notes.unshift(P.slides.length+' slide dimasukkan ke '+r.sheets+' lembar'+(r.cut?' ('+r.cut+')':''));
   }
   if(o.warn.chart)notes.push(o.warn.chart+' grafik tidak ikut (tidak didukung).');
   if(o.warn.other)notes.push(o.warn.other+' objek khusus (SmartArt/video/dll.) dilewati.');
   if(o.warn.imgFmt)notes.push(o.warn.imgFmt+' gambar berformat khusus (EMF/WMF) dilewati.');
   return notes;
  }
  /* ---- DOCX ---- */
  if(kind==='docx'){
   const D=await parseDocx(buf,o);if(!D.blocks.length)throw new Error('Dokumen tidak berisi teks.');
   if(target==='word'){
    const r=await hook.apply(blocksToHtml(D.blocks),{replace});notes.push('Dokumen dimasukkan'+(r.saved?'':' — tetapi penyimpanan perangkat penuh, coba "Teks saja"'));
   }else if(target==='excel'){
    const rows=[],tabs=[];D.blocks.forEach(b=>{if(b.t==='table')tabs.push(b.rows);else if(b.t!=='img')rows.push([b.t==='li'?(b.num?'1. ':'• ')+b.text:b.text]);});
    const sheets=[];for(let i=0;i<rows.length;i+=60)sheets.push({name:'Dokumen'+(i?' ('+(i/60+1)+')':''),rows:rows.slice(i,i+60),widths:{1:560}});
    tabs.forEach((t,i)=>sheets.push({name:'Tabel '+(i+1),rows:t}));
    const r=await hook.apply(sheets,{replace});notes.push('Dimasukkan ke '+r.sheets+' lembar'+(r.cut?' ('+r.cut+')':''));
   }else{
    const secs=[];let curS={ttl:title,bl:[]};
    D.blocks.forEach(b=>{if((b.t==='h1'||b.t==='h2')){if(curS.bl.length)secs.push(curS);curS={ttl:b.text.slice(0,80),bl:[]};}else curS.bl.push(b);});
    if(curS.bl.length||!secs.length)secs.push(curS);
    const slides=secs.flatMap(x=>blocksToSlides(x.bl,x.ttl,''));
    const r=await hook.apply(slides,{title,replace});notes.push(slides.length+' slide teks dibuat; '+r.added+' ditambahkan'+(r.saved?'':' — tetapi penyimpanan perangkat penuh'));
    notes.push('Gambar tidak ikut ke slide; judul 1/2 menjadi pemisah slide.');
   }
   return notes;
  }
  /* ---- XLSX ---- */
  if(kind==='xlsx'){
   const total=await(async()=>{const JSZip=await needZip();const z=await JSZip.loadAsync(buf);const d=xmlDoc(await z.file('xl/workbook.xml').async('string'));return d.getElementsByTagName('sheet').length;})();
   const idx=parseRange(range,total);o.sel=new Set(idx.slice(0,8));if(idx.length>8)notes.push('Dibatasi 8 lembar pertama.');
   const X=await parseXlsx(buf,o);const sheets=X.sheets.filter(x=>x.rows.length);
   if(!sheets.length)throw new Error('Lembar yang dipilih kosong.');
   if(target==='excel'){
    const r=await hook.apply(sheets.map(x=>({name:x.name,rows:x.rows})),{replace});notes.push(r.sheets+' lembar dimasukkan'+(r.cut?' ('+r.cut+')':''));
   }else if(target==='word'){
    const r=await hook.apply(sheets.map(x=>'<h2>'+esc(x.name)+'</h2>'+tableHtml(x.rows.slice(0,200))).join(''),{replace});notes.push(sheets.length+' lembar dimasukkan sebagai tabel'+(r.saved?'':' — tetapi penyimpanan perangkat penuh'));
   }else{
    const slides=sheets.flatMap(x=>tableSlides(x.name,x.rows.slice(0,200),'Lembar Excel '+x.no));
    const r=await hook.apply(slides,{title,replace});notes.push(slides.length+' slide tabel dibuat; '+r.added+' ditambahkan'+(r.saved?'':' — tetapi penyimpanan perangkat penuh'));
    notes.push('Tabel dibatasi 8 kolom pertama.');
   }
   if(X.formulas)notes.push('Rumus diimpor sebagai nilai hasilnya.');
   return notes;
  }
  /* ---- PDF ---- */
  const pdf=await openPdf(buf,o);const total=pdf.numPages;
  const cap=(target==='ppt'&&mode==='gambar')?30:(target==='word'&&mode==='gambar')?20:(target==='excel')?8:60;
  let idx=parseRange(range,total);if(idx.length>cap){idx=idx.slice(0,cap);notes.push('Dibatasi '+cap+' halaman pertama dari rentang (batas untuk cara ini).');}
  if(mode==='gambar'){
   const pages=[];
   for(let i=0;i<idx.length;i++){
    if(c.aborted)throw new Error('Dibatalkan');
    c.progress('Menggambar halaman '+(idx[i]+1)+' ('+(i+1)+'/'+idx.length+')…');await tick();
    const pg=await pdf.getPage(idx[i]+1);
    pages.push({n:idx[i]+1,...(await renderPage(pg,target==='ppt'?1100:820,target==='ppt'?800:1200,target==='ppt'?.6:.6))});
    pg.cleanup();
   }
   if(target==='ppt'){
    const slides=pages.map(p=>{const k=Math.min(SW/p.w,SH/p.h),w=Math.round(p.w*k),h=Math.round(p.h*k);
     return{bg:'#ffffff',fg:'#1f2430',notes:'Halaman PDF '+p.n,html:'<div class="ppt-obj" style="left:'+Math.round((SW-w)/2)+'px;top:'+Math.round((SH-h)/2)+'px;width:'+w+'px">'+HANDLE+'<img alt="Halaman '+p.n+'" src="'+p.url+'" style="width:100%;height:auto"></div>'};});
    const r=await hook.apply(slides,{title,replace});notes.unshift(pages.length+' halaman jadi slide gambar; '+r.added+' ditambahkan'+(r.saved?'':' — tetapi penyimpanan perangkat penuh, kurangi jumlah halaman'));
   }else{
    const html=pages.map(p=>'<p><img alt="Halaman '+p.n+'" src="'+p.url+'" style="max-width:100%"></p>').join('<hr>');
    const r=await hook.apply(html,{replace});notes.unshift(pages.length+' halaman dimasukkan sebagai gambar'+(r.saved?'':' — tetapi penyimpanan perangkat penuh, kurangi halaman'));
   }
   return notes;
  }
  /* teks */
  const pagesT=[];let chars=0;
  for(let i=0;i<idx.length;i++){
   if(c.aborted)throw new Error('Dibatalkan');
   c.progress('Membaca teks halaman '+(idx[i]+1)+' ('+(i+1)+'/'+idx.length+')…');await tick();
   const pg=await pdf.getPage(idx[i]+1);const lines=await pageLines(pg);pg.cleanup();
   chars+=lines.reduce((a,l)=>a+l.text.length,0);pagesT.push({n:idx[i]+1,lines});
  }
  if(chars<20){
   throw new Error('PDF ini tidak berisi teks (mungkin hasil pindai/foto). Pilih cara "Gambar halaman" untuk memasukkannya sebagai gambar.');
  }
  const bodyH=median(pagesT.flatMap(p=>p.lines.flatMap(l=>Array(Math.max(1,Math.min(20,l.text.length>>2))).fill(l.h))));
  if(target==='excel'){
   const sheets=[];
   pagesT.forEach(p=>{if(!p.lines.length)return;const rows=linesToRows(p.lines);for(let s=0;s<rows.length;s+=60)sheets.push({name:'PDF Hal '+p.n+(s?' ('+(s/60+1)+')':''),rows:rows.slice(s,s+60),widths:{1:240}});});
   const r=await hook.apply(sheets,{replace});notes.unshift(pagesT.length+' halaman dimasukkan ke '+r.sheets+' lembar'+(r.cut?' ('+r.cut+')':''));
   return notes;
  }
  if(target==='word'){
   const html=pagesT.map(p=>blocksToHtml(linesToBlocks(p.lines,bodyH))).filter(Boolean).join('<hr>');
   const r=await hook.apply(html,{replace});notes.unshift(pagesT.length+' halaman teks dimasukkan'+(r.saved?'':' — tetapi penyimpanan perangkat penuh'));
   notes.push('Tata letak kolom/tabel PDF disederhanakan jadi paragraf; gambar di PDF tidak ikut (pakai "Gambar halaman" bila perlu).');
   return notes;
  }
  /* ppt teks */
  const slides=[];
  pagesT.forEach(p=>{
   const bl=linesToBlocks(p.lines,bodyH);let ttl='';
   if(bl.length&&/^h/.test(bl[0].t)){ttl=bl.shift().text;}
   const groups=[];let g=[],len=0;
   bl.forEach(b=>{const l=(b.t==='table'?b.rows.reduce((a,r)=>a+r.join(' | ').length,0):b.text.length)+20;if(g.length&&len+l>900){groups.push(g);g=[];len=0;}g.push(b);len+=l;});
   if(g.length||!groups.length)groups.push(g);
   groups.forEach((gr,gi)=>{
    const body=gr.reduce((a,b)=>a+(b.t==='table'?b.rows.reduce((x,r)=>x+r.join(' | ').length,0):b.text.length),0),px=body<=350?28:body<=650?23:body<=900?19:16;
    const t=(ttl||'Halaman '+p.n)+(gi?' (lanjutan)':'');
    const html='<div class="ppt-ph ppt-t2" contenteditable="true" data-ph="Judul slide">'+esc(t)+'</div><div class="ppt-ph ppt-body" contenteditable="true" data-ph="Tulis isi di sini" style="font-size:'+px+'px">'+blocksToHtml(gr.map(b=>b.t==='table'?{t:'p',text:b.rows.map(r=>r.join(' | ')).join('\n')}:/^h/.test(b.t)?{t:'p',text:b.text}:b))+'</div>';
    slides.push({bg:'#ffffff',fg:'#1f2430',notes:'Halaman PDF '+p.n,html});
   });
  });
  const r=await hook.apply(slides,{title,replace});
  notes.unshift(pagesT.length+' halaman jadi '+slides.length+' slide teks; '+r.added+' ditambahkan');
  return notes;
 }

 /* ============================================================
    Dialog
    ============================================================ */
 const css='.oi-ov{position:fixed;inset:0;z-index:99999;background:rgba(15,20,30,.55);display:flex;align-items:center;justify-content:center;padding:14px;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}'+
  '.oi-box{background:#fff;color:#1f2430;border-radius:14px;box-shadow:0 18px 50px rgba(0,0,0,.35);width:min(440px,100%);max-height:92vh;overflow:auto;padding:16px 16px 14px}'+
  '.oi-box h3{margin:0 0 4px;font-size:17px}.oi-file{font-size:13px;color:#566;margin:0 0 12px;word-break:break-all}'+
  '.oi-box label{display:block;font-size:12.5px;font-weight:600;margin:10px 0 4px;color:#334}'+
  '.oi-box select,.oi-box input[type=text]{width:100%;box-sizing:border-box;font-size:15px;padding:9px 10px;border:1px solid #c5ccd8;border-radius:8px;background:#fff;color:#1f2430}'+
  '.oi-hint{font-size:12px;color:#667;margin-top:3px}.oi-status{font-size:13.5px;margin:12px 0 0;min-height:1.3em;white-space:pre-wrap}'+
  '.oi-bar{height:6px;border-radius:3px;background:#e4e8ef;margin-top:8px;overflow:hidden;display:none}.oi-bar i{display:block;height:100%;width:40%;background:#185abd;animation:oiMove 1s linear infinite}'+
  '@keyframes oiMove{0%{margin-left:-40%}100%{margin-left:100%}}'+
  '.oi-act{display:flex;gap:8px;justify-content:flex-end;margin-top:14px}.oi-act button{font-size:14.5px;padding:9px 16px;border-radius:8px;border:1px solid #c5ccd8;background:#f4f6fa;color:#1f2430;cursor:pointer}'+
  '.oi-act button.go{background:#185abd;border-color:#185abd;color:#fff;font-weight:600}.oi-act button:disabled{opacity:.5}.oi-err{color:#b3261e}.oi-ok{color:#1b6e3c}';
 function injectCss(){if($('#oiCss'))return;const s=document.createElement('style');s.id='oiCss';s.textContent=css;document.head.appendChild(s);}
 let fileInp=null,busy=false;
 function pick(target){
  if(busy)return;
  if(!fileInp){fileInp=document.createElement('input');fileInp.type='file';fileInp.hidden=true;fileInp.accept='.pptx,.ppt,.pdf,.docx,.xlsx,application/pdf,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';document.body.appendChild(fileInp);}
  fileInp.value='';
  fileInp.onchange=()=>{const f=fileInp.files&&fileInp.files[0];fileInp.value='';if(f)openDialog(target,f);};
  fileInp.click();
 }
 async function sniff(file){
  const head=new Uint8Array(await file.slice(0,8).arrayBuffer());
  const s=String.fromCharCode(...head.slice(0,5));
  if(s==='%PDF-')return'pdf';
  if(head[0]===0x50&&head[1]===0x4b)return'zip';
  if(head[0]===0xD0&&head[1]===0xCF&&head[2]===0x11&&head[3]===0xE0)return'ole';
  /* PDF kadang punya sampah di depan header */
  const first=new TextDecoder('latin1').decode(new Uint8Array(await file.slice(0,1024).arrayBuffer()));
  return first.includes('%PDF-')?'pdf':'';
 }
 async function openDialog(target,file){
  injectCss();
  const ov=document.createElement('div');ov.className='oi-ov';
  ov.innerHTML='<div class="oi-box" role="dialog" aria-modal="true" aria-label="Impor file"><h3>Impor file ke '+TARGET[target].name+'</h3><p class="oi-file"></p><div class="oi-form"></div><div class="oi-bar"><i></i></div><div class="oi-status" role="status"></div><div class="oi-act"><button type="button" class="cancel">Batal</button><button type="button" class="go">Mulai impor</button></div></div>';
  document.body.appendChild(ov);
  const $$=s=>ov.querySelector(s),status=$$('.oi-status'),form=$$('.oi-form'),go=$$('.go'),cancel=$$('.cancel'),bar=$$('.oi-bar');
  $$('.oi-file').textContent=file.name+' · '+(file.size/1048576<1?Math.max(1,Math.round(file.size/1024))+' KB':(file.size/1048576).toFixed(1)+' MB');
  const ctx={target,aborted:false,progress:m=>{status.className='oi-status';status.textContent=m;}};
  const close=()=>{ctx.aborted=true;busy=false;ov.remove();document.removeEventListener('keydown',onKey,true);};
  const onKey=e=>{if(e.key==='Escape'){e.stopPropagation();close();}};
  document.addEventListener('keydown',onKey,true);
  cancel.onclick=close;ov.addEventListener('pointerdown',e=>{if(e.target===ov&&!busy)close();});
  const fail=m=>{status.className='oi-status oi-err';status.textContent=m;go.disabled=true;go.style.display='none';cancel.textContent='Tutup';};
  if(file.size>MAXFILE){fail('File terlalu besar (maks 80 MB).');return;}
  let k;try{k=await sniff(file);}catch(_){fail('File tidak bisa dibaca.');return;}
  if(k==='ole'){fail('Format .ppt lama (biner) tidak didukung. Simpan ulang sebagai .pptx di PowerPoint/WPS Office, atau ekspor ke PDF, lalu impor lagi.');return;}
  let kind=k;
  if(k==='zip'){try{const JSZip=await needZip();const z=await JSZip.loadAsync(file);kind=z.file('ppt/presentation.xml')?'pptx':z.file('word/document.xml')?'docx':z.file('xl/workbook.xml')?'xlsx':'';}catch(_){kind='';}}
  if(kind==='ole'||!kind||kind==='zip'){fail('Bukan file yang dikenali. Pilih .pptx, .pdf, .docx, atau .xlsx.');return;}
  ctx.kind=kind;ctx.name=file.name;
  const modes=modesFor(target,kind);
  let ph='<label>Cara impor</label><select class="f-mode">'+modes.map(m=>'<option value="'+m[0]+'">'+esc(m[1])+'</option>').join('')+'</select>';
  ph+=(kind==='docx'?'':'<label>'+(kind==='pdf'?'Halaman':kind==='xlsx'?'Lembar':'Slide')+' yang diimpor</label><input type="text" class="f-range" placeholder="Kosongkan = semua, atau contoh: 1-3,5" inputmode="numeric" autocomplete="off"><div class="oi-hint f-hint"></div>');
  ph+='<label>Penempatan</label><select class="f-place"><option value="add">'+(target==='excel'?'Tambah sebagai lembar baru':target==='word'?'Tambahkan di akhir dokumen':'Tambahkan di akhir presentasi')+'</option><option value="replace">'+(target==='excel'?'Ganti seluruh buku':target==='word'?'Ganti isi dokumen':'Ganti seluruh presentasi')+'</option></select>';
  form.innerHTML=ph;
  const hint=$$('.f-hint');
  const updHint=()=>{if(!hint)return;if(kind==='xlsx'){hint.textContent='Maks 8 lembar sekali impor.';return;}const m=$$('.f-mode').value;const c=kind==='pdf'?(target==='ppt'&&m==='gambar'?'Maks 30 halaman sekali impor (agar muat di penyimpanan perangkat).':target==='word'&&m==='gambar'?'Maks 20 halaman sekali impor.':target==='excel'?'Maks 8 lembar; tiap lembar 60 baris × 26 kolom.':'Maks 60 halaman sekali impor.'):(target==='excel'?'Maks 8 lembar; tiap lembar 60 baris × 26 kolom.':'Maks 60 slide sekali impor.');hint.textContent=c;};
  $$('.f-mode').onchange=updHint;updHint();
  if(modes.length===1)$$('.f-mode').disabled=true;
  go.onclick=async()=>{
   if(busy)return;busy=true;go.disabled=true;cancel.textContent='Batalkan';bar.style.display='block';
   ctx.mode=$$('.f-mode').value;ctx.range=($$('.f-range')||{value:''}).value;ctx.place=$$('.f-place').value;
   $$('.f-mode').disabled=$$('.f-place').disabled=true;if($$('.f-range'))$$('.f-range').disabled=true;
   try{
    ctx.progress('Membuka file…');await tick();
    ctx.buf=await file.arrayBuffer();
    const notes=await runImport(ctx);
    if(ctx.aborted)return;
    bar.style.display='none';status.className='oi-status oi-ok';status.textContent='Selesai. '+notes.join(' ');
    go.style.display='none';cancel.textContent='Tutup';busy=false;
   }catch(e){
    if(ctx.aborted||!ov.isConnected)return;
    bar.style.display='none';busy=false;status.className='oi-status oi-err';status.textContent=(e&&e.message)||'Gagal mengimpor.';
    go.style.display='none';cancel.textContent='Tutup';
   }finally{ctx.buf=null;}
  };
  setTimeout(()=>{try{go.focus({preventScroll:true});}catch(_){}} ,0);
 }

 document.addEventListener('click',e=>{const b=e.target.closest('[data-office-import]');if(!b)return;e.preventDefault();pick(b.dataset.officeImport);});
 window.CDMS_OFFICE=window.CDMS_OFFICE||{};
 window.CDMS_OFFICE.importFile=openDialog;
 /* dipakai pengujian */
 window.CDMS_OFFICE._internal={parsePptx,pageLines,linesToBlocks,linesToRows,runImport};
})();
