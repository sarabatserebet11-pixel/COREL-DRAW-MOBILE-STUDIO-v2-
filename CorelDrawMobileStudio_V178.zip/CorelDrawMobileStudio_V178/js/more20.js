/* V33: menu Impor (SVG sebagai gambar atau vektor), Pudar (fade tepi), Ekspor HTML presentasi */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,P=CDMS.Pages,{MENUS,BT,edit,pick,T,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height,NS="http://www.w3.org/2000/svg",E=CDMS.escape;
const nm=()=>(S.projectName||"desain").replace(/[^\w-]+/g,"_");

/* ---- renderer: pt (geser path impor) & pudar tepi ---- */
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);
 if(o.pt&&o.type==="path")s=s.replace(/(<path [^>]*?transform="scale\([^)]*\))"/,`$1 translate(${-o.pt[0]} ${-o.pt[1]})"`);
 if(o.fade&&!o.clipSub&&!o.clipBy&&!/ mask="/.test(s.slice(0,260))){const f=o.fade,w=o.w||1,h=o.h||1,id="fd-"+o.id,st=`<stop offset="${f.s}" stop-color="#fff"/><stop offset="1" stop-color="#000"/>`;
  const G={bottom:'x1="0" y1="0" x2="0" y2="1"',top:'x1="0" y1="1" x2="0" y2="0"',right:'x1="0" y1="0" x2="1" y2="0"',left:'x1="1" y1="0" x2="0" y2="0"'};
  const def=f.d==="vignette"?`<radialGradient id="${id}g" cx=".5" cy=".5" r=".72">${st}</radialGradient>`:`<linearGradient id="${id}g" ${G[f.d]||G.bottom}>${st}</linearGradient>`;
  s=s.replace("<g ",`<g mask="url(#${id})" `).replace(">",`><mask id="${id}" maskUnits="userSpaceOnUse" x="-2" y="-2" width="${w+4}" height="${h+4}"><defs>${def}</defs><rect x="-2" y="-2" width="${w+4}" height="${h+4}" fill="url(#${id}g)"/></mask>`);}
 return s;};
S.fadeStr=S.fadeStr??.35;
const setFade=d=>edit(o=>{o.fade={d,s:S.fadeStr};},"Pudar tepi diterapkan",o=>o.type!=="line");
MENUS.fade=()=>[{h:"Arah pudar (objek terpilih)",items:[["Ke bawah","bottom"],["Ke atas","top"],["Ke kanan","right"],["Ke kiri","left"],["Vinyet (tengah jelas)","vignette"]].map(x=>it(x[0],()=>setFade(x[1]),"layers"))},
 {h:"Kekuatan",items:[["Lembut",.6],["Sedang",.35],["Kuat",.1]].map(x=>tc(x[0]+(S.fadeStr===x[1]?" ✓":""),()=>{S.fadeStr=x[1];T("Kekuatan: "+x[0]);}))},
 {h:"Hapus",items:[it("Hapus pudar tepi",()=>edit(o=>{delete o.fade;},"Pudar tepi dihapus"),"trash")]}];

/* ---- impor SVG ---- */
function chooseSvg(cb){const inp=document.createElement("input");inp.type="file";inp.accept=".svg,image/svg+xml";
 inp.onchange=()=>{const f=inp.files[0];if(!f)return;if(f.size>2*1048576)return T("File SVG maksimal 2 MB");const r=new FileReader();r.onload=()=>cb(String(r.result),f.name);r.readAsText(f);};inp.click();}
function parse(txt){const doc=new DOMParser().parseFromString(txt,"image/svg+xml"),root=doc.documentElement;if(!root||root.nodeName.toLowerCase()!=="svg"||doc.querySelector("parsererror")){T("File SVG tidak valid");return null;}return{doc,root};}
function dims(root){const vb=(root.getAttribute("viewBox")||"").split(/[\s,]+/).map(Number);if(vb.length===4&&vb[2]>0&&vb[3]>0)return[vb[2],vb[3]];return[parseFloat(root.getAttribute("width"))||300,parseFloat(root.getAttribute("height"))||150];}
function asImage(txt,name){const p=parse(txt);if(!p)return;const[vw,vh]=dims(p.root);p.root.setAttribute("xmlns",NS);if(!p.root.getAttribute("viewBox"))p.root.setAttribute("viewBox",`0 0 ${vw} ${vh}`);p.root.setAttribute("width",vw);p.root.setAttribute("height",vh);
 const href="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(new XMLSerializer().serializeToString(p.root)),f=Math.min(W()*.6/vw,H()*.6/vh),w=Math.round(vw*f),h=Math.round(vh*f);
 Hi.snapshot();const o={id:uid(),type:"image",name:name.replace(/\.svg$/i,""),href,x:Math.round((W()-w)/2),y:Math.round((H()-h)/2),w,h,strokeWidth:0,opacity:100,rotation:0};S.objects.push(o);pick([o]);T("SVG diimpor sebagai gambar");}
const hex=c=>{const m=String(c).match(/rgba?\(([^)]+)\)/);if(!m)return c==="none"?"none":null;const v=m[1].split(",").map(s=>parseFloat(s));return{h:"#"+v.slice(0,3).map(n=>Math.round(n).toString(16).padStart(2,"0")).join(""),a:v.length>3?v[3]:1};};
function prim(el){const t=el.tagName.toLowerCase(),n=a=>parseFloat(el.getAttribute(a))||0;
 if(t==="path")return el.getAttribute("d");
 if(t==="rect"){const x=n("x"),y=n("y"),w=n("width"),h=n("height");return `M${x} ${y}h${w}v${h}h${-w}z`;}
 if(t==="circle"){const cx=n("cx"),cy=n("cy"),r=n("r");return `M${cx-r} ${cy}a${r} ${r} 0 1 0 ${2*r} 0a${r} ${r} 0 1 0 ${-2*r} 0z`;}
 if(t==="ellipse"){const cx=n("cx"),cy=n("cy"),rx=n("rx"),ry=n("ry");return `M${cx-rx} ${cy}a${rx} ${ry} 0 1 0 ${2*rx} 0a${rx} ${ry} 0 1 0 ${-2*rx} 0z`;}
 if(t==="line")return `M${n("x1")} ${n("y1")}L${n("x2")} ${n("y2")}`;
 if(t==="polygon"||t==="polyline"){const p=(el.getAttribute("points")||"").trim().split(/[\s,]+/).map(Number);let d="";for(let i=0;i+1<p.length;i+=2)d+=(i?"L":"M")+p[i]+" "+p[i+1];return d+(t==="polygon"?"Z":"");}
 return null;}
function asVector(txt){const p=parse(txt);if(!p)return;const host=document.createElementNS(NS,"svg");host.setAttribute("style","position:absolute;left:-99999px;top:0;width:10px;height:10px");document.body.appendChild(host);
 const[vw,vh]=dims(p.root);const imp=document.importNode(p.root,true);imp.setAttribute("width",vw);imp.setAttribute("height",vh);if(!imp.getAttribute("viewBox"))imp.setAttribute("viewBox",`0 0 ${vw} ${vh}`);host.appendChild(imp);
 const out=[];let skipped=0;
 try{[...host.querySelectorAll("path,rect,circle,ellipse,polygon,polyline,line")].slice(0,300).forEach(el=>{if(el.closest("defs,clipPath,mask,symbol"))return;const d=prim(el);if(!d)return;
  let bb;try{bb=el.getBBox();}catch(e){return;}const mt=el.getCTM(),hs=host.getCTM?host.getCTM():null;if(!mt)return;
  const rel=hs?hs.inverse().multiply(mt):mt;if(Math.abs(rel.b)>1e-4||Math.abs(rel.c)>1e-4){skipped++;}
  const sx=rel.a,sy=rel.d,cs=getComputedStyle(el),fl=hex(cs.fill),sk=hex(cs.stroke),sw=parseFloat(cs.strokeWidth)||0,op=parseFloat(cs.opacity);if(el.tagName.toLowerCase()==="line"&&fl&&fl.h)fl.h="none";
  out.push({d,bx:bb.x,by:bb.y,bw:bb.width,bh:bb.height,x:rel.a*bb.x+rel.e,y:rel.d*bb.y+rel.f,w:Math.abs(sx)*bb.width,h:Math.abs(sy)*bb.height,fill:fl==="none"?"none":(fl&&fl.h)||"#000000",stroke:sk==="none"?"none":(sk&&sk.h)||"none",sw:sw*Math.abs(sx),op:Math.round((op||1)*(fl&&fl.a!==undefined?fl.a:1)*100),tag:el.tagName.toLowerCase()});});}finally{host.remove();}
 if(!out.length)return T("Tidak ada bentuk yang bisa diimpor (teks dan gambar di SVG diabaikan)");
 const gx0=Math.min(...out.map(o=>o.x)),gy0=Math.min(...out.map(o=>o.y)),gx1=Math.max(...out.map(o=>o.x+o.w)),gy1=Math.max(...out.map(o=>o.y+o.h)),f=Math.min(W()*.6/Math.max(1,gx1-gx0),H()*.6/Math.max(1,gy1-gy0)),ox=(W()-(gx1-gx0)*f)/2,oy=(H()-(gy1-gy0)*f)/2,g=uid();
 Hi.snapshot();const objs=out.map((o,i)=>({id:uid(),groupId:g,type:"path",name:"SVG "+o.tag+" "+(i+1),x:Math.round(ox+(o.x-gx0)*f),y:Math.round(oy+(o.y-gy0)*f),w:Math.max(1,Math.round(o.w*f)),h:Math.max(1,Math.round(o.h*f)),vw:Math.max(o.bw,.001),vh:Math.max(o.bh,.001),pt:[o.bx,o.by],d:o.d,fill:o.fill,stroke:o.stroke,strokeWidth:+(o.sw*f).toFixed(2),opacity:o.op,rotation:0}));
 S.objects.push(...objs);pick(objs);T(objs.length+" bentuk diimpor"+(skipped?" ("+skipped+" memakai rotasi/miring dan diratakan)":""));}
MENUS.impor=()=>[{h:"Impor SVG",items:[it("SVG sebagai gambar (utuh)…",()=>chooseSvg(asImage),"image"),it("SVG sebagai vektor (bisa diedit)…",()=>chooseSvg(asVector),"pen")]},{h:"Catatan",items:[it("Vektor: path & bentuk dasar; teks dan gambar di dalam SVG diabaikan",()=>{},"settings")]}];

/* ---- ekspor HTML presentasi ---- */
function htmlExport(){P.sync();const n=S.pages.length,slides=S.pages.map((pg,i)=>M.pageSvg(pg,true).replace(/pgG/g,"pgG"+i));
 const css="html,body{margin:0;height:100%;background:#000;color:#fff;font-family:system-ui,sans-serif;overflow:hidden}.s{position:absolute;inset:0 0 56px 0;display:none;align-items:center;justify-content:center}.s.on{display:flex}.s svg{max-width:100%;max-height:100%}.bar{position:fixed;left:0;right:0;bottom:0;height:56px;display:flex;gap:12px;align-items:center;justify-content:center;background:#0b0d16}.bar button{height:38px;min-width:46px;border:1px solid #2b3250;border-radius:10px;background:#1a1f33;color:#fff;font-size:15px}.bar b{min-width:70px;text-align:center}";
 const js="var s=document.querySelectorAll('.s'),i=0,l=document.getElementById('i');function g(d){s[i].classList.remove('on');i=(i+d+s.length)%s.length;s[i].classList.add('on');l.textContent=(i+1)+' / '+s.length}document.getElementById('p').onclick=function(){g(-1)};document.getElementById('n').onclick=function(){g(1)};addEventListener('keydown',function(e){if(e.key==='ArrowRight'||e.key===' ')g(1);if(e.key==='ArrowLeft')g(-1)});l.textContent='1 / '+s.length;";
 const html=`<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${E(S.projectName||"Presentasi")}</title><style>${css}</style></head><body>${slides.map((s,i)=>`<div class="s${i?"":" on"}">${s}</div>`).join("")}<div class="bar"><button id="p">◀</button><b id="i"></b><button id="n">▶</button></div><script>${js}<`+`/script></body></html>`;
 CDMS.Export.download(new Blob([html],{type:"text/html"}),nm()+".html");T("HTML presentasi disimpan ("+n+" halaman, "+Math.round(html.length/1024)+" KB)");}
const oc=MENUS.cetak;MENUS.cetak=()=>[...oc(),{h:"HTML",items:[it("Ekspor HTML presentasi (1 file)",htmlExport,"export")]}];

BT.push(["impor","import","Impor"],["fade","fade","Pudar"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("berkas").push("impor");hub("warna").push("fade");
})();
