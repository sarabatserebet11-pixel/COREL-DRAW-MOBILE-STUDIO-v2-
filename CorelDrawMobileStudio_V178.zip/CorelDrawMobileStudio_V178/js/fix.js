/* V3 upgrade: perbaikan render, seleksi + handle, teks, layer, simpan, ekspor */
(function(){
const NS="http://www.w3.org/2000/svg",S=CDMS.state,C=CDMS.Canvas,H=CDMS.History,N=CDMS.Navigation,E=CDMS.escape;
const get=id=>S.objects.find(o=>o.id===id);
const ids=()=>S.selectedIds&&S.selectedIds.length?S.selectedIds:(S.selected?[S.selected]:[]);
CDMS.toast=m=>{const t=document.createElement("div");t.className="toast";t.textContent=m;document.body.appendChild(t);setTimeout(()=>t.remove(),1900);};
CDMS.setTool=t=>{S.tool=t;document.querySelectorAll("[data-tool]").forEach(b=>b.classList.toggle("active",b.dataset.tool===t));};

/* ---------- render ---------- */
C.objMarkup=function(o){
 const w=o.w||1,h=o.type==="line"?(o.h||0):(o.h||1),stk=o.stroke||"#20243a",sw=o.strokeWidth??2;
 const base=`stroke="${stk}" stroke-width="${sw}" stroke-linejoin="round" stroke-linecap="round"`;
 let s;
 if(o.type==="text"){const fs=o.fontSize||64;s=`<text font-size="${fs}" font-family="${E(o.fontFamily||"Arial, sans-serif")}" font-weight="${o.bold?700:400}" font-style="${o.italic?"italic":"normal"}" letter-spacing="${o.spacing||0}" fill="${o.fill||"#20243a"}" stroke="${o.textOutline?(o.stroke||"#000"):"none"}" stroke-width="${o.textOutline?(o.strokeWidth||2):0}" paint-order="stroke" dominant-baseline="hanging">${String(o.text||"Teks").split("\n").map((l,i)=>`<tspan x="0" y="${i*fs*1.2}">${E(l)||" "}</tspan>`).join("")}</text>`;}
 else if(o.type==="image")s=`<image href="${E(o.href)}" width="${w}" height="${h}" preserveAspectRatio="none"/>`;
 else if(o.type==="line")s=`<line x1="0" y1="0" x2="${w}" y2="${h}" stroke="transparent" stroke-width="${Math.max(sw,26)}"/><line x1="0" y1="0" x2="${w}" y2="${h}" ${base}/>`;
 else if(o.type==="path"){const vw=o.vw||(o.vw=w),vh=o.vh||(o.vh=h),k=Math.max(.01,(w/vw+h/vh)/2);s=`<path d="${E(o.d||"")}" transform="scale(${w/vw} ${h/vh})" fill="${o.fill??"none"}" stroke="${stk}" stroke-width="${sw/k}" stroke-linejoin="round" stroke-linecap="round"/>`;}
 else if(o.type==="ellipse")s=`<ellipse cx="${w/2}" cy="${h/2}" rx="${w/2}" ry="${h/2}" fill="${o.fill||"#00d6c9"}" ${base}/>`;
 else if(o.type==="star")s=`<polygon points="${C.starPoints(w,h)}" fill="${o.fill||"#ffc857"}" ${base}/>`;
 else if(o.type==="polygon")s=`<polygon points="${w*.5},0 ${w},${h*.35} ${w*.82},${h} ${w*.18},${h} 0,${h*.35}" fill="${o.fill||"#b34dff"}" ${base}/>`;
 else s=`<rect width="${w}" height="${h}" rx="${o.rx||0}" fill="${o.fill||"#6d5dfc"}" ${base}/>`;
 return `<g data-id="${o.id}" opacity="${(o.opacity??100)/100}" style="cursor:${o.locked?"default":"move"}" transform="translate(${o.x} ${o.y}) rotate(${o.rotation||0} ${w/2} ${h/2}) translate(${w/2} ${h/2}) scale(${o.flipH?-1:1} ${o.flipV?-1:1}) translate(${-w/2} ${-h/2})">${s}</g>`;
};
C.docMarkup=p=>p.objects.filter(o=>!o.hidden).map(o=>C.objMarkup(o)).join("");
C.render=function(){
 const P=S.page,bg=document.getElementById("pageBackground");
 this.svg.setAttribute("viewBox",`0 0 ${P.width} ${P.height}`);
 bg.setAttribute("width",P.width);bg.setAttribute("height",P.height);bg.setAttribute("fill",P.background);
 this.group.innerHTML=S.objects.filter(o=>!o.hidden).map(o=>this.objMarkup(o)).join("");
 S.objects.forEach(o=>{if(o.type!=="text"||o.hidden)return;const el=this.group.querySelector(`[data-id="${o.id}"] text`);if(!el)return;try{const b=el.getBBox();if(b.width&&(Math.abs(b.width-o.w)>1||Math.abs(b.height-o.h)>1)){o.w=Math.round(b.width);o.h=Math.round(b.height);}}catch(e){}});
 this.drawOverlay();
 document.getElementById("documentLabel").textContent=S.projectName;
 this.updateProperties();CDMS.Layers.render();
 const n=ids().length;document.getElementById("selectionStatus").textContent=n>1?`${n} objek dipilih`:n?"1 objek dipilih":"Tidak ada objek dipilih";
};
C.drawOverlay=function(){
 let ov=document.getElementById("overlayLayer");
 if(!ov){ov=document.createElementNS(NS,"g");ov.id="overlayLayer";this.svg.appendChild(ov);}
 const P=S.page,k=Math.max(.3,P.width/(this.svg.getBoundingClientRect().width||P.width)),sel=ids().map(get).filter(Boolean);let h="";
 sel.forEach(o=>{h+=`<g pointer-events="none" transform="translate(${o.x} ${o.y}) rotate(${o.rotation||0} ${o.w/2} ${o.h/2})"><rect width="${o.w}" height="${o.h}" fill="none" stroke="#00d6c9" stroke-width="${1.5*k}" stroke-dasharray="${6*k} ${4*k}"/></g>`;});
 if(sel.length===1&&!sel[0].locked){const o=sel[0],r=9*k,pts={nw:[0,0],ne:[o.w,0],se:[o.w,o.h],sw:[0,o.h]};
  h+=`<g transform="translate(${o.x} ${o.y}) rotate(${o.rotation||0} ${o.w/2} ${o.h/2})"><line x1="${o.w/2}" y1="0" x2="${o.w/2}" y2="${-32*k}" stroke="#00d6c9" stroke-width="${1.5*k}"/><circle data-h="rot" cx="${o.w/2}" cy="${-32*k}" r="${r*1.2}" fill="#7b6cff" stroke="#fff" stroke-width="${1.5*k}"/>`+Object.entries(pts).map(([n,[x,y]])=>`<rect data-h="${n}" x="${x-r}" y="${y-r}" width="${2*r}" height="${2*r}" rx="${2*k}" fill="#fff" stroke="#00d6c9" stroke-width="${2*k}"/>`).join("")+`</g>`;}
 ov.innerHTML=h;
};

/* ---------- pointer ---------- */
C.pointerDown=function(e){
 const t=e.target,p=this.point(e),hd=t.closest&&t.closest("[data-h]");
 if(hd&&S.selected){const o=get(S.selected);S.drag={mode:hd.dataset.h==="rot"?"rot":"size",h:hd.dataset.h,id:o.id,orig:{...o},start:p};this.svg.setPointerCapture&&this.svg.setPointerCapture(e.pointerId);return;}
 const g=t.closest&&t.closest("[data-id]"),o=g&&get(g.dataset.id);
 if(o&&!o.locked&&(S.tool==="select"||S.tool==="eraser")){
  if(S.tool==="eraser"){this.deleteObject(o.id);return;}
  let sel=S.selectedIds||[];const grp=o.groupId?S.objects.filter(x=>x.groupId===o.groupId).map(x=>x.id):[o.id];
  if(e.shiftKey||S.multi)sel=grp.every(i=>sel.includes(i))?sel.filter(i=>!grp.includes(i)):[...new Set([...sel,...grp])];
  else if(!sel.includes(o.id))sel=grp;
  S.selectedIds=sel;S.selected=sel.includes(o.id)?o.id:(sel[sel.length-1]||null);
  S.drag={mode:"move",start:p,starts:sel.map(i=>{const b=get(i);return{id:i,x:b.x,y:b.y};})};
  this.svg.setPointerCapture&&this.svg.setPointerCapture(e.pointerId);this.render();return;}
 if(S.tool==="select"){S.selected=null;S.selectedIds=[];this.render();return;}
 if(S.tool==="pan"){const v=document.getElementById("canvasViewport");S.drag={mode:"pan",x:e.clientX,y:e.clientY,sl:v.scrollLeft,st:v.scrollTop};return;}
 if(["rect","ellipse","star","polygon","line"].includes(S.tool)){CDMS.Shapes.add(S.tool,p.x-(S.tool==="line"?140:120),p.y-(S.tool==="line"?0:90));CDMS.setTool("select");}
 else if(S.tool==="text")CDMS.Text.open(p);
 else if(S.tool==="image")document.getElementById("imageInput").click();
 else if(S.tool==="pen"){H.snapshot();S.drawPath={points:[p]};this.svg.setPointerCapture&&this.svg.setPointerCapture(e.pointerId);}
};
C.pointerMove=function(e){
 if(S.drawPath){const pt=this.point(e);S.drawPath.points.push(pt);let el=this.group.querySelector('[data-preview="path"]');if(!el){el=document.createElementNS(NS,"path");el.dataset.preview="path";["fill:none","stroke:"+(S.penColor||"#6d5dfc"),"stroke-width:"+(S.penWidth||5),"stroke-linecap:round","stroke-linejoin:round"].forEach(a=>{const[k,v]=a.split(":");el.setAttribute(k,v);});this.group.appendChild(el);}el.setAttribute("d",S.drawPath.points.map((q,i)=>(i?"L":"M")+q.x+" "+q.y).join(" "));return;}
 const d=S.drag;if(!d)return;
 if(d.mode==="pan"){const v=document.getElementById("canvasViewport");v.scrollLeft=d.sl-(e.clientX-d.x);v.scrollTop=d.st-(e.clientY-d.y);return;}
 const p=this.point(e);
 if(!d.moved){if(Math.hypot(p.x-d.start.x,p.y-d.start.y)<3)return;H.snapshot();d.moved=true;}
 if(d.mode==="move"){const dx=p.x-d.start.x,dy=p.y-d.start.y;d.starts.forEach(st=>{const o=get(st.id);if(o){o.x=Math.round(st.x+dx);o.y=Math.round(st.y+dy);}});}
 else{
  const o=get(d.id),q=d.orig,th=(q.rotation||0)*Math.PI/180,cs=Math.cos(th),sn=Math.sin(th),cx=q.x+q.w/2,cy=q.y+q.h/2;
  if(!o)return;
  if(d.mode==="rot"){let a=Math.atan2(p.y-cy,p.x-cx)*180/Math.PI+90;const r=Math.round(a/15)*15;if(e.shiftKey||Math.abs(a-r)<3)a=r;o.rotation=Math.round(((a+540)%360)-180);}
  else{
   const sx=d.h.includes("e")?1:-1,sy=d.h.includes("s")?1:-1,dx=p.x-cx,dy=p.y-cy,lx=dx*cs+dy*sn,ly=-dx*sn+dy*cs,ox=-sx*q.w/2,oy=-sy*q.h/2;
   let nw=Math.max(8,(lx-ox)*sx),nh=Math.max(q.type==="line"?0:8,(ly-oy)*sy);
   if(q.type==="text"){o.fontSize=Math.max(8,Math.round((q.fontSize||64)*Math.max(.1,nh/(q.h||1))));}
   else{
    if((e.shiftKey||q.type==="image"||q.lockAR)&&q.h)nh=nw*q.h/q.w;
    const ncx=ox+sx*nw/2,ncy=oy+sy*nh/2,gx=cx+ncx*cs-ncy*sn,gy=cy+ncx*sn+ncy*cs;
    o.w=Math.round(nw);o.h=Math.round(nh);o.x=Math.round(gx-nw/2);o.y=Math.round(gy-nh/2);
   }
  }
 }
 this.render();
};

/* ---------- properti ---------- */
let _pb=0;
C.bindProperties=function(){
 if(_pb)return;_pb=1;
 const bind=(id,key,parse=v=>v,ev="change")=>document.getElementById(id).addEventListener(ev,e=>{
  const o=get(S.selected);if(!o)return;const now=Date.now();if(now-(this._ps||0)>700)H.snapshot();this._ps=now;
  const v=parse(e.target.value);o[key]=v;
  if(["fill","stroke","strokeWidth","opacity"].includes(key))ids().map(get).forEach(x=>{if(x)x[key]=v;});
  this.render();});
 const num=v=>Number(v)||0,size=v=>Math.max(1,Number(v)||1);
 bind("propName","name");bind("propX","x",num);bind("propY","y",num);bind("propW","w",size);bind("propH","h",size);
 bind("propRotation","rotation",num,"input");bind("propFill","fill",v=>v,"input");bind("propStroke","stroke",v=>v,"input");
 bind("propStrokeWidth","strokeWidth",num);bind("propOpacity","opacity",num,"input");bind("propText","text");
 const fams=[["Arial, sans-serif","Arial"],["Georgia, serif","Georgia"],["'Times New Roman', serif","Times"],["'Courier New', monospace","Courier"],["Impact, 'Arial Black', sans-serif","Impact"],["'Trebuchet MS', sans-serif","Trebuchet"],["Verdana, sans-serif","Verdana"],["'Comic Sans MS', cursive","Comic"]];
 const tp=document.getElementById("textProperty");
 if(tp&&!document.getElementById("textExtra")){
  tp.insertAdjacentHTML("afterend",`<div id="textExtra" class="hidden"><div class="two-fields"><label>Ukuran<input id="propFont" type="number" min="8" max="400"></label><label>Font<select id="propFamily">${fams.map(f=>`<option value="${E(f[0])}">${f[1]}</option>`).join("")}</select></label></div><div class="property-actions"><button class="btn subtle" id="propBold"><b>B</b></button><button class="btn subtle" id="propItalic"><i>I</i></button></div></div>`);
  bind("propFont","fontSize",v=>Math.max(8,Number(v)||64));bind("propFamily","fontFamily");
  const tg=(id,key)=>document.getElementById(id).addEventListener("click",()=>{const o=get(S.selected);if(!o)return;H.snapshot();o[key]=!o[key];this.render();});
  tg("propBold","bold");tg("propItalic","italic");
 }
};
const up=C.updateProperties;
C.updateProperties=function(){
 up.call(this);const o=get(S.selected),x=document.getElementById("textExtra");if(!x)return;
 const show=!!o&&o.type==="text";x.classList.toggle("hidden",!show);if(!show)return;
 const f=document.getElementById("propFont"),m=document.getElementById("propFamily");
 if(document.activeElement!==f)f.value=o.fontSize||64;if(document.activeElement!==m)m.value=o.fontFamily||"Arial, sans-serif";
 document.getElementById("propBold").classList.toggle("on",!!o.bold);document.getElementById("propItalic").classList.toggle("on",!!o.italic);
};

/* ---------- teks, bentuk, stiker ---------- */
const sa=CDMS.Shapes.add;
CDMS.Shapes.add=function(){sa.apply(this,arguments);S.selectedIds=[S.selected];C.render();};
CDMS.Text.open=function(pos){
 N.openModal("Tambah teks",`<label>Isi teks<textarea id="newTextValue" rows="3" style="width:100%;margin:10px 0;padding:10px;border-radius:8px;background:var(--panel2);color:var(--text);border:1px solid var(--line)">Teks baru</textarea></label><button class="btn primary" id="insertText">Tambahkan teks</button>`);
 document.getElementById("insertText").onclick=()=>{const v=document.getElementById("newTextValue").value||"Teks baru";CDMS.Shapes.add("text",pos?pos.x:undefined,pos?pos.y:undefined);const o=get(S.selected);o.text=v;C.render();N.closeModal();CDMS.setTool("select");};
};
const STK=[["heart","Hati","#ff5d8f","M50 88C10 58 6 34 22 20C34 10 46 16 50 28C54 16 66 10 78 20C94 34 90 58 50 88Z"],["spark","Kilau","#ffc857","M50 4L61 39L96 50L61 61L50 96L39 61L4 50L39 39Z"],["plus","Plus","#00d6c9","M38 6H62V38H94V62H62V94H38V62H6V38H38Z"],["check","Centang","#3ddc84","M10 54L22 42L40 60L78 18L90 30L40 84Z"],["bolt","Petir","#ffb020","M58 4L16 56H44L38 96L84 40H54Z"],["moon","Bulan","#9d92ff","M70 8A44 44 0 1 0 92 66A36 36 0 0 1 70 8Z"],["arrow","Panah","#4f83ff","M6 38H60V14L94 50L60 86V62H6Z"]];
const BAS=[["star","Bintang"],["ellipse","Lingkaran"],["rect","Persegi"]];
CDMS.Stickers.open=function(){
 N.openModal("Stiker & elemen",'<div class="modal-grid">'+BAS.map(b=>`<button data-basic="${b[0]}">${CDMS.Icons.svg(b[0])}<span>${b[1]}</span></button>`).join("")+STK.map(s=>`<button data-sticker="${s[0]}"><svg viewBox="0 0 100 100" class="stk"><path d="${s[3]}" fill="${s[2]}"/></svg><span>${s[1]}</span></button>`).join("")+'</div>');
 document.querySelectorAll("[data-basic]").forEach(b=>b.onclick=()=>{CDMS.Shapes.add(b.dataset.basic);N.closeModal();});
 document.querySelectorAll("[data-sticker]").forEach(b=>b.onclick=()=>{const s=STK.find(x=>x[0]===b.dataset.sticker);H.snapshot();const id=crypto.randomUUID();S.objects.push({id,type:"path",name:s[1],x:Math.round(S.page.width/2-100),y:Math.round(S.page.height/2-100),w:200,h:200,vw:100,vh:100,d:s[3],fill:s[2],stroke:"none",strokeWidth:0,opacity:100,rotation:0});S.selected=id;S.selectedIds=[id];C.render();N.closeModal();});
};

/* ---------- layer ---------- */
CDMS.Layers.render=function(){
 const root=document.getElementById("layersList");if(!root)return;const I=CDMS.Icons,objs=[...S.objects].reverse();
 if(!objs.length){root.innerHTML='<div class="muted">Belum ada objek.</div>';return;}
 root.innerHTML=objs.map(o=>`<div class="layer-row ${ids().includes(o.id)?"selected":""}" data-layer="${o.id}"><button data-vis="${o.id}" title="Tampil/sembunyi">${I.svg(o.hidden?"eyeoff":"eye")}</button><span class="layer-name">${E(o.name||o.type)}</span><button data-lock="${o.id}" title="Kunci">${I.svg(o.locked?"lock":"unlock")}</button></div>`).join("");
 root.onclick=e=>{const b=e.target.closest("button"),r=e.target.closest("[data-layer]");if(!r)return;const o=get(r.dataset.layer);if(!o)return;
  if(b&&b.dataset.vis){H.snapshot();o.hidden=!o.hidden;C.render();}else if(b&&b.dataset.lock){H.snapshot();o.locked=!o.locked;C.render();}else C.select(o.id);};
};

/* ---------- group, multi, simpan, riwayat ---------- */
N.groupSelected=function(){const sel=S.selectedIds||[];if(sel.length<2)return CDMS.toast("Pilih 2 objek atau lebih (tombol Multi / Shift + klik)");H.snapshot();const g=crypto.randomUUID();S.objects.forEach(o=>{if(sel.includes(o.id))o.groupId=g;});C.render();CDMS.toast("Objek dikelompokkan");};
N.ungroupSelected=function(){const sel=ids();H.snapshot();S.objects.forEach(o=>{if(sel.includes(o.id))delete o.groupId;});C.render();CDMS.toast("Kelompok dilepas");};
const oa=N.action;
N.action=function(a){if(a==="toggleMulti"){S.multi=!S.multi;document.querySelectorAll('[data-action="toggleMulti"]').forEach(b=>b.classList.toggle("active",S.multi));CDMS.toast(S.multi?"Multi-pilih aktif":"Multi-pilih mati");return;}oa.call(this,a);};
CDMS.Storage.save=function(){
 const item={name:S.projectName,width:S.page.width,height:S.page.height,background:S.page.background,objects:S.objects,updated:Date.now()};
 let list=this.list();const i=list.findIndex(x=>x.name===item.name);if(i>=0)list.splice(i,1);list.unshift(item);list=list.slice(0,20);
 try{localStorage.setItem(this.key,JSON.stringify(list));N.renderRecents();CDMS.toast("Proyek tersimpan");}catch(e){CDMS.toast("Penyimpanan penuh. Pakai Ekspor > Cadangkan proyek.");}
};
N.renderRecents=function(){
 const list=CDMS.Storage.list(),root=document.getElementById("recentProjects");
 if(!list.length){root.innerHTML='<div class="empty-state">Belum ada proyek tersimpan. Buat desain pertama kamu!</div>';return;}
 root.innerHTML=list.map((p,i)=>`<button class="recent-card" data-recent="${i}"><span class="recent-thumb"><svg viewBox="0 0 ${p.width} ${p.height}"><rect width="${p.width}" height="${p.height}" fill="${E((p.background||"#fff").startsWith("grad:")?p.background.slice(5).split(",")[0]:(p.background||"#fff"))}"/>${C.docMarkup(p)}</svg></span><b>${E(p.name||"Desain")}</b><small>${new Date(p.updated||Date.now()).toLocaleString("id-ID")}</small></button>`).join("");
 root.querySelectorAll("[data-recent]").forEach(b=>b.onclick=()=>CDMS.Storage.openAt(+b.dataset.recent));
};
const rs=H.restore;H.restore=function(s){rs.call(this,s);S.selectedIds=[];C.render();};
const lp=C.loadProject;C.loadProject=function(p){lp.call(this,p);S.history=[];S.future=[];};
["svg","png"].forEach(k=>{const f=CDMS.Export[k];CDMS.Export[k]=function(){const ov=document.getElementById("overlayLayer");if(ov)ov.remove();try{f.call(this);}finally{if(ov)C.svg.appendChild(ov);}};});

/* ---------- init setelah Tools.init ---------- */
const ti=CDMS.Tools.init;
CDMS.Tools.init=function(){
 ti.call(this);
 const bar=document.querySelector(".editor-toolbar");
 if(bar&&!bar.querySelector('[data-action="toggleMulti"]'))bar.insertAdjacentHTML("beforeend",'<button class="tool" data-action="toggleMulti" title="Pilih banyak objek"><span>Multi</span></button>');
 const inp=document.getElementById("imageInput"),ni=inp.cloneNode(true);inp.replaceWith(ni);
 ni.addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const sc=Math.min(1,S.page.width*.6/im.width,S.page.height*.6/im.height),w=Math.round(im.width*sc),h=Math.round(im.height*sc);H.snapshot();const id=crypto.randomUUID();S.objects.push({id,type:"image",name:f.name,x:Math.round((S.page.width-w)/2),y:Math.round((S.page.height-h)/2),w,h,href:r.result,strokeWidth:0,opacity:100,rotation:0});S.selected=id;S.selectedIds=[id];C.render();CDMS.setTool("select");};im.src=r.result;};r.readAsDataURL(f);e.target.value="";});
 CDMS.Icons.apply();C.render();
};
})();
