/* V117: Menu konteks. Klik kanan (desktop) atau tekan lama (HP) pada objek/kanvas membuka menu cepat:
   Salin, Potong, Tempel, Duplikat, Hapus, urutan, kelompok, kunci, sembunyikan, balik, dan Pilih serupa.
   Memakai ulang fungsi yang sudah ada (copy/cut/paste di menus.js, aksi di navigation.js); semua perubahan bisa di-undo. */
(()=>{
const S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,M=CDMS.Menus,E=CDMS.escape,$=(s,r=document)=>r.querySelector(s);
let menu=null,lastPress=0,press=null;
const sel=()=>{const ids=S.selectedIds&&S.selectedIds.length?S.selectedIds:(S.selected?[S.selected]:[]);return S.objects.filter(o=>ids.includes(o.id));};
const act=a=>()=>N.action(a);
const ubah=(fn,pesan)=>()=>{const a=sel();if(!a.length)return;Hi.snapshot();a.forEach(fn);C.render();if(pesan)M.T(pesan);};
function serupa(o){Hi.snapshot();const ids=S.objects.filter(x=>!x.hidden&&!x.locked&&x.type===o.type&&(x.fill||"")===(o.fill||"")).map(x=>x.id);
 S.selectedIds=ids;S.selected=ids[0]||null;C.render();M.T(ids.length+" objek serupa dipilih");}
function daftar(o){const a=sel(),n=a.length,grup=a.some(x=>x.groupId),kunci=a.every(x=>x.locked);
 if(!o)return[["Tempel",M.paste],["Pilih semua",()=>M.pick(S.objects.filter(x=>!x.hidden&&!x.locked))],"-",["Zoom 100%",()=>C.setZoom(100)],["Tampilkan/sembunyikan grid",act("toggleGrid")]];
 if(o.locked)return[["Buka kunci",()=>{Hi.snapshot();o.locked=false;C.render();M.T("Objek dibuka kuncinya");}],["Tempel",M.paste]];
 return[["Salin",M.copy],["Potong",M.cut],["Tempel",M.paste],["Duplikat",act("duplicate")],["Hapus",act("delete")],"-",
  ["Ke depan",act("front")],["Ke belakang",act("back")],
  n>1&&!grup?["Kelompokkan",act("group")]:grup?["Pisahkan kelompok",act("ungroup")]:null,"-",
  [kunci?"Buka kunci":"Kunci",ubah(x=>{x.locked=!kunci;},kunci?"Terbuka":"Dikunci")],["Sembunyikan",ubah(x=>{x.hidden=true;},"Disembunyikan (tampilkan lewat panel Lapisan)")],
  ["Balik horizontal",act("flipH")],["Balik vertikal",act("flipV")],"-",["Pilih serupa",()=>serupa(o)],n===1&&!grup&&CDMS.Bend?["Titik kurva (lengkungkan)",()=>CDMS.Bend.start()]:null].filter(Boolean);}
function tutup(){if(menu){menu.remove();menu=null;}document.removeEventListener("pointerdown",luar,true);document.removeEventListener("keydown",tombol,true);window.removeEventListener("resize",tutup);}
function luar(e){if(menu&&!menu.contains(e.target))tutup();}
function tombol(e){if(!menu)return;const it=[...menu.querySelectorAll("button")],i=it.indexOf(document.activeElement);
 if(e.key==="Escape"){e.preventDefault();e.stopPropagation();tutup();}
 else if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();e.stopPropagation();const d=e.key==="ArrowDown"?1:-1;it[(i+d+it.length)%it.length].focus();}
 else if(e.key==="Home"){e.preventDefault();it[0].focus();}else if(e.key==="End"){e.preventDefault();it[it.length-1].focus();}}
function buka(x,y,el){tutup();/* elemen target bisa sudah dilepas dari kanvas (render ulang saat pointerdown memilih objek), jadi cari lewat data-id atau titik layar */
 let g=el&&el.closest?el.closest("[data-id]"):null;if(!g||!S.objects.some(t=>t.id===g.dataset.id)){const q=document.elementFromPoint(x,y);g=q&&q.closest?q.closest("#designCanvas [data-id]"):null;}
 const o=g?S.objects.find(t=>t.id===g.dataset.id):null;
 if(o&&!o.locked&&!(S.selectedIds||[]).includes(o.id)){S.selected=o.id;S.selectedIds=[o.id];C.render();}
 const it=daftar(o);menu=document.createElement("div");menu.className="ctx-menu";menu.setAttribute("role","menu");menu.setAttribute("aria-label","Menu konteks");
 menu.innerHTML=it.map((r,i)=>r==="-"?'<div class="ctx-sep" role="separator"></div>':`<button type="button" role="menuitem" data-i="${i}">${E(r[0])}</button>`).join("");
 document.body.appendChild(menu);
 const w=menu.offsetWidth,h=menu.offsetHeight;menu.style.left=Math.max(6,Math.min(x,window.innerWidth-w-6))+"px";menu.style.top=Math.max(6,Math.min(y,window.innerHeight-h-6))+"px";
 menu.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const r=it[+b.dataset.i];tutup();if(r&&r[1])r[1]();});
 document.addEventListener("pointerdown",luar,true);document.addEventListener("keydown",tombol,true);window.addEventListener("resize",tutup);
 const f=menu.querySelector("button");if(f&&!(window.matchMedia&&matchMedia("(pointer:coarse)").matches))f.focus();}

function pasang(){const v=$("#canvasViewport");if(!v||v.dataset.v117)return;v.dataset.v117="1";
 /* bila tekan lama baru saja membuka menu, abaikan "contextmenu" bawaan browser yang menyusul */
 v.addEventListener("contextmenu",e=>{e.preventDefault();if(Date.now()-lastPress<900)return;buka(e.clientX,e.clientY,e.target);});
 /* tekan lama untuk layar sentuh yang tidak memicu "contextmenu" (mis. iOS) */
 v.addEventListener("pointerdown",e=>{if(e.pointerType!=="touch"||!e.isPrimary)return;const x=e.clientX,y=e.clientY,t=e.target;
  clearTimeout(press&&press.t);press={x,y,t:setTimeout(()=>{press=null;if(!S.drag||!S.drag.moved){lastPress=Date.now();buka(x,y,t);}},550)};});
 const batal=()=>{if(press){clearTimeout(press.t);press=null;}};
 v.addEventListener("pointermove",e=>{if(press&&Math.hypot(e.clientX-press.x,e.clientY-press.y)>10)batal();});
 v.addEventListener("pointerup",batal);v.addEventListener("pointercancel",batal);
 v.addEventListener("touchstart",e=>{if(e.touches.length>1)batal();},{passive:true});
 v.addEventListener("scroll",()=>{batal();tutup();},{passive:true});}
pasang();setTimeout(pasang,400);
CDMS.Context={open:buka,close:tutup};
})();
