/* V96: dua grup menu baru.
   "Geometri Hias" (ikon rosette): Cincin (lingkaran konsentris), Roset (kelopak melingkar), Jaring (jaringan titik terhubung).
   "Data Visual" (ikon gaugechart): Radar (grafik laba-laba dari angka), Dial (meteran setengah lingkaran), Bilah Skor (daftar bilah persentase).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,tc,cell,sels,T}=M;
if(!M.HUBS)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),uid=()=>crypto.randomUUID();
const W=()=>S.page.width,H=()=>S.page.height,rnd=(a,b)=>a+Math.random()*(b-a);
const done=m=>{C.render();if(m)T(m);};
const bb=a=>{let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;a.forEach(o=>{x0=Math.min(x0,o.x);y0=Math.min(y0,o.y);x1=Math.max(x1,o.x+(o.w||0));y1=Math.max(y1,o.y+(o.h||0));});return{x:x0,y:y0,w:x1-x0,h:y1-y0};};
const parse=c=>{const m=/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(c||"").trim());if(!m)return null;let h=m[1];if(h.length===3)h=h.split("").map(x=>x+x).join("");return[0,2,4].map(i=>parseInt(h.substr(i,2),16));};
const toHex=r=>"#"+r.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0")).join("");
const mix=(a,b,t)=>toHex(a.map((v,i)=>v+(b[i]-v)*t));
const toHsl=([r,g,b])=>{r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;}return[h,s*100,l*100];};
const fromHsl=(h,s,l)=>{h=((h%360)+360)%360;s/=100;l/=100;const k=n=>(n+h/30)%12,a=s*Math.min(l,1-l),f=n=>l-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)));return toHex([f(0)*255,f(8)*255,f(4)*255]);};
const grup=(arr,nama)=>{const g=uid();arr.forEach(o=>{o.groupId=g;o.groupName=nama;});return arr;};
const R=Math.round;
const shape=(type,x,y,w,h,fill,x2)=>({id:uid(),type,name:type==="ellipse"?"Lingkaran":"Kotak",x:R(x),y:R(y),w:Math.max(1,R(w)),h:Math.max(1,R(h)),rx:0,fill,stroke:"none",strokeWidth:0,opacity:100,rotation:0,...x2});
const text=(t,x,y,fs,fill,x2)=>({id:uid(),type:"text",name:"Teks",text:t,x:R(x),y:R(y),w:R(t.length*fs*.6),h:R(fs*1.2),fontSize:R(fs),fill,opacity:100,rotation:0,...x2});
const line=(x,y,w,h,col,sw,x2)=>({id:uid(),type:"line",name:"Garis",x:R(x),y:R(y),w:R(w),h:R(h),stroke:col,strokeWidth:sw,fill:"none",opacity:100,rotation:0,...x2});
/* segmen garis dari (x1,y1) ke (x2,y2): lebar/tinggi selalu positif, arah diagonal lewat flipV */
const seg=(x1,y1,x2,y2,col,sw,x2o)=>{const o=line(Math.min(x1,x2),Math.min(y1,y2),Math.abs(x2-x1),Math.abs(y2-y1),col,sw,x2o);if((x2-x1)*(y2-y1)<0)o.flipV=true;return o;};
const path=(x,y,w,h,vw,vh,d,fill,stroke,sw,x2)=>({id:uid(),type:"path",name:"Bentuk",x:R(x),y:R(y),w:R(w),h:R(h),vw,vh,d,fill,stroke,strokeWidth:sw,opacity:100,rotation:0,...x2});
const gelap=()=>{const c=parse(S.page.background||"#ffffff");return c?(c[0]*.3+c[1]*.59+c[2]*.11)<110:false;};
const baseCol=a=>(a&&a[0]&&parse(a[0].fill))||[109,93,252];
/* titik pusat & jari-jari: dari pilihan bila ada, kalau tidak dari halaman */
const pusat=()=>{const a=sels();if(a.length){const b=bb(a);return{cx:b.x+b.w/2,cy:b.y+b.h/2,r:Math.max(30,Math.max(b.w,b.h)/2),a};}return{cx:W()/2,cy:H()/2,r:Math.min(W(),H())*.36,a:[]};};
const ptn=(cx,cy,r,deg)=>[cx+r*Math.sin(deg*Math.PI/180),cy-r*Math.cos(deg*Math.PI/180)];
const finish=(arr,nama,msg)=>{S.objects.push(...arr);S.selectedIds=arr.map(o=>o.id);S.selected=arr[0].id;done(msg);};
const pilihKey=(k,def)=>S[k]||def;

/* ================= GEOMETRI HIAS ================= */
const CST=[["Isi bertingkat","isi"],["Garis","garis"],["Selang-seling","selang"]];
function cincin(){const p=pusat(),n=S.cincinN96||6,st=S.cincinSt96||"isi",base=baseCol(p.a),dk=mix(base,[0,0,0],.35),lt=mix(base,[255,255,255],.8),out=[];Hi.snapshot();
 for(let i=0;i<n;i++){const r=p.r*(n-i)/n,t=n>1?i/(n-1):0,col=mix(parse(dk),parse(lt),t);
  if(st==="isi")out.push(shape("ellipse",p.cx-r,p.cy-r,2*r,2*r,col,{name:"Cincin "+(i+1)}));
  else if(st==="garis")out.push(shape("ellipse",p.cx-r,p.cy-r,2*r,2*r,"none",{name:"Cincin "+(i+1),stroke:col,strokeWidth:Math.max(2,R(p.r/n/5))}));
  else out.push(shape("ellipse",p.cx-r,p.cy-r,2*r,2*r,i%2?toHex(base.map(v=>v)):dk,{name:"Cincin "+(i+1)}));}
 finish(grup(out,"Cincin"),"Cincin","Cincin "+n+"× ("+st+")");}
MENUS.cincin96=()=>[
 {h:"Gaya",items:CST.map(x=>tc(x[0],()=>{S.cincinSt96=x[1];},{keep:1,on:pilihKey("cincinSt96","isi")===x[1]}))},
 {h:"Jumlah cincin",items:[4,6,8,12].map(v=>tc(v+"",()=>{S.cincinN96=v;},{keep:1,on:(S.cincinN96||6)===v}))},
 {h:"Buat",items:[it("Buat cincin (di pilihan / tengah halaman)",cincin,"rings")]}];

const RWR=[["Analog","analog"],["Pelangi","pelangi"],["Ombre","ombre"]];
function roset(){const p=pusat(),n=S.rosetN96||8,st=S.rosetSt96||"analog",base=baseCol(p.a),hsl=toHsl(base),out=[];Hi.snapshot();const pw=p.r*(n<=6?.5:n<=8?.4:n<=12?.3:.22);
 for(let i=0;i<n;i++){const deg=360*i/n,[x,y]=ptn(p.cx,p.cy,p.r/2,deg),t=i/n;
  const col=st==="pelangi"?fromHsl(360*t,75,58):st==="ombre"?mix(parse(mix(base,[0,0,0],.3)),parse(mix(base,[255,255,255],.7)),t<.5?t*2:2-2*t):fromHsl(hsl[0]+60*t,Math.max(50,hsl[1]),Math.min(65,Math.max(45,hsl[2])));
  out.push(shape("ellipse",x-pw/2,y-p.r/2,pw,p.r,col,{name:"Kelopak "+(i+1),rotation:R(deg),opacity:72,stroke:"#ffffff",strokeWidth:1}));}
 out.push(shape("ellipse",p.cx-p.r*.09,p.cy-p.r*.09,p.r*.18,p.r*.18,"#ffc857",{name:"Putik",stroke:"#ffffff",strokeWidth:2}));
 finish(grup(out,"Roset"),"Roset","Roset "+n+" kelopak");}
MENUS.roset96=()=>[
 {h:"Warna",items:RWR.map(x=>tc(x[0],()=>{S.rosetSt96=x[1];},{keep:1,on:pilihKey("rosetSt96","analog")===x[1]}))},
 {h:"Jumlah kelopak",items:[6,8,12,16].map(v=>tc(v+"",()=>{S.rosetN96=v;},{keep:1,on:(S.rosetN96||8)===v}))},
 {h:"Buat",items:[it("Buat roset (di pilihan / tengah halaman)",roset,"petal")]}];

const JRG=[["Neon","#00d6c9","#7b6cff"],["Biru","#4f83ff","#9db8ff"],["Mono","#e8ebf5","#8a93aa"]];
function jaring(){const n=S.jaringN96||40,pal=JRG[S.jaringP96||0],m=Math.round(Math.min(W(),H())*.05);let th=Math.min(W(),H())*.26;Hi.snapshot();
 const pts=[];for(let i=0;i<n;i++)pts.push([rnd(m,W()-m),rnd(m,H()-m)]);
 let pairs=[];const build=()=>{pairs=[];for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){const d=Math.hypot(pts[i][0]-pts[j][0],pts[i][1]-pts[j][1]);if(d<th)pairs.push([i,j,d]);}};
 build();while(pairs.length>260){th*=.9;build();}
 const sw=Math.max(1,R(Math.min(W(),H())/500)),rr=Math.max(4,R(Math.min(W(),H())*.008)),out=[];
 pairs.forEach(([i,j,d])=>out.push(seg(pts[i][0],pts[i][1],pts[j][0],pts[j][1],pal[2],sw,{name:"Sambungan",opacity:Math.round(25+60*(1-d/th))})));
 pts.forEach((q,i)=>out.push(shape("ellipse",q[0]-rr,q[1]-rr,rr*2,rr*2,i%3?pal[1]:pal[2],{name:"Titik "+(i+1)})));
 finish(grup(out,"Jaring"),"Jaring","Jaring "+n+" titik · "+pairs.length+" garis");}
MENUS.jaring96=()=>[
 {h:"Warna",items:JRG.map((x,i)=>tc(x[0],()=>{S.jaringP96=i;},{keep:1,on:(S.jaringP96||0)===i}))},
 {h:"Jumlah titik",items:[20,40,70].map(v=>tc(v+"",()=>{S.jaringN96=v;},{keep:1,on:(S.jaringN96||40)===v}))},
 {h:"Buat",items:[it("Buat jaring acak di halaman",jaring,"network")]}];

/* ================= DATA VISUAL ================= */
function angka(q,min){const it0=String(q||"").split(/[,;\n]+/).map(s=>s.trim()).filter(Boolean).map(s=>{const m=/^(?:(.+?)\s*[=:]\s*)?(-?\d+(?:[.,]\d+)?)$/.exec(s);return m?{n:m[1]||"",v:Math.max(0,Math.min(100,parseFloat(m[2].replace(",","."))))}:null;});
 if(it0.some(x=>!x))return null;return it0.length>=min?it0:null;}
function radar(){const q=prompt("Isi nilai 0–100, pisahkan koma (3–10 nilai). Boleh pakai nama: Desain=80, Kode=60, Musik=90","Desain=80, Kode=60, Musik=90, Riset=50, Bisnis=70");if(q===null)return;
 const d=angka(q,3);if(!d||d.length>10)return T("Isi 3–10 nilai angka 0–100");Hi.snapshot();
 const k=d.length,Rr=Math.min(W(),H())*.3,cx=W()/2,cy=H()/2,base=baseCol(sels()),col=toHex(base),sz=Rr*2,gl=gelap()?"#4a5275":"#cfd4e6",tc0=gelap()?"#f1f3ff":"#20243a",out=[];
 const poly=(f)=>{let s="";for(let i=0;i<k;i++){const [x,y]=ptn(Rr,Rr,Rr*f(i),360*i/k);s+=(i?"L":"M")+x.toFixed(1)+" "+y.toFixed(1);}return s+"Z";};
 [.25,.5,.75,1].forEach(f=>out.push(path(cx-Rr,cy-Rr,sz,sz,sz,sz,poly(()=>f),"none",gl,1.5,{name:"Cincin "+f*100+"%"})));
 for(let i=0;i<k;i++){const [x,y]=ptn(cx,cy,Rr,360*i/k);out.push(seg(cx,cy,x,y,gl,1.5,{name:"Sumbu "+(i+1)}));}
 out.push(path(cx-Rr,cy-Rr,sz,sz,sz,sz,poly(i=>d[i].v/100),col,col,3,{name:"Data",opacity:55}));
 const fs=Math.max(12,R(Math.min(W(),H())*.026));
 d.forEach((e,i)=>{const [x,y]=ptn(cx,cy,Rr*(e.v/100),360*i/k),rr=Math.max(4,fs*.3);out.push(shape("ellipse",x-rr,y-rr,rr*2,rr*2,col,{name:"Titik "+(i+1),stroke:"#ffffff",strokeWidth:2}));
  const lbl=(e.n?e.n+" ":"")+R(e.v),[lx,ly]=ptn(cx,cy,Rr*1.14,360*i/k),tw=lbl.length*fs*.6;out.push(text(lbl,lx-tw/2,ly-fs*.6,fs,tc0,{name:"Label "+(i+1),bold:true}));});
 finish(grup(out,"Radar"),"Radar","Radar "+k+" sumbu");}
MENUS.radar96=()=>[{h:"Grafik laba-laba",items:[it("Buat radar dari angka…",radar,"radar"),it("Warna ikut warna isi objek terpilih (tanpa pilihan: ungu)",()=>{},"info",{keep:1})]}];

function dial(v){if(v==null){const q=prompt("Nilai meteran 0–100:","72");if(q===null)return;v=parseFloat(String(q).replace(",","."));}if(!isFinite(v)||v<0||v>100)return T("Isi angka 0–100");Hi.snapshot();
 const w=Math.min(W(),H())*.6,h=w/2+w*.08,cx=W()/2,x0=cx-w/2,y0=H()/2-h/2,vw=200,vh=100,rr=88,sw=Math.max(8,R(w*.075)),track=gelap()?"#2f3555":"#e3e6f2",col=v<34?"#ef4444":v<67?"#f59e0b":"#22c55e",ph=Math.PI*v/100,ex=100-rr*Math.cos(ph),ey=95-rr*Math.sin(ph),tc0=gelap()?"#f1f3ff":"#20243a",out=[];
 out.push(path(x0,y0,w,h,vw,vh,"M12 95A88 88 0 0 1 188 95","none",track,sw,{name:"Jalur"}));
 if(v>0)out.push(path(x0,y0,w,h,vw,vh,`M12 95A88 88 0 0 1 ${ex.toFixed(1)} ${ey.toFixed(1)}`,"none",col,sw,{name:"Nilai",linecap:"round"}));
 const fs=Math.round(w*.2);out.push(text(Math.round(v)+"%",cx-String(Math.round(v)+"%").length*fs*.3,y0+h-fs*1.15,fs,tc0,{name:"Angka",bold:true}));
 finish(grup(out,"Dial"),"Dial","Dial "+Math.round(v)+"%");}
MENUS.dial96=()=>[{h:"Meteran setengah lingkaran",items:[...[25,50,75,90].map(v=>tc(v+"%",()=>dial(v))),it("Nilai sendiri…",()=>dial(),"dial")]}];

const BPAL=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4f83ff","#ff7ac8"];
function skor(){const q=prompt("Daftar skor 0–100, pisahkan koma. Format: Nama=nilai","Desain=90, Kode=70, Musik=55, Riset=40");if(q===null)return;const d=angka(q,1);if(!d||d.length>12||d.some(x=>!x.n))return T("Isi 1–12 baris berformat Nama=nilai");Hi.snapshot();
 const x0=W()*.1,wt=W()*.8,bh=Math.max(14,Math.min(36,R(H()*.035))),gp=Math.round(bh*1.9),fs=Math.round(bh*.8),tot=d.length*gp,y0=(H()-tot)/2,lw=Math.min(wt*.28,Math.max(...d.map(e=>e.n.length))*fs*.6+10),bx=x0+lw,bw=wt-lw-fs*3,track=gelap()?"#2b3150":"#e5e8f2",tc0=gelap()?"#f1f3ff":"#20243a",out=[];
 d.forEach((e,i)=>{const y=y0+i*gp,c=BPAL[i%BPAL.length];out.push(text(e.n,x0,y+(bh-fs*1.2)/2,fs,tc0,{name:"Nama "+e.n}));
  out.push(shape("rect",bx,y,bw,bh,track,{name:"Jalur "+e.n,rx:bh/2}));if(e.v>0)out.push(shape("rect",bx,y,Math.max(bh,bw*e.v/100),bh,c,{name:"Isi "+e.n,rx:bh/2}));
  out.push(text(R(e.v)+"%",bx+bw+fs*.6,y+(bh-fs*1.2)/2,fs,tc0,{name:"Nilai "+e.n,bold:true}));});
 finish(grup(out,"Bilah skor"),"Bilah skor","Bilah skor "+d.length+" baris");}
MENUS.skor96=()=>[{h:"Daftar bilah persentase",items:[it("Buat bilah skor dari daftar…",skor,"scorebars"),it("Warna bilah bergilir 6 warna; mengikuti latar terang/gelap",()=>{},"info",{keep:1})]}];

/* ================= tombol & grup ================= */
BT.push(["cincin96","rings","Cincin"],["roset96","petal","Roset"],["jaring96","network","Jaring"],["radar96","radar","Radar"],["dial96","dial","Dial"],["skor96","scorebars","Bilah Skor"]);
const defHub=(id,icon,nama,keys)=>{const i=M.HUBS.findIndex(h=>h[0]==="ritme");M.HUBS.splice(i<0?M.HUBS.length:i+1,0,[id,icon,nama,keys]);
 MENUS["hub_"+id]=()=>[{h:nama,items:keys.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($(`[data-menu="hub_${id}"]`),k),0));})}];};
defHub("datavisual96","gaugechart","Data Visual",["radar96","dial96","skor96"]);
defHub("geometri96","rosette","Geometri Hias",["cincin96","roset96","jaring96"]);
CDMS.GeometriHias={cincin,roset,jaring,radar,dial,skor};
})();
