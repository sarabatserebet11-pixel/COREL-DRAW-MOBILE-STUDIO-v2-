/* V123: Mode Excel — lembar kerja bergaya Office (pita bertab, seleksi rentang, rumus, format, banyak lembar) */
(()=>{
 const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
 const dash=$('#dashboard'), editor=$('#editor'), view=$('#excelMode'), sheetBox=$('#excelSheet');
 if(!dash||!view||!sheetBox)return;
 const ROWS=60, COLS=26, STORE='cdms-excel-sheet';
 const letters=n=>{let s='';while(n){n--;s=String.fromCharCode(65+n%26)+s;n=Math.floor(n/26)}return s};
 const key=(r,c)=>letters(c)+r;
 const parse=a=>{const m=/^([A-Z]+)(\d+)$/.exec(a);if(!m)return null;let c=0;for(const x of m[1])c=c*26+x.charCodeAt(0)-64;return{r:+m[2],c};};
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let book={sheets:[{name:'Lembar1',data:{},styles:{}}],active:0,zoom:100,title:'Buku1'};
 let sel={a:{r:1,c:1},f:{r:1,c:1}}, editing=false, saveTimer=0, internalClip=null, cellEls={}, colHd=[], rowHd=[];
 const sh=()=>book.sheets[book.active];
 let undoSt=[],redoSt=[];
 const snapStr=()=>JSON.stringify({i:book.active,d:sh().data,s:sh().styles,w:sh().widths||{},c:sh().cf||[]});
 function snap(){undoSt.push(snapStr());if(undoSt.length>60)undoSt.shift();redoSt=[];}
 function restoreSnap(str){const o=JSON.parse(str);book.active=Math.min(o.i,book.sheets.length-1);sh().data=o.d;sh().styles=o.s;sh().widths=o.w;sh().cf=o.c||[];renderTabs();applyWidths();refreshAll();paintSel();touch();}
 function undo(){if(!undoSt.length){toast('Tidak ada yang bisa diurungkan.');return;}redoSt.push(snapStr());restoreSnap(undoSt.pop());}
 function redo(){if(!redoSt.length)return;undoSt.push(snapStr());restoreSnap(redoSt.pop());}
 const raw=ref=>sh().data[ref]??'';

 /* ---------- Rumus ---------- */
 const FN={
  SUM:a=>a.reduce((x,y)=>x+y,0), AVERAGE:a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0,
  MIN:a=>a.length?Math.min(...a):0, MAX:a=>a.length?Math.max(...a):0, COUNT:a=>a.length,
  ABS:a=>Math.abs(a[0]), SQRT:a=>Math.sqrt(a[0]), ROUND:a=>{const p=Math.pow(10,a[1]||0);return Math.round(a[0]*p)/p;},
  MEDIAN:a=>{if(!a.length)return 0;const b=[...a].sort((x,y)=>x-y),m=b.length>>1;return b.length%2?b[m]:(b[m-1]+b[m])/2;},
  PRODUCT:a=>a.reduce((x,y)=>x*y,a.length?1:0), INT:a=>Math.floor(a[0]), MOD:a=>a[0]-a[1]*Math.floor(a[0]/a[1]), POWER:a=>Math.pow(a[0],a[1]),
  ROUNDUP:a=>{const p=Math.pow(10,a[1]||0);return Math.ceil(a[0]*p)/p;}, ROUNDDOWN:a=>{const p=Math.pow(10,a[1]||0);return Math.floor(a[0]*p)/p;},
  /* V149: fungsi tambahan */
  SIGN:a=>Math.sign(a[0]), EXP:a=>Math.exp(a[0]), LN:a=>{if(!(a[0]>0))throw new Error('#NUM!');return Math.log(a[0]);}, LOG10:a=>{if(!(a[0]>0))throw new Error('#NUM!');return Math.log10(a[0]);},
  SIN:a=>Math.sin(a[0]), COS:a=>Math.cos(a[0]), TAN:a=>Math.tan(a[0]), RADIANS:a=>a[0]*Math.PI/180, DEGREES:a=>a[0]*180/Math.PI,
  CEILING:a=>{const s=a[1]===undefined?1:a[1];if(!s)return 0;return Math.ceil(a[0]/s)*s;}, FLOOR:a=>{const s=a[1]===undefined?1:a[1];if(!s)return 0;return Math.floor(a[0]/s)*s;},
  FACT:a=>{const n=Math.floor(a[0]);if(!(n>=0&&n<=170))throw new Error('#NUM!');let r=1;for(let i=2;i<=n;i++)r*=i;return r;},
  SUMSQ:a=>a.reduce((x,y)=>x+y*y,0), RAND:()=>Math.random(), RANDBETWEEN:a=>{const lo=Math.ceil(Math.min(a[0],a[1])),hi=Math.floor(Math.max(a[0],a[1]));return lo+Math.floor(Math.random()*(hi-lo+1));},
  LARGE:a=>{const k=a[a.length-1],b=a.slice(0,-1).sort((x,y)=>y-x);if(!(k>=1&&k<=b.length))throw new Error('#NUM!');return b[k-1];},
  SMALL:a=>{const k=a[a.length-1],b=a.slice(0,-1).sort((x,y)=>x-y);if(!(k>=1&&k<=b.length))throw new Error('#NUM!');return b[k-1];},
  VAR:a=>{if(a.length<2)throw new Error('#DIV/0!');const m=a.reduce((x,y)=>x+y,0)/a.length;return a.reduce((x,y)=>x+(y-m)*(y-m),0)/(a.length-1);},
  STDEV:a=>{if(a.length<2)throw new Error('#DIV/0!');const m=a.reduce((x,y)=>x+y,0)/a.length;return Math.sqrt(a.reduce((x,y)=>x+(y-m)*(y-m),0)/(a.length-1));}
 };
 /* V128: fungsi teks/logika/bersyarat menerima nilai mentah (tidak diratakan jadi angka) */
 const flat1=a=>a.flat(2);
 const matchCrit=(v,c)=>{const m=/^(<=|>=|<>|<|>|=)?(.*)$/.exec(String(c)),op=m[1]||'=',x=m[2],n=Number(x.replace(',','.')),isN=x.trim()!==''&&Number.isFinite(n);
  if(isN&&typeof v==='number'){switch(op){case'>':return v>n;case'<':return v<n;case'>=':return v>=n;case'<=':return v<=n;case'<>':return v!==n;default:return v===n;}}
  const a=String(v).toLowerCase(),b=x.toLowerCase();return op==='<>'?a!==b:op==='='?a===b:false;};
 const mAll=(n,p)=>{if(p.length%2||!p.length)throw new Error('#VALUE!');const m=Array(n).fill(true);for(let k=0;k<p.length;k+=2){const a=flat1([p[k]]);if(a.length!==n)throw new Error('#VALUE!');a.forEach((v,i)=>{if(!(v!==''&&matchCrit(v,p[k+1])))m[i]=false;});}return m;};
 const XFN={
  COUNTIF:(r,c)=>flat1([r]).filter(v=>v!==''&&matchCrit(v,c)).length,
  SUMIF:(r,c,s)=>{const a=flat1([r]),b=s===undefined?a:flat1([s]);return a.reduce((t,v,i)=>t+(v!==''&&matchCrit(v,c)&&typeof b[i]==='number'?b[i]:0),0);},
  AND:(...a)=>flat1(a).every(Boolean), OR:(...a)=>flat1(a).some(Boolean), NOT:a=>!a,
  LEN:a=>String(a).length, UPPER:a=>String(a).toUpperCase(), LOWER:a=>String(a).toLowerCase(), TRIM:a=>String(a).trim().replace(/\s+/g,' '),
  CONCAT:(...a)=>flat1(a).join(''), LEFT:(a,n)=>String(a).slice(0,n===undefined?1:n), RIGHT:(a,n)=>{n=n===undefined?1:n;return n<=0?'':String(a).slice(-n);},
  COUNTA:(...a)=>flat1(a).filter(v=>v!=='').length, COUNTBLANK:(...a)=>flat1(a).filter(v=>v==='').length,
  VLOOKUP:(k,r,i,ex)=>{const w=r.w||1,n=Math.round(i);if(!(n>=1&&n<=w))throw new Error('#REF!');const exact=ex===0||ex===false;let best=-1;
   for(let j=0;j*w<r.length;j++){const v=r[j*w];if(v===''&&k!=='')continue;if(String(v).toLowerCase()===String(k).toLowerCase()){best=j;break;}if(!exact&&typeof v==='number'&&typeof k==='number'&&v<=k&&(best<0||v>r[best*w]))best=j;}
   if(best<0)throw new Error('#N/A');const out=r[best*w+n-1];return out;},
  MID:(t,s,n)=>{s=Math.floor(s);n=Math.floor(n);if(!(s>=1&&n>=0))throw new Error('#VALUE!');return String(t).substr(s-1,n);},
  FIND:(f,t,s)=>{const i=String(t).indexOf(String(f),(s||1)-1);if(i<0)throw new Error('#VALUE!');return i+1;},
  SEARCH:(f,t,s)=>{const i=String(t).toLowerCase().indexOf(String(f).toLowerCase(),(s||1)-1);if(i<0)throw new Error('#VALUE!');return i+1;},
  SUBSTITUTE:(t,a,b)=>a===''?String(t):String(t).split(String(a)).join(String(b)),
  REPT:(t,n)=>{n=Math.floor(n);if(!(n>=0&&n<=1000))throw new Error('#VALUE!');return String(t).repeat(n);},
  PROPER:t=>String(t).toLowerCase().replace(/(^|[^a-z\u00c0-\u024f])([a-z\u00c0-\u024f])/g,(m,a,b)=>a+b.toUpperCase()),
  VALUE:t=>{const n=Number(String(t).trim().replace(',','.'));if(!Number.isFinite(n)||String(t).trim()==='')throw new Error('#VALUE!');return n;},
  EXACT:(a,b)=>String(a)===String(b), CONCATENATE:(...a)=>flat1(a).join(''),
  ISNUMBER:a=>typeof a==='number', ISTEXT:a=>typeof a==='string'&&a!=='',
  AVERAGEIF:(r,c,s)=>{const a=flat1([r]),b=s===undefined?a:flat1([s]);let t=0,n=0;a.forEach((v,i)=>{if(v!==''&&matchCrit(v,c)&&typeof b[i]==='number'){t+=b[i];n++;}});if(!n)throw new Error('#DIV/0!');return t/n;},
  INDEX:(r,i,j)=>{const w=r.w||1,rows=Math.ceil(r.length/w);i=Math.floor(i);let idx;if(j===undefined||j===0){if(w===1||rows===1)idx=i-1;else throw new Error('#REF!');}else{j=Math.floor(j);if(i<1||i>rows||j<1||j>w)throw new Error('#REF!');idx=(i-1)*w+(j-1);}if(idx<0||idx>=r.length)throw new Error('#REF!');return r[idx]===''?0:r[idx];},
  MATCH:(k,r,t)=>{const a=flat1([r]);if(t===0||t===false){const i=a.findIndex(v=>v!==''&&String(v).toLowerCase()===String(k).toLowerCase());if(i<0)throw new Error('#N/A');return i+1;}let best=-1;a.forEach((v,i)=>{if(typeof v===typeof k&&v!==''&&v<=k)best=i;});if(best<0)throw new Error('#N/A');return best+1;},
  /* V159: fungsi bersyarat banyak kriteria, pencarian, dan lainnya */
  SUMIFS:(s,...p)=>{const b=flat1([s]),m=mAll(b.length,p);return b.reduce((t,v,i)=>t+(m[i]&&typeof v==='number'?v:0),0);},
  COUNTIFS:(...p)=>{const n=flat1([p[0]]).length,m=mAll(n,p);return m.filter(Boolean).length;},
  AVERAGEIFS:(s,...p)=>{const b=flat1([s]),m=mAll(b.length,p);let t=0,n=0;b.forEach((v,i)=>{if(m[i]&&typeof v==='number'){t+=v;n++;}});if(!n)throw new Error('#DIV/0!');return t/n;},
  MAXIFS:(s,...p)=>{const b=flat1([s]),m=mAll(b.length,p),a=b.filter((v,i)=>m[i]&&typeof v==='number');return a.length?Math.max(...a):0;},
  MINIFS:(s,...p)=>{const b=flat1([s]),m=mAll(b.length,p),a=b.filter((v,i)=>m[i]&&typeof v==='number');return a.length?Math.min(...a):0;},
  XLOOKUP:(k,lr,rr,nf)=>{const a=flat1([lr]),b=flat1([rr]);const i=a.findIndex(v=>v!==''&&String(v).toLowerCase()===String(k).toLowerCase());if(i<0){if(nf!==undefined)return nf;throw new Error('#N/A');}if(i>=b.length)throw new Error('#REF!');return b[i]===''?0:b[i];},
  IFS:(...a)=>{if(a.length%2)throw new Error('#N/A');for(let i=0;i<a.length;i+=2)if(a[i])return a[i+1];throw new Error('#N/A');},
  CHOOSE:(i,...a)=>{i=Math.floor(i);if(!(i>=1&&i<=a.length))throw new Error('#VALUE!');return a[i-1];},
  SUMPRODUCT:(...r)=>{const L=r.map(x=>flat1([x]));if(L.some(x=>x.length!==L[0].length))throw new Error('#VALUE!');return L[0].reduce((t,_,i)=>t+L.reduce((p,x)=>p*(typeof x[i]==='number'?x[i]:0),1),0);},
  RANK:(x,r,o)=>{const a=flat1([r]).filter(v=>typeof v==='number');if(!a.includes(x))throw new Error('#N/A');return 1+a.filter(v=>o?v<x:v>x).length;},
  TEXTJOIN:(d,ig,...a)=>flat1(a).filter(v=>!(ig&&v==='')).join(String(d)),
  ROWS:r=>Math.ceil(r.length/(r.w||1)), COLUMNS:r=>r.w||1,
  NOW:()=>new Date().toLocaleString('id-ID'),
  TODAY:()=>{const d=new Date();return d.toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'});}, PI:()=>Math.PI
 };
 const NUMFN=new Set(Object.keys(FN));
 function evalFormula(expr,stack){
  const toks=expr.match(/"[^"]*"|[A-Za-z]+\d+:[A-Za-z]+\d+|[A-Za-z]+\d+|[A-Za-z_]+|\d+\.?\d*|<=|>=|<>|[-+*/^%(),;<>=&]|\s+|./g)||[];
  let out='',pend=false;const frames=[];
  for(const t of toks){
   if(/^\s+$/.test(t))continue;
   if(/^"/.test(t))out+=JSON.stringify(t.slice(1,-1));
   else if(/^[A-Za-z]+\d+:[A-Za-z]+\d+$/.test(t)){const[a,b]=t.toUpperCase().split(':');out+=`R("${a}","${b}")`;}
   else if(/^[A-Za-z]+\d+$/.test(t))out+=`V("${t.toUpperCase()}")`;
   else if(/^[A-Za-z_]+$/.test(t)){const u=t.toUpperCase();if(u==='IF')out+='IF';else if(u==='IFERROR'){pend=true;continue;}else if(NUMFN.has(u))out+=`F.${u}`;else if(XFN[u])out+=`X.${u}`;else if(u==='TRUE'||u==='FALSE')out+=u.toLowerCase();else throw new Error('#NAME?');}
   else if(/^\d/.test(t))out+=t;
   else if(t==='^')out+='**';
   else if(t==='=')out+='==';
   else if(t==='<>')out+='!=';
   else if(t==='&')out+='+""+';
   else if(t==='%')out+='/100';
   else if(t==='('){frames.push(pend);out+=pend?'IFE(()=>(':'(';pend=false;}
   else if(t===','||t===';'){out+=frames.length&&frames[frames.length-1]?'),()=>(':',';}
   else if(t===')'){out+=frames.length&&frames.pop()?'))':')';}
   else if('+-*/<>'.includes(t)||t==='<='||t==='>=')out+=t;
   else throw new Error('#ERROR');
  }
  const flat=a=>a.flat(2);
  const num=x=>{const n=Number(x);return Number.isFinite(n)&&x!==''&&x!==null?n:null;};
  const V=ref=>{const v=val(ref,stack);if(typeof v==='string'&&v.startsWith('#'))throw new Error(v);return v===''?0:v;};
  const R=(a,b)=>{const A=parse(a),B=parse(b),o=[];for(let r=Math.min(A.r,B.r);r<=Math.max(A.r,B.r);r++)for(let c=Math.min(A.c,B.c);c<=Math.max(A.c,B.c);c++){const v=val(key(r,c),stack);if(typeof v==='string'&&v.startsWith('#'))throw new Error(v);o.push(v);}o.w=Math.abs(B.c-A.c)+1;return o;};
  const F=new Proxy({},{get:(_,name)=>(...args)=>{const a=flat(args).map(num).filter(x=>x!==null);const r=FN[name](a);if(Number.isNaN(r))throw new Error('#ERROR');return r;}});
  const IF=(c,a,b)=>c?a:b;
  const IFE=(a,b)=>{try{const r=a();if(typeof r==='number'&&!Number.isFinite(r))return b();if(typeof r==='string'&&r.startsWith('#'))return b();return r;}catch(_){return b();}};
  const r=Function('V','R','F','IF','X','IFE','"use strict";return ('+out+')')(V,R,F,IF,XFN,IFE);
  if(typeof r==='number'&&!Number.isFinite(r))throw new Error('#DIV/0!');
  return r;
 }
 function val(ref,stack=[]){
  if(stack.includes(ref))return'#CYCLE!';
  const v=raw(ref);
  if(typeof v==='string'&&v.startsWith('=')){try{return evalFormula(v.slice(1),[...stack,ref]);}catch(e){return/^#/.test(e.message)?e.message:'#ERROR';}}
  if(v==='')return'';
  const n=Number(String(v).replace(',','.'));
  return String(v).trim()!==''&&Number.isFinite(n)?n:v;
 }
 function fmtNum(v,f){
  if(typeof v!=='number')return String(v);
  switch(f){
   case'num':return v.toLocaleString('id-ID',{minimumFractionDigits:2,maximumFractionDigits:2});
   case'idr':return'Rp '+v.toLocaleString('id-ID',{maximumFractionDigits:0});
   case'int':return Math.round(v).toLocaleString('id-ID');
   case'usd':return'$ '+v.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
   case'pct':return(v*100).toLocaleString('id-ID',{maximumFractionDigits:1})+'%';
   default:return Number.isInteger(v)?String(v):String(+v.toFixed(8));
  }
 }
 const display=ref=>{const v=val(ref);return v===''?'':fmtNum(v,(sh().styles[ref]||{}).fmt);};

 /* ---------- Render ---------- */
 function build(){
  let h='<table><colgroup><col class="c-rh">'+Array.from({length:COLS},()=>'<col class="c-w">').join('')+'</colgroup><thead><tr><th class="corner" data-all="1"></th>';
  for(let c=1;c<=COLS;c++)h+=`<th data-col="${c}">${letters(c)}<span class="rz" data-rz="${c}"></span></th>`;
  h+='</tr></thead><tbody>';
  for(let r=1;r<=ROWS;r++){h+=`<tr><th data-row="${r}">${r}</th>`;for(let c=1;c<=COLS;c++)h+=`<td data-cell="${key(r,c)}"></td>`;h+='</tr>';}
  sheetBox.innerHTML=h+'</tbody></table>';
  cellEls={};sheetBox.querySelectorAll('td').forEach(td=>cellEls[td.dataset.cell]=td);
  colHd=[null,...sheetBox.querySelectorAll('thead th[data-col]')];rowHd=[null,...sheetBox.querySelectorAll('tbody th[data-row]')];
  applyZoom();applyWidths();refreshAll();paintSel();
 }
 function applyWidths(){const cols=sheetBox.querySelectorAll('col.c-w'),w=sh().widths||{};cols.forEach((el,i)=>{const x=w[i+1];el.style.width=x?`calc(${x}px*var(--z))`:'';});}
 function cfMatch(r,v){
  if(v==='')return false;const n=typeof v==='number'?v:NaN,x=Number(r.val);
  switch(r.op){case'>':return n>x;case'<':return n<x;case'>=':return n>=x;case'<=':return n<=x;
   case'=':return Number.isFinite(x)&&Number.isFinite(n)?n===x:String(v).toLowerCase()===String(r.val).toLowerCase();
   case'~':return String(v).toLowerCase().includes(String(r.val).toLowerCase());}
  return false;}
 function paintCell(ref){
  const td=cellEls[ref];if(!td)return;const st=sh().styles[ref]||{},v=val(ref);
  td.textContent=display(ref);
  td.style.boxShadow=st.bd?'inset 0 0 0 1.5px #222':'';if(st.note){td.title=st.note;td.classList.add('has-note');}else{td.removeAttribute('title');td.classList.remove('has-note');}td.style.fontSize=st.fs?'calc('+st.fs+'px*var(--z))':'';td.style.whiteSpace=st.wrap?'normal':'';td.style.wordBreak=st.wrap?'break-word':'';td.style.verticalAlign=st.wrap?'top':'';td.style.fontWeight=st.b?'700':'';td.style.fontStyle=st.i?'italic':'';td.style.textDecoration=st.u?'underline':'';
  let bg=st.fill||'',fc=st.color||'';
  if(sh().cf&&sh().cf.length){const p=parse(ref);for(const r of sh().cf){if(p.r<r.r1||p.r>r.r2||p.c<r.c1||p.c>r.c2)continue;if(cfMatch(r,v)){bg=r.bg;fc=r.fg;}}}
  td.style.background=bg;td.style.color=fc;
  td.style.textAlign=st.align||(typeof v==='number'?'right':'');
  td.classList.toggle('err',typeof v==='string'&&v.startsWith('#'));
 }
 function refreshAll(){for(const ref in cellEls)paintCell(ref);afterRefresh();}
 const rng=()=>({r1:Math.min(sel.a.r,sel.f.r),r2:Math.max(sel.a.r,sel.f.r),c1:Math.min(sel.a.c,sel.f.c),c2:Math.max(sel.a.c,sel.f.c)});
 function eachSel(fn){const g=rng();for(let r=g.r1;r<=g.r2;r++)for(let c=g.c1;c<=g.c2;c++)fn(key(r,c),r,c);}
 function paintSel(){
  sheetBox.querySelectorAll('td.in-sel,td.active').forEach(x=>x.classList.remove('in-sel','active','sel-t','sel-b','sel-l','sel-r'));
  colHd.forEach(x=>x&&x.classList.remove('hl'));rowHd.forEach(x=>x&&x.classList.remove('hl'));
  const g=rng();
  eachSel((ref,r,c)=>{const td=cellEls[ref];if(!td)return;td.classList.add('in-sel');if(r===g.r1)td.classList.add('sel-t');if(r===g.r2)td.classList.add('sel-b');if(c===g.c1)td.classList.add('sel-l');if(c===g.c2)td.classList.add('sel-r');});
  const a=cellEls[key(sel.a.r,sel.a.c)];if(a)a.classList.add('active');
  for(let c=g.c1;c<=g.c2;c++)colHd[c]&&colHd[c].classList.add('hl');
  for(let r=g.r1;r<=g.r2;r++)rowHd[r]&&rowHd[r].classList.add('hl');
  const ref=key(sel.a.r,sel.a.c),multi=g.r1!==g.r2||g.c1!==g.c2;
  $('#excelCellName').textContent=multi?`${key(g.r1,g.c1)}:${key(g.r2,g.c2)}`:ref;
  if(!editing)$('#excelFormula').value=raw(ref);
  const st=sh().styles[ref]||{};
  $$('[data-excel-cmd]').forEach(b=>{const k=b.dataset.excelCmd;if(['b','i','u'].includes(k))b.classList.toggle('on',!!st[k]);if(k.startsWith('align-'))b.classList.toggle('on',st.align===k.slice(6));});
  const fm=$('#excelFmt');if(fm)fm.value=st.fmt||'';
  const fz=$('#excelFs');if(fz)fz.value=st.fs||'';
  stats();
 }
 function stats(){
  const g=rng(),nums=[];let cnt=0;
  eachSel(ref=>{const v=val(ref);if(v!==''){cnt++;if(typeof v==='number')nums.push(v);}});
  const box=$('#excelStats');
  if(cnt<2||!nums.length){box.textContent=cnt>1?`Hitung: ${cnt}`:'';return;}
  const sum=nums.reduce((a,b)=>a+b,0);
  const f=x=>x.toLocaleString('id-ID',{maximumFractionDigits:2});
  box.textContent=`Rata-rata: ${f(sum/nums.length)}   Hitung: ${cnt}   Jumlah: ${f(sum)}`;
 }
 function scrollTo(ref){const td=cellEls[ref],wrap=$('.excel-sheet-wrap');if(!td||!wrap)return;
  const t=td.getBoundingClientRect(),w=wrap.getBoundingClientRect(),hh=30,rw=44;
  if(t.top<w.top+hh)wrap.scrollTop-=w.top+hh-t.top+4;else if(t.bottom>w.bottom)wrap.scrollTop+=t.bottom-w.bottom+4;
  if(t.left<w.left+rw)wrap.scrollLeft-=w.left+rw-t.left+4;else if(t.right>w.right)wrap.scrollLeft+=t.right-w.right+4;}
 function moveTo(r,c,extend){
  r=Math.max(1,Math.min(ROWS,r));c=Math.max(1,Math.min(COLS,c));
  if(extend)sel.f={r,c};else sel={a:{r,c},f:{r,c}};
  paintSel();scrollTo(key(r,c));
 }

 /* ---------- Edit sel ---------- */
 const ed=document.createElement('input');ed.className='excel-editor';ed.autocomplete='off';ed.spellcheck=false;ed.setAttribute('aria-label','Edit sel');
 function startEdit(initial){
  const ref=key(sel.a.r,sel.a.c),td=cellEls[ref];if(!td)return;
  const dv0=dvFor(ref);if(dv0&&initial===undefined){openDv(td,dv0,ref);return;}
  editing=true;const wrap=$('.excel-sheet-wrap');
  td.appendChild(ed);ed.value=initial!==undefined?initial:raw(ref);
  const cs=getComputedStyle(td);ed.style.textAlign=td.style.textAlign||'left';ed.style.fontWeight=cs.fontWeight;ed.style.fontStyle=cs.fontStyle;
  td.classList.add('editing');ed.focus();if(initial===undefined)ed.setSelectionRange(ed.value.length,ed.value.length);
  $('#excelFormula').value=ed.value;
 }
 function endEdit(commit){
  if(!editing)return;editing=false;const td=ed.parentElement;
  const ref=td?td.dataset.cell:key(sel.a.r,sel.a.c),v=ed.value;
  if(td){td.classList.remove('editing');}
  ed.remove();
  if(commit){const d=dvFor(ref);if(d&&v!==''&&v[0]!=='='&&!d.list.some(x=>x.toLowerCase()===v.toLowerCase()))toast('Nilai harus salah satu: '+d.list.join(', '));else setCell(ref,v);}
  sheetBox.parentElement.focus({preventScroll:true});
 }
 function setCell(ref,v,silent){
  if(!silent&&(raw(ref)!==(v==null?'':v)))snap();
  if(v===''||v==null)delete sh().data[ref];else sh().data[ref]=v;
  if(!silent){refreshAll();paintSel();touch();}
 }
 ed.addEventListener('input',()=>{$('#excelFormula').value=ed.value;});
 ed.addEventListener('keydown',e=>{
  if(e.key==='Enter'){e.preventDefault();e.stopPropagation();endEdit(true);moveTo(sel.a.r+(e.shiftKey?-1:1),sel.a.c);}
  else if(e.key==='Tab'){e.preventDefault();e.stopPropagation();endEdit(true);moveTo(sel.a.r,sel.a.c+(e.shiftKey?-1:1));}
  else if(e.key==='Escape'){e.preventDefault();e.stopPropagation();endEdit(false);paintSel();}
 });
 ed.addEventListener('blur',()=>{if(editing&&document.activeElement!==$('#excelFormula'))endEdit(true);});
 ed.addEventListener('mousedown',e=>e.stopPropagation());

 const fb=$('#excelFormula');
 fb.addEventListener('keydown',e=>{
  if(e.key==='Enter'){e.preventDefault();const ref=key(sel.a.r,sel.a.c);if(editing){editing=false;ed.parentElement&&ed.parentElement.classList.remove('editing');ed.remove();}setCell(ref,fb.value);moveTo(sel.a.r+1,sel.a.c);sheetBox.parentElement.focus({preventScroll:true});}
  else if(e.key==='Escape'){fb.value=raw(key(sel.a.r,sel.a.c));sheetBox.parentElement.focus({preventScroll:true});}
 });
 fb.addEventListener('input',()=>{if(editing)ed.value=fb.value;});

 /* ---------- Pointer / keyboard ---------- */
 let dragging=false,rangeMode=false,tapEdit=null;
  let rz=null;
 sheetBox.addEventListener('pointerdown',e=>{
  const h=e.target.closest('.rz');
  if(h){e.preventDefault();e.stopPropagation();endEdit(true);const c=+h.dataset.rz,th=h.parentElement;rz={c,x:e.clientX,w:th.getBoundingClientRect().width/(book.zoom/100),moved:false};try{h.setPointerCapture(e.pointerId);}catch(_){}return;}
  const td=e.target.closest('td[data-cell]'),ch=e.target.closest('th[data-col]'),rh=e.target.closest('th[data-row]'),all=e.target.closest('th[data-all]');
  if(td){
   if(e.target===ed)return;
   const p=parse(td.dataset.cell),same=!editing&&p.r===sel.a.r&&p.c===sel.a.c&&sel.a.r===sel.f.r&&sel.a.c===sel.f.c;
   if(editing)endEdit(true);
   if(rangeMode||e.shiftKey)sel.f=p;else if(same&&e.pointerType!=='mouse'){tapEdit={x:e.clientX,y:e.clientY};return;}else sel={a:p,f:p};
   dragging=e.pointerType==='mouse';paintSel();sheetBox.parentElement.focus({preventScroll:true});
  }else if(ch){endEdit(true);const c=+ch.dataset.col;sel={a:{r:1,c},f:{r:ROWS,c}};paintSel();}
  else if(rh){endEdit(true);const r=+rh.dataset.row;sel={a:{r,c:1},f:{r,c:COLS}};paintSel();}
  else if(all){endEdit(true);sel={a:{r:1,c:1},f:{r:ROWS,c:COLS}};paintSel();}
 });
 sheetBox.addEventListener('pointerover',e=>{if(!dragging)return;const td=e.target.closest('td[data-cell]');if(td){sel.f=parse(td.dataset.cell);paintSel();}});
 document.addEventListener('pointermove',e=>{if(!rz)return;const w=Math.max(40,Math.min(400,Math.round(rz.w+(e.clientX-rz.x)/(book.zoom/100))));if(!rz.moved){snap();rz.moved=true;}(sh().widths=sh().widths||{})[rz.c]=w;applyWidths();});
 document.addEventListener('pointerup',e=>{dragging=false;if(tapEdit){const d=Math.hypot(e.clientX-tapEdit.x,e.clientY-tapEdit.y);tapEdit=null;if(d<8)startEdit();}if(rz){if(rz.moved)touch();rz=null;}});
 sheetBox.addEventListener('dblclick',e=>{const h=e.target.closest('.rz');if(h&&sh().widths){snap();delete sh().widths[+h.dataset.rz];applyWidths();touch();}},true);
 sheetBox.addEventListener('dblclick',e=>{const td=e.target.closest('td[data-cell]');if(td&&e.target!==ed)startEdit();});
 const wrap=sheetBox.parentElement;wrap.tabIndex=0;
 wrap.addEventListener('keydown',e=>{
  if(editing)return;
  const mod=e.ctrlKey||e.metaKey,k=e.key;
  if(mod){
   if(k==='b'||k==='B'){e.preventDefault();cmd('b');return;}
   if(k==='i'||k==='I'){e.preventDefault();cmd('i');return;}
   if(k==='u'||k==='U'){e.preventDefault();cmd('u');return;}
   if(k==='a'||k==='A'){e.preventDefault();sel={a:{r:1,c:1},f:{r:ROWS,c:COLS}};paintSel();return;}
   if(k==='s'||k==='S'){e.preventDefault();save();return;}
   if(k==='z'||k==='Z'){e.preventDefault();e.shiftKey?redo():undo();return;}
   if(k==='y'||k==='Y'){e.preventDefault();redo();return;}
   if(k==='d'||k==='D'){e.preventDefault();fill('d');return;}
   if(k==='r'||k==='R'){e.preventDefault();fill('r');return;}
   return;
  }
  const ext=e.shiftKey;
  switch(k){
   case'ArrowUp':e.preventDefault();ext?moveTo(sel.f.r-1,sel.f.c,true):moveTo(sel.a.r-1,sel.a.c);break;
   case'ArrowDown':e.preventDefault();ext?moveTo(sel.f.r+1,sel.f.c,true):moveTo(sel.a.r+1,sel.a.c);break;
   case'ArrowLeft':e.preventDefault();ext?moveTo(sel.f.r,sel.f.c-1,true):moveTo(sel.a.r,sel.a.c-1);break;
   case'ArrowRight':e.preventDefault();ext?moveTo(sel.f.r,sel.f.c+1,true):moveTo(sel.a.r,sel.a.c+1);break;
   case'Enter':e.preventDefault();moveTo(sel.a.r+(ext?-1:1),sel.a.c);break;
   case'Tab':e.preventDefault();moveTo(sel.a.r,sel.a.c+(ext?-1:1));break;
   case'F2':e.preventDefault();startEdit();break;
   case'Delete':case'Backspace':e.preventDefault();snap();eachSel(ref=>{delete sh().data[ref];});refreshAll();paintSel();touch();break;
   default:if(k.length===1&&!e.altKey){e.preventDefault();startEdit(k);}
  }
 });
 /* salin / tempel / potong (TSV) */
 function selText(){const g=rng(),rows=[];for(let r=g.r1;r<=g.r2;r++){const a=[];for(let c=g.c1;c<=g.c2;c++)a.push(raw(key(r,c)));rows.push(a.join('\t'));}return rows.join('\n');}
 wrap.addEventListener('copy',e=>{if(editing)return;e.preventDefault();const g=rng(),st={};eachSel((ref,r,c)=>{st[(r-g.r1)+','+(c-g.c1)]=sh().styles[ref];});const t=selText();e.clipboardData.setData('text/plain',t);internalClip={t,st};});
 wrap.addEventListener('cut',e=>{if(editing)return;e.preventDefault();const g=rng(),st={};eachSel((ref,r,c)=>{st[(r-g.r1)+','+(c-g.c1)]=sh().styles[ref];});const t=selText();e.clipboardData.setData('text/plain',t);internalClip={t,st};snap();eachSel(ref=>{delete sh().data[ref];});refreshAll();paintSel();touch();});
 wrap.addEventListener('paste',e=>{if(editing)return;e.preventDefault();const t=(e.clipboardData.getData('text/plain')||'').replace(/\r/g,'');if(!t)return;
  snap();const rows=t.replace(/\n$/,'').split('\n').map(x=>x.split('\t')),useSt=internalClip&&internalClip.t===t?internalClip.st:null;
  rows.forEach((row,i)=>row.forEach((v,j)=>{const r=sel.a.r+i,c=sel.a.c+j;if(r>ROWS||c>COLS)return;const ref=key(r,c);setCell(ref,v,true);if(useSt&&useSt[i+','+j])sh().styles[ref]={...useSt[i+','+j]};}));
  sel.f={r:Math.min(ROWS,sel.a.r+rows.length-1),c:Math.min(COLS,sel.a.c+rows[0].length-1)};refreshAll();paintSel();touch();});

 /* ---------- Perintah pita ---------- */
 function cmd(k,arg){
  endEdit(true);
  if(k==='undo'){undo();return;}if(k==='redo'){redo();return;}
  if(!/^(sample|newsheet|find|importcsv|filter|unfilter|freezeR|freezeC|unfreeze|dv)$/.test(k))snap();
  const styled=fn=>{eachSel(ref=>{const s=sh().styles[ref]||(sh().styles[ref]={});fn(s);if(!Object.keys(s).length)delete sh().styles[ref];});};
  const first=sh().styles[key(sel.a.r,sel.a.c)]||{};
  switch(k){
   case'freezeR':case'freezeC':case'unfreeze':freezeCmd(k);return;
   case'dv':dvCmd();return;
   case'b':case'i':case'u':{const on=!first[k];styled(s=>{if(on)s[k]=1;else delete s[k];});break;}
   case'align-left':case'align-center':case'align-right':{const a=k.slice(6),on=first.align!==a;styled(s=>{if(on)s.align=a;else delete s.align;});break;}
   case'wrap':{const on=!first.wrap;styled(s=>{if(on)s.wrap=1;else delete s.wrap;});break;}
   case'fs':styled(s=>{if(arg)s.fs=+arg;else delete s.fs;});break;
   case'border':{const on=!first.bd;styled(s=>{if(on)s.bd=1;else delete s.bd;});break;}
   case'borderclear':styled(s=>{delete s.bd;});break;
   case'fill':styled(s=>{if(arg)s.fill=arg;else delete s.fill;});break;
   case'color':styled(s=>{if(arg)s.color=arg;else delete s.color;});break;
   case'fmt':styled(s=>{if(arg)s.fmt=arg;else delete s.fmt;});break;
   case'clearfmt':styled(s=>{for(const x in s)delete s[x];});break;
   case'clear':eachSel(ref=>{delete sh().data[ref];});break;
   case'sortasc':case'sortdesc':sortBy(k==='sortasc');return;
   case'sample':sample();return;
   case'newsheet':newSheet();return;
   case'find':findCell();return;
   case'note':{const cur=(sh().styles[key(sel.a.r,sel.a.c)]||{}).note||'';const t=prompt('Catatan untuk sel '+key(sel.a.r,sel.a.c)+' (kosongkan untuk menghapus):',cur);if(t===null)return;const ref=key(sel.a.r,sel.a.c),stl=sh().styles[ref]||(sh().styles[ref]={});if(t.trim())stl.note=t.trim().slice(0,200);else delete stl.note;if(!Object.keys(stl).length)delete sh().styles[ref];break;}
   case'tovalue':{let n=0;eachSel(ref=>{const v=sh().data[ref];if(typeof v==='string'&&v[0]==='='){const r=val(ref);if(typeof r==='string'&&r[0]==='#')return;sh().data[ref]=String(r);n++;}});toast(n?n+' rumus diubah jadi nilai.':'Tidak ada rumus (yang valid) di pilihan.');break;}
   case'filter':filterRows();return;
   case'unfilter':showRows();toast('Filter dihapus.');return;
   case'importcsv':importCsv();return;
   case'series':{const st=prompt('Mulai dari angka:','1');if(st===null)return;const sp=prompt('Selisih tiap sel:','1');if(sp===null)return;const a0=Number(String(st).replace(',','.')),d=Number(String(sp).replace(',','.'));if(!Number.isFinite(a0)||!Number.isFinite(d)){toast('Masukkan angka yang valid.');return;}const g=rng();let v=a0;const one=g.r1===g.r2&&g.c1===g.c2,r2=one?Math.min(ROWS,g.r1+9):g.r2;for(let r=g.r1;r<=r2;r++)for(let c=g.c1;c<=g.c2;c++){sh().data[key(r,c)]=String(+v.toFixed(10));v+=d;}if(one)toast('Satu sel dipilih: 10 sel ke bawah diisi.');break;}
   case'dedupe':{const g=rng(),seen=new Set();let n=0;for(let r=g.r1;r<=g.r2;r++){const row=[];for(let c=g.c1;c<=g.c2;c++)row.push(String(raw(key(r,c))));const sig=row.join('\u0001');if(sig.replace(/\u0001/g,'')==='')continue;if(seen.has(sig)){for(let c=g.c1;c<=g.c2;c++)delete sh().data[key(r,c)];n++;}else seen.add(sig);}toast(n?n+' baris duplikat dikosongkan.':'Tidak ada duplikat di rentang.');break;}
   case'replaceall':replaceAll();return;
   case'insrow':shiftSheet('r',sel.a.r,1);return;
   case'inscol':shiftSheet('c',sel.a.c,1);return;
   case'delrow':shiftSheet('r',rng().r1,-(rng().r2-rng().r1+1));return;
   case'delcol':shiftSheet('c',rng().c1,-(rng().c2-rng().c1+1));return;
   case'filldown':fill('d');return;
   case'fillright':fill('r');return;
   default:if(/^fn-/.test(k)){autoFn(k.slice(3).toUpperCase());return;}
  }
  refreshAll();paintSel();touch();wrap.focus({preventScroll:true});
 }

 /* V128: cari & ganti */
 let lastFind='';
 function findCell(){
  const q=prompt('Cari teks atau angka di lembar ini:',lastFind);if(q===null||q==='')return;lastFind=q;
  const refs=[];for(let r=1;r<=ROWS;r++)for(let c=1;c<=COLS;c++){const k2=key(r,c);if(raw(k2)!==''&&(String(display(k2)).toLowerCase().includes(q.toLowerCase())||String(raw(k2)).toLowerCase().includes(q.toLowerCase())))refs.push([r,c]);}
  if(!refs.length){toast('Tidak ditemukan: '+q);return;}
  const cur=(sel.a.r-1)*COLS+sel.a.c,nx=refs.find(x=>(x[0]-1)*COLS+x[1]>cur)||refs[0];
  sel={a:{r:nx[0],c:nx[1]},f:{r:nx[0],c:nx[1]}};paintSel();const td=cellEls[key(nx[0],nx[1])];if(td&&td.scrollIntoView)td.scrollIntoView({block:'center',inline:'center'});
  toast(refs.length+' hasil — ketuk Cari lagi untuk berikutnya');
 }
 function replaceAll(){
  const q=prompt('Cari teks:',lastFind);if(!q)return;const w=prompt('Ganti dengan:','');if(w===null)return;lastFind=q;
  const re=new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi');let n=0;
  const g=rng(),one=g.r1===g.r2&&g.c1===g.c2;
  for(let r=one?1:g.r1;r<=(one?ROWS:g.r2);r++)for(let c=one?1:g.c1;c<=(one?COLS:g.c2);c++){const k2=key(r,c),v=sh().data[k2];if(typeof v==='string'&&v[0]!=='='&&re.test(v)){re.lastIndex=0;sh().data[k2]=v.replace(re,()=>{n++;return w;});}re.lastIndex=0;}
  toast(n?n+' penggantian'+(one?' di seluruh lembar.':' di rentang terpilih.'):'Tidak ada yang cocok (rumus tidak diubah).');
 }

 /* V159: bekukan panel & validasi data (daftar pilihan) */
 function applyFreeze(){
  const f=sh().frz||{},hh=colHd[1]?colHd[1].offsetHeight:26,rw=rowHd[1]?rowHd[1].offsetWidth:46;
  for(const ref in cellEls){const td=cellEls[ref],p=parse(ref),r1=!!f.r&&p.r===1,c1=!!f.c&&p.c===1;
   if(r1||c1){td.style.position='sticky';td.style.top=r1?hh+'px':'';td.style.left=c1?rw+'px':'';td.style.zIndex=r1&&c1?'2':'1';}
   else if(td.style.position==='sticky'){td.style.position='';td.style.top='';td.style.left='';td.style.zIndex='';}
   td.classList.toggle('frz-r',r1);td.classList.toggle('frz-c',c1);}
 }
 const dvFor=ref=>{const p=parse(ref);return(sh().dv||[]).find(d=>p.r>=d.r1&&p.r<=d.r2&&p.c>=d.c1&&p.c<=d.c2)||null;};
 function afterRefresh(){applyFreeze();for(const ref in cellEls)cellEls[ref].classList.toggle('has-dv',!!dvFor(ref));}
 function freezeCmd(k){
  if(k==='unfreeze')sh().frz={};else{const f=sh().frz=sh().frz||{};if(k==='freezeR')f.r=!f.r;else f.c=!f.c;}
  applyFreeze();touch();const f=sh().frz||{};toast(f.r||f.c?'Dibekukan:'+(f.r?' baris 1':'')+(f.c?' kolom A':''):'Pembekuan dilepas.');
 }
 function dvCmd(){
  const g=rng(),name=key(g.r1,g.c1)+(g.r1!==g.r2||g.c1!==g.c2?':'+key(g.r2,g.c2):''),cur=dvFor(key(g.r1,g.c1));
  const t=prompt('Daftar pilihan untuk '+name+' (pisahkan dengan koma, mis. Ya, Tidak, Mungkin).\nKosongkan untuk menghapus validasi:',cur?cur.list.join(', '):'');if(t===null)return;
  sh().dv=(sh().dv||[]).filter(d=>!(d.r1>=g.r1&&d.r2<=g.r2&&d.c1>=g.c1&&d.c2<=g.c2));
  const list=[...new Set(t.split(',').map(x=>x.trim()).filter(Boolean))].slice(0,50);
  if(list.length)sh().dv.push({...g,list});
  afterRefresh();touch();toast(list.length?'Daftar pilihan dipasang di '+name+'. Ketuk dua kali sel untuk memilih.':'Validasi dihapus.');
 }
 function openDv(td,d,ref){
  const old=document.getElementById('excelDvPick');if(old)old.remove();
  const s=document.createElement('select');s.id='excelDvPick';s.className='excel-dv';s.size=Math.min(d.list.length+1,7);
  const cur=String(raw(ref));s.innerHTML='<option value="">(kosong)</option>'+d.list.map(x=>`<option${x===cur?' selected':''}>${esc(x)}</option>`).join('');
  const r=td.getBoundingClientRect();s.style.left=Math.min(window.innerWidth-170,Math.max(4,r.left))+'px';s.style.top=Math.min(window.innerHeight-s.size*28-16,r.bottom+2)+'px';
  document.body.appendChild(s);s.focus();
  const done=v=>{s.remove();if(v!==null)setCell(ref,v);sheetBox.parentElement.focus({preventScroll:true});};
  s.addEventListener('change',()=>done(s.value));
  s.addEventListener('click',e=>{if(e.target.tagName==='OPTION')done(s.value);});
  s.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();done(null);}else if(e.key==='Enter'){e.preventDefault();done(s.value);}});
  s.addEventListener('blur',()=>setTimeout(()=>{if(document.body.contains(s))s.remove();},150));
 }

 /* V132: impor CSV / teks tab */
 function parseCsv(t){const rows=[];let row=[],f='',q=false;const d=(t.split('\n')[0].split(';').length>t.split('\n')[0].split(',').length)?';':(t.split('\n')[0].includes('\t')?'\t':',');
  for(let i=0;i<t.length;i++){const c=t[i];if(q){if(c==='"'){if(t[i+1]==='"'){f+='"';i++;}else q=false;}else f+=c;}else if(c==='"')q=true;else if(c===d){row.push(f);f='';}else if(c==='\n'){row.push(f);rows.push(row);row=[];f='';}else if(c!=='\r')f+=c;}
  if(f!==''||row.length){row.push(f);rows.push(row);}return rows;}
 function importCsv(){
  let inp=$('#excelCsvInput');if(!inp){inp=document.createElement('input');inp.type='file';inp.id='excelCsvInput';inp.accept='.csv,.tsv,.txt,text/csv,text/plain';inp.hidden=true;document.body.appendChild(inp);
   inp.addEventListener('change',()=>{const f=inp.files[0];inp.value='';if(!f)return;if(f.size>2*1024*1024){toast('Pilih file maksimum 2 MB.');return;}
    const fr=new FileReader();fr.onload=()=>{const rows=parseCsv(String(fr.result).replace(/^\uFEFF/,''));if(!rows.length){toast('File kosong.');return;}snap();let n=0,cut=false;
     rows.forEach((r,i)=>r.forEach((v,j)=>{const rr=sel.a.r+i,cc=sel.a.c+j;if(rr>ROWS||cc>COLS){cut=true;return;}if(v!==''){sh().data[key(rr,cc)]=v;n++;}}));
     refreshAll();paintSel();touch();toast(n+' sel diimpor mulai dari '+key(sel.a.r,sel.a.c)+(cut?' (sebagian terpotong: lembar 60×26)':'')+'.');};fr.readAsText(f);});}
  inp.click();
 }

 /* V135: filter baris sederhana (tampilan saja, tidak mengubah data) */
 function showRows(){rowHd.forEach(h=>{if(h&&h.parentElement)h.parentElement.style.display='';});}
 function filterRows(){
  const col=sel.a.c,q=prompt('Tampilkan hanya baris yang kolom '+letters(col)+' mengandung (kosongkan = angka/teks apa saja):','');if(q===null)return;
  showRows();if(q==='')return;let hid=0;const ql=q.toLowerCase();
  for(let r=1;r<=ROWS;r++){const used=[...Array(COLS)].some((_,i)=>raw(key(r,i+1))!=='');if(!used)continue;if(!String(display(key(r,col))).toLowerCase().includes(ql)){rowHd[r].parentElement.style.display='none';hid++;}}
  toast(hid?hid+' baris disembunyikan. Data tidak berubah; ketuk Hapus filter untuk menampilkan.':'Semua baris berisi cocok.');
 }

 /* V136: cetak / simpan PDF lembar aktif (area yang terisi) */
 function printSheet(){
  let mr=0,mc=0;for(const k2 in sh().data){if(sh().data[k2]==='')continue;const p=parse(k2);if(p){mr=Math.max(mr,p.r);mc=Math.max(mc,p.c);}}
  if(!mr){toast('Lembar masih kosong.');return;}
  let h='<table><thead><tr><th></th>';for(let c=1;c<=mc;c++)h+='<th>'+letters(c)+'</th>';h+='</tr></thead><tbody>';
  for(let r=1;r<=mr;r++){h+='<tr><th>'+r+'</th>';for(let c=1;c<=mc;c++){const k2=key(r,c),st=sh().styles[k2]||{},v=val(k2);let bg=st.fill||'',fc=st.color||'';
   if(sh().cf)for(const x of sh().cf){const p=parse(k2);if(p.r>=x.r1&&p.r<=x.r2&&p.c>=x.c1&&p.c<=x.c2&&cfMatch(x,v)){bg=x.bg;fc=x.fg;}}
   h+='<td style="'+(bg?'background:'+esc(bg)+';':'')+(fc?'color:'+esc(fc)+';':'')+(st.b?'font-weight:700;':'')+(st.i?'font-style:italic;':'')+(st.u?'text-decoration:underline;':'')+(st.bd?'outline:1.5px solid #222;':'')+'text-align:'+(st.align||(typeof v==='number'?'right':'left'))+'">'+esc(display(k2))+'</td>';}h+='</tr>';}
  const f=document.createElement('iframe');f.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0';document.body.appendChild(f);const d=f.contentDocument;d.open();
  d.write('<!doctype html><html><head><meta charset="utf-8"><title>'+esc(book.title)+' - '+esc(sh().name)+'</title><style>body{font-family:Calibri,Arial,sans-serif;font-size:11pt}h3{margin:0 0 8px}table{border-collapse:collapse}td,th{border:1px solid #bbb;padding:3px 8px;white-space:nowrap}th{background:#eef0f3;color:#555;font-weight:600}@page{margin:1.2cm}</style></head><body><h3>'+esc(book.title)+' — '+esc(sh().name)+'</h3>'+h+'</tbody></table></body></html>');d.close();
  setTimeout(()=>{try{f.contentWindow.focus();f.contentWindow.print();}catch(_){toast('Cetak tidak tersedia di perangkat ini.');}setTimeout(()=>f.remove(),4000);},300);
 }
 function shiftRef(f,ax,at,d){return f.replace(/(\$?)([A-Z]+)(\d+)/g,(m,_,col,row)=>{let c=parse(col+row).c,r=+row,v=ax==='r'?r:c;
   if(d>0){if(v>=at)v+=d;}else{const n=-d;if(v>=at&&v<at+n)return'#REF!';if(v>=at+n)v-=n;}
   return ax==='r'?col+v:letters(v)+row;});}
 function shiftSheet(ax,at,d){
  const S=sh(),nd={},ns={},nw={};
  const move=(ref)=>{const p=parse(ref);if(!p)return null;let v=ax==='r'?p.r:p.c;if(d>0){if(v>=at)v+=d;}else{const n=-d;if(v>=at&&v<at+n)return null;if(v>=at+n)v-=n;}const r=ax==='r'?v:p.r,c=ax==='c'?v:p.c;return(r>=1&&r<=ROWS&&c>=1&&c<=COLS)?key(r,c):null;};
  for(const ref in S.data){const t=move(ref);if(t){let v=S.data[ref];if(typeof v==='string'&&v[0]==='=')v=shiftRef(v,ax,at,d);nd[t]=v;}}
  for(const ref in S.styles){const t=move(ref);if(t)ns[t]=S.styles[ref];}
  /* rumus di lembar lain tidak ikut digeser */
  if(ax==='c'&&S.widths){for(const c in S.widths){let v=+c;if(d>0){if(v>=at)v+=d;}else{const n=-d;if(v>=at&&v<at+n)continue;if(v>=at+n)v-=n;}nw[v]=S.widths[c];}S.widths=nw;applyWidths();}
  S.data=nd;S.styles=ns;refreshAll();paintSel();touch();toast((d>0?'Disisipkan ':'Dihapus ')+(ax==='r'?'baris':'kolom')+'.');
 }
 function fill(dir){
  const g=rng();snap();
  if(dir==='d'){const r0=g.r1;if(g.r1===g.r2){if(r0<2)return;for(let c=g.c1;c<=g.c2;c++)copyCell(key(r0-1,c),key(r0,c),1,0);}else for(let c=g.c1;c<=g.c2;c++)for(let r=g.r1+1;r<=g.r2;r++)copyCell(key(g.r1,c),key(r,c),r-g.r1,0);}
  else{if(g.c1===g.c2){if(g.c1<2)return;for(let r=g.r1;r<=g.r2;r++)copyCell(key(r,g.c1-1),key(r,g.c1),0,1);}else for(let r=g.r1;r<=g.r2;r++)for(let c=g.c1+1;c<=g.c2;c++)copyCell(key(r,g.c1),key(r,c),0,c-g.c1);}
  refreshAll();paintSel();touch();
 }
 function copyCell(from,to,dr,dc){let v=sh().data[from];if(v===undefined){delete sh().data[to];}else{if(typeof v==='string'&&v[0]==='=')v=v.replace(/([A-Z]+)(\d+)/g,(m,col,row)=>{const p=parse(m);const nr=p.r+dr,nc=p.c+dc;return nr>=1&&nc>=1&&nr<=ROWS&&nc<=COLS?key(nr,nc):'#REF!';});sh().data[to]=v;}
  if(sh().styles[from])sh().styles[to]={...sh().styles[from]};else delete sh().styles[to];}
 function autoFn(name){
  const g=rng(),multi=g.r1!==g.r2||g.c1!==g.c2;let ref,expr;
  if(multi){
   /* tulis hasil tepat di bawah rentang, tiap kolom */
   const tr=Math.min(ROWS,g.r2+1);for(let c=g.c1;c<=g.c2;c++)sh().data[key(tr,c)]=`=${name}(${key(g.r1,c)}:${key(g.r2,c)})`;
   sel={a:{r:tr,c:g.c1},f:{r:tr,c:g.c2}};
  }else{
   let r=g.r1-1;while(r>=1&&val(key(r,g.c1))!==''&&typeof val(key(r,g.c1))==='number')r--;
   if(r+1>=g.r1){toast('Pilih rentang sel atau letakkan kursor di bawah deretan angka.');return;}
   sh().data[key(g.r1,g.c1)]=`=${name}(${key(r+1,g.c1)}:${key(g.r1-1,g.c1)})`;
  }
  refreshAll();paintSel();touch();wrap.focus({preventScroll:true});
 }
 function sortBy(asc){
  snap();
  const c=sel.a.c,rows=[];let last=0;
  for(const ref in sh().data){const p=parse(ref);if(p&&p.r>last)last=p.r;}
  const start=(raw(key(1,c))!==''&&typeof val(key(1,c))==='string'&&last>1)?2:1;
  for(let r=start;r<=last;r++){const row={d:{},s:{}};for(let cc=1;cc<=COLS;cc++){const ref=key(r,cc);if(sh().data[ref]!==undefined)row.d[cc]=sh().data[ref];if(sh().styles[ref])row.s[cc]=sh().styles[ref];}rows.push({r,row,k:val(key(r,c))});}
  rows.sort((x,y)=>{const a=x.k,b=y.k;if(a===''&&b==='')return 0;if(a==='')return 1;if(b==='')return-1;const na=typeof a==='number',nb=typeof b==='number';let v=na&&nb?a-b:String(a).localeCompare(String(b),'id');return asc?v:-v;});
  rows.forEach((o,i)=>{const r=start+i;for(let cc=1;cc<=COLS;cc++){const ref=key(r,cc);delete sh().data[ref];delete sh().styles[ref];if(o.row.d[cc]!==undefined)sh().data[ref]=o.row.d[cc];if(o.row.s[cc])sh().styles[ref]=o.row.s[cc];}});
  refreshAll();paintSel();touch();toast('Diurutkan menurut kolom '+letters(c)+'.');
 }
 function sample(){
  snap();
  const S=sh();S.data={};S.styles={};
  const rows=[['Produk','Kuartal 1','Kuartal 2','Kuartal 3','Total'],['Poster',1250000,1480000,1320000],['Banner',830000,910000,1050000],['Logo',2100000,1980000,2430000],['Kartu nama',460000,520000,610000],['Stiker',380000,440000,395000]];
  rows.forEach((row,i)=>{row.forEach((v,j)=>{S.data[key(i+1,j+1)]=v;});if(i>0)S.data['E'+(i+1)]=`=SUM(B${i+1}:D${i+1})`;});
  S.data.A7='Jumlah';for(const c of['B','C','D','E'])S.data[c+'7']=`=SUM(${c}2:${c}6)`;
  S.data.A8='Rata-rata';for(const c of['B','C','D','E'])S.data[c+'8']=`=AVERAGE(${c}2:${c}6)`;
  for(let c=1;c<=5;c++)S.styles[key(1,c)]={b:1,fill:'#217346',color:'#ffffff',align:c>1?'center':'left'};
  for(let r=2;r<=8;r++)for(let c=2;c<=5;c++)S.styles[key(r,c)]={fmt:'idr'};
  for(const r of[7,8])for(let c=1;c<=5;c++)S.styles[key(r,c)]={...(S.styles[key(r,c)]||{}),b:1,fill:'#e2f0e8'};
  sel={a:{r:1,c:1},f:{r:1,c:1}};refreshAll();paintSel();touch();
 }

 /* ---------- Lembar ---------- */
 function renderTabs(){
  $('#excelTabs').innerHTML=book.sheets.map((s,i)=>`<button class="excel-tab${i===book.active?' active':''}" data-sheet="${i}">${esc(s.name)}</button>`).join('')+'<button class="excel-tab add" data-action-sheet="add" title="Lembar baru" aria-label="Lembar baru">＋</button>';
 }
 function newSheet(){if(book.sheets.length>=8){toast('Maksimum 8 lembar.');return;}endEdit(true);let n=book.sheets.length+1;while(book.sheets.some(s=>s.name==='Lembar'+n))n++;book.sheets.push({name:'Lembar'+n,data:{},styles:{}});book.active=book.sheets.length-1;sel={a:{r:1,c:1},f:{r:1,c:1}};renderTabs();refreshAll();paintSel();touch();}
 /* V162: pengait impor PPTX/PDF (dipakai js/office-import.js) */
 (window.CDMS_OFFICE=window.CDMS_OFFICE||{}).excel={apply(list,o){
  endEdit(true);
  const first=book.sheets.length===1&&!Object.keys(book.sheets[0].data).length;
  if((o&&o.replace)||first)book.sheets=[];
  const start=book.sheets.length;let added=0,skipped=0,trunc=0;
  for(const it of list){
   if(book.sheets.length>=8){skipped++;continue;}
   let nm=String(it.name||'Lembar').slice(0,24),n=1;const base=nm;while(book.sheets.some(s=>s.name===nm))nm=base.slice(0,21)+' '+(++n);
   const S={name:nm,data:{},styles:{}};if(it.widths)S.widths=it.widths;
   (it.rows||[]).forEach((r,i)=>r.forEach((v,j)=>{v=String(v==null?'':v);if(v==='')return;if(i>=ROWS||j>=COLS){trunc++;return;}S.data[key(i+1,j+1)]=/^=/.test(v)?' '+v:v;}));
   book.sheets.push(S);added++;
  }
  if(!book.sheets.length)book.sheets.push({name:'Lembar1',data:{},styles:{}});
  book.active=Math.min(start,book.sheets.length-1);sel={a:{r:1,c:1},f:{r:1,c:1}};undoSt=[];redoSt=[];
  renderTabs();applyWidths();refreshAll();paintSel();touch();
  const cut=[skipped?skipped+' lembar melebihi batas 8 dilewati':'',trunc?trunc+' sel di luar 60×26 dipotong':''].filter(Boolean).join('; ');
  return{sheets:added,cut};
 }};
 $('#excelTabs').addEventListener('click',e=>{
  if(e.target.closest('[data-action-sheet]')){newSheet();return;}
  const b=e.target.closest('[data-sheet]');if(!b)return;endEdit(true);const i=+b.dataset.sheet;
  if(i===book.active){const nm=prompt('Nama lembar:',sh().name);if(nm&&nm.trim()){sh().name=nm.trim().slice(0,24);renderTabs();touch();}return;}
  book.active=i;sel={a:{r:1,c:1},f:{r:1,c:1}};renderTabs();refreshAll();paintSel();touch();
 });
 $('#excelTabs').addEventListener('contextmenu',e=>{const b=e.target.closest('[data-sheet]');if(!b||book.sheets.length<2)return;e.preventDefault();if(confirm('Hapus lembar "'+book.sheets[+b.dataset.sheet].name+'"?')){book.sheets.splice(+b.dataset.sheet,1);book.active=Math.min(book.active,book.sheets.length-1);renderTabs();refreshAll();paintSel();touch();}});

 /* ---------- Zoom, simpan, ekspor ---------- */
 function applyZoom(){const z=book.zoom/100;sheetBox.style.setProperty('--z',z);setTimeout(applyFreeze,0);$('#excelZoomLbl').textContent=book.zoom+'%';$('#excelZoom').value=book.zoom;}
 $('#excelZoom').addEventListener('input',e=>{book.zoom=+e.target.value;applyZoom();touch(true);});
 function toast(m){const s=$('#excelMsg');s.textContent=m;s.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>s.classList.remove('show'),2600);}
 function touch(quiet){$('#excelStatus').textContent=quiet?$('#excelStatus').textContent:'Menyimpan…';clearTimeout(saveTimer);saveTimer=setTimeout(save,700);}
 function save(){try{localStorage.setItem(STORE,JSON.stringify(book));$('#excelStatus').textContent='Tersimpan di perangkat';}catch(_){$('#excelStatus').textContent='Gagal menyimpan';}}
 function used(){let mr=1,mc=1;for(const ref in sh().data){const p=parse(ref);if(p){mr=Math.max(mr,p.r);mc=Math.max(mc,p.c);}}return{mr,mc};}
 function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
 function exportCSV(){const u=used(),rows=[];for(let r=1;r<=u.mr;r++){const a=[];for(let c=1;c<=u.mc;c++)a.push('"'+display(key(r,c)).replace(/"/g,'""')+'"');rows.push(a.join(','));}download(new Blob(['﻿'+rows.join('\r\n')],{type:'text/csv;charset=utf-8'}),(sh().name||'Lembar1')+'.csv');}
 function exportXLS(){const u=used();let h='<html><head><meta charset="utf-8"></head><body>';book.sheets.forEach(S=>{const save=book.active;book.active=book.sheets.indexOf(S);const uu=used();h+=`<h3>${esc(S.name)}</h3><table border="1" style="border-collapse:collapse">`;for(let r=1;r<=uu.mr;r++){h+='<tr>';for(let c=1;c<=uu.mc;c++){const ref=key(r,c),st=S.styles[ref]||{};h+=`<td style="${st.b?'font-weight:bold;':''}${st.i?'font-style:italic;':''}${st.fill?'background:'+st.fill+';':''}${st.color?'color:'+st.color+';':''}">${esc(display(ref))}</td>`;}h+='</tr>';}h+='</table>';book.active=save;});download(new Blob([h+'</body></html>'],{type:'application/vnd.ms-excel'}),(book.title||'Buku1')+'.xls');}
 $('#excelTitle').addEventListener('input',e=>{book.title=e.target.value.trim()||'Buku1';touch();});

 /* ---------- Pita bertab ---------- */
 $$('[data-excel-tab]').forEach(b=>b.addEventListener('click',()=>{if(b.classList.contains('active')){view.classList.toggle('rib-off');return;}view.classList.remove('rib-off');const t=b.dataset.excelTab;$$('[data-excel-tab]').forEach(x=>x.classList.toggle('active',x===b));$$('[data-excel-pane]').forEach(p=>p.classList.toggle('active',p.dataset.excelPane===t));}));
 $$('[data-excel-cmd]').forEach(b=>b.addEventListener('mousedown',e=>e.preventDefault()));
 $$('[data-excel-cmd]').forEach(b=>b.addEventListener('click',()=>cmd(b.dataset.excelCmd)));
 $('#excelFs').addEventListener('change',e=>{cmd('fs',e.target.value);});
 $('#excelFmt').addEventListener('change',e=>{cmd('fmt',e.target.value);});
 $('#excelFill').addEventListener('input',e=>{cmd('fill',e.target.value);});
 $('#excelColor').addEventListener('input',e=>{cmd('color',e.target.value);});

 /* ---------- Format bersyarat ---------- */
 const CFC={merah:['#ffc7ce','#9c0006'],kuning:['#ffeb9c','#7a5c00'],hijau:['#c6efce','#006100'],biru:['#cfe2ff','#0a3c8a']};
 const cfm=$('#excelCfModal');
 function cfOpen(){endEdit(true);const g=rng();$('#cfRange').textContent=g.r1===g.r2&&g.c1===g.c2?key(g.r1,g.c1):key(g.r1,g.c1)+':'+key(g.r2,g.c2);cfm.classList.remove('hidden');$('#cfVal').focus();}
 document.addEventListener('click',e=>{
  if(e.target.closest('[data-excel-cf-open]')){cfOpen();return;}
  const b=e.target.closest('[data-cf]');if(!b&&e.target!==cfm)return;
  const a=b?b.dataset.cf:'close';
  if(a==='apply'){const val=$('#cfVal').value.trim();if(val===''){toast('Isi nilainya dulu.');return;}const g=rng(),col=CFC[$('#cfColor').value];snap();(sh().cf=sh().cf||[]).push({...g,op:$('#cfOp').value,val,bg:col[0],fg:col[1]});refreshAll();touch();toast('Aturan diterapkan.');cfm.classList.add('hidden');}
  else if(a==='clear'){snap();sh().cf=[];refreshAll();touch();toast('Aturan lembar dihapus.');cfm.classList.add('hidden');}
  else cfm.classList.add('hidden');
 });
 /* ---------- Cubit untuk zoom ---------- */
 function pinch(el,get,set){const dist=t=>Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY);let d0=0,z0=0;
  el.addEventListener('touchstart',e=>{if(e.touches.length===2){d0=dist(e.touches);z0=get();}},{passive:true});
  el.addEventListener('touchmove',e=>{if(e.touches.length===2&&d0){e.preventDefault();set(Math.round(z0*dist(e.touches)/d0));}},{passive:false});
  el.addEventListener('touchend',e=>{if(e.touches.length<2)d0=0;},{passive:true});}
 pinch(wrap,()=>book.zoom,z=>{book.zoom=Math.max(60,Math.min(160,z));applyZoom();touch(true);});
 const rb=$('#excelRangeBtn'),eb=$('#excelEditBtn');
 if(rb)rb.addEventListener('click',()=>{rangeMode=!rangeMode;rb.classList.toggle('on',rangeMode);rb.setAttribute('aria-pressed',rangeMode);toast(rangeMode?'Mode rentang aktif: ketuk sel lain untuk memperluas.':'Mode rentang mati.');if(!rangeMode){sel={a:sel.a,f:sel.a};paintSel();}});
 if(eb)eb.addEventListener('click',()=>{if(!editing)startEdit();});
 /* ---------- Buka / tutup ---------- */
 function open(){dash.classList.add('hidden');editor&&editor.classList.add('hidden');$('#wordMode')?.classList.add('hidden');view.classList.remove('hidden');document.body.classList.add('office-open');wrap.focus({preventScroll:true});paintSel();}
 function home(){endEdit(true);save();view.classList.add('hidden');document.body.classList.remove('office-open');dash.classList.remove('hidden');}
 document.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(!b)return;switch(b.dataset.action){case'excelMode':open();break;case'excelHome':home();break;case'home':if(!view.classList.contains('hidden'))home();break;case'excelSave':save();toast('Tersimpan di perangkat.');break;case'excelExport':exportCSV();break;case'excelExportXls':exportXLS();break;case'excelPrint':printSheet();break;}});
 window.addEventListener('beforeunload',()=>{try{endEdit(true);save();}catch(_){}});

 /* ---------- Muat ---------- */
 try{const s=JSON.parse(localStorage.getItem(STORE)||'null');if(s){if(s.sheets&&s.sheets.length)book={...book,...s};else if(s.data)book.sheets=[{name:'Lembar1',data:s.data||{},styles:{}}];}}catch(_){}
 /* migrasi gaya lama {bold,italic} */
 book.sheets.forEach(S=>{for(const r in S.styles){const s=S.styles[r];if(s.bold){s.b=1;delete s.bold;}if(s.italic){s.i=1;delete s.italic;}}});
 $('#excelTitle').value=book.title||'Buku1';
 renderTabs();build();
 window.cdmsExcel={open,home,matrix:()=>{const g=rng();if(g.r1===g.r2&&g.c1===g.c2){toast('Pilih rentang sel dulu (seret atau Shift+klik).');return null;}const m=[];for(let r=g.r1;r<=g.r2;r++){const a=[];for(let c=g.c1;c<=g.c2;c++)a.push(val(key(r,c)));m.push(a);}return m;}};
})();
