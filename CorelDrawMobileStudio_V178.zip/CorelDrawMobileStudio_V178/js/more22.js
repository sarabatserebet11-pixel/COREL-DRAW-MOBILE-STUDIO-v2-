/* V35: garis bantu cerdas saat menggeser, menu Pipet (pipet objek, kunci rasio), menu Optimasi (kompres gambar, info ukuran) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it}=M,$=s=>document.querySelector(s),W=()=>S.page.width,H=()=>S.page.height,E=CDMS.escape;

/* ---- garis bantu cerdas (di overlay, tidak ikut ekspor) ---- */
const dov=C.drawOverlay;
C.drawOverlay=function(){dov.call(this);const d=S.drag;if(!d||d.mode!=="move"||!d.moved)return;
 const ids=new Set(S.selectedIds||[]),sel=S.objects.filter(o=>ids.has(o.id)),ov=document.getElementById("overlayLayer");if(!sel.length||!ov)return;
 const x0=Math.min(...sel.map(o=>o.x)),x1=Math.max(...sel.map(o=>o.x+o.w)),y0=Math.min(...sel.map(o=>o.y)),y1=Math.max(...sel.map(o=>o.y+(o.h||0))),xs=[x0,(x0+x1)/2,x1],ys=[y0,(y0+y1)/2,y1],tx=[0,W()/2,W()],ty=[0,H()/2,H()];
 S.objects.forEach(o=>{if(ids.has(o.id)||o.hidden)return;tx.push(o.x,o.x+o.w/2,o.x+o.w);ty.push(o.y,o.y+(o.h||0)/2,o.y+(o.h||0));});
 const k=Math.max(1,W()/(this.svg.getBoundingClientRect().width||W())),st=`stroke="#ff2fa0" stroke-width="${1.5*k}" stroke-dasharray="${6*k} ${4*k}"`,L=[];
 xs.forEach(x=>{const t=tx.find(v=>Math.abs(v-x)<=1.01);if(t!==undefined)L.push(`<line x1="${t}" y1="0" x2="${t}" y2="${H()}" ${st}/>`);});
 ys.forEach(y=>{const t=ty.find(v=>Math.abs(v-y)<=1.01);if(t!==undefined)L.push(`<line x1="0" y1="${t}" x2="${W()}" y2="${t}" ${st}/>`);});
 if(L.length)ov.insertAdjacentHTML("beforeend",`<g id="cdSmart" pointer-events="none">${L.join("")}</g>`);};

window.addEventListener("pointerup",()=>{if(document.getElementById("cdSmart"))setTimeout(()=>C.drawOverlay(),0);});
/* ---- pipet objek ---- */
S.pipet=null;
const pd=C.pointerDown;
C.pointerDown=function(e){if(S.pipet){const g=e.target.closest&&e.target.closest("[data-id]"),src=g&&S.objects.find(x=>x.id===g.dataset.id),mode=S.pipet,tg=(S.pipetT||[]).map(id=>S.objects.find(o=>o.id===id)).filter(Boolean);S.pipet=null;
  if(src&&tg.length){Hi.snapshot();tg.forEach(o=>{if(o===src)return;if(mode==="fill"){if(src.type==="image")return;o.fill=src.fill;if(src.grad)o.grad=src.grad;else delete o.grad;if(src.pat)o.pat=src.pat;else delete o.pat;}else{o.stroke=src.stroke;o.strokeWidth=src.strokeWidth;}});S.selectedIds=tg.map(o=>o.id);S.selected=tg[0].id;this.render();T("Warna diambil dari objek");}else T("Pipet dibatalkan");return;}
 pd.call(this,e);};
const startPipet=m=>{const a=sels();if(!a.length)return T("Pilih objek tujuan dulu");S.pipet=m;S.pipetT=a.map(o=>o.id);CDMS.setTool("select");T("Ketuk objek sumber warna di kanvas");};
const ratio=(on)=>edit(o=>{if(on)o.lockAR=true;else delete o.lockAR;},on?"Rasio dikunci saat ubah ukuran":"Rasio dibuka");
MENUS.pipet=()=>[{h:"Pipet (ambil dari objek lain)",items:[it("Pipet isi: ketuk objek sumber",()=>startPipet("fill"),"color"),it("Pipet garis: ketuk objek sumber",()=>startPipet("stroke"),"line")]},
 {h:"Rasio ukuran",items:[it("Kunci rasio objek terpilih",()=>ratio(true),"lock"),it("Buka kunci rasio",()=>ratio(false),"unlock")]}];

/* ---- optimasi ukuran proyek ---- */
const kb=n=>n>1048576?(n/1048576).toFixed(2)+" MB":Math.round(n/1024)+" KB";
const load=h=>new Promise((res,rej)=>{const im=new Image();im.onload=()=>res(im);im.onerror=()=>rej(new Error("x"));im.src=h;});
async function shrink(maxSide,jpeg){const imgs=S.objects.filter(o=>o.type==="image"&&/^data:image\/(png|jpeg|webp)/.test(o.href||""));if(!imgs.length)return T("Tidak ada gambar raster");Hi.snapshot();T("Memproses "+imgs.length+" gambar…");let before=0,after=0;
 for(const o of imgs){before+=o.href.length;try{const im=await load(o.href),s=Math.min(1,maxSide/Math.max(im.width,im.height));
  if(s>=1&&!jpeg){after+=o.href.length;continue;}
  const cv=document.createElement("canvas");cv.width=Math.max(1,Math.round(im.width*s));cv.height=Math.max(1,Math.round(im.height*s));const x=cv.getContext("2d");if(jpeg){x.fillStyle="#fff";x.fillRect(0,0,cv.width,cv.height);}x.drawImage(im,0,0,cv.width,cv.height);
  const mime=jpeg||o.href.startsWith("data:image/jpeg")?"image/jpeg":"image/png",nu=cv.toDataURL(mime,.85);if(nu.length<o.href.length)o.href=nu;after+=o.href.length;}catch(e){after+=o.href.length;}}
 C.render();T("Gambar dikompres: "+kb(before)+" → "+kb(after));}
function info(){if(CDMS.Pages)CDMS.Pages.sync();const pages=S.pages&&S.pages.length>1?S.pages:[{objects:S.objects}],byType={};let imgB=0,tot=0;
 pages.forEach(pg=>pg.objects.forEach(o=>{const n=JSON.stringify(o).length;tot+=n;byType[o.type]=(byType[o.type]||0)+1;if(o.type==="image")imgB+=(o.href||"").length;}));
 N.openModal("Ukuran data proyek",`<div class="st-pane"><p class="st-note"><b>Total:</b> ${kb(tot)} (${pages.length} halaman)</p><p class="st-note"><b>Gambar tertanam:</b> ${kb(imgB)}</p><p class="st-note"><b>Objek:</b> ${Object.entries(byType).map(e=>E(e[0])+" "+e[1]).join(", ")||"-"}</p><p class="st-note">Penyimpanan lokal browser biasanya terbatas sekitar 5 MB. Kompres gambar bila hampir penuh.</p></div>`);}
function purge(){const out=S.objects.filter(o=>o.hidden||o.x+o.w<0||o.y+(o.h||0)<0||o.x>W()||o.y>H());if(!out.length)return T("Tidak ada yang perlu dibersihkan");Hi.snapshot();const ids=new Set(out.map(o=>o.id));S.objects=S.objects.filter(o=>!ids.has(o.id));S.selected=null;S.selectedIds=[];C.render();T(out.length+" objek dibersihkan");}
MENUS.optim=()=>[{h:"Kompres gambar",items:[it("Perkecil resolusi, maks 1600 px",()=>shrink(1600,false),"image"),it("Perkecil resolusi, maks 1000 px",()=>shrink(1000,false),"image"),it("Ubah ke JPEG ringan, maks 1600 px",()=>shrink(1600,true),"image")]},
 {h:"Info & bersih-bersih",items:[it("Lihat ukuran data proyek",info,"layers"),it("Hapus objek tersembunyi / di luar kanvas",purge,"trash")]}];

BT.push(["pipet","pipette","Pipet"],["optim","gauge","Optimasi"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("warna").push("pipet");hub("berkas").push("optim");
})();
