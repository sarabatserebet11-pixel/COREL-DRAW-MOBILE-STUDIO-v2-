/* V57: menu Rapikan (bersihkan spasi, kapital kalimat, daftar bullet/nomor, tanda kutip pintar, urut/duplikat baris) dan Tabel (kustom, siap pakai, teks ke tabel) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,it,tc,sels,pick,T}=M,K=CDMS.UIKit,{COMP,place,R,X,AC,INK,MUTE,LINE}=K;
const $=s=>document.querySelector(s);
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
/* ---------- Rapikan ---------- */
function fit(o){const L=String(o.text).split("\n"),fs=o.fontSize||32;o.h=Math.round(L.length*fs*1.2);o.w=Math.max(40,Math.round(Math.max(...L.map(l=>l.length))*fs*.58));}
function tedit(fn,msg){const a=sels().filter(o=>o.type==="text");if(!a.length)return T("Pilih teks dulu");
 Hi.snapshot();let n=0;a.forEach(o=>{const r=fn(String(o.text||""));if(r!=null&&r!==o.text){o.text=r;fit(o);n++;}});C.render();T(n?n+" teks dirapikan"+(msg?" · "+msg:""):"Tidak ada yang perlu diubah");}
const lines=(f)=>s=>s.split("\n").map(f).join("\n");
const stripList=l=>l.replace(/^\s*(?:[•\-*–·]|\d+[.)])\s+/,"");
const OPS={
 spasi:s=>s.replace(/[ \t]+/g," ").replace(/ *\n */g,"\n").trim(),
 kalimat:s=>s.toLowerCase().replace(/(^\s*|[.!?]\s+|\n\s*)([a-zà-ÿ])/g,(m,a,b)=>a+b.toUpperCase()),
 perKalimat:s=>s.replace(/([.!?])\s+/g,"$1\n"),
 gabung:s=>s.replace(/\s*\n\s*/g," ").trim(),
 bullet:s=>s.split("\n").map(l=>l.trim()?"• "+stripList(l):l).join("\n"),
 nomor:s=>{let i=0;return s.split("\n").map(l=>l.trim()?(++i)+". "+stripList(l):l).join("\n");},
 hapusDaftar:lines(stripList),
 kutip:s=>s.replace(/\.\.\./g,"…").replace(/ -- /g," — ").replace(/"([^"]*)"/g,"“$1”").replace(/(\w)'(\w)/g,"$1’$2").replace(/(^|[\s(])'([^']*)'/g,"$1‘$2’"),
 lurus:s=>s.replace(/[“”]/g,'"').replace(/[‘’]/g,"'").replace(/…/g,"...").replace(/—/g," -- "),
 tandaBaca:s=>s.replace(/[.,;:!?"'“”‘’()\[\]]/g,""),
 kosong:s=>s.split("\n").filter(l=>l.trim()).join("\n"),
 az:s=>s.split("\n").sort((a,b)=>a.localeCompare(b,"id")).join("\n"),
 za:s=>s.split("\n").sort((a,b)=>b.localeCompare(a,"id")).join("\n"),
 balik:s=>s.split("\n").reverse().join("\n"),
 unik:s=>{const seen=new Set();return s.split("\n").filter(l=>{const k=l.trim().toLowerCase();if(!k)return true;if(seen.has(k))return false;seen.add(k);return true;}).join("\n");}
};
MENUS.rapikan=()=>[
 {h:"Bersihkan",items:[tc("Spasi ganda & tepi",()=>tedit(OPS.spasi)),tc("Baris kosong",()=>tedit(OPS.kosong)),tc("Tanda baca",()=>tedit(OPS.tandaBaca))]},
 {h:"Kalimat",items:[tc("Kapital awal kalimat",()=>tedit(OPS.kalimat)),tc("Satu kalimat per baris",()=>tedit(OPS.perKalimat)),tc("Gabung jadi satu baris",()=>tedit(OPS.gabung))]},
 {h:"Daftar (satu item per baris)",items:[tc("• Bullet",()=>tedit(OPS.bullet)),tc("1. Nomor",()=>tedit(OPS.nomor)),tc("Hapus penanda",()=>tedit(OPS.hapusDaftar))]},
 {h:"Urutan baris",items:[tc("A → Z",()=>tedit(OPS.az)),tc("Z → A",()=>tedit(OPS.za)),tc("Balik urutan",()=>tedit(OPS.balik)),tc("Hapus duplikat",()=>tedit(OPS.unik))]},
 {h:"Tipografi",items:[tc("Kutip pintar “ ”",()=>tedit(OPS.kutip)),tc("Kutip lurus",()=>tedit(OPS.lurus))]}];
BT.push(["rapikan","justify","Rapikan"]);
hubAdd("teks","rapikan");
/* ---------- Tabel ---------- */
const STY={
 zebra:{n:"Zebra",hd:INK,hf:"#ffffff",b:["#ffffff","#f4f6ff"],bf:INK,ln:null},
 bersih:{n:"Bersih",hd:AC,hf:"#ffffff",b:["#ffffff","#ffffff"],bf:INK,ln:"#e3e7f3"},
 garis:{n:"Garis",hd:"#eef0fa",hf:INK,b:["none","none"],bf:INK,ln:INK},
 gelap:{n:"Gelap",hd:AC,hf:"#ffffff",b:["#1b1f3a","#232846"],bf:"#ffffff",ln:null},
 neon:{n:"Neon",hd:"#00c9a7",hf:"#0b1020",b:["#11162a","#11162a"],bf:"#ffffff",ln:"#00c9a7"}
};
function cfg(data,style,header){const st=STY[style]||STY.zebra,rows=data.length,cols=Math.max(...data.map(r=>r.length)),W=S.page.width,H=S.page.height;
 const ch=Math.round(Math.max(50,Math.min(88,H*.8/rows)));let fs=Math.max(18,Math.min(32,Math.round(ch*.36)));
 const wid=f=>Array.from({length:cols},(_,c)=>Math.max(110,Math.round(Math.max(...data.map(r=>String(r[c]==null?"":r[c]).length))*f*.6+44)));
 let cws=wid(fs),tot=cws.reduce((x,y)=>x+y,0);
 if(tot>W*.92){const k=W*.92/tot;fs=Math.max(14,Math.floor(fs*k));cws=wid(fs);tot=cws.reduce((x,y)=>x+y,0);if(tot>W*.92){const k2=W*.92/tot;cws=cws.map(w=>Math.round(w*k2));}}
 const xs=cws.map((_,c)=>cws.slice(0,c).reduce((x,y)=>x+y,0)),a=[];
 data.forEach((r,i)=>{const hd=header&&i===0;for(let c=0;c<cols;c++){const x=xs[c],cw=cws[c],y=i*ch,txt=String(r[c]==null?"":r[c]),fill=hd?st.hd:st.b[(i-(header?1:0))%2];
  a.push(R(x,y,cw,ch,fill,{stroke:st.ln||"none",strokeWidth:st.ln?2:0,name:"Sel "+(i+1)+","+(c+1)}));
  if(txt){const col=hd?st.hf:st.bf,o={bold:hd};a.push(c===0?X(txt,x+18,y+ch/2,fs,col,{left:1,...o}):X(txt,x+cw/2,y+ch/2,fs,col,o));}}});
 return {w:tot>W*.92?cws.reduce((x,y)=>x+y,0):tot,h:rows*ch,a};}
let cur=null;
COMP["Tabel"]=()=>cur;
function make(data,style,header,msg){if(!data.length||!data[0].length)return T("Data tabel kosong");cur=cfg(data,style,header);place("Tabel");T(msg||"Tabel ditambahkan");}
const grid=(r,c,h)=>Array.from({length:r},(_,i)=>Array.from({length:c},(_,j)=>i===0&&h?"Kolom "+(j+1):(j===0?"Baris "+(i+(h?0:1)):"Data")));
function dlg(){N.openModal("Tabel kustom",`<div class="st-pane"><div class="st-grid"><label>Baris<input id="tbR" type="number" min="1" max="15" value="5"></label><label>Kolom<input id="tbC" type="number" min="1" max="8" value="3"></label><label>Gaya<select id="tbS">${Object.keys(STY).map(k=>`<option value="${k}">${STY[k].n}</option>`).join("")}</select></label><label>Baris judul<select id="tbH"><option value="1">Ya</option><option value="0">Tidak</option></select></label></div><button class="btn primary" id="aOk">Buat tabel</button></div>`);
 $("#aOk").onclick=()=>{const r=Math.max(1,Math.min(15,+$("#tbR").value||1)),c=Math.max(1,Math.min(8,+$("#tbC").value||1)),h=$("#tbH").value==="1";N.closeModal();make(grid(r,c,h),$("#tbS").value,h,r+" × "+c+" tabel ditambahkan");};}
const PRE=[
 ["Jadwal pelajaran","zebra",[["Jam","Senin","Selasa","Rabu","Kamis","Jumat"],["07.00","Matematika","IPA","Bahasa","IPS","Seni"],["09.00","Bahasa","Matematika","IPA","Olahraga","IPS"],["11.00","IPS","Seni","Matematika","Bahasa","IPA"]]],
 ["Daftar harga","bersih",[["Paket","Isi","Harga"],["Basic","1 desain","Rp 50.000"],["Standar","3 desain","Rp 120.000"],["Premium","10 desain","Rp 300.000"]]],
 ["Perbandingan fitur","gelap",[["Fitur","Gratis","Pro"],["Ekspor PNG","Ya","Ya"],["Tanpa watermark","Tidak","Ya"],["Cadangan awan","Tidak","Ya"]]],
 ["Anggaran bulanan","garis",[["Pos","Rencana","Realisasi"],["Makan","1.500.000","1.420.000"],["Transport","600.000","650.000"],["Hiburan","400.000","300.000"]]],
 ["Skor pertandingan","neon",[["Tim","Main","Menang","Poin"],["Garuda","5","4","13"],["Elang","5","3","10"],["Harimau","5","2","7"]]]];
function dariTeks(){const o=sels().find(x=>x.type==="text");if(!o)return T("Pilih teks dulu (satu baris per baris tabel)");
 const L=String(o.text).split("\n").filter(l=>l.trim());if(!L.length)return T("Teks kosong");
 const dl=["\t",";","|",","].find(d=>L.some(l=>l.includes(d)))||null,data=L.map(l=>dl?l.split(dl).map(s=>s.trim()):[l.trim()]);
 cur=cfg(data,"zebra",true);place("Tabel");S.objects=S.objects.filter(x=>x.id!==o.id);C.render();T("Teks diubah menjadi tabel "+data.length+" × "+Math.max(...data.map(r=>r.length)));}
MENUS.tabel=()=>[
 {h:"Buat tabel",items:[it("Tabel kustom…",dlg,"rect"),it("Teks → tabel (pisah koma, ; | atau tab)",dariTeks,"rect")]},
 {h:"Siap pakai",items:PRE.map(p=>it(p[0],()=>make(p[2],p[1],true,p[0]+" ditambahkan"),"rect"))}];
BT.push(["tabel","table","Tabel"]);
hubAdd("pustaka","tabel");
CDMS.Rapikan={OPS,fit};
})();
