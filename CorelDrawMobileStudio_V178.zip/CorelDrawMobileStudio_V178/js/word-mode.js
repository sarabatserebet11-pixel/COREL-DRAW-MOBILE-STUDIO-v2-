/* V123: Mode Word — dokumen bergaya Office (pita bertab, gaya paragraf, tabel, gambar, zoom, cetak) */
(()=>{
 const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
 const dash=$('#dashboard'), editor=$('#editor'), view=$('#wordMode'), doc=$('#wordDocument');
 if(!dash||!view||!doc)return;
 const STORE='cdms-word-document', META='cdms-word-meta';
 let meta={title:'Dokumen1',zoom:100,margin:'normal',header:'',footer:'',land:false,cols:1,wm:''}, savedRange=null, saveTimer=0;
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

 /* ---------- Seleksi ---------- */
 document.addEventListener('selectionchange',()=>{
  try{const g=getSelection();if(g.rangeCount&&!g.isCollapsed&&doc.contains(g.anchorNode)){const tx=g.toString().trim(),w=tx?tx.split(/\s+/).length:0;$('#wordCount').textContent=w+' kata dipilih';}else if(document.activeElement===doc||doc.contains(getSelection().anchorNode))count();}catch(_){}
  const s=getSelection();if(s.rangeCount&&doc.contains(s.anchorNode)){savedRange=s.getRangeAt(0).cloneRange();syncState();}
 });
 function restore(){doc.focus({preventScroll:true});if(savedRange){const s=getSelection();s.removeAllRanges();s.addRange(savedRange);}}
 function exec(c,v){restore();try{document.execCommand('styleWithCSS',false,c==='foreColor'||c==='hiliteColor'||c==='backColor');}catch(_){ }document.execCommand(c,false,v==null?null:v);changed();syncState();}
 function syncState(){
  $$('[data-word-cmd]').forEach(b=>{const c=b.dataset.wordCmd;if(['bold','italic','underline','strikeThrough','superscript','subscript','insertUnorderedList','insertOrderedList','justifyLeft','justifyCenter','justifyRight','justifyFull'].includes(c)){let on=false;try{on=document.queryCommandState(c);}catch(_){ }b.classList.toggle('on',on);}});
  try{const fb=(document.queryCommandValue('formatBlock')||'').toLowerCase().replace(/[<>]/g,'');const st=$('#wordStyle');if(st){const m={h1:'h1',h2:'h2',h3:'h3',blockquote:'blockquote',p:'p',div:'p'};st.value=m[fb]||'p';}}catch(_){ }
 }

 /* ---------- Hitung ---------- */
 function count(){
  const t=doc.innerText.replace(/ /g,' ').trim();const w=t?t.split(/\s+/).length:0;
  $('#wordCount').textContent=w.toLocaleString('id-ID')+' kata';
  $('#wordChars').title='Perkiraan waktu baca: '+Math.max(1,Math.round(w/200))+' menit';$('#wordChars').textContent=t.replace(/\n/g,'').length.toLocaleString('id-ID')+' karakter';
  const pg=Math.max(1,Math.ceil(doc.scrollHeight/(meta.land?816:1056)));
  $('#wordPages').textContent='Halaman '+pg;
 }
 function changed(){count();$('#wordStatus').textContent='Menyimpan…';clearTimeout(saveTimer);saveTimer=setTimeout(save,800);}
 function save(){try{localStorage.setItem(STORE,doc.innerHTML);localStorage.setItem(META,JSON.stringify(meta));$('#wordStatus').textContent='Tersimpan di perangkat';}catch(e){$('#wordStatus').textContent='Gagal menyimpan dokumen';}}
 /* V162: pengait impor PPTX/PDF (dipakai js/office-import.js) */
 (window.CDMS_OFFICE=window.CDMS_OFFICE||{}).word={apply(html,o){
  const empty=!doc.innerText.trim()&&!doc.querySelector('img,table');
  if((o&&o.replace)||empty)doc.innerHTML=html;else doc.insertAdjacentHTML('beforeend','<hr>'+html);
  count();let ok=true;
  try{localStorage.setItem(STORE,doc.innerHTML);localStorage.setItem(META,JSON.stringify(meta));$('#wordStatus').textContent='Tersimpan di perangkat';}catch(_){ok=false;$('#wordStatus').textContent='Gagal menyimpan dokumen (penyimpanan penuh?)';}
  return{saved:ok};
 }};
 function toast(m){const s=$('#wordMsg');s.textContent=m;s.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>s.classList.remove('show'),2400);}

 /* ---------- Tampilan ---------- */
 function applyView(){
  const z=meta.zoom/100;doc.style.zoom=z;doc.style.setProperty('--z',z);
  $('#wordZoom').value=meta.zoom;$('#wordZoomLbl').textContent=meta.zoom+'%';
  doc.dataset.margin=meta.margin;doc.classList.toggle('land',!!meta.land);doc.classList.toggle('cols2',meta.cols===2);
  meta.header?doc.dataset.header=meta.header:doc.removeAttribute('data-header');
  meta.footer?doc.dataset.footer=meta.footer.replace(/\{n\}/g,'1'):doc.removeAttribute('data-footer');$('#wordMargin').value=meta.margin;
  $('#wordTitle').value=meta.title;
  const wu=wmUrl();doc.style.backgroundImage=wu?`url("${wu}")`:'';doc.style.backgroundRepeat='no-repeat';doc.style.backgroundPosition='center 360px';doc.style.backgroundSize='70% auto';
 }
 function wmUrl(){if(!meta.wm)return '';const t=String(meta.wm).replace(/[<>&"'#%]/g,'').slice(0,30);return 'data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400"><text x="400" y="230" text-anchor="middle" font-family="Arial" font-weight="700" font-size="110" fill="#9aa6bd" fill-opacity=".28" transform="rotate(-30 400 200)">'+t+'</text></svg>');}
 $('#wordZoom').addEventListener('input',e=>{meta.zoom=+e.target.value;applyView();count();clearTimeout(saveTimer);saveTimer=setTimeout(save,600);});
 $('#wordMargin').addEventListener('change',e=>{meta.margin=e.target.value;applyView();save();});
 $('#wordTitle').addEventListener('input',e=>{meta.title=e.target.value.trim()||'Dokumen1';clearTimeout(saveTimer);saveTimer=setTimeout(save,600);});

 /* ---------- Pita ---------- */
 $$('[data-word-tab]').forEach(b=>b.addEventListener('click',()=>{if(b.classList.contains('active')){view.classList.toggle('rib-off');return;}view.classList.remove('rib-off');const t=b.dataset.wordTab;$$('[data-word-tab]').forEach(x=>x.classList.toggle('active',x===b));$$('[data-word-pane]').forEach(p=>p.classList.toggle('active',p.dataset.wordPane===t));}));
 $$('[data-word-cmd],[data-word-act],[data-word-quick]').forEach(b=>b.addEventListener('mousedown',e=>e.preventDefault()));
 $$('[data-word-cmd]').forEach(b=>b.addEventListener('click',()=>exec(b.dataset.wordCmd)));
 $('#wordFont').addEventListener('change',e=>exec('fontName',e.target.value));
 $('#wordSize').addEventListener('change',e=>exec('fontSize',e.target.value));
 $('#wordStyle').addEventListener('change',e=>{const v=e.target.value;exec('formatBlock',v==='p'?'<p>':'<'+v+'>');});
 $('#wordSpacing').addEventListener('change',e=>{const v=e.target.value;if(!v)return;restore();const s=getSelection();if(!s.rangeCount)return;let n=s.anchorNode;n=n.nodeType===3?n.parentElement:n;const blk=n.closest('p,h1,h2,h3,li,blockquote,div');if(blk&&doc.contains(blk)&&blk!==doc){const set=new Set();const r=s.getRangeAt(0);doc.querySelectorAll('p,h1,h2,h3,li,blockquote').forEach(b=>{if(r.intersectsNode(b))set.add(b);});if(!set.size)set.add(blk);set.forEach(b=>b.style.lineHeight=v);}else doc.style.lineHeight=v;changed();e.target.value='';});
 $('#wordFindInput').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();ACT.findnext();}if(e.key==='Escape')ACT.findclose();});
 $('#wordColor').addEventListener('input',e=>{exec('foreColor',e.target.value);$('#wordColorBar').style.background=e.target.value;});
 $('#wordHilite').addEventListener('input',e=>{exec('hiliteColor',e.target.value);$('#wordHiliteBar').style.background=e.target.value;});


 /* V128: simbol & ubah huruf besar/kecil */
 $('#wordSymbol').addEventListener('change',e=>{const v=e.target.value;e.target.value='';if(v)exec('insertText',v);});
 $('#wordCase').addEventListener('change',e=>{const k=e.target.value;e.target.value='';if(!k)return;restore();const s=getSelection();if(!s.rangeCount||s.isCollapsed||!doc.contains(s.anchorNode)){toast('Blok teks dulu, lalu pilih huruf.');return;}
  const t=s.toString(),o=k==='up'?t.toUpperCase():k==='low'?t.toLowerCase():t.toLowerCase().replace(/(^|[\s(\-"'])(\p{L})/gu,(m,a,b)=>a+b.toUpperCase());exec('insertText',o);});
 function curCell(){const r=savedRange;if(!r)return null;let n=r.startContainer;n=n.nodeType===3?n.parentElement:n;const c=n&&n.closest&&n.closest('td,th');return c&&doc.contains(c)?c:null;}
 function countMatches(q){const t=doc.innerText.toLowerCase();let n=0,i=0;q=q.toLowerCase();while((i=t.indexOf(q,i))>=0){n++;i+=q.length;}return n;}
 /* V177: baca keras (TTS bawaan perangkat) dan statistik dokumen */
 function speakText(){
  if(!('speechSynthesis' in window)||typeof SpeechSynthesisUtterance==='undefined'){toast('Baca keras tidak didukung di perangkat ini');return;}
  const g=getSelection();let t=(g&&g.rangeCount&&!g.isCollapsed&&doc.contains(g.anchorNode))?g.toString():doc.innerText;
  t=(t||'').replace(/\s+/g,' ').trim();if(!t){toast('Tidak ada teks untuk dibaca');return;}
  speechSynthesis.cancel();
  const parts=t.match(/[^.!?\n]+[.!?]*/g)||[t];let i=0;
  const next=()=>{if(i>=parts.length||i>400){return;}const u=new SpeechSynthesisUtterance(parts[i++].trim());u.lang=(document.documentElement.lang&&document.documentElement.lang.length>1?document.documentElement.lang:'id-ID');u.onend=next;u.onerror=()=>{};speechSynthesis.speak(u);};
  next();toast('Membaca… (⏹ Berhenti untuk menghentikan)');
 }
 function docStats(){
  const t=doc.innerText.replace(/\u00a0/g,' ').trim();
  const words=t?t.split(/\s+/).length:0, chars=t.length, noSp=t.replace(/\s/g,'').length;
  const sent=(t.match(/[.!?]+(\s|$)/g)||[]).length||(t?1:0);
  const paras=[...doc.querySelectorAll('p,h1,h2,h3,li,blockquote')].filter(x=>x.innerText.trim()).length;
  const freq={};(t.toLowerCase().match(/[\p{L}\p{N}']{4,}/gu)||[]).forEach(w=>freq[w]=(freq[w]||0)+1);
  const top=Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,5).map(e=>e[0]+' ('+e[1]+')').join(', ')||'—';
  const n=x=>x.toLocaleString('id-ID');
  alert('Statistik dokumen\n\nKata: '+n(words)+'\nKarakter: '+n(chars)+' (tanpa spasi '+n(noSp)+')\nKalimat: '+n(sent)+'\nParagraf: '+n(paras)+'\nGambar: '+doc.querySelectorAll('img').length+'\nTabel: '+doc.querySelectorAll('table').length+'\nWaktu baca: ±'+Math.max(1,Math.round(words/200))+' menit\nKata sering: '+top);
 }
 const ACT={
  speak:speakText,
  speakstop:()=>{try{speechSynthesis.cancel();}catch(_){}toast('Dihentikan');},
  stats:docStats,
  table(){const r=+(prompt('Jumlah baris:','3')||0),c=+(prompt('Jumlah kolom:','3')||0);if(!r||!c||r>30||c>12)return;let h='<table class="word-table"><tbody>';for(let i=0;i<r;i++){h+='<tr>';for(let j=0;j<c;j++)h+=i===0?'<th>Judul</th>':'<td><br></td>';h+='</tr>';}exec('insertHTML',h+'</tbody></table><p><br></p>');},
  link(){const u=prompt('Alamat tautan (https://…):','https://');if(!u||u==='https://')return;if(!/^(https?:|mailto:)/i.test(u)){toast('Hanya tautan http, https, atau mailto.');return;}const s=getSelection();if(s.isCollapsed)exec('insertHTML',`<a href="${esc(u)}" target="_blank" rel="noopener">${esc(u)}</a>`);else exec('createLink',u);},
  cols(){meta.cols=meta.cols===2?1:2;applyView();count();save();toast(meta.cols===2?'Teks dua kolom.':'Teks satu kolom.');},
  indent1(){restore();const sl=getSelection();if(!sl.rangeCount)return;const r=sl.getRangeAt(0),bl=[...doc.querySelectorAll('p,h1,h2,h3,li,blockquote')].filter(b=>r.intersectsNode(b));if(!bl.length){toast('Letakkan kursor di paragraf.');return;}const on=!bl[0].style.textIndent;bl.forEach(b=>{b.style.textIndent=on?'36px':'';});changed();},
  callout(){const t=getSelection().toString().trim();exec('insertHTML','<div class="word-callout"><p><b>Catatan:</b> '+(t?esc(t):'Tulis catatan di sini')+'</p></div><p><br></p>');},
  focus(){const on=view.classList.toggle('focus-mode');toast(on?'Mode fokus: ketuk ✕ di pojok untuk keluar.':'');let b=$('#wordFocusExit');if(!b){b=document.createElement('button');b.id='wordFocusExit';b.className='ox-focus-exit';b.textContent='✕';b.setAttribute('aria-label','Keluar mode fokus');b.addEventListener('click',()=>{view.classList.remove('focus-mode');});view.appendChild(b);}},
  template(){const n=prompt('Pilih templat:\n1 = Surat resmi\n2 = Notulen rapat\n3 = Daftar riwayat hidup (CV)\n4 = Tanda tangan','1');if(!n)return;
   const T={1:'<p style="text-align:right">Kota, tanggal</p><p>Nomor&nbsp;&nbsp;: …<br>Lampiran : …<br>Perihal&nbsp;&nbsp;: …</p><p>Yth. …<br>di tempat</p><p>Dengan hormat,</p><p>Isi surat…</p><p>Demikian surat ini kami sampaikan. Atas perhatian Bapak/Ibu, kami ucapkan terima kasih.</p><p>Hormat kami,</p><p><br><br></p><p><b>Nama</b><br>Jabatan</p>',
   2:'<h1>Notulen Rapat</h1><p><b>Hari/tanggal:</b> …<br><b>Waktu:</b> …<br><b>Tempat:</b> …<br><b>Peserta:</b> …</p><h2>Agenda</h2><ol><li>…</li></ol><h2>Pembahasan</h2><p>…</p><h2>Keputusan</h2><ul><li>…</li></ul><h2>Tindak lanjut</h2><p>…</p>',
   3:'<h1>Nama Lengkap</h1><p>Alamat · Telepon · Email</p><h2>Ringkasan</h2><p>…</p><h2>Pendidikan</h2><ul><li>… (tahun)</li></ul><h2>Pengalaman</h2><ul><li>… (tahun)</li></ul><h2>Keterampilan</h2><ul><li>…</li></ul>',
   4:'<p><br></p><p>Hormat kami,</p><p><br><br><br></p><p><b><u>Nama Lengkap</u></b><br>Jabatan</p>'}[n.trim()];
   if(!T){toast('Pilih angka 1–4.');return;}exec('insertHTML',T+'<p><br></p>');},
  orient(){meta.land=!meta.land;applyView();count();save();toast(meta.land?'Orientasi lanskap.':'Orientasi potret.');},
  tblrow(){const c=curCell();if(!c){toast('Letakkan kursor di dalam tabel.');return;}const tr=c.parentElement,n=tr.cells.length,nr=document.createElement('tr');for(let i=0;i<n;i++){const d=document.createElement('td');d.innerHTML='<br>';nr.appendChild(d);}tr.after(nr);changed();},
  tblcol(){const c=curCell();if(!c){toast('Letakkan kursor di dalam tabel.');return;}const i=c.cellIndex;[...c.closest('table').rows].forEach(r=>{const d=document.createElement(r.cells[i]&&r.cells[i].tagName==='TH'?'th':'td');d.innerHTML=r.cells[i]&&r.cells[i].tagName==='TH'?'Judul':'<br>';r.cells[i]?r.cells[i].after(d):r.appendChild(d);});changed();},
  tbldelrow(){const c=curCell();if(!c){toast('Letakkan kursor di dalam tabel.');return;}const t=c.closest('table');if(t.rows.length<=1){t.remove();}else c.parentElement.remove();changed();},
  tbldelcol(){const c=curCell();if(!c){toast('Letakkan kursor di dalam tabel.');return;}const t=c.closest('table'),i=c.cellIndex;if(t.rows[0].cells.length<=1){t.remove();}else[...t.rows].forEach(r=>r.cells[i]&&r.cells[i].remove());changed();},
  tbldel(){const c=curCell();if(!c){toast('Letakkan kursor di dalam tabel.');return;}c.closest('table').remove();changed();},
  checklist(){exec('insertHTML','<p>☐ <br></p>');},
  tick(){const sel=getSelection();if(!sel.rangeCount)return;restore();const n=getSelection().anchorNode;const p=(n&&(n.nodeType===3?n.parentElement:n)).closest&&(n.nodeType===3?n.parentElement:n).closest('p,li,div');if(!p||!doc.contains(p)||p===doc){toast('Letakkan kursor di baris daftar tugas.');return;}const t=p.textContent;if(t.startsWith('☐')){p.textContent=t.replace('☐','☑');}else if(t.startsWith('☑')){p.textContent=t.replace('☑','☐');}else{toast('Baris ini belum diawali kotak ☐.');return;}changed();},
  importtxt(){let i=$('#wordTxtInput');if(!i){i=document.createElement('input');i.type='file';i.id='wordTxtInput';i.accept='.txt,.md,text/plain';i.hidden=true;document.body.appendChild(i);i.addEventListener('change',()=>{const f=i.files[0];i.value='';if(!f)return;if(f.size>1024*1024){toast('Pilih file maksimum 1 MB.');return;}const fr=new FileReader();fr.onload=()=>{const t=String(fr.result).replace(/\r/g,'').trim();if(!t)return;exec('insertHTML',t.split(/\n{2,}/).map(x=>'<p>'+esc(x).replace(/\n/g,'<br>')+'</p>').join(''));toast('Teks dimasukkan di kursor.');};fr.readAsText(f);});}i.click();},
  hr(){exec('insertHorizontalRule');},
  date(){exec('insertText',new Date().toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'}));},
  pagebreak(){exec('insertHTML','<hr class="page-break"><p><br></p>');},
  image(){$('#wordImgInput').click();},
  clear(){exec('removeFormat');exec('formatBlock','<p>');},
  print(){printDoc();},
  doc(){exportDoc();},
  html(){download(new Blob(['<!doctype html><html><head><meta charset="utf-8"><title>'+esc(meta.title)+'</title><style>'+pageCss()+'</style></head><body>'+hf()+doc.innerHTML+ft()+'</body></html>'],{type:'text/html'}),meta.title+'.html');},
  find(){const f=$('#wordFind');f.classList.toggle('open');if(f.classList.contains('open')){const t=getSelection().toString();if(t&&doc.contains(getSelection().anchorNode))$('#wordFindInput').value=t.slice(0,60);$('#wordFindInput').focus();$('#wordFindInput').select();}else doc.focus();},
  findclose(){$('#wordFind').classList.remove('open');doc.focus();},
  findnext(){const q=$('#wordFindInput').value;if(!q)return;const n=countMatches(q);$('#wordFindInfo').textContent=n?n+' hasil':'Tidak ditemukan';if(!n)return;doc.focus();if(!window.find(q,false,false,true,false,false,false)){getSelection().collapse(doc,0);window.find(q,false,false,true,false,false,false);}},
  replaceone(){const q=$('#wordFindInput').value;if(!q)return;const s=getSelection();if(s.toString().toLowerCase()===q.toLowerCase()&&doc.contains(s.anchorNode)){exec('insertText',$('#wordReplaceInput').value);}ACT.findnext();},
  replaceall(){const q=$('#wordFindInput').value,r=$('#wordReplaceInput').value;if(!q)return;let n=0;const re=new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi');const walker=document.createTreeWalker(doc,NodeFilter.SHOW_TEXT),nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);nodes.forEach(t=>{if(re.test(t.nodeValue)){re.lastIndex=0;t.nodeValue=t.nodeValue.replace(re,()=>{n++;return r;});}re.lastIndex=0;});$('#wordFindInfo').textContent=n+' diganti';if(n)changed();},
  headfoot(){const h=prompt('Teks header (kosongkan untuk menghapus):',meta.header||'');if(h===null)return;const f=prompt('Teks footer. Tulis {n} untuk nomor halaman, mis. Halaman {n}:',meta.footer||'Halaman {n}');if(f===null)return;meta.header=h.trim().slice(0,120);meta.footer=f.trim().slice(0,120);applyView();save();toast('Header & footer diperbarui (nomor halaman tampil saat cetak/PDF).');},
  toc(){const hs=[...doc.querySelectorAll('h1,h2,h3')];if(!hs.length){toast('Belum ada judul. Pakai gaya Judul 1–3 dulu.');return;}exec('insertHTML','<div class="word-toc"><p><b>Daftar isi</b></p>'+hs.map(h=>'<p style="margin:0 0 4px '+(({H1:0,H2:18,H3:36})[h.tagName])+'px">'+esc(h.textContent.trim())+'</p>').join('')+'</div><p><br></p>');},
  tblstyle(){const c=curCell();if(!c){toast('Letakkan kursor di dalam tabel.');return;}const t=c.closest('table'),n=prompt('Gaya tabel:\n1 = Garis penuh\n2 = Selang-seling (zebra)\n3 = Hanya garis mendatar\n4 = Tanpa garis','1');if(!n)return;const m={1:'',2:'tbl-zebra',3:'tbl-lines',4:'tbl-plain'}[n.trim()];if(m===undefined){toast('Pilih angka 1–4.');return;}t.classList.remove('tbl-zebra','tbl-lines','tbl-plain');if(m)t.classList.add(m);changed();},
  cellclear(){const c=curCell();if(!c){toast('Letakkan kursor di dalam tabel.');return;}const r=savedRange,cells=new Set([c]);if(r&&!r.collapsed)c.closest('table').querySelectorAll('td,th').forEach(x=>{if(r.intersectsNode(x))cells.add(x);});cells.forEach(x=>x.style.background='');changed();},
  txt(){download(new Blob([doc.innerText],{type:'text/plain;charset=utf-8'}),meta.title+'.txt');},
  watermark(){const t=prompt('Teks tanda air (kosongkan untuk menghapus), mis. DRAF / RAHASIA:',meta.wm||'');if(t===null)return;meta.wm=t.trim().slice(0,30);applyView();save();toast(meta.wm?'Tanda air dipasang (tampil juga di cetak/PDF).':'Tanda air dihapus.');},
  footnote(){const t=prompt('Isi catatan kaki:');if(!t||!t.trim())return;restore();let box=doc.querySelector('.word-footnotes');
   if(!box){box=document.createElement('div');box.className='word-footnotes';box.contentEditable='false';doc.appendChild(box);}
   const n=doc.querySelectorAll('sup.fn').length+1;exec('insertHTML','<sup class="fn">'+n+'</sup>');
   const p=document.createElement('p');p.innerHTML='<sup>'+n+'</sup> '+esc(t.trim().slice(0,300));box.appendChild(p);changed();},
  sample(){if(!confirm('Ganti isi dokumen dengan contoh?'))return;doc.innerHTML=SAMPLE;changed();}
 };
 $$('[data-word-act]').forEach(b=>b.addEventListener('click',()=>{const f=ACT[b.dataset.wordAct];if(f)f();}));
 $('#wordImgInput').addEventListener('change',e=>{
  const f=e.target.files[0];e.target.value='';if(!f)return;if(!/^image\//.test(f.type)||f.size>6*1024*1024){toast('Pilih gambar maksimum 6 MB.');return;}
  const fr=new FileReader();fr.onload=()=>{const img=new Image();img.onload=()=>{const max=900,k=Math.min(1,max/img.width),cv=document.createElement('canvas');cv.width=Math.round(img.width*k);cv.height=Math.round(img.height*k);cv.getContext('2d').drawImage(img,0,0,cv.width,cv.height);exec('insertHTML',`<img src="${cv.toDataURL(f.type==='image/png'?'image/png':'image/jpeg',.85)}" alt="Gambar" style="max-width:100%">`);};img.src=fr.result;};fr.readAsDataURL(f);
 });


 /* V158: warna sel */
 $('#wordCellColor').addEventListener('input',e=>{const v=e.target.value;$('#wordCellBar').style.background=v;const c=curCell();if(!c){toast('Letakkan kursor di dalam tabel.');return;}const r=savedRange,cells=new Set([c]);if(r&&!r.collapsed)c.closest('table').querySelectorAll('td,th').forEach(x=>{if(r.intersectsNode(x))cells.add(x);});cells.forEach(x=>x.style.background=v);changed();});
 $('#wordCellColor').addEventListener('mousedown',e=>e.stopPropagation());
 /* V158: alat gambar (ketuk gambar → ubah ukuran, rata, hapus) */
 const imgBar=$('#wordImgBar');let selImg=null;
 function hideImg(){if(selImg)selImg.classList.remove('img-sel');selImg=null;imgBar.hidden=true;}
 function showImg(im){hideImg();selImg=im;im.classList.add('img-sel');imgBar.hidden=false;const r=im.getBoundingClientRect(),bw=imgBar.offsetWidth||300;imgBar.style.left=Math.max(6,Math.min(window.innerWidth-bw-6,r.left+r.width/2-bw/2))+'px';imgBar.style.top=Math.max(8,Math.min(window.innerHeight-50,r.top-46<8?r.bottom+8:r.top-46))+'px';}
 doc.addEventListener('click',e=>{if(e.target.tagName==='IMG')showImg(e.target);else hideImg();});
 doc.addEventListener('keydown',e=>{if(selImg&&(e.key==='Delete'||e.key==='Backspace')&&getSelection().isCollapsed){e.preventDefault();selImg.remove();hideImg();changed();}});
 $('.word-page-wrap').addEventListener('scroll',hideImg,{passive:true});
 imgBar.addEventListener('mousedown',e=>e.preventDefault());
 imgBar.addEventListener('click',e=>{const b=e.target.closest('[data-img]');if(!b||!selImg)return;const k=b.dataset.img,im=selImg;
  if(k==='del'){im.remove();hideImg();changed();return;}
  if(/^\d+$/.test(k)){im.style.width=k+'%';im.style.height='auto';}
  else{im.style.display='block';im.style.marginLeft=k==='left'?'0':'auto';im.style.marginRight=k==='right'?'0':'auto';}
  changed();showImg(im);});
 /* ---------- Ekspor ---------- */
 function pageCss(){return pageCss0()+(meta.cols===2?'body{column-count:2;column-gap:36px}':'');}
 function pageCss0(){return'body{font-family:Calibri,Arial,sans-serif;font-size:12pt;line-height:1.5;color:#1f2430;margin:2.2cm}h1{font-size:24pt}h2{font-size:18pt}h3{font-size:14pt}div.word-callout{border-left:4px solid #e8a317;background:#fff7e0;padding:6px 14px;margin:10px 0}blockquote{border-left:4px solid #185abd;margin:12px 0;padding:6px 16px;color:#46506a;background:#f2f6fd}table{border-collapse:collapse;width:100%}td,th{border:1px solid #9aa6bd;padding:6px 8px}th{background:#e8eefb}img{max-width:100%}hr.page-break{page-break-after:always;border:0}table.tbl-plain td,table.tbl-plain th{border-color:transparent}table.tbl-zebra tr:nth-child(even) td{background:#f1f5fc}table.tbl-lines td,table.tbl-lines th{border-width:0 0 1px 0}sup.fn{color:#185abd;font-weight:700}.word-footnotes{border-top:1px solid #9aa6bd;margin-top:28px;padding-top:6px;font-size:10pt;color:#46506a}.word-footnotes p{margin:0 0 3px}'+(wmUrl()?'body{-webkit-print-color-adjust:exact;print-color-adjust:exact;background:url("'+wmUrl()+'") no-repeat center 40%;background-size:70% auto}':'');}
 function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
 function hf(){return(meta.header?'<div style="text-align:center;color:#7a8499;font-size:10pt">'+esc(meta.header)+'</div>':'');}
 function ft(){return(meta.footer?'<div style="text-align:center;color:#7a8499;font-size:10pt;margin-top:24px">'+esc(meta.footer.replace(/\{n\}/g,'1'))+'</div>':'');}
 function exportDoc(){download(new Blob(['<!doctype html><html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><title>'+esc(meta.title)+'</title><style>'+pageCss()+'</style></head><body>'+hf()+doc.innerHTML+ft()+'</body></html>'],{type:'application/msword'}),meta.title+'.doc');}
 function printDoc(){const f=document.createElement('iframe');f.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0';document.body.appendChild(f);const d=f.contentDocument;d.open();d.write('<!doctype html><html><head><meta charset="utf-8"><title>'+esc(meta.title)+'</title><style>'+pageCss()+''+(meta.land?'@page{size:landscape}':'')+'@page{margin:1.8cm}body{margin:.4cm}'+(meta.footer?'@page{@bottom-center{content:"'+meta.footer.replace(/["\\]/g,'').replace(/\{n\}/g,'" counter(page) "')+'";font-size:10pt;color:#7a8499}}':'')+(meta.header?'@page{@top-center{content:"'+meta.header.replace(/["\\]/g,'')+'";font-size:10pt;color:#7a8499}}':'')+'</style></head><body>'+doc.innerHTML+'</body></html>');d.close();setTimeout(()=>{try{f.contentWindow.focus();f.contentWindow.print();}catch(_){toast('Cetak tidak tersedia di peramban ini.');}setTimeout(()=>f.remove(),2000);},350);}

 /* ---------- Editor ---------- */
 doc.addEventListener('input',changed);
 doc.addEventListener('keyup',syncState);doc.addEventListener('mouseup',syncState);
 doc.addEventListener('paste',e=>{e.preventDefault();const t=(e.clipboardData||window.clipboardData).getData('text/plain');document.execCommand('insertText',false,t);});
 doc.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&(e.key==='s'||e.key==='S')){e.preventDefault();save();toast('Tersimpan di perangkat.');}if((e.ctrlKey||e.metaKey)&&(e.key==='f'||e.key==='F')){e.preventDefault();$('#wordFind').classList.add('open');$('#wordFindInput').focus();}});

 /* ---------- Cubit untuk zoom ---------- */
 (()=>{const el=$('.word-page-wrap'),dist=t=>Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY);let d0=0,z0=0;
  el.addEventListener('touchstart',e=>{if(e.touches.length===2){d0=dist(e.touches);z0=meta.zoom;}},{passive:true});
  el.addEventListener('touchmove',e=>{if(e.touches.length===2&&d0){e.preventDefault();meta.zoom=Math.max(50,Math.min(160,Math.round(z0*dist(e.touches)/d0)));applyView();clearTimeout(saveTimer);saveTimer=setTimeout(save,600);}},{passive:false});
  el.addEventListener('touchend',e=>{if(e.touches.length<2)d0=0;},{passive:true});})();
 /* ---------- Bilah cepat di atas keyboard (HP) ---------- */
 const quick=$('#wordQuick'),mq=window.matchMedia('(max-width:720px)');
 function posQuick(){const vv=window.visualViewport;if(!quick||!vv)return;quick.style.bottom=Math.max(0,window.innerHeight-vv.height-vv.offsetTop)+'px';}
 if(window.visualViewport){visualViewport.addEventListener('resize',posQuick);visualViewport.addEventListener('scroll',posQuick);}
 doc.addEventListener('focus',()=>{if(mq.matches&&quick){view.classList.add('rib-off');quick.classList.add('open');posQuick();}});
 doc.addEventListener('blur',()=>{setTimeout(()=>{if(quick&&!doc.contains(document.activeElement)&&!quick.contains(document.activeElement))quick.classList.remove('open');},250);});
 $$('[data-word-quick]').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.wordQuick==='ribbon'){view.classList.toggle('rib-off');if(!view.classList.contains('rib-off'))view.querySelector('.ox-ribbon').scrollIntoView({block:'nearest'});}}));
 /* ---------- Buka / tutup ---------- */
 function open(){dash.classList.add('hidden');editor&&editor.classList.add('hidden');$('#excelMode')?.classList.add('hidden');view.classList.remove('hidden');document.body.classList.add('office-open');applyView();count();}
 function home(){save();view.classList.add('hidden');document.body.classList.remove('office-open');dash.classList.remove('hidden');}
 document.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(!b)return;switch(b.dataset.action){case'wordMode':open();break;case'wordHome':home();break;case'wordSave':save();toast('Tersimpan di perangkat.');break;case'wordExport':exportDoc();break;case'home':if(!view.classList.contains('hidden'))home();break;}});
 window.addEventListener('beforeunload',()=>{try{save();}catch(_){}});

 const SAMPLE='<h1>Judul Dokumen</h1><p>Mulai menulis di sini. Gunakan pita di atas untuk mengubah <b>tebal</b>, <i>miring</i>, <u>garis bawah</u>, warna, daftar, tabel, dan gambar.</p><h2>Bagian pertama</h2><p>Dokumen disimpan otomatis di perangkat ini dan dapat diunduh sebagai .DOC atau dicetak ke PDF.</p><blockquote>Kutipan tampil dengan garis biru di sisi kiri.</blockquote>';
 try{Object.assign(meta,JSON.parse(localStorage.getItem(META)||'{}'));}catch(_){}
 try{const saved=localStorage.getItem(STORE);doc.innerHTML=saved||SAMPLE;}catch(e){doc.innerHTML=SAMPLE;}
 applyView();count();
 window.cdmsWord={open,home};
})();
