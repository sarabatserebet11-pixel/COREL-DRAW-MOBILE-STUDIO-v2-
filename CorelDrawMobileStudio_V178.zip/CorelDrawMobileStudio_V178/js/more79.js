/* V91: grup menu baru "Ekspor Lot" - ekspor banyak bagian sekaligus ke satu berkas ZIP: tiap grup, grup terpilih, tiap objek terpilih, atau tiap objek di desain
   (PNG / JPG / SVG, skala, margin, latar transparan atau berwarna; nama berkas dari nama grup) + tab Lot di panel Penata + tombol cepat. ZIP dibuat lokal tanpa pustaka. */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,P=CDMS.Penata,{MENUS,BT,it,sels,T,cell}=M;
if(!M.HUBS||!P||!C.objMarkup)return;
const addTab=(k,l,html,h)=>{const nh={};Object.keys(h).forEach(x=>{nh["x91_"+x]=h[x];});P.addTab(k,l,html.replace(/data-h="([^"]+)"/g,'data-h="x91_$1"'),nh);};
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n);
const b=(k,l,i)=>`<button data-h="${k}">${i?ic(i):""}<span>${l}</span></button>`;
const num=(id,d)=>{const e=$("#"+id),v=e?parseFloat(e.value):NaN;return isFinite(v)?v:d;};
const val=(id,d)=>{const e=$("#"+id);return e&&e.value?e.value:d;};
const MAXF=100;
/* ---- ZIP (metode simpan, tanpa kompresi) ---- */
const CRC=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0;}return t;})();
const crc32=u=>{let c=0xFFFFFFFF;for(let i=0;i<u.length;i++)c=CRC[(c^u[i])&255]^(c>>>8);return(c^0xFFFFFFFF)>>>0;};
function zip(files){const enc=new TextEncoder(),parts=[],cd=[];let off=0;const d=new Date(),dt=((d.getHours()<<11)|(d.getMinutes()<<5)|(d.getSeconds()>>1))&0xFFFF,dd=(((d.getFullYear()-1980)<<9)|((d.getMonth()+1)<<5)|d.getDate())&0xFFFF;
 files.forEach(f=>{const nm=enc.encode(f.name),c=crc32(f.data),n=f.data.length;
  const lh=new DataView(new ArrayBuffer(30));lh.setUint32(0,0x04034b50,true);lh.setUint16(4,20,true);lh.setUint16(6,0x0800,true);lh.setUint16(8,0,true);lh.setUint16(10,dt,true);lh.setUint16(12,dd,true);lh.setUint32(14,c,true);lh.setUint32(18,n,true);lh.setUint32(22,n,true);lh.setUint16(26,nm.length,true);lh.setUint16(28,0,true);
  parts.push(new Uint8Array(lh.buffer),nm,f.data);
  const ch=new DataView(new ArrayBuffer(46));ch.setUint32(0,0x02014b50,true);ch.setUint16(4,20,true);ch.setUint16(6,20,true);ch.setUint16(8,0x0800,true);ch.setUint16(10,0,true);ch.setUint16(12,dt,true);ch.setUint16(14,dd,true);ch.setUint32(16,c,true);ch.setUint32(20,n,true);ch.setUint32(24,n,true);ch.setUint16(28,nm.length,true);ch.setUint32(42,off,true);
  cd.push(new Uint8Array(ch.buffer),nm);off+=30+nm.length+n;});
 const cs=cd.reduce((t,x)=>t+x.length,0),e=new DataView(new ArrayBuffer(22));e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,cs,true);e.setUint32(16,off,true);
 return new Blob([...parts,...cd,new Uint8Array(e.buffer)],{type:"application/zip"});}
/* ---- bagian yang diekspor ---- */
const aman=s=>String(s||"").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-z0-9_-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,40)||"bagian";
function unitsGrup(a){const m=new Map();a.forEach(o=>{if(!o.groupId)return;if(!m.has(o.groupId))m.set(o.groupId,[]);m.get(o.groupId).push(o);});let i=0;return[...m.values()].map(mem=>({n:(mem.find(o=>o.groupName)||{}).groupName||"grup-"+(++i),objs:mem}));}
function bagian(mode){const vis=S.objects.filter(o=>!o.hidden),pil=sels().filter(o=>!o.hidden);let u=[];
 if(mode==="grup")u=unitsGrup(vis);
 else if(mode==="grupsel"){const g=new Set(pil.filter(o=>o.groupId).map(o=>o.groupId));u=unitsGrup(vis.filter(o=>g.has(o.groupId)));}
 else if(mode==="objsel")u=pil.map((o,i)=>({n:(o.name||o.type)+"-"+(i+1),objs:[o]}));
 else u=vis.map((o,i)=>({n:(o.name||o.type)+"-"+(i+1),objs:[o]}));
 return u;}
function svgOf(a,pad,bg){let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
 a.forEach(o=>{const w=o.w||0,h=o.h||0;let ax=o.x,ay=o.y,bx=o.x+w,by=o.y+h;if(o.rotation){const r=Math.hypot(w,h)/2,cx=o.x+w/2,cy=o.y+h/2;ax=cx-r;ay=cy-r;bx=cx+r;by=cy+r;}
  const sw=(o.strokeWidth||0)/2;x0=Math.min(x0,ax-sw);y0=Math.min(y0,ay-sw);x1=Math.max(x1,bx+sw);y1=Math.max(y1,by+sw);});
 x0-=pad;y0-=pad;const w=Math.max(1,x1-x0+pad),h=Math.max(1,y1-y0+pad);
 return{w,h,svg:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${x0} ${y0} ${w} ${h}" width="${w}" height="${h}">${bg?`<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="${bg}"/>`:""}${a.map(o=>C.objMarkup(o)).join("")}</svg>`};}
function raster(r,fmt,sc,bg){return new Promise(res=>{let W=Math.round(r.w*sc),Hh=Math.round(r.h*sc);const mx=Math.min(1,8000/Math.max(W,Hh,1));W=Math.max(1,Math.round(W*mx));Hh=Math.max(1,Math.round(Hh*mx));
 const url=URL.createObjectURL(new Blob([r.svg],{type:"image/svg+xml;charset=utf-8"})),im=new Image();
 im.onload=()=>{try{const cv=document.createElement("canvas");cv.width=W;cv.height=Hh;const x=cv.getContext("2d");if(fmt==="jpg"){x.fillStyle=bg||"#ffffff";x.fillRect(0,0,W,Hh);}x.drawImage(im,0,0,W,Hh);cv.toBlob(bl=>{URL.revokeObjectURL(url);res(bl);},fmt==="jpg"?"image/jpeg":"image/png",.92);}catch(e){URL.revokeObjectURL(url);res(null);}};
 im.onerror=()=>{URL.revokeObjectURL(url);res(null);};im.src=url;});}
let sibuk=false;
async function buat(mode,opt){opt=opt||{};const fmt=opt.fmt||val("p91fmt","png"),pad=Math.max(0,opt.pad!==undefined?opt.pad:num("p91pad",16)),sc=Math.max(.25,Math.min(6,opt.sc||num("p91sc",2))),tr=opt.transparan!==undefined?opt.transparan:($("#p91tr")?$("#p91tr").checked:true),warna=opt.warna||val("p91bg","#ffffff");
 let u=bagian(mode);if(!u.length)return{err:mode==="grup"?"Belum ada grup di desain":mode==="grupsel"?"Pilih grup dulu":mode==="objsel"?"Pilih objek dulu":"Desain masih kosong"};
 if(u.length>MAXF){u=u.slice(0,MAXF);}const bg=fmt==="jpg"?warna:(tr?null:warna),pakai=new Set(),files=[],enc=new TextEncoder();let gagal=0;
 for(let i=0;i<u.length;i++){const r=svgOf(u[i].objs,pad,fmt==="svg"?(tr?null:warna):null);let nm=aman(u[i].n),k=nm,c=2;while(pakai.has(k))k=nm+"-"+(c++);pakai.add(k);
  if(fmt==="svg")files.push({name:k+".svg",data:enc.encode(r.svg)});
  else{const bl=await raster(r,fmt,sc,bg);if(!bl){gagal++;continue;}files.push({name:k+"."+fmt,data:new Uint8Array(await bl.arrayBuffer())});}
  if(opt.progress)opt.progress(i+1,u.length);}
 if(!files.length)return{err:"Semua bagian gagal dirender"};return{blob:zip(files),n:files.length,total:u.length,gagal,dipotong:bagian(mode).length>MAXF};}
async function ekspor(mode){if(sibuk)return T("Ekspor sedang berjalan");sibuk=true;T("Mengekspor…");
 try{const r=await buat(mode,{progress:(i,n)=>{if(n>4&&i%4===0)T("Mengekspor "+i+"/"+n+"…");}});if(r.err)return T(r.err);
  CDMS.Export.download(r.blob,aman(S.projectName||"desain")+"_"+(mode==="grup"||mode==="grupsel"?"grup":"objek")+".zip");
  T(r.n+" berkas dalam ZIP"+(r.gagal?" ("+r.gagal+" gagal)":"")+(r.dipotong?" — dibatasi "+MAXF+" berkas":""));}
 finally{sibuk=false;}}
CDMS.EksporLot={buat,zip,crc32};
const H={eg:()=>ekspor("grup"),es:()=>ekspor("grupsel"),eo:()=>ekspor("objsel"),ea:()=>ekspor("semua")};
addTab("lot91","Lot",`<p class="muted" style="margin:0 0 8px">Ekspor banyak bagian sekaligus ke satu berkas ZIP. Nama berkas diambil dari nama grup (ubah di tab Grup). Objek tersembunyi dilewati; maksimum ${MAXF} berkas.</p>
 <div class="p69row"><label>Format<select id="p91fmt"><option value="png">PNG</option><option value="jpg">JPG</option><option value="svg">SVG</option></select></label><label>Skala<input id="p91sc" type="number" value="2" min="0.25" max="6" step="0.25"></label><label>Margin (px)<input id="p91pad" type="number" value="16" min="0"></label><label>Warna latar<input id="p91bg" type="color" value="#ffffff"></label></div>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:6px 0 10px"><input id="p91tr" type="checkbox" checked> Latar transparan (PNG/SVG; JPG selalu berlatar)</label>
 <div class="p69btns">${b("eg","Semua grup","group")}${b("es","Grup terpilih","select")}${b("eo","Tiap objek terpilih","export")}${b("ea","Tiap objek di desain","layers")}</div>`,H);
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q91="grup" title="Ekspor semua grup ke ZIP">${ic("export")}</button><button data-q91="panel" title="Pengaturan Ekspor Lot">${ic("settings")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q91]");if(!x)return;if(x.dataset.q91==="grup")ekspor("grup");else P.openTab("lot91");});}
MENUS.lot1=()=>[{h:"Ekspor ke ZIP",items:[it("Semua grup",()=>ekspor("grup"),"group"),it("Grup terpilih",()=>ekspor("grupsel"),"select"),it("Tiap objek terpilih",()=>ekspor("objsel"),"export"),it("Tiap objek di desain",()=>ekspor("semua"),"layers")]}];
MENUS.lot2=()=>[{h:"Pengaturan",items:[it("Buka panel Lot (format, skala, margin)",()=>P.openTab("lot91"),"panel")]}];
BT.push(["lot1","export","Ekspor ZIP"],["lot2","settings","Pengaturan lot"]);
const LOT=["lot1","lot2"],ai=M.HUBS.findIndex(h=>h[0]==="periksa");
M.HUBS.splice(ai<0?M.HUBS.length:ai+1,0,["lot","export","Ekspor Lot",LOT]);
MENUS.hub_lot=()=>[{h:"Ekspor Lot",items:LOT.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($('[data-menu="hub_lot"]'),k),0));})}];
})();
