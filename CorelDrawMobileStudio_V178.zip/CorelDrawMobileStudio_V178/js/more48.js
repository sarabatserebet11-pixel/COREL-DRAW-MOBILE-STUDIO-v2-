/* V59: menu Cari Teks (cari & ganti semua teks, pilih yang cocok, statistik kata/waktu baca, hapus teks kosong) dan Sampul (podcast, banner LinkedIn, banner channel, highlight story, playlist) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,it,tc,sels,pick,T}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,STAR,AC,INK,MUTE}=K;
const $=s=>document.querySelector(s);
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const WHT="#ffffff";
/* ---------- Cari & Ganti ---------- */
const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
function fit(o){const f=CDMS.Rapikan&&CDMS.Rapikan.fit;if(f)f(o);}
function texts(scope){const a=scope==="sel"?sels():S.objects;return a.filter(o=>o.type==="text");}
function rx(q,cs,word){if(!q)return null;let p=esc(q);if(word)p="(?<![\\p{L}\\p{N}_])"+p+"(?![\\p{L}\\p{N}_])";return new RegExp(p,"gu"+(cs?"":"i"));}
function cari(){N.openModal("Cari & ganti teks",`<div class="st-pane"><div class="st-grid"><label>Cari<input id="ctQ" type="text" placeholder="kata yang dicari"></label><label>Ganti dengan<input id="ctR" type="text" placeholder="kosongkan untuk menghapus"></label><label>Cakupan<select id="ctS"><option value="all">Semua teks</option><option value="sel">Teks terpilih</option></select></label><label>Huruf besar/kecil<select id="ctC"><option value="0">Abaikan</option><option value="1">Harus sama</option></select></label><label>Kata utuh<select id="ctW"><option value="0">Tidak</option><option value="1">Ya</option></select></label></div><p id="ctInfo" class="muted">Ketik kata lalu pilih tindakan.</p><div class="property-actions"><button class="btn subtle" id="ctPick">Pilih yang cocok</button><button class="btn primary" id="ctDo">Ganti semua</button></div></div>`);
 const read=()=>{const q=$("#ctQ").value;return {q,re:rx(q,$("#ctC").value==="1",$("#ctW").value==="1"),sc:$("#ctS").value};};
 const count=()=>{const{q,re,sc}=read();if(!re)return {n:0,objs:[]};let n=0;const objs=texts(sc).filter(o=>{const m=String(o.text||"").match(re);if(m){n+=m.length;return true;}return false;});return {n,objs};};
 const upd=()=>{const{q}=read();if(!q){$("#ctInfo").textContent="Ketik kata lalu pilih tindakan.";return;}const r=count();$("#ctInfo").textContent=r.n?r.n+" cocok di "+r.objs.length+" teks":"Tidak ada yang cocok";};
 ["ctQ","ctS","ctC","ctW"].forEach(i=>$("#"+i).addEventListener("input",upd));
 $("#ctPick").onclick=()=>{const r=count();if(!r.objs.length)return T("Tidak ada yang cocok");N.closeModal();pick(r.objs);T(r.objs.length+" teks dipilih");};
 $("#ctDo").onclick=()=>{const{re,sc}=read(),rep=$("#ctR").value;if(!re)return T("Isi kata yang dicari");const r=count();if(!r.n)return T("Tidak ada yang cocok");
  Hi.snapshot();r.objs.forEach(o=>{o.text=String(o.text).replace(re,()=>rep);fit(o);});C.render();N.closeModal();T(r.n+" kata diganti di "+r.objs.length+" teks");};}
/* ---------- Statistik ---------- */
function stat(){const sel=sels().filter(o=>o.type==="text"),a=sel.length?sel:texts("all");if(!a.length)return T("Belum ada teks");
 const s=a.map(o=>String(o.text||"")).join("\n"),kata=(s.match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu)||[]).length,kal=(s.match(/[^.!?\n]+[.!?]*/g)||[]).filter(x=>x.trim()).length,baris=s.split("\n").filter(l=>l.trim()).length,mnt=kata/200;
 const wkt=mnt<1?Math.max(1,Math.round(mnt*60))+" detik":(Math.round(mnt*10)/10)+" menit";
 N.openModal("Statistik teks",`<div class="st-pane"><p class="muted">${sel.length?"Dari "+a.length+" teks terpilih":"Dari semua teks ("+a.length+" objek)"}</p><div class="st-grid"><label>Kata<output>${kata}</output></label><label>Karakter<output>${s.length}</output></label><label>Tanpa spasi<output>${s.replace(/\s/g,"").length}</output></label><label>Kalimat<output>${kal}</output></label><label>Baris<output>${baris}</output></label><label>Waktu baca<output>${wkt}</output></label></div></div>`);}
function hapusKosong(){const k=S.objects.filter(o=>o.type==="text"&&!String(o.text||"").trim());if(!k.length)return T("Tidak ada teks kosong");Hi.snapshot();const ids=new Set(k.map(o=>o.id));S.objects=S.objects.filter(o=>!ids.has(o.id));S.selectedIds=[];S.selected=null;C.render();T(k.length+" teks kosong dihapus");}
function pilihSemua(){const a=texts("all");if(!a.length)return T("Belum ada teks");pick(a);T(a.length+" teks dipilih");}
MENUS.cariteks=()=>[
 {h:"Cari",items:[it("Cari & ganti…",cari,"text"),tc("Pilih semua teks",pilihSemua)]},
 {h:"Info",items:[tc("Statistik teks",stat),tc("Hapus teks kosong",hapusKosong)]}];
BT.push(["cariteks","findtext","Cari Teks"]);
hubAdd("teks","cariteks");
/* ---------- Sampul ---------- */
const ring=(x,y,d,c,w)=>E(x,y,d,d,"none",{stroke:c,strokeWidth:w});
Object.assign(COMP,{
 "Sampul podcast":()=>({w:600,h:600,a:[R(0,0,600,600,AC,{rx:48,name:"Sampul podcast"}),ring(100,60,400,"#ffffff40",6),ring(150,110,300,"#ffffff60",6),E(220,150,160,160,WHT),R(270,310,60,70,WHT,{rx:30}),R(290,380,20,60,WHT),X("PODCAST",300,470,28,"#ffffffcc",{bold:1}),X("Judul Episode",300,530,52,WHT,{bold:1})]}),
 "Banner LinkedIn":()=>({w:1000,h:250,a:[R(0,0,1000,250,INK,{rx:24,name:"Banner"}),E(780,-80,320,320,AC,{opacity:70}),E(880,100,240,240,"#00c9a7",{opacity:60}),X("Nama Anda",60,90,64,WHT,{left:1,bold:1}),X("Profesi · Spesialisasi · Kota",60,160,30,"#c8cee6",{left:1}),R(60,196,120,6,"#00c9a7",{rx:3})]}),
 "Banner channel":()=>({w:1000,h:260,a:[R(0,0,1000,260,"#ff4f6d",{rx:24,name:"Banner channel"}),E(60,50,160,160,WHT),P(110,90,70,80,"M20 10L90 50L20 90Z","#ff4f6d"),X("Nama Channel",250,100,60,WHT,{left:1,bold:1}),X("Konten baru setiap Jumat",250,165,30,"#ffffffdd",{left:1})]}),
 "Highlight story":()=>({w:540,h:200,a:[...[["#6d5dfc","Tips"],["#00c9a7","Promo"],["#ffb020","Info"]].flatMap((h,i)=>{const x=i*190;return [ring(x,0,160,h[0],8),E(x+16,16,128,128,h[0],{opacity:25}),P(x+48,48,64,64,STAR,h[0]),X(h[1],x+80,184,26,INK,{bold:1})];})]}),
 "Sampul playlist":()=>({w:500,h:500,a:[R(0,0,500,500,"#11162a",{rx:36,name:"Sampul playlist"}),R(40,40,420,420,"#232846",{rx:24}),E(90,90,320,320,AC,{opacity:80}),E(165,165,170,170,"#11162a"),E(225,225,50,50,AC),X("MIX SANTAI",250,440,32,WHT,{bold:1})]})
});
MENUS.sampul=()=>[
 {h:"Audio & video",items:["Sampul podcast","Sampul playlist","Banner channel"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Profil & story",items:["Banner LinkedIn","Highlight story"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["sampul","cover","Sampul"]);
hubAdd("pustaka","sampul");
CDMS.CariTeks={rx,texts};
})();
