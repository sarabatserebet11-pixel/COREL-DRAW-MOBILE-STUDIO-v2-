window.CDMS=window.CDMS||{};CDMS.Tools={init(){document.querySelectorAll("[data-tool]").forEach(b=>b.addEventListener("click",()=>{CDMS.state.tool=b.dataset.tool;document.querySelectorAll("[data-tool]").forEach(x=>x.classList.toggle("active",x===b));if(b.dataset.tool==="image")document.getElementById("imageInput").click();if(b.dataset.tool==="text")CDMS.Text.open();}));document.getElementById("imageInput").addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;const reader=new FileReader();reader.onload=()=>{CDMS.History.snapshot();const id=crypto.randomUUID();CDMS.state.objects.push({id,type:"image",name:f.name,x:100,y:100,w:400,h:300,href:reader.result,fill:"#fff",stroke:"#20243a",strokeWidth:0,opacity:100});CDMS.state.selected=id;CDMS.Canvas.render();};reader.readAsDataURL(f);e.target.value="";});CDMS.Canvas.bindProperties();}};

document.addEventListener("keydown",e=>{
 const tag=e.target?.tagName?.toLowerCase();if(["input","textarea","select"].includes(tag))return;
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="s"){e.preventDefault();CDMS.Storage.save();}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="z"){e.preventDefault();CDMS.History.undo();}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="y"){e.preventDefault();CDMS.History.redo();}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="d"){e.preventDefault();CDMS.Canvas.duplicateSelected();}
 if(e.key==="Delete"||e.key==="Backspace")CDMS.Canvas.deleteSelected();
 if(e.key==="Escape")CDMS.Navigation.closeModal();
});
