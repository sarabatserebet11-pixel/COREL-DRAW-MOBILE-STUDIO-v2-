/* V76: tab baru Menu (daftar semua tab + cari), Palet (harmoni warna dari satu warna dasar, terapkan berurutan, teks kontras otomatis) di panel Penata; panel bisa diciutkan dan mengingat tab terakhir; tombol cepat baru */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n);
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const done=m=>{C.render();if(m)T(m);};
const hex=c=>/^#[0-9a-f]{6}$/i.test(c||"");
function h2hsl(h){let r=parseInt(h.slice(1,3),16)/255,g=parseInt(h.slice(3,5),16)/255,bl=parseInt(h.slice(5,7),16)/255;const mx=Math.max(r,g,bl),mn=Math.min(r,g,bl),l=(mx+mn)/2;let H=0,Sx=0;if(mx!==mn){const d=mx-mn;Sx=l>.5?d/(2-mx-mn):d/(mx+mn);H=mx===r?(g-bl)/d+(g<bl?6:0):mx===g?(bl-r)/d+2:(r-g)/d+4;H*=60;}return [H,Sx,l];}
function hsl2h(H,Sx,L){H=((H%360)+360)%360;const k=n=>(n+H/30)%12,a=Sx*Math.min(L,1-L),f=n=>L-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)));return "#"+[f(0),f(8),f(4)].map(v=>Math.round(v*255).toString(16).padStart(2,"0")).join("");}
const lum=h=>{const p=[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255).map(v=>v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4));return .2126*p[0]+.7152*p[1]+.0722*p[2];};
const SK={komp:[0,180],analog:[-30,0,30],triad:[0,120,240],tetra:[0,90,180,270]};
let pal=[],skema="analog";
function bangun(){const base=$("#p76base").value;let [h,s,l]=h2hsl(base);if(s<.08){s=.6;l=Math.max(.35,Math.min(.65,l));}
 if(skema==="mono")pal=[.2,.35,.5,.65,.8].map(x=>hsl2h(h,s,x));else pal=SK[skema].map(d=>hsl2h(h+d,s,l));
 const box=$("#p76pal");if(box)box.innerHTML=pal.map((c,i)=>`<button class="p76sw" data-p76="${i}" title="${c}" style="background:${c}"><span style="color:${lum(c)>.45?"#000":"#fff"}">${c.toUpperCase()}</span></button>`).join("");
 document.querySelectorAll(".p69 [data-sk]").forEach(x=>x.classList.toggle("on",x.dataset.sk===skema));}
const sels=()=>M.sels().filter(o=>!o.locked);
const setFill=(o,c)=>{if(o.type==="image")return;o.fill=c;delete o.grad;};
function terapkanBertahap(){const a=sels();if(!a.length)return T("Pilih objek dulu");if(!pal.length)bangun();Hi.snapshot();const seen=new Map();let i=0;
 a.forEach(o=>{const k=o.groupId||o.id;if(!seen.has(k))seen.set(k,pal[i++%pal.length]);});
 a.forEach(o=>setFill(o,seen.get(o.groupId||o.id)));done("Palet diterapkan berurutan pada "+seen.size+" unit");}
function ambilDasar(){const a=M.sels().find(o=>hex(o.fill));if(!a)return T("Pilih objek berwarna isi dulu");$("#p76base").value=a.fill.toLowerCase();bangun();}
function kontras(){const tx=sels().filter(o=>o.type==="text");if(!tx.length)return T("Pilih teks dulu");Hi.snapshot();let n=0;
 tx.forEach(t=>{const i=S.objects.indexOf(t),cx=t.x+t.w/2,cy=t.y+t.h/2;let bg=S.page.background&&hex(S.page.background)?S.page.background:"#ffffff";
  for(let k=i-1;k>=0;k--){const o=S.objects[k];if(o.hidden||o.type==="text"||!(o.w>0&&o.h>0))continue;if(cx>=o.x&&cx<=o.x+o.w&&cy>=o.y&&cy<=o.y+o.h){const f=o.grad&&hex(o.grad[0])?o.grad[0]:o.fill;if(hex(f)){bg=f;break;}}}
  t.fill=lum(bg)>.4?"#111111":"#ffffff";n++;});done(n+" teks diberi warna kontras otomatis");}
const H={komp:()=>{skema="komp";bangun();},analog:()=>{skema="analog";bangun();},triad:()=>{skema="triad";bangun();},tetra:()=>{skema="tetra";bangun();},mono:()=>{skema="mono";bangun();},
 ambil:ambilDasar,bertahap:terapkanBertahap,kontras,
 salin:()=>{if(!pal.length)bangun();try{navigator.clipboard.writeText(pal.join(" ")).then(()=>T("Kode warna disalin"),()=>T("Gagal menyalin"));}catch(e){T("Gagal menyalin");}}};
P.addTab("palet","Palet",`<div class="p69row"><label>Warna dasar<input id="p76base" type="color" value="#6d5dfc"></label></div>
 <div class="p69btns c3">${[["komp","Komplemen"],["analog","Analog"],["triad","Triadik"],["tetra","Tetradik"],["mono","Monokrom"]].map(x=>`<button data-h="${x[0]}" data-sk="${x[0]}"><span>${x[1]}</span></button>`).join("")}${b("ambil","Dari pilihan")}</div>
 <div id="p76pal" class="p76pal"></div>
 <p class="muted" style="margin-top:6px">Ketuk warna untuk mewarnai semua objek terpilih.</p>
 <div class="p69btns">${b("bertahap","Terapkan berurutan")}${b("salin","Salin kode warna")}</div>
 <div class="p69h">Keterbacaan</div><div class="p69btns">${b("kontras","Teks kontras otomatis")}</div>`,H);
document.addEventListener("input",e=>{if(e.target.id==="p76base")bangun();});
document.addEventListener("click",e=>{const w=e.target.closest&&e.target.closest("[data-p76]");if(w){const a=sels();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const c=pal[+w.dataset.p76];a.forEach(o=>setFill(o,c));done("Warna "+c.toUpperCase()+" diterapkan");return;}
 const t=e.target.closest&&e.target.closest(".p69 [data-t=palet]");if(t)bangun();});
/* ---- tab Menu (daftar semua tab) ---- */
function drawMenu(){const q=($("#p76q")?$("#p76q").value:"").trim().toLowerCase(),box=$("#p76menu");if(!box)return;
 const l=P.TABS.filter(t=>t[0]!=="menu"&&(!q||t[1].toLowerCase().includes(q)||t[0].includes(q)));
 box.innerHTML=l.length?l.map(t=>`<button data-p76t="${t[0]}"><span>${t[1]}</span></button>`).join(""):'<p class="muted">Tidak ada tab cocok.</p>';}
P.addTab("menu","Menu",`<div class="p69row"><label>Cari tab<input id="p76q" type="text" placeholder="mis. warna, garis, ekspor"></label></div><div id="p76menu" class="p69btns c3"></div>`,{});
document.addEventListener("input",e=>{if(e.target.id==="p76q")drawMenu();});
document.addEventListener("click",e=>{const x=e.target.closest&&e.target.closest("[data-p76t]");if(x){P.openTab(x.dataset.p76t);if(x.dataset.p76t==="palet")bangun();return;}
 const t=e.target.closest&&e.target.closest(".p69 [data-t=menu]");if(t)drawMenu();});
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q6="palet" title="Palet warna">${ic("color")}</button><button data-q6="kontras" title="Teks kontras otomatis">${ic("text")}</button><button data-q6="menu" title="Semua tab Penata">${ic("menu")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q6]");if(!x)return;const k=x.dataset.q6;
  if(k==="palet"){P.openTab("palet");const a=M.sels().find(o=>hex(o.fill));if(a)$("#p76base").value=a.fill.toLowerCase();bangun();}
  else if(k==="menu"){P.openTab("menu");drawMenu();}else kontras();});}
MENUS.penata76=()=>[{h:"Tab Penata",items:[it("Semua tab (cari)",()=>{P.openTab("menu");drawMenu();},"menu"),it("Palet warna harmoni",()=>{P.openTab("palet");bangun();},"color"),it("Teks kontras otomatis",kontras,"text")]}];
BT.push(["penata76","panel","Penata 7"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata76");
})();
