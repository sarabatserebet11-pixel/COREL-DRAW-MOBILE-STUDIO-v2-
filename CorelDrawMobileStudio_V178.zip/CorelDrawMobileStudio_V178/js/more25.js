/* V38: Kotak teks (bungkus otomatis), Penggaris & kolom panduan, Simpanan (gaya & warna tersimpan) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,T,it,tc,cell}=M,$=s=>document.querySelector(s),W=()=>S.page.width,H=()=>S.page.height,E=CDMS.escape;
function ask(title,html,cb,label){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">${label||"Simpan"}</button></div>`);$("#aOk").onclick=cb;}

/* ---- kotak teks: bungkus otomatis berdasarkan lebar ---- */
const mc=document.createElement("canvas").getContext("2d");
function wrapPx(o,maxW){mc.font=`${o.italic?"italic ":""}${o.bold?"700":"400"} ${o.fontSize||64}px ${o.fontFamily||"Arial, sans-serif"}`;const lines=[];
 String(o.text||"").split("\n").forEach(par=>{let line="";par.split(/(\s+)/).filter(x=>x!=="").forEach(tok=>{const t=line+tok;if(line.trim()&&tok.trim()&&mc.measureText(t.trimEnd()).width>maxW){lines.push(line.trimEnd());line=tok.trimStart();}else line=t;});lines.push(line.trimEnd());});return lines.join("\n");}
const om=C.objMarkup;
C.objMarkup=function(o){if(o.type==="text"&&o.wrapW>0)return om.call(this,{...o,text:wrapPx(o,o.wrapW)});return om.call(this,o);};
const setBox=f=>edit(o=>{o.wrapW=f==="cur"?Math.round(o.w):Math.round(W()*f);},"Kotak teks diterapkan",o=>o.type==="text");
MENUS.kotak=()=>[{h:"Lebar kotak (teks dibungkus otomatis)",items:[["30% halaman",.3],["50% halaman",.5],["70% halaman",.7],["90% halaman",.9]].map(x=>tc(x[0],()=>setBox(x[1])))},
 {h:"Lainnya",items:[it("Pakai lebar teks saat ini",()=>setBox("cur"),"text"),it("Lepas kotak (satu baris)",()=>edit(o=>{delete o.wrapW;},"Kotak dilepas",o=>o.type==="text"),"undo")]}];

/* ---- kolom panduan (di overlay, tidak ikut ekspor) ---- */
S.cols=S.cols||null;
const dov=C.drawOverlay;
C.drawOverlay=function(){dov.call(this);const c=S.cols,ov=document.getElementById("overlayLayer");if(!c||!ov)return;const m=Math.round(W()*c.m),g=Math.round(W()*c.g),cw=(W()-2*m-(c.n-1)*g)/c.n;let h="";
 for(let i=0;i<c.n;i++)h+=`<rect x="${(m+i*(cw+g)).toFixed(1)}" y="0" width="${cw.toFixed(1)}" height="${H()}" fill="#ff4f9a" fill-opacity=".12" stroke="#ff4f9a" stroke-opacity=".4" stroke-width="1"/>`;
 ov.insertAdjacentHTML("afterbegin",`<g id="cdCols" pointer-events="none">${h}</g>`);};
const setCols=(n,m,g)=>{S.cols={n,m,g};C.render();T(n+" kolom aktif");};

/* ---- penggaris ---- */
S.rulers=S.rulers||false;
const area=$(".canvas-area");let rh=null,rv=null;
function mkRuler(cls){if(getComputedStyle(area).position==="static")area.style.position="relative";const c=document.createElement("canvas");c.className="ruler "+cls;c.style.cssText="position:absolute;z-index:5;pointer-events:none";area.appendChild(c);return c;}
function drawRulers(){if(!area)return;if(!S.rulers){if(rh){rh.remove();rv.remove();rh=rv=null;}return;}
 if(!rh){rh=mkRuler("rh");rv=mkRuler("rv");}const vp=$("#canvasViewport"),sv=C.svg;if(!vp||!sv)return;const a=area.getBoundingClientRect(),v=vp.getBoundingClientRect(),r=sv.getBoundingClientRect(),s=r.width/W(),T0=18,bg=getComputedStyle(document.body).getPropertyValue("--panel").trim()||"#1a2030",fg="#8a93aa";
 const place=(c,x,y,w,h)=>{c.style.left=x+"px";c.style.top=y+"px";c.style.width=w+"px";c.style.height=h+"px";c.width=Math.max(1,Math.round(w));c.height=Math.max(1,Math.round(h));};
 place(rh,v.left-a.left+T0,v.top-a.top,v.width-T0,T0);place(rv,v.left-a.left,v.top-a.top+T0,T0,v.height-T0);
 const step=[10,20,50,100,200,500,1000].find(n=>n*s>=8)||1000,big=step*(step<100?5:(step<500?2:1));
 const run=(c,horiz)=>{const x=c.getContext("2d");x.fillStyle=bg;x.fillRect(0,0,c.width,c.height);x.strokeStyle=fg;x.fillStyle=fg;x.font="9px sans-serif";x.lineWidth=1;
  const origin=horiz?r.left-(v.left+T0):r.top-(v.top+T0),len=horiz?W():H();
  for(let u=0;u<=len;u+=step){const p=origin+u*s+.5;if(p<0||p>(horiz?c.width:c.height))continue;const bigTick=u%big===0,L=bigTick?T0*.7:T0*.35;x.beginPath();if(horiz){x.moveTo(p,T0);x.lineTo(p,T0-L);}else{x.moveTo(T0,p);x.lineTo(T0-L,p);}x.stroke();
   if(bigTick){if(horiz)x.fillText(String(u),p+2,9);else{x.save();x.translate(9,p+2);x.rotate(-Math.PI/2);x.fillText(String(u),-String(u).length*4,0);x.restore();}}}};
 run(rh,true);run(rv,false);}
const rr=C.render;C.render=function(){rr.call(this);drawRulers();};
const vp0=$("#canvasViewport");if(vp0)vp0.addEventListener("scroll",drawRulers);window.addEventListener("resize",drawRulers);
MENUS.rule=()=>[{h:"Penggaris",items:[it((S.rulers?"✓ ":"")+"Tampilkan penggaris (satuan px kanvas)",()=>{S.rulers=!S.rulers;C.render();},"ruler")]},
 {h:"Kolom panduan",items:[["2 kolom",2,.06,.03],["3 kolom",3,.06,.03],["4 kolom",4,.06,.025],["6 kolom",6,.06,.02],["12 kolom",12,.05,.01]].map(x=>it(x[0],()=>setCols(x[1],x[2],x[3]),"grid")).concat([it("Matikan kolom",()=>{S.cols=null;C.render();},"eyeoff")])}];

/* ---- simpanan: gaya & warna ---- */
const SK="cdms_saved_styles",CK="cdms_saved_colors",ld=k=>{try{return JSON.parse(localStorage.getItem(k)||"[]");}catch(e){return[];}},sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch(e){T("Penyimpanan penuh");}};
const KEYS=["fill","stroke","strokeWidth","opacity","fx","fxColor","fxAmount","pat","grad","dash","imgFx","mask","fontFamily","bold","italic","spacing","align","lh","textOutline","rx","skx","sky","sh","bm","svgfx","wrapW"];
function saveStyle(){const a=sels()[0];if(!a)return T("Pilih objek dulu");ask("Simpan gaya",'<label>Nama gaya<input id="ssN" maxlength="30" value="Gaya saya"></label>',()=>{const name=$("#ssN").value.trim()||"Gaya";const p={};KEYS.forEach(k=>{if(a[k]!==undefined)p[k]=a[k];});const l=ld(SK).filter(x=>x.name!==name);l.push({name,p});sv(SK,l.slice(-24));N.closeModal();T("Gaya \""+name+"\" tersimpan");});}
function applyStyle(st){edit(o=>{KEYS.forEach(k=>{if(k in st.p){if(!(o.type==="image"&&(k==="fill"||k==="stroke")))o[k]=JSON.parse(JSON.stringify(st.p[k]));}else if(!["fill","stroke","strokeWidth","opacity","rx","fontFamily","bold","italic"].includes(k))delete o[k];});},"Gaya \""+st.name+"\" diterapkan");}
function saveColor(){const a=sels()[0];if(!a||!/^#[0-9a-f]{6}$/i.test(String(a.fill)))return T("Pilih objek berwarna polos dulu");const l=ld(CK).filter(c=>c!==a.fill);l.push(a.fill);sv(CK,l.slice(-24));T("Warna "+a.fill+" tersimpan");}
MENUS.simpan=()=>{const st=ld(SK),cs=ld(CK);return[
 {h:"Gaya tersimpan",items:[it("Simpan gaya objek terpilih…",saveStyle,"save"),...st.map(s=>it(s.name,()=>applyStyle(s),"copy"))]},
 {h:"Warna tersimpan (ketuk untuk mewarnai)",items:[it("Simpan warna isi objek terpilih",saveColor,"color"),...cs.map(c=>cell(`<i style="background:${c};border:1px solid var(--line)"></i><span>${c}</span>`,()=>edit(o=>{o.fill=c;delete o.grad;delete o.pat;},"",o=>o.type!=="image"&&o.type!=="line")))]},
 {h:"Kelola",items:[it("Hapus semua gaya & warna tersimpan",()=>{try{localStorage.removeItem(SK);localStorage.removeItem(CK);}catch(e){}T("Simpanan dihapus");},"trash")]}];};

BT.push(["kotak","textbox","Kotak"],["rule","ruler","Penggaris"],["simpan","save","Simpanan"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("teks").push("kotak");hub("kanvas").push("rule");hub("warna").push("simpan");
})();
