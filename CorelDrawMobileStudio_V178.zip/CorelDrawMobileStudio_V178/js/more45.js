/* V56: menu Tanggal (format, geser, relatif, selisih, sisipkan) dan Infografis+ (batang, donut, angka besar, corong, piramida, sebelum/sesudah, pro-kontra, matriks 2x2, roadmap) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,it,tc,sels,pick,T}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,AC,INK,MUTE,LINE}=K;
const $=s=>document.querySelector(s);
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
/* ---------- Tanggal ---------- */
const BLN=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
const BLS=["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
const HRI=["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
const p2=n=>String(n).padStart(2,"0");
const valid=(y,m,d)=>{const t=new Date(y,m,d);return t.getFullYear()===y&&t.getMonth()===m&&t.getDate()===d?t:null;};
const WD="(?:(?:senin|selasa|rabu|kamis|jum'?at|sabtu|minggu|ahad),?\\s*)?";
const RX=[
 {k:"iso",r:new RegExp(WD+"(\\d{4})-(\\d{1,2})-(\\d{1,2})","i"),f:m=>valid(+m[1],m[2]-1,+m[3])},
 {k:"nama",r:new RegExp(WD+"(\\d{1,2})\\s+([A-Za-z]{3,9})\\.?\\s+(\\d{4})","i"),f:m=>{const s=m[2].toLowerCase().slice(0,3),i=BLS.findIndex(b=>b.toLowerCase()===s||(s==="agt"&&b==="Agu")||(s==="ags"&&b==="Agu")||(s==="mre"&&b==="Mar"));return i<0?null:valid(+m[3],i,+m[1]);}},
 {k:"num",r:new RegExp(WD+"(\\d{1,2})([/.\\-])(\\d{1,2})\\2(\\d{2,4})","i"),f:m=>{let y=+m[4];if(m[4].length===2)y+=2000;return valid(y,m[3]-1,+m[1]);}}
];
function findDate(t){for(const e of RX){const m=String(t).match(e.r);if(m){const d=e.f(m);if(d){const full=m[0],hasWd=/^[A-Za-z']/.test(full);let st="slash";
 if(e.k==="iso")st="iso";else if(e.k==="nama")st=hasWd?"panjang":(m[2].length>3&&BLN.some(b=>b.toLowerCase()===m[2].toLowerCase())?"tgl":(m[2].length>3?"tgl":"singkat"));
 else if(m[2]===".")st="dot";else if(m[2]==="-")st="strip";
 return {d,txt:full,st,idx:m.index};}}}return null;}
const FMT={
 panjang:d=>HRI[d.getDay()]+", "+d.getDate()+" "+BLN[d.getMonth()]+" "+d.getFullYear(),
 tgl:d=>d.getDate()+" "+BLN[d.getMonth()]+" "+d.getFullYear(),
 singkat:d=>d.getDate()+" "+BLS[d.getMonth()]+" "+d.getFullYear(),
 slash:d=>p2(d.getDate())+"/"+p2(d.getMonth()+1)+"/"+d.getFullYear(),
 strip:d=>p2(d.getDate())+"-"+p2(d.getMonth()+1)+"-"+d.getFullYear(),
 dot:d=>p2(d.getDate())+"."+p2(d.getMonth()+1)+"."+String(d.getFullYear()).slice(2),
 iso:d=>d.getFullYear()+"-"+p2(d.getMonth()+1)+"-"+p2(d.getDate()),
 hari:d=>HRI[d.getDay()],
 blnthn:d=>BLN[d.getMonth()]+" "+d.getFullYear(),
 rel:d=>{const t=new Date();t.setHours(0,0,0,0);const n=Math.round((d-t)/864e5);return n===0?"Hari ini":n===1?"Besok":n===-1?"Kemarin":n>0?n+" hari lagi":Math.abs(n)+" hari yang lalu";}
};
function addMonths(d,n){const day=d.getDate(),r=new Date(d.getFullYear(),d.getMonth()+n,1),last=new Date(r.getFullYear(),r.getMonth()+1,0).getDate();r.setDate(Math.min(day,last));return r;}
function dateEdit(fn,msg){const a=sels().filter(o=>o.type==="text");if(!a.length)return T("Pilih teks dulu");
 const ok=a.filter(o=>findDate(o.text));if(!ok.length)return T("Tidak ada tanggal di teks terpilih (contoh: 24/10/2026 atau 24 Oktober 2026)");
 Hi.snapshot();let n=0;ok.forEach(o=>{const f=findDate(o.text),r=fn(f.d,f);if(r){o.text=o.text.replace(f.txt,r);n++;}});C.render();T(n+" teks diubah"+(msg?" · "+msg:""));}
const shift=(u,n)=>dateEdit((d,f)=>{const x=u==="h"?new Date(d.getFullYear(),d.getMonth(),d.getDate()+n):u==="b"?addMonths(d,n):addMonths(d,12*n);return FMT[f.st](x);});
function selisih(){const a=sels().filter(o=>o.type==="text"&&findDate(o.text));if(a.length<2)return T("Pilih 2 teks berisi tanggal");
 const d1=findDate(a[0].text).d,d2=findDate(a[1].text).d,n=Math.round(Math.abs(d2-d1)/864e5),w=Math.floor(n/7),txt=n+" hari"+(n>=7?" ("+w+" minggu"+(n%7?" "+(n%7)+" hari":"")+")":"");
 const x=Math.min(...a.map(o=>o.x)),y=Math.max(...a.map(o=>o.y+o.h))+24,fs=Math.max(...a.map(o=>o.fontSize||32));
 Hi.snapshot();const o={id:crypto.randomUUID(),type:"text",text:"Selisih: "+txt,x:Math.round(x),y:Math.round(y),w:Math.max(40,Math.round((txt.length+9)*fs*.58)),h:Math.round(fs*1.4),fontSize:fs,fill:INK,bold:true,fontFamily:"Arial, sans-serif",opacity:100,rotation:0,stroke:"none",strokeWidth:0,name:"Selisih tanggal"};
 S.objects.push(o);C.render();pick([o]);T("Selisih "+txt);}
function insertDlg(){const t=new Date(),iso=t.getFullYear()+"-"+p2(t.getMonth()+1)+"-"+p2(t.getDate());
 N.openModal("Sisipkan tanggal",`<div class="st-pane"><div class="st-grid"><label>Tanggal<input id="tgD" type="date" value="${iso}"></label><label>Format<select id="tgF"><option value="panjang">Sabtu, 24 Oktober 2026</option><option value="tgl">24 Oktober 2026</option><option value="singkat">24 Okt 2026</option><option value="slash">24/10/2026</option><option value="iso">2026-10-24</option><option value="blnthn">Oktober 2026</option><option value="hari">Hari saja</option></select></label></div><button class="btn primary" id="aOk">Sisipkan</button></div>`);
 $("#aOk").onclick=()=>{const v=($("#tgD").value||"").split("-"),f=$("#tgF").value;if(v.length!==3)return T("Pilih tanggal dulu");const d=valid(+v[0],v[1]-1,+v[2]);if(!d)return T("Tanggal tidak valid");N.closeModal();
  const txt=FMT[f](d),fs=Math.max(32,Math.round(S.page.width/22));Hi.snapshot();const o={id:crypto.randomUUID(),type:"text",text:txt,w:Math.round(txt.length*fs*.58),h:Math.round(fs*1.4),fontSize:fs,fill:INK,bold:true,fontFamily:"Arial, sans-serif",opacity:100,rotation:0,stroke:"none",strokeWidth:0,name:"Tanggal"};
  o.x=Math.round((S.page.width-o.w)/2);o.y=Math.round((S.page.height-o.h)/2);S.objects.push(o);C.render();pick([o]);T("Tanggal ditambahkan");};}
MENUS.tanggal=()=>[
 {h:"Ubah format (teks berisi tanggal)",items:[["Sabtu, 24 Oktober 2026","panjang"],["24 Oktober 2026","tgl"],["24 Okt 2026","singkat"],["24/10/2026","slash"],["24-10-2026","strip"],["24.10.26","dot"],["2026-10-24","iso"]].map(x=>tc(x[0],()=>dateEdit(d=>FMT[x[1]](d))))},
 {h:"Ambil bagian",items:[it("Nama hari saja",()=>dateEdit(d=>FMT.hari(d)),"text"),it("Bulan + tahun",()=>dateEdit(d=>FMT.blnthn(d)),"text"),it("Relatif (X hari lagi)",()=>dateEdit(d=>FMT.rel(d)),"text")]},
 {h:"Geser tanggal",items:[["+1 hari","h",1],["−1 hari","h",-1],["+7 hari","h",7],["−7 hari","h",-7],["+1 bulan","b",1],["−1 bulan","b",-1],["+1 tahun","t",1],["−1 tahun","t",-1]].map(x=>tc(x[0],()=>shift(x[1],x[2])))},
 {h:"Buat teks",items:[it("Sisipkan tanggal…",insertDlg,"text"),it("Selisih 2 tanggal (pilih 2 teks)",selisih,"text")]}];
BT.push(["tanggal","calendar","Tanggal"]);
hubAdd("teks","tanggal");
/* ---------- Infografis+ ---------- */
const WHT="#ffffff",SOFT="#9aa6d0";
function arc(pct){const a=Math.min(.9999,Math.max(.0001,pct/100))*2*Math.PI,x=50+50*Math.sin(a),y=50-50*Math.cos(a);return "M50 0A50 50 0 "+(pct>50?1:0)+" 1 "+x.toFixed(2)+" "+y.toFixed(2);}
function trap(x,y,tw,bw,h,fill,o){const ins=(tw-bw)/2/tw*100;return P(x,y,tw,h,"M0 0L100 0L"+(100-ins).toFixed(2)+" 100L"+ins.toFixed(2)+" 100Z",fill,o);}
const BAR=[["Desain",.9,AC],["Riset",.7,"#00a6d6"],["Produksi",.55,"#00c9a7"],["Promosi",.35,"#ffb020"]];
const FUN=[["Kunjungan",480,390,"#6d5dfc"],["Prospek",390,300,"#5b7cfa"],["Penawaran",300,210,"#00a6d6"],["Penjualan",210,130,"#00c9a7"]];
const PYR=[["Puncak","#6d5dfc"],["Menengah","#5b7cfa"],["Dasar","#00a6d6"]];
const hw=y=>220*(y/300);
const lines=(x,y,arr,col,dot)=>arr.flatMap((t,i)=>[E(x,y+i*56-8,16,16,dot,{}),X(t,x+30,y+i*56,24,col,{left:1})]);
Object.assign(COMP,{
 "Batang mendatar":()=>({w:520,h:290,a:BAR.flatMap((b,i)=>{const cy=30+i*72,fw=Math.round(340*b[1]);return [X(b[0],0,cy,24,INK,{left:1,bold:1}),R(140,cy-14,340,28,"#e3e7f3",{rx:14,name:"Jalur "+b[0]}),R(140,cy-14,fw,28,b[2],{rx:14,name:"Batang "+b[0]}),X(Math.round(b[1]*100)+"%",140+fw+12,cy,22,MUTE,{left:1,bold:1})];})}),
 "Donut persen":()=>({w:300,h:300,a:[E(0,0,300,300,"none",{stroke:"#e3e7f3",strokeWidth:34,name:"Donut dasar"}),P(0,0,300,300,arc(75),"none",{stroke:AC,strokeWidth:34,name:"Donut isi"}),X("75%",150,140,76,INK,{bold:1}),X("Tercapai",150,200,24,MUTE)]}),
 "Angka besar":()=>({w:420,h:260,a:[R(0,0,420,260,"#11162a",{rx:32,name:"Angka besar"}),R(32,36,56,8,AC,{rx:4}),X("98%",32,140,112,WHT,{left:1,bold:1}),X("Pelanggan puas",32,214,28,SOFT,{left:1,bold:1})]}),
 "Corong penjualan":()=>({w:480,h:304,a:FUN.flatMap((f,i)=>[trap(Math.round((480-f[1])/2),i*78,f[1],f[2],70,f[3],{name:"Corong "+f[0]}),X(f[0],240,i*78+35,26,WHT,{bold:1})])}),
 "Piramida 3 level":()=>({w:440,h:300,a:PYR.flatMap((p,i)=>{const y0=i*100,y1=y0+100,tw=Math.max(2,2*hw(y0)),bw=2*hw(y1);return [P(Math.round(220-hw(y1)),y0,bw,100,"M"+((bw-tw)/2/bw*100).toFixed(2)+" 0L"+(100-(bw-tw)/2/bw*100).toFixed(2)+" 0L100 100L0 100Z",p[1],{stroke:WHT,strokeWidth:5,name:"Piramida "+p[0]}),X(p[0],220,y0+(i?58:68),i?26:22,WHT,{bold:1})];})}),
 "Sebelum / sesudah":()=>({w:560,h:360,a:[R(0,0,264,360,"#fee2e2",{rx:28,name:"Sebelum"}),R(0,0,264,360,"none",{rx:28,stroke:"#fca5a5",strokeWidth:3}),R(20,20,120,40,"#b91c1c",{rx:20}),X("SEBELUM",80,40,20,WHT,{bold:1}),R(20,76,224,170,"#ffffff",{rx:18,opacity:70}),X("Kondisi awal",24,282,28,INK,{left:1,bold:1}),X("Tulis kondisi awal",24,318,20,MUTE,{left:1}),
  R(296,0,264,360,"#dcfce7",{rx:28,name:"Sesudah"}),R(296,0,264,360,"none",{rx:28,stroke:"#86efac",strokeWidth:3}),R(316,20,120,40,"#15803d",{rx:20}),X("SESUDAH",376,40,20,WHT,{bold:1}),R(316,76,224,170,"#ffffff",{rx:18,opacity:70}),X("Hasil akhir",320,282,28,INK,{left:1,bold:1}),X("Tulis hasil akhir",320,318,20,MUTE,{left:1}),
  E(252,152,56,56,AC,{stroke:WHT,strokeWidth:5,name:"Panah"}),P(266,172,28,16,"M0 50L90 50M60 15L95 50L60 85","none",{stroke:WHT,strokeWidth:14})]}),
 "Pro dan kontra":()=>({w:560,h:340,a:[R(0,0,264,340,"#ffffff",{rx:28,stroke:"#86efac",strokeWidth:4,name:"Kelebihan"}),R(0,0,264,64,"#16a34a",{rx:28}),R(0,32,264,32,"#16a34a"),X("Kelebihan",132,34,28,WHT,{bold:1}),...lines(24,112,["Mudah dipakai","Hemat biaya","Hasil cepat"],INK,"#16a34a"),
  R(296,0,264,340,"#ffffff",{rx:28,stroke:"#fca5a5",strokeWidth:4,name:"Kekurangan"}),R(296,0,264,64,"#dc2626",{rx:28}),R(296,32,264,32,"#dc2626"),X("Kekurangan",428,34,28,WHT,{bold:1}),...lines(320,112,["Fitur terbatas","Butuh internet","Perlu latihan"],INK,"#dc2626")]}),
 "Matriks 2x2":()=>({w:520,h:520,a:[["Kerjakan sekarang","Penting · mendesak",0,0,"#ffe4e6","#be123c"],["Jadwalkan","Penting · santai",268,0,"#dbeafe","#1d4ed8"],["Delegasikan","Mendesak · kurang penting",0,268,"#fef3c7","#b45309"],["Abaikan","Kurang penting · santai",268,268,"#e5e7eb","#4b5563"]].flatMap(q=>[R(q[2],q[3],252,252,q[4],{rx:28,name:q[0]}),X(q[0],q[2]+126,q[3]+110,24,q[5],{bold:1}),X(q[1],q[2]+126,q[3]+150,18,MUTE)])}),
 "Roadmap 3 fase":()=>({w:600,h:320,a:[R(0,27,600,6,LINE,{rx:3,name:"Garis waktu"}),...[["Fase 1","Riset","Jan – Mar"],["Fase 2","Produksi","Apr – Jun"],["Fase 3","Peluncuran","Jul – Sep"]].flatMap((f,i)=>{const x=i*210;return [R(x,92,180,228,"#f4f6ff",{rx:24,name:f[0]}),E(x+62,0,56,56,AC,{stroke:WHT,strokeWidth:5}),X(String(i+1),x+90,28,28,WHT,{bold:1}),X(f[1],x+90,132,28,INK,{bold:1}),X(f[2],x+90,170,20,AC,{bold:1}),X("Tulis rencana",x+90,224,20,MUTE),X("fase ini di sini",x+90,252,20,MUTE)];})]})
});
MENUS.infoplus=()=>[
 {h:"Data",items:["Batang mendatar","Donut persen","Angka besar","Corong penjualan","Piramida 3 level"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Perbandingan & rencana",items:["Sebelum / sesudah","Pro dan kontra","Matriks 2x2","Roadmap 3 fase"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["infoplus","infograph","Infografis+"]);
hubAdd("pustaka","infoplus");
CDMS.Tanggal={findDate,FMT,addMonths};
})();
