/* V150: Aplikasi Berguna — 8 aplikasi mini (offline, tanpa pustaka luar):
   Kalkulator, Catatan, Tugas, Konverter, Timer & Stopwatch, Kata Sandi, Tanggal, Keuangan. */
(() => {
  'use strict';
  const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const ls={get(k,d){try{const v=JSON.parse(localStorage.getItem('cdms-ua-'+k));return v==null?d:v}catch(_){return d}},
            set(k,v){try{localStorage.setItem('cdms-ua-'+k,JSON.stringify(v));return true}catch(_){toast('Penyimpanan penuh/tidak tersedia');return false}}};
  const NF=new Intl.NumberFormat('id-ID',{maximumFractionDigits:8}), RP=new Intl.NumberFormat('id-ID',{maximumFractionDigits:0});
  const fmt=n=>Number.isFinite(n)?NF.format(n):'—', rp=n=>Number.isFinite(n)?'Rp '+RP.format(Math.round(n)):'—';
  const val=el=>{const n=parseFloat(String(el.value).replace(',','.'));return Number.isFinite(n)?n:NaN};
  let overlay, body, titleEl, cleanup=null, toastT=0;
  function toast(m){let t=$('#uaToast');if(!t){t=document.createElement('div');t.id='uaToast';t.className='ua-toast';document.body.appendChild(t)}t.textContent=m;t.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove('show'),2200)}
  async function copy(text){try{await navigator.clipboard.writeText(text);toast('Disalin');}catch(_){const ta=document.createElement('textarea');ta.value=text;ta.style.cssText='position:fixed;opacity:0';document.body.appendChild(ta);ta.select();try{document.execCommand('copy');toast('Disalin')}catch(__){toast('Tidak bisa menyalin')}ta.remove()}}
  const out=(label,value,big)=>`<div class="ua-res${big?' big':''}"><span>${esc(label)}</span><b>${esc(value)}</b></div>`;

  /* ---------- 1. Kalkulator ---------- */
  function evalExpr(src){
    const s=src.replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/π/g,'('+Math.PI+')').replace(/,/g,'.');
    let i=0;const ws=()=>{while(s[i]===' ')i++};
    function expr(){let v=term();for(;;){ws();if(s[i]==='+'){i++;v+=term()}else if(s[i]==='-'){i++;v-=term()}else return v}}
    function term(){let v=pow();for(;;){ws();if(s[i]==='*'){i++;v*=pow()}else if(s[i]==='/'){i++;const d=pow();if(d===0)throw new Error('Dibagi nol');v/=d}else return v}}
    function pow(){const b=unary();ws();if(s[i]==='^'){i++;return Math.pow(b,pow())}return b}
    function unary(){ws();if(s[i]==='-'){i++;return -unary()}if(s[i]==='+'){i++;return unary()}return post()}
    function post(){let v=atom();for(;;){ws();if(s[i]==='%'){i++;v/=100}else return v}}
    function atom(){ws();if(s[i]==='('){i++;const v=expr();ws();if(s[i]!==')')throw new Error('Kurung');i++;return v}
      if(s[i]==='√'){i++;const v=unary();if(v<0)throw new Error('Akar negatif');return Math.sqrt(v)}
      const m=/^(\d+\.?\d*|\.\d+)/.exec(s.slice(i));if(!m)throw new Error('Format salah');i+=m[0].length;return parseFloat(m[0])}
    const v=expr();ws();if(i<s.length)throw new Error('Format salah');if(!Number.isFinite(v))throw new Error('Hasil tidak valid');return v;
  }
  const numStr=v=>String(+v.toPrecision(12));
  function calc(root){
    let ex='',hist=ls.get('calc-hist',[]);
    root.innerHTML=`<div class="ua-calc"><div class="ua-disp"><div id="cEx" class="ex"></div><div id="cRes" class="rs">0</div></div>
      <div class="ua-keys sci">${['√','x²','xʸ','π'].map(k=>`<button data-k="${k}">${k}</button>`).join('')}</div>
      <div class="ua-keys">${['C','(',')','÷','7','8','9','×','4','5','6','−','1','2','3','+','0',',','%','='].map(k=>`<button data-k="${k}" class="${'÷×−+'.includes(k)?'op':k==='='?'eq':k==='C'?'clr':''}">${k}</button>`).join('')}<button data-k="⌫" class="wide2">⌫ Hapus</button></div>
      <div class="ua-hist"><div class="ua-row"><b>Riwayat</b><button class="ua-link" id="cClr">Hapus riwayat</button></div><div id="cHist"></div></div></div>`;
    const exEl=$('#cEx',root),rsEl=$('#cRes',root);
    function paint(){exEl.textContent=ex||'';let r='0';if(ex){try{r='= '+fmt(evalExpr(ex))}catch(_){r=''}}rsEl.textContent=r||'…';
      $('#cHist',root).innerHTML=hist.length?hist.slice().reverse().map((h,i)=>`<button class="ua-h" data-h="${hist.length-1-i}"><span>${esc(h.e)}</span><b>= ${esc(h.r)}</b></button>`).join(''):'<p class="ua-muted">Belum ada perhitungan.</p>'}
    function press(k){
      if(k==='C')ex='';else if(k==='⌫')ex=ex.slice(0,-1);
      else if(k==='x²')ex+='^2';else if(k==='xʸ')ex+='^';else if(k==='√')ex+='√(';
      else if(k==='='){if(!ex)return;try{const r=evalExpr(ex);const rs=numStr(r);hist.push({e:ex,r:fmt(r)});hist=hist.slice(-30);ls.set('calc-hist',hist);ex=rs.replace('.',',')}catch(e){toast(e.message||'Format salah')}}
      else ex+=k;paint();}
    root.addEventListener('click',e=>{const b=e.target.closest('[data-k]');if(b)return press(b.dataset.k);const h=e.target.closest('[data-h]');if(h){ex=hist[+h.dataset.h].r.replace(/\./g,'');paint()}});
    $('#cClr',root).onclick=()=>{hist=[];ls.set('calc-hist',hist);paint()};
    const key=e=>{if(e.target.closest('input,textarea,select'))return;const k=e.key;
      if(/^[0-9]$/.test(k))press(k);else if(k==='+')press('+');else if(k==='-')press('−');else if(k==='*')press('×');else if(k==='/'){e.preventDefault();press('÷')}
      else if(k==='('||k===')'||k==='%'||k==='.'||k===',')press(k==='.'?',':k);else if(k==='Enter'||k==='='){e.preventDefault();press('=')}else if(k==='Backspace')press('⌫');else if(k==='Delete')press('C')};
    document.addEventListener('keydown',key);cleanup=()=>document.removeEventListener('keydown',key);paint();
  }

  /* ---------- 2. Catatan ---------- */
  function notes(root){
    let list=ls.get('notes',[]),q='';
    const save=()=>ls.set('notes',list);
    function showList(){
      const items=list.filter(n=>(n.t+' '+n.b).toLowerCase().includes(q.toLowerCase())).sort((a,b)=>b.ts-a.ts);
      root.innerHTML=`<div class="ua-row"><input id="nQ" type="search" placeholder="Cari catatan..." value="${esc(q)}"><button class="ua-btn pri" id="nNew">＋ Baru</button></div>
        <div class="ua-list">${items.length?items.map(n=>`<button class="ua-note" data-id="${n.id}"><b>${esc(n.t||'(Tanpa judul)')}</b><span>${esc((n.b||'').slice(0,90))}</span><small>${new Date(n.ts).toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'short'})}</small></button>`).join(''):`<p class="ua-muted">${q?'Tidak ada yang cocok.':'Belum ada catatan. Ketuk ＋ Baru.'}</p>`}</div>`;
      $('#nQ',root).oninput=e=>{q=e.target.value;const pos=e.target.selectionStart;showList();const i=$('#nQ',root);i.focus();i.setSelectionRange(pos,pos)};
      $('#nNew',root).onclick=()=>{const n={id:Date.now().toString(36),t:'',b:'',ts:Date.now()};list.push(n);save();edit(n.id)};
      $$('.ua-note',root).forEach(b=>b.onclick=()=>edit(b.dataset.id));
    }
    function edit(id){
      const n=list.find(x=>x.id===id);if(!n)return showList();
      root.innerHTML=`<div class="ua-row"><button class="ua-btn" id="nBack">‹ Daftar</button><span class="ua-grow"></span><button class="ua-btn" id="nCopy">Salin</button><button class="ua-btn dng" id="nDel">Hapus</button></div>
        <input id="nT" class="ua-title" maxlength="120" placeholder="Judul" value="${esc(n.t)}"><textarea id="nB" class="ua-area" placeholder="Tulis catatan di sini...">${esc(n.b)}</textarea><p class="ua-muted" id="nS">Tersimpan otomatis</p>`;
      let t=0;const upd=()=>{n.t=$('#nT',root).value;n.b=$('#nB',root).value;n.ts=Date.now();clearTimeout(t);$('#nS',root).textContent='Menyimpan…';t=setTimeout(()=>{if(save())$('#nS',root).textContent='Tersimpan otomatis'},400)};
      $('#nT',root).oninput=upd;$('#nB',root).oninput=upd;
      $('#nBack',root).onclick=()=>{clearTimeout(t);n.t=$('#nT',root).value;n.b=$('#nB',root).value;if(!n.t&&!n.b)list=list.filter(x=>x!==n);save();showList()};
      $('#nCopy',root).onclick=()=>copy((n.t?n.t+'\n\n':'')+n.b);
      $('#nDel',root).onclick=()=>{if(confirm('Hapus catatan ini?')){list=list.filter(x=>x!==n);save();showList()}};
      $('#nB',root).focus();
    }
    showList();
  }

  /* ---------- 3. Tugas ---------- */
  function todo(root){
    let items=ls.get('todo',[]),filter='all';const save=()=>ls.set('todo',items);
    function paint(){
      const vis=items.filter(t=>filter==='all'||(filter==='open'?!t.d:t.d)),left=items.filter(t=>!t.d).length;
      root.innerHTML=`<form class="ua-row" id="tF"><input id="tIn" maxlength="200" placeholder="Tugas baru..." autocomplete="off"><button class="ua-btn pri" type="submit">Tambah</button></form>
        <div class="ua-tabs">${[['all','Semua'],['open','Aktif'],['done','Selesai']].map(([k,l])=>`<button data-f="${k}" class="${filter===k?'on':''}">${l}</button>`).join('')}</div>
        <div class="ua-list">${vis.length?vis.map(t=>`<div class="ua-todo${t.d?' done':''}"><label><input type="checkbox" data-t="${t.id}" ${t.d?'checked':''}><span>${esc(t.x)}</span></label><button class="ua-x" data-del="${t.id}" aria-label="Hapus">×</button></div>`).join(''):'<p class="ua-muted">Tidak ada tugas.</p>'}</div>
        <div class="ua-row"><span class="ua-muted">${left} tugas tersisa</span><span class="ua-grow"></span><button class="ua-link" id="tClr">Hapus yang selesai</button></div>`;
      $('#tF',root).onsubmit=e=>{e.preventDefault();const v=$('#tIn',root).value.trim();if(!v)return;items.unshift({id:Date.now().toString(36)+Math.random().toString(36).slice(2,5),x:v,d:false});save();paint();$('#tIn',root).focus()};
      $$('[data-f]',root).forEach(b=>b.onclick=()=>{filter=b.dataset.f;paint()});
      $$('[data-t]',root).forEach(c=>c.onchange=()=>{const t=items.find(x=>x.id===c.dataset.t);if(t){t.d=c.checked;save();paint()}});
      $$('[data-del]',root).forEach(b=>b.onclick=()=>{items=items.filter(x=>x.id!==b.dataset.del);save();paint()});
      $('#tClr',root).onclick=()=>{const n=items.filter(t=>t.d).length;if(!n){toast('Belum ada yang selesai');return}items=items.filter(t=>!t.d);save();paint()};
    }
    paint();
  }

  /* ---------- 4. Konverter ---------- */
  const UNITS={
    'Panjang':{base:'m',u:{mm:.001,cm:.01,m:1,km:1000,inci:.0254,kaki:.3048,yard:.9144,mil:1609.344}},
    'Berat':{u:{mg:1e-6,g:.001,ons:.1,kg:1,kuintal:100,ton:1000,oz:.028349523125,pon:.45359237}},
    'Luas':{u:{'cm²':1e-4,'m²':1,are:100,ha:1e4,'km²':1e6,'kaki²':.09290304,acre:4046.8564224}},
    'Volume':{u:{mL:.001,'sendok teh':.005,'sendok makan':.015,L:1,'galon (AS)':3.785411784,'m³':1000}},
    'Kecepatan':{u:{'m/s':1,'km/jam':1/3.6,'mil/jam':.44704,knot:1852/3600}},
    'Data':{u:{bit:.125,B:1,KB:1024,MB:1048576,GB:1073741824,TB:1099511627776}},
    'Waktu':{u:{detik:1,menit:60,jam:3600,hari:86400,minggu:604800,'tahun (365 hr)':31536000}},
    'Suhu':{temp:true,u:{'°C':1,'°F':1,'K':1}}
  };
  const toC={'°C':v=>v,'°F':v=>(v-32)*5/9,'K':v=>v-273.15}, fromC={'°C':v=>v,'°F':v=>v*9/5+32,'K':v=>v+273.15};
  function convert(root){
    const cats=Object.keys(UNITS);let cat=ls.get('conv-cat','Panjang');if(!UNITS[cat])cat='Panjang';
    root.innerHTML=`<div class="ua-form"><label>Kategori<select id="vC">${cats.map(c=>`<option ${c===cat?'selected':''}>${c}</option>`).join('')}</select></label>
      <label>Nilai<input id="vV" type="number" step="any" value="1" inputmode="decimal"></label>
      <div class="ua-row"><label class="ua-grow">Dari<select id="vF"></select></label><button class="ua-btn" id="vS" aria-label="Tukar" style="margin-top:18px">⇄</button><label class="ua-grow">Ke<select id="vT"></select></label></div></div><div id="vO"></div><div id="vA"></div>`;
    const sel=$('#vC',root),F=$('#vF',root),T=$('#vT',root),V=$('#vV',root);
    function units(){cat=sel.value;ls.set('conv-cat',cat);const ks=Object.keys(UNITS[cat].u);F.innerHTML=T.innerHTML=ks.map(k=>`<option>${esc(k)}</option>`).join('');F.selectedIndex=Math.min(2,ks.length-1);T.selectedIndex=Math.min(3,ks.length-1);if(cat==='Suhu'){F.selectedIndex=0;T.selectedIndex=1}calcC()}
    function conv(v,f,t){const d=UNITS[cat];return d.temp?fromC[t](toC[f](v)):v*d.u[f]/d.u[t]}
    function calcC(){const v=val(V);if(!Number.isFinite(v)){$('#vO',root).innerHTML=out('Hasil','—',true);$('#vA',root).innerHTML='';return}
      $('#vO',root).innerHTML=out(`${fmt(v)} ${F.value} =`,`${fmt(conv(v,F.value,T.value))} ${T.value}`,true);
      $('#vA',root).innerHTML='<div class="ua-grid2">'+Object.keys(UNITS[cat].u).filter(k=>k!==F.value).map(k=>out(k,fmt(conv(v,F.value,k)))).join('')+'</div>'}
    sel.onchange=units;[V,F,T].forEach(e=>e.addEventListener('input',calcC));F.onchange=T.onchange=calcC;
    $('#vS',root).onclick=()=>{const a=F.value;F.value=T.value;T.value=a;calcC()};units();
  }

  /* ---------- 5. Timer & Stopwatch ---------- */
  let audioCtx=null;
  function beep(times){try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();const c=audioCtx;for(let i=0;i<times;i++){const o=c.createOscillator(),g=c.createGain();o.frequency.value=880;g.gain.value=.15;o.connect(g);g.connect(c.destination);const t=c.currentTime+i*.4;o.start(t);o.stop(t+.22)}}catch(_){}try{navigator.vibrate&&navigator.vibrate([250,120,250,120,250])}catch(_){}}
  const pad=n=>String(n).padStart(2,'0');
  const hms=ms=>{const s=Math.max(0,Math.ceil(ms/1000)),h=Math.floor(s/3600);return (h?pad(h)+':':'')+pad(Math.floor(s%3600/60))+':'+pad(s%60)};
  function timer(root){
    let mode=ls.get('timer-mode','timer'),iv=0;
    const stop=()=>{clearInterval(iv);iv=0};cleanup=stop;
    function paint(){stop();root.innerHTML=`<div class="ua-tabs"><button data-m="timer" class="${mode==='timer'?'on':''}">Timer</button><button data-m="sw" class="${mode==='sw'?'on':''}">Stopwatch</button></div><div id="tBody"></div>`;
      $$('[data-m]',root).forEach(b=>b.onclick=()=>{mode=b.dataset.m;ls.set('timer-mode',mode);paint()});mode==='timer'?tm($('#tBody',root)):sw($('#tBody',root))}
    function tm(r){
      let end=0,left=0,run=false;
      r.innerHTML=`<div class="ua-clock" id="tC">05:00</div><div class="ua-row ua-center"><label>Menit<input id="tM" type="number" min="0" max="999" value="5"></label><label>Detik<input id="tS" type="number" min="0" max="59" value="0"></label></div>
        <div class="ua-chips">${[1,5,10,15,25,45].map(m=>`<button data-p="${m}">${m} mnt</button>`).join('')}</div>
        <div class="ua-row ua-center"><button class="ua-btn pri" id="tGo">Mulai</button><button class="ua-btn" id="tRs">Atur ulang</button></div>`;
      const C=$('#tC',r),setDisp=()=>C.textContent=hms(run?end-Date.now():left);
      const read=()=>Math.min(999,Math.max(0,parseInt($('#tM',r).value)||0))*60000+Math.min(59,Math.max(0,parseInt($('#tS',r).value)||0))*1000;
      const sync=()=>{if(!run){left=read();setDisp()}};
      $$('#tM,#tS',r).forEach(i=>i.oninput=sync);$$('[data-p]',r).forEach(b=>b.onclick=()=>{if(run)return;$('#tM',r).value=b.dataset.p;$('#tS',r).value=0;sync()});
      function tick(){const rem=end-Date.now();if(rem<=0){run=false;stop();left=0;C.textContent='00:00';C.classList.add('ring');$('#tGo',r).textContent='Mulai';beep(4);toast('⏰ Waktu habis!');setTimeout(()=>C.classList.remove('ring'),3000);return}setDisp()}
      $('#tGo',r).onclick=()=>{if(run){left=end-Date.now();run=false;stop();$('#tGo',r).textContent='Lanjut';return}
        if(left<=0)left=read();if(left<=0){toast('Atur waktu dulu');return}
        try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();audioCtx.resume&&audioCtx.resume()}catch(_){}
        end=Date.now()+left;run=true;$('#tGo',r).textContent='Jeda';stop();iv=setInterval(tick,200);tick()};
      $('#tRs',r).onclick=()=>{run=false;stop();$('#tGo',r).textContent='Mulai';C.classList.remove('ring');left=read();setDisp()};sync();
    }
    function sw(r){
      let acc=0,start=0,run=false,laps=[];
      r.innerHTML=`<div class="ua-clock" id="sC">00:00.00</div><div class="ua-row ua-center"><button class="ua-btn pri" id="sGo">Mulai</button><button class="ua-btn" id="sLap">Putaran</button><button class="ua-btn" id="sRs">Atur ulang</button></div><div class="ua-list" id="sL"></div>`;
      const fmtSw=ms=>{const t=Math.floor(ms/10),cs=t%100,s=Math.floor(t/100)%60,m=Math.floor(t/6000);return pad(m)+':'+pad(s)+'.'+pad(cs)};
      const now=()=>acc+(run?Date.now()-start:0),paintL=()=>{$('#sL',r).innerHTML=laps.slice().reverse().map((l,i)=>`<div class="ua-lap"><span>#${laps.length-i}</span><b>${fmtSw(l.d)}</b><small>${fmtSw(l.t)}</small></div>`).join('')};
      $('#sGo',r).onclick=()=>{if(run){acc+=Date.now()-start;run=false;stop();$('#sGo',r).textContent='Lanjut'}else{start=Date.now();run=true;stop();iv=setInterval(()=>{$('#sC',r).textContent=fmtSw(now())},40);$('#sGo',r).textContent='Jeda'}};
      $('#sLap',r).onclick=()=>{if(!run&&!acc)return;const t=now(),prev=laps.length?laps[laps.length-1].t:0;laps.push({t,d:t-prev});paintL()};
      $('#sRs',r).onclick=()=>{run=false;stop();acc=0;laps=[];$('#sC',r).textContent='00:00.00';$('#sGo',r).textContent='Mulai';paintL()};
    }
    paint();
  }

  /* ---------- 6. Kata Sandi ---------- */
  function password(root){
    const S=ls.get('pw',{len:16,up:true,lo:true,di:true,sy:true});
    root.innerHTML=`<div class="ua-pw" id="pO"></div><div class="ua-row ua-center"><button class="ua-btn pri" id="pG">Buat baru</button><button class="ua-btn" id="pC">Salin</button></div><div id="pStr" class="ua-str"></div>
      <div class="ua-form"><label>Panjang: <b id="pL">${S.len}</b><input id="pR" type="range" min="6" max="64" value="${S.len}"></label>
      ${[['up','Huruf besar (A–Z)'],['lo','Huruf kecil (a–z)'],['di','Angka (0–9)'],['sy','Simbol (!@#$…)']].map(([k,l])=>`<label class="ua-chk"><input type="checkbox" data-o="${k}" ${S[k]?'checked':''}> ${l}</label>`).join('')}</div>`;
    const SETS={up:'ABCDEFGHIJKLMNOPQRSTUVWXYZ',lo:'abcdefghijklmnopqrstuvwxyz',di:'0123456789',sy:'!@#$%^&*()-_=+[]{};:,.?/'};
    const rnd=n=>{const a=new Uint32Array(1),lim=Math.floor(4294967296/n)*n;let x;do{crypto.getRandomValues(a);x=a[0]}while(x>=lim);return x%n};
    let cur='';
    function gen(){const act=Object.keys(SETS).filter(k=>S[k]);if(!act.length){toast('Pilih minimal satu jenis karakter');$('#pO',root).textContent='—';return}
      const pool=act.map(k=>SETS[k]).join('');const ch=act.map(k=>SETS[k][rnd(SETS[k].length)]);while(ch.length<S.len)ch.push(pool[rnd(pool.length)]);
      for(let i=ch.length-1;i>0;i--){const j=rnd(i+1);[ch[i],ch[j]]=[ch[j],ch[i]]}cur=ch.slice(0,S.len).join('');$('#pO',root).textContent=cur;
      const bits=Math.round(cur.length*Math.log2(pool.length)),lv=bits<50?['Lemah','#ef4444']:bits<70?['Sedang','#f59e0b']:bits<100?['Kuat','#22c55e']:['Sangat kuat','#06b6d4'];
      $('#pStr',root).innerHTML=`<i style="width:${Math.min(100,bits)}%;background:${lv[1]}"></i><span>${lv[0]} • ±${bits} bit</span>`}
    $('#pR',root).oninput=e=>{S.len=+e.target.value;$('#pL',root).textContent=S.len;ls.set('pw',S);gen()};
    $$('[data-o]',root).forEach(c=>c.onchange=()=>{S[c.dataset.o]=c.checked;ls.set('pw',S);gen()});
    $('#pG',root).onclick=gen;$('#pC',root).onclick=()=>cur&&copy(cur);gen();
  }

  /* ---------- 7. Tanggal ---------- */
  const D=s=>{const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s||'');return m?new Date(+m[1],+m[2]-1,+m[3],12):null};
  const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
  const longD=d=>d.toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  function ymd(a,b){let y=b.getFullYear()-a.getFullYear(),m=b.getMonth()-a.getMonth(),d=b.getDate()-a.getDate();if(d<0){m--;d+=new Date(b.getFullYear(),b.getMonth(),0).getDate()}if(m<0){y--;m+=12}return{y,m,d}}
  const days=(a,b)=>Math.round((b-a)/864e5);
  function dates(root){
    let tab=ls.get('date-tab','diff');const today=iso(new Date());
    function paint(){
      root.innerHTML=`<div class="ua-tabs">${[['diff','Selisih'],['age','Umur'],['add','Tambah hari']].map(([k,l])=>`<button data-t="${k}" class="${tab===k?'on':''}">${l}</button>`).join('')}</div><div class="ua-form" id="dF"></div><div id="dO"></div>`;
      $$('[data-t]',root).forEach(b=>b.onclick=()=>{tab=b.dataset.t;ls.set('date-tab',tab);paint()});
      const F=$('#dF',root),O=$('#dO',root);
      if(tab==='diff'){F.innerHTML=`<label>Dari tanggal<input type="date" id="d1" value="${today}"></label><label>Sampai tanggal<input type="date" id="d2" value="${today}"></label>`;
        const f=()=>{const a=D($('#d1',F).value),b=D($('#d2',F).value);if(!a||!b){O.innerHTML=out('Hasil','Isi kedua tanggal',true);return}const rev=b<a,[x,y]=rev?[b,a]:[a,b],n=days(x,y),r=ymd(x,y);
          O.innerHTML=out(rev?'Selisih (tanggal akhir lebih awal)':'Selisih',`${fmt(n)} hari`,true)+out('Rincian',`${r.y} tahun ${r.m} bulan ${r.d} hari`)+out('Dalam minggu',`${fmt(Math.floor(n/7))} minggu ${n%7} hari`)}
        $$('input',F).forEach(i=>i.oninput=f);f();}
      else if(tab==='age'){F.innerHTML=`<label>Tanggal lahir<input type="date" id="b1" value="2000-01-01" max="${today}"></label>`;
        const f=()=>{const b=D($('#b1',F).value),t=D(today);if(!b||b>t){O.innerHTML=out('Hasil','Isi tanggal lahir yang valid',true);return}const r=ymd(b,t);let nb=new Date(t.getFullYear(),b.getMonth(),b.getDate(),12);if(nb<t)nb=new Date(t.getFullYear()+1,b.getMonth(),b.getDate(),12);
          O.innerHTML=out('Umur',`${r.y} tahun`,true)+out('Rincian',`${r.y} tahun ${r.m} bulan ${r.d} hari`)+out('Total hari hidup',fmt(days(b,t)))+out('Ulang tahun berikutnya',days(t,nb)===0?'Hari ini! 🎉':`${days(t,nb)} hari lagi (${longD(nb)})`)+out('Lahir pada hari',b.toLocaleDateString('id-ID',{weekday:'long'}))}
        $('#b1',F).oninput=f;f();}
      else{F.innerHTML=`<label>Tanggal awal<input type="date" id="a1" value="${today}"></label><label>Jumlah hari (negatif = mundur)<input type="number" id="a2" value="30" step="1"></label>`;
        const f=()=>{const a=D($('#a1',F).value),n=parseInt($('#a2',F).value);if(!a||!Number.isFinite(n)||Math.abs(n)>100000){O.innerHTML=out('Hasil','Isi data yang valid',true);return}const r=new Date(a);r.setDate(r.getDate()+n);O.innerHTML=out('Hasil',longD(r),true)+out('Format',iso(r))}
        $$('input',F).forEach(i=>i.oninput=f);f();}
    }
    paint();
  }

  /* ---------- 8. Keuangan ---------- */
  function money(root){
    let tab=ls.get('money-tab','disc');
    const tabs=[['disc','Diskon'],['tax','PPN'],['loan','Cicilan'],['split','Patungan']];
    function paint(){
      root.innerHTML=`<div class="ua-tabs">${tabs.map(([k,l])=>`<button data-t="${k}" class="${tab===k?'on':''}">${l}</button>`).join('')}</div><div class="ua-form" id="mF"></div><div id="mO"></div>`;
      $$('[data-t]',root).forEach(b=>b.onclick=()=>{tab=b.dataset.t;ls.set('money-tab',tab);paint()});
      const F=$('#mF',root),O=$('#mO',root),I=id=>$('#'+id,F),bind=f=>{$$('input,select',F).forEach(i=>{i.oninput=f;i.onchange=f});f()};
      if(tab==='disc'){F.innerHTML=`<label>Harga awal (Rp)<input id="p" type="number" step="any" value="100000" inputmode="decimal"></label><label>Diskon (%)<input id="d" type="number" step="any" value="20" inputmode="decimal"></label><label>Diskon tambahan (%) <small>opsional</small><input id="d2" type="number" step="any" value="0" inputmode="decimal"></label>`;
        bind(()=>{const p=val(I('p')),d=val(I('d'))||0,d2=val(I('d2'))||0;if(!Number.isFinite(p)||p<0||d<0||d>100||d2<0||d2>100){O.innerHTML=out('Hasil','Isi data yang valid',true);return}const pay=p*(1-d/100)*(1-d2/100);O.innerHTML=out('Harga setelah diskon',rp(pay),true)+out('Hemat',rp(p-pay))+out('Diskon efektif',fmt((1-pay/(p||1))*100)+'%')})}
      else if(tab==='tax'){F.innerHTML=`<label>Jumlah (Rp)<input id="p" type="number" step="any" value="1000000" inputmode="decimal"></label><label>Tarif PPN (%)<input id="r" type="number" step="any" value="11" inputmode="decimal"></label><label>Jumlah tersebut<select id="m"><option value="add">Belum termasuk PPN (tambahkan)</option><option value="inc">Sudah termasuk PPN (pisahkan)</option></select></label>`;
        bind(()=>{const p=val(I('p')),r=val(I('r')),inc=I('m').value==='inc';if(!Number.isFinite(p)||!Number.isFinite(r)||p<0||r<0){O.innerHTML=out('Hasil','Isi data yang valid',true);return}
          const dpp=inc?p/(1+r/100):p,ppn=inc?p-dpp:p*r/100;O.innerHTML=out('Total bayar',rp(dpp+ppn),true)+out('Dasar (sebelum PPN)',rp(dpp))+out(`PPN ${fmt(r)}%`,rp(ppn))})}
      else if(tab==='loan'){F.innerHTML=`<label>Pokok pinjaman (Rp)<input id="p" type="number" step="any" value="12000000" inputmode="decimal"></label><label>Bunga per tahun (%)<input id="r" type="number" step="any" value="12" inputmode="decimal"></label><label>Tenor (bulan)<input id="n" type="number" step="1" value="12" inputmode="numeric"></label>`;
        bind(()=>{const P=val(I('p')),R=val(I('r')),n=parseInt(I('n').value);if(!Number.isFinite(P)||!Number.isFinite(R)||!(n>=1&&n<=600)||P<0||R<0){O.innerHTML=out('Hasil','Isi data yang valid (tenor 1–600)',true);return}
          const mr=R/1200,an=mr?P*mr/(1-Math.pow(1+mr,-n)):P/n,flat=(P+P*R/100*n/12)/n;
          O.innerHTML=out('Cicilan/bulan (bunga efektif/anuitas)',rp(an),true)+out('Total bayar (anuitas)',rp(an*n))+out('Total bunga (anuitas)',rp(an*n-P))+out('Cicilan/bulan (bunga flat)',rp(flat))+out('Total bayar (flat)',rp(flat*n))})}
      else{F.innerHTML=`<label>Total tagihan (Rp)<input id="p" type="number" step="any" value="450000" inputmode="decimal"></label><label>Jumlah orang<input id="n" type="number" step="1" value="4" inputmode="numeric"></label><label>Tip / service (%)<input id="t" type="number" step="any" value="10" inputmode="decimal"></label>`;
        bind(()=>{const P=val(I('p')),n=parseInt(I('n').value),t=val(I('t'))||0;if(!Number.isFinite(P)||!(n>=1&&n<=1000)||P<0||t<0){O.innerHTML=out('Hasil','Isi data yang valid',true);return}const tot=P*(1+t/100);O.innerHTML=out('Per orang',rp(tot/n),true)+out('Total + tip',rp(tot))+out('Tip',rp(P*t/100))})}
    }
    paint();
  }

  /* ---------- Kerangka ---------- */
  const APPS={calc:['Kalkulator',calc],notes:['Catatan',notes],todo:['Tugas',todo],convert:['Konverter Satuan',convert],timer:['Timer & Stopwatch',timer],password:['Pembuat Kata Sandi',password],dates:['Kalkulator Tanggal',dates],money:['Kalkulator Keuangan',money]};
  function build(){
    overlay=document.createElement('div');overlay.id='uaOverlay';overlay.className='ua-overlay hidden';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');
    overlay.innerHTML='<header class="ua-head"><button class="ua-back" id="uaBack" aria-label="Kembali">‹</button><h2 id="uaTitle"></h2></header><main class="ua-body" id="uaBody"></main>';
    document.body.appendChild(overlay);body=$('#uaBody');titleEl=$('#uaTitle');$('#uaBack').onclick=close;
  }
  function open(id){const a=APPS[id];if(!a)return;if(!overlay)build();close(true);titleEl.textContent=a[0];body.innerHTML='';overlay.classList.remove('hidden');overlay.dataset.app=id;document.body.classList.add('ua-open');try{a[1](body)}catch(e){console.error(e);body.innerHTML='<p class="ua-muted">Gagal memuat aplikasi.</p>'}body.scrollTop=0}
  function close(keep){if(cleanup){try{cleanup()}catch(_){}cleanup=null}if(!overlay)return;if(!keep){overlay.classList.add('hidden');document.body.classList.remove('ua-open');body.innerHTML=''}}
  document.addEventListener('click',e=>{const b=e.target.closest('[data-uapp]');if(b)open(b.dataset.uapp)});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&overlay&&!overlay.classList.contains('hidden')&&!$('.app-panel-overlay.is-open'))close()});
  window.UsefulApps={open,close,evalExpr};
})();
