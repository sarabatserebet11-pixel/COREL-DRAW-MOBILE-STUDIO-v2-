/* V116: Navigasi kanvas. Menambah cara berpindah/zoom yang sebelumnya belum ada:
   - HP: cubit 2 jari untuk zoom, geser 2 jari untuk memindah tampilan.
   - Desktop: Ctrl/⌘ + roda mouse (atau cubit di trackpad) untuk zoom; tahan Spasi lalu seret (atau tombol tengah mouse) untuk menggeser.
   - Keyboard: + / = zoom masuk, - zoom keluar, 0 kembali 100%.
   Hanya mengubah tampilan (zoom/scroll); objek, riwayat, dan data proyek tidak disentuh. */
(()=>{
const S=CDMS.state,C=CDMS.Canvas,$=(s,r=document)=>r.querySelector(s);
const vp=()=>$("#canvasViewport");
const mengetik=()=>{const a=document.activeElement,t=a&&a.tagName;return/^(INPUT|TEXTAREA|SELECT)$/.test(t||"")||(a&&a.isContentEditable);};
const edVisible=()=>{const ed=$("#editor");return !!ed&&!ed.classList.contains("hidden");};
const modalBuka=()=>{const m=$("#modalBackdrop");return !!m&&!m.classList.contains("hidden");};
const zoom=z=>{if(C&&C.setZoom)C.setZoom(Math.round(z));};

/* ---------- Ctrl + roda / cubit trackpad ---------- */
function pasangRoda(v){v.addEventListener("wheel",e=>{if(!(e.ctrlKey||e.metaKey))return;e.preventDefault();
 const before=S.zoom,dy=e.deltaMode===1?e.deltaY*33:e.deltaY;
 /* roda mouse (lompatan besar): 10% per ketukan; trackpad/cubit (delta kecil): halus */
 let z=Math.abs(dy)>=50?before+(dy<0?10:-10):Math.round(before*Math.exp(-dy*0.01));
 if(z===before&&dy)z+=dy<0?1:-1;zoom(z);},{passive:false});}

/* ---------- cubit 2 jari ---------- */
let pin=null;
const jarak=t=>Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY);
const tengah=t=>({x:(t[0].clientX+t[1].clientX)/2,y:(t[0].clientY+t[1].clientY)/2});
function pasangSentuh(v){
 v.addEventListener("touchstart",e=>{if(e.touches.length!==2)return;
  S.drag=null;S.drawPath=null;e.preventDefault();
  pin={d:jarak(e.touches),z:S.zoom,m:tengah(e.touches)};},{passive:false,capture:true});
 v.addEventListener("touchmove",e=>{if(!pin||e.touches.length!==2)return;e.preventDefault();
  const m=tengah(e.touches),d=jarak(e.touches);
  v.scrollLeft-=m.x-pin.m.x;v.scrollTop-=m.y-pin.m.y;pin.m=m;
  if(pin.d>0)zoom(pin.z*d/pin.d);},{passive:false,capture:true});
 const akhir=e=>{if(e.touches.length<2)pin=null;};
 v.addEventListener("touchend",akhir,{capture:true});v.addEventListener("touchcancel",akhir,{capture:true});}

/* ---------- Spasi + seret / tombol tengah ---------- */
let spasi=false,pan=null;
function pasangPan(v){
 v.addEventListener("pointerdown",e=>{if(!((spasi&&e.button===0)||e.button===1))return;
  e.preventDefault();e.stopPropagation();S.drag=null;
  pan={x:e.clientX,y:e.clientY,l:v.scrollLeft,t:v.scrollTop,id:e.pointerId};v.classList.add("panning");
  try{v.setPointerCapture(e.pointerId);}catch(x){}},true);
 v.addEventListener("pointermove",e=>{if(!pan||e.pointerId!==pan.id)return;
  v.scrollLeft=pan.l-(e.clientX-pan.x);v.scrollTop=pan.t-(e.clientY-pan.y);});
 const stop=e=>{if(!pan||(e&&e.pointerId!==pan.id))return;pan=null;v.classList.remove("panning");};
 v.addEventListener("pointerup",stop);v.addEventListener("pointercancel",stop);
 v.addEventListener("auxclick",e=>{if(e.button===1)e.preventDefault();});}
function setSpasi(on){spasi=on;const v=vp();if(v)v.classList.toggle("pan-ready",on);}
document.addEventListener("keydown",e=>{if(!edVisible()||modalBuka())return;
 if(e.code==="Space"&&!e.ctrlKey&&!e.metaKey&&!e.altKey){const a=document.activeElement,t=a&&a.tagName;
  if(mengetik()||t==="BUTTON"||t==="A"||t==="SUMMARY")return;e.preventDefault();if(!e.repeat)setSpasi(true);return;}
 if(e.ctrlKey||e.metaKey||e.altKey||mengetik())return;
 if(e.key==="+"||e.key==="="){e.preventDefault();zoom(S.zoom+10);}
 else if(e.key==="-"||e.key==="_"){e.preventDefault();zoom(S.zoom-10);}
 else if(e.key==="0"){e.preventDefault();zoom(100);}});
document.addEventListener("keyup",e=>{if(e.code==="Space")setSpasi(false);});
window.addEventListener("blur",()=>setSpasi(false));

function pasang(){const v=vp();if(!v||v.dataset.v116)return;v.dataset.v116="1";pasangRoda(v);pasangSentuh(v);pasangPan(v);}
pasang();setTimeout(pasang,400);
CDMS.CanvasNav={zoom,pan:setSpasi};
})();
