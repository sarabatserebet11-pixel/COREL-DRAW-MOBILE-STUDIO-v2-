/* V92: grup menu baru "Ritme" - analisis jarak antar unit terpilih (objek/grup) dengan penanda jarak tidak seragam, seragamkan jarak (rata-rata, median, terkecil, tepat),
   ratakan sumbu silang, + Lembar Sprite (semua grup/objek disusun dalam satu gambar PNG/SVG dengan atlas koordinat JSON) + tab Ritme & Sprite di panel Penata + tombol cepat */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,P=CDMS.Penata,{MENUS,BT,it,sels,pick,T,cell}=M;
if(!M.HUBS||!P||!C.objMarkup)return;
const addTab=(k,l,html,h)=>{const nh={};Object.keys(h).forEach(x=>{nh["x92_"+x]=h[x];});P.addTab(k,l,html.replace(/data-h="([^"]+)"/g,'data-h="x92_$1"'),nh);};
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n);
const b=(k,l,i)=>`<button data-h="${k}">${i?ic(i):""}<span>${l}</span></button>`;
const num=(id,d)=>{const e=$("#"+id),v=e?parseFloat(e.value):NaN;return isFinite(v)?v:d;};
const val=(id,d)=>{const e=$("#"+id);return e&&e.value?e.value:d;};
const bbox=a=>{let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;a.forEach(o=>{const w=o.w||0,h=o.h||0;let ax=o.x,ay=o.y,bx=o.x+w,by=o.y+h;if(o.rotation){const r=Math.hypot(w,h)/2,cx=o.x+w/2,cy=o.y+h/2;ax=cx-r;ay=cy-r;bx=cx+r;by=cy+r;}x0=Math.min(x0,ax);y0=Math.min(y0,ay);x1=Math.max(x1,bx);y1=Math.max(y1,by);});return{x:x0,y:y0,x2:x1,y2:y1,w:x1-x0,h:y1-y0};};
/* ---- unit: grup = satu unit ---- */
function units(a){const seen=new Set(),out=[];a.forEach(o=>{if(seen.has(o.id)||o.locked)return;const m=o.groupId?S.objects.filter(p=>p.groupId===o.groupId&&!p.locked):[o];m.forEach(p=>seen.add(p.id));out.push(m);});return out;}
function sumbuAuto(us){if(us.length<2)return"h";const c=us.map(u=>{const r=bbox(u);return[(r.x+r.x2)/2,(r.y+r.y2)/2];}),sp=i=>Math.max(...c.map(p=>p[i]))-Math.min(...c.map(p=>p[i]));return sp(0)>=sp(1)?"h":"v";}
function analisis(){const us=units(sels());if(us.length<3){return null;}let ax=val("p92ax","auto");if(ax==="auto")ax=sumbuAuto(us);
 const k=ax==="h"?"x":"y",k2=ax==="h"?"x2":"y2",urut=us.map(u=>({u,r:bbox(u)})).sort((p,q)=>p.r[k]-q.r[k]),gaps=[];
 for(let i=0;i<urut.length-1;i++)gaps.push(Math.round((urut[i+1].r[k]-urut[i].r[k2])*10)/10);
 const s=[...gaps].sort((p,q)=>p-q),med=s.length%2?s[(s.length-1)/2]:(s[s.length/2-1]+s[s.length/2])/2,avg=gaps.reduce((t,v)=>t+v,0)/gaps.length;
 return{ax,k,k2,urut,gaps,min:s[0],max:s[s.length-1],avg:Math.round(avg*10)/10,med:Math.round(med*10)/10,seragam:s[s.length-1]-s[0]<=1};}
/* ---- tata ulang ---- */
function seragam(mode){const a=analisis();if(!a)return T("Pilih 3 objek atau grup (atau lebih)");
 const t=mode==="avg"?a.avg:mode==="med"?a.med:mode==="min"?a.min:num("p92gap",24);const sz=a.ax==="h"?"w":"h",ctr=!!($("#p92ctr")&&$("#p92ctr").checked);Hi.snapshot();
 const awal=(a.urut[0].r[a.k]+a.urut[a.urut.length-1].r[a.k2])/2;let pos=a.urut[0].r[a.k];
 a.urut.forEach((e,i)=>{const d=pos-e.r[a.k];if(a.ax==="h")e.u.forEach(o=>{o.x=Math.round(o.x+d);});else e.u.forEach(o=>{o.y=Math.round(o.y+d);});pos+=e.r[sz]+t;});
 if(ctr){const akhir=pos-t,mulai=a.urut[0].r[a.k],g=awal-(mulai+akhir)/2;a.urut.forEach(e=>e.u.forEach(o=>{if(a.ax==="h")o.x=Math.round(o.x+g);else o.y=Math.round(o.y+g);}));}
 C.render();draw();T("Jarak diseragamkan: "+Math.round(t*10)/10+" px ("+a.urut.length+" unit)");}
function silang(){const a=analisis();if(!a)return T("Pilih 3 objek atau grup (atau lebih)");Hi.snapshot();const k=a.ax==="h"?"y":"x",k2=a.ax==="h"?"y2":"x2",ctr=a.urut.map(e=>(e.r[k]+e.r[k2])/2),m=ctr.reduce((t,v)=>t+v,0)/ctr.length;
 a.urut.forEach((e,i)=>{const d=m-ctr[i];e.u.forEach(o=>{if(a.ax==="h")o.y=Math.round(o.y+d);else o.x=Math.round(o.x+d);});});C.render();draw();T("Sumbu silang diratakan di tengah");}
function draw(){const box=$("#p92list");if(!box)return;const a=analisis(),inf=$("#p92info");
 if(!a){box.innerHTML='<div class="kosong">Pilih 3 objek atau grup (atau lebih) untuk menganalisis jarak.</div>';if(inf)inf.textContent="";return;}
 if(inf)inf.textContent=a.urut.length+" unit · "+(a.ax==="h"?"mendatar":"menurun");
 const tol=Math.max(2,Math.round((a.max-a.min)*.0));
 box.innerHTML=`<div class="p92stat ${a.seragam?"ok":"bad"}"><b>${a.seragam?"✔ Jarak seragam":"⚠ Jarak tidak seragam"}</b><span>min ${a.min} · rata-rata ${a.avg} · median ${a.med} · maks ${a.max} px</span></div>`+
  a.gaps.map((g,i)=>`<div class="p92gap${Math.abs(g-a.med)>tol?" off":""}"><span>${i+1} → ${i+2}</span><i style="width:${Math.min(100,Math.max(4,Math.abs(g)/Math.max(1,Math.abs(a.max),Math.abs(a.min))*100))}%"></i><b>${g} px</b></div>`).join("");}
/* ---- lembar sprite ---- */
function sumberSprite(){const vis=S.objects.filter(o=>!o.hidden);const pil=sels().filter(o=>!o.hidden);
 if(pil.length)return units(pil).map((m,i)=>({n:(m.find(o=>o.groupName)||{}).groupName||m[0].name||m[0].type+"-"+(i+1),objs:m}));
 const g=new Map(),lepas=[];vis.forEach(o=>{if(o.groupId){if(!g.has(o.groupId))g.set(o.groupId,[]);g.get(o.groupId).push(o);}else lepas.push(o);});
 const out=[...g.values()].map((m,i)=>({n:(m.find(o=>o.groupName)||{}).groupName||"grup-"+(i+1),objs:m}));
 if(!out.length)lepas.forEach((o,i)=>out.push({n:(o.name||o.type)+"-"+(i+1),objs:[o]}));return out;}
const aman=s=>String(s||"").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-z0-9_-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,40)||"sprite";
function susunSprite(){const src=sumberSprite();if(!src.length)return null;const pad=Math.max(0,num("p92pad",8)),sc=Math.max(.25,Math.min(4,num("p92sc",1)));
 const it0=src.slice(0,200).map(s=>({...s,r:bbox(s.objs)})),cw=Math.max(...it0.map(e=>e.r.w))+pad*2,ch=Math.max(...it0.map(e=>e.r.h))+pad*2;
 let kol=Math.round(num("p92col",0));if(kol<1)kol=Math.ceil(Math.sqrt(it0.length));kol=Math.min(kol,it0.length);const baris=Math.ceil(it0.length/kol),W=cw*kol,Hh=ch*baris,atlas=[];
 const g=it0.map((e,i)=>{const cx=(i%kol)*cw,cy=Math.floor(i/kol)*ch,dx=cx+pad+(cw-pad*2-e.r.w)/2-e.r.x,dy=cy+pad+(ch-pad*2-e.r.h)/2-e.r.y;
  atlas.push({name:e.n,x:Math.round(cx*sc),y:Math.round(cy*sc),w:Math.round(cw*sc),h:Math.round(ch*sc)});
  return`<g transform="translate(${dx} ${dy})">${e.objs.map(o=>C.objMarkup(o)).join("")}</g>`;}).join("");
 const fill=($("#p92tr")&&$("#p92tr").checked)?"":`<rect width="${W}" height="${Hh}" fill="${val("p92bg","#ffffff")}"/>`;
 return{W,Hh,sc,atlas,n:it0.length,kol,baris,svg:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${Hh}" width="${W}" height="${Hh}">${fill}${g}</svg>`};}
function sprite(){const r=susunSprite();if(!r)return T("Desain masih kosong");const fmt=val("p92fmt","png"),atl=$("#p92atl")&&$("#p92atl").checked,nm=aman(S.projectName||"desain")+"_sprite";
 const simpan=(blob,ext,teksAtlas)=>{if(atl&&CDMS.EksporLot){const enc=new TextEncoder(),ab=blob.arrayBuffer?blob.arrayBuffer():Promise.resolve(blob);ab.then(buf=>{CDMS.Export.download(CDMS.EksporLot.zip([{name:"sprite."+ext,data:new Uint8Array(buf)},{name:"atlas.json",data:enc.encode(teksAtlas)}]),nm+".zip");T("Sprite "+r.n+" gambar + atlas dalam ZIP");});}
  else{CDMS.Export.download(blob,nm+"."+ext);T("Sprite "+r.n+" gambar ("+r.kol+"×"+r.baris+")");}};
 const teks=JSON.stringify({image:"sprite."+fmt,scale:r.sc,size:{w:Math.round(r.W*r.sc),h:Math.round(r.Hh*r.sc)},frames:r.atlas},null,1);
 if(fmt==="svg")return simpan(new Blob([r.svg],{type:"image/svg+xml"}),"svg",teks);
 let w=Math.round(r.W*r.sc),h=Math.round(r.Hh*r.sc);const mx=Math.min(1,8000/Math.max(w,h));w=Math.max(1,Math.round(w*mx));h=Math.max(1,Math.round(h*mx));
 const url=URL.createObjectURL(new Blob([r.svg],{type:"image/svg+xml;charset=utf-8"})),im=new Image();
 im.onload=()=>{const cv=document.createElement("canvas");cv.width=w;cv.height=h;cv.getContext("2d").drawImage(im,0,0,w,h);cv.toBlob(bl=>{URL.revokeObjectURL(url);bl?simpan(bl,"png",teks):T("Gagal membuat sprite");},"image/png");};
 im.onerror=()=>{URL.revokeObjectURL(url);T("Gagal membuat sprite");};im.src=url;}
CDMS.Sprite={susun:susunSprite,analisis};
const H={an:()=>{draw();const a=analisis();T(a?(a.seragam?"Jarak sudah seragam":"Jarak tidak seragam: "+a.min+"–"+a.max+" px"):"Pilih 3 objek atau grup (atau lebih)");},sa:()=>seragam("avg"),sm:()=>seragam("med"),sn:()=>seragam("min"),st:()=>seragam("tepat"),sl:silang,sp:sprite};
addTab("ritme92","Ritme",`<p class="muted" style="margin:0 0 8px">Pilih 3 objek atau grup lalu analisis jarak antar unit. Grup dihitung satu unit.</p>
 <div class="p69h">Hasil <span id="p92info" class="muted" style="font-weight:400"></span></div><div id="p92list" class="p92list"></div>
 <div class="p69row"><label>Arah<select id="p92ax"><option value="auto">Otomatis</option><option value="h">Mendatar</option><option value="v">Menurun</option></select></label><label>Jarak tepat (px)<input id="p92gap" type="number" value="24"></label></div>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:4px 0 8px"><input id="p92ctr" type="checkbox" checked> Pertahankan titik tengah barisan</label>
 <div class="p69btns c3">${b("an","Analisis","search")}${b("sa","Rata-rata")}${b("sm","Median")}${b("sn","Terkecil")}${b("st","Jarak tepat")}${b("sl","Ratakan silang","align")}</div>`,H);
addTab("sprite92","Sprite",`<p class="muted" style="margin:0 0 8px">Susun grup (atau objek terpilih; tanpa pilihan: semua grup) dalam satu gambar berpetak sama besar. Atlas JSON berisi nama dan koordinat tiap petak.</p>
 <div class="p69row"><label>Format<select id="p92fmt"><option value="png">PNG</option><option value="svg">SVG</option></select></label><label>Kolom (0 = otomatis)<input id="p92col" type="number" value="0" min="0"></label><label>Margin petak (px)<input id="p92pad" type="number" value="8" min="0"></label><label>Skala<input id="p92sc" type="number" value="1" min="0.25" max="4" step="0.25"></label><label>Warna latar<input id="p92bg" type="color" value="#ffffff"></label></div>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:4px 0"><input id="p92tr" type="checkbox" checked> Latar transparan</label>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 8px"><input id="p92atl" type="checkbox" checked> Sertakan atlas JSON (hasil ZIP)</label>
 <div class="p69btns">${b("sp","Buat lembar sprite","export")}</div>`,H);
const ot=P.openTab;P.openTab=function(){const r=ot.apply(this,arguments);setTimeout(draw,0);return r;};
document.addEventListener("click",e=>{if(e.target.closest&&e.target.closest(".p69 [data-t=ritme92]"))setTimeout(draw,0);});
document.addEventListener("input",e=>{if(e.target&&e.target.id==="p92ax")draw();});
let raf=0;const r0=C.render;C.render=function(){const v=r0.apply(this,arguments);if(!raf&&$("#p92list")){raf=requestAnimationFrame(()=>{raf=0;draw();});}return v;};
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q92="ritme" title="Analisis jarak antar objek">${ic("distribute")}</button><button data-q92="seragam" title="Seragamkan jarak (rata-rata)">${ic("steps")}</button><button data-q92="sprite" title="Lembar sprite">${ic("icongrid")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q92]");if(!x)return;const k=x.dataset.q92;if(k==="ritme")P.openTab("ritme92");else if(k==="seragam")seragam("avg");else sprite();});}
MENUS.rit1=()=>[{h:"Jarak antar unit",items:[it("Analisis jarak (panel)",()=>P.openTab("ritme92"),"distribute"),it("Seragamkan: rata-rata",()=>seragam("avg"),"steps"),it("Seragamkan: median",()=>seragam("med"),"steps"),it("Seragamkan: terkecil",()=>seragam("min"),"steps"),it("Seragamkan: jarak tepat (panel)",()=>seragam("tepat"),"steps"),it("Ratakan sumbu silang",silang,"align")]}];
MENUS.rit2=()=>[{h:"Lembar sprite",items:[it("Buat lembar sprite",sprite,"icongrid"),it("Pengaturan sprite (panel)",()=>P.openTab("sprite92"),"panel")]}];
BT.push(["rit1","distribute","Jarak"],["rit2","icongrid","Sprite"]);
const RIT=["rit1","rit2"],ai=M.HUBS.findIndex(h=>h[0]==="lot");
M.HUBS.splice(ai<0?M.HUBS.length:ai+1,0,["ritme","distribute","Ritme",RIT]);
MENUS.hub_ritme=()=>[{h:"Ritme",items:RIT.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($('[data-menu="hub_ritme"]'),k),0));})}];
})();
