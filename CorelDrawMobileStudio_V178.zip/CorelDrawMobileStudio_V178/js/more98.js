/* V110: perapihan pita dan panel. Pemisah kelompok, pudar tepi, geser roda mouse, navigasi keyboard tab,
   dan label lapisan berbahasa Indonesia. Tidak mengubah fitur atau data proyek. */
(()=>{
const $=(s,r=document)=>r.querySelector(s);
const GROUP_STARTS={beranda:["tool:text","tool:pan","act:arrange","hub:warna"]};
const keyOf=e=>e.dataset.tool?"tool:"+e.dataset.tool:e.dataset.action?"act:"+e.dataset.action:(e.dataset.menu||"").startsWith("hub_")?"hub:"+e.dataset.menu.slice(4):"";

/* pudar di tepi bila isi bisa digeser */
function fade(el){if(!el)return;const max=el.scrollWidth-el.clientWidth;el.classList.toggle("fade-r",max>2&&el.scrollLeft<max-2);el.classList.toggle("fade-l",max>2&&el.scrollLeft>2);}
function watch(el){if(!el||el.dataset.v110)return;el.dataset.v110="1";
 el.addEventListener("scroll",()=>fade(el),{passive:true});
 el.addEventListener("wheel",e=>{if(el.scrollWidth<=el.clientWidth||Math.abs(e.deltaX)>Math.abs(e.deltaY))return;el.scrollLeft+=e.deltaY;e.preventDefault();},{passive:false});
 if(window.ResizeObserver)new ResizeObserver(()=>fade(el)).observe(el);
 fade(el);}

/* pemisah kelompok pada tab aktif */
function marks(tb){const starts=GROUP_STARTS[tb.dataset.tab]||[];
 [...tb.children].forEach(e=>e.classList&&e.classList.remove("rb-gs"));
 if(!starts.length)return;
 const vis=[...tb.children].filter(e=>keyOf(e)&&!e.classList.contains("rb-off")).sort((a,b)=>(+a.style.order||0)-(+b.style.order||0));
 vis.forEach((e,i)=>{if(i>0&&starts.includes(keyOf(e)))e.classList.add("rb-gs");});}

/* tab: roving tabindex, panah kiri/kanan, tab aktif selalu terlihat */
function tabs(bar){const list=()=>[...bar.querySelectorAll(".ribbon-tab")];
 const sync=()=>{list().forEach(b=>{b.tabIndex=b.classList.contains("active")?0:-1;b.title=b.textContent.trim();});
  const a=bar.querySelector(".ribbon-tab.active");if(a&&a.scrollIntoView)try{a.scrollIntoView({block:"nearest",inline:"nearest"});}catch(e){}fade(bar);};
 bar.addEventListener("keydown",e=>{const l=list(),i=l.indexOf(document.activeElement);if(i<0)return;let n=-1;
  if(e.key==="ArrowRight")n=(i+1)%l.length;else if(e.key==="ArrowLeft")n=(i-1+l.length)%l.length;else if(e.key==="Home")n=0;else if(e.key==="End")n=l.length-1;
  if(n<0)return;e.preventDefault();l[n].focus();l[n].click();});
 new MutationObserver(sync).observe(bar,{subtree:true,attributes:true,attributeFilter:["class"]});sync();}

function setup(){const tb=$(".editor-toolbar"),bar=$(".ribbon-tabs");if(!tb||!bar||tb.dataset.v110s)return false;tb.dataset.v110s="1";
 watch(tb);watch(bar);tabs(bar);marks(tb);
 new MutationObserver(()=>{marks(tb);tb.scrollLeft=0;fade(tb);}).observe(tb,{attributes:true,attributeFilter:["data-tab"]});
 return true;}

/* bilah aksi cepat */
function qbar(){const qb=$(".qbar");if(!qb||qb.dataset.v110)return;watch(qb);
 new MutationObserver(()=>fade(qb)).observe(qb,{attributes:true,attributeFilter:["hidden"],childList:true});}

/* nama bawaan lapisan berbahasa Indonesia (data proyek lama tidak diubah) */
const NAMA={Rect:"Persegi",Ellipse:"Elips",Text:"Teks",Star:"Bintang",Line:"Garis",Polygon:"Poligon",Image:"Gambar",Path:"Coretan"};
function lokal(){const root=$("#layersList");if(!root)return;root.querySelectorAll(".layer-name").forEach(n=>{const t=n.textContent.trim();if(NAMA[t])n.textContent=NAMA[t];});}
if(CDMS.Layers&&CDMS.Layers.render){const r=CDMS.Layers.render;CDMS.Layers.render=function(){const x=r.apply(this,arguments);lokal();return x;};}
const root=$("#layersList");if(root)new MutationObserver(lokal).observe(root,{childList:true});

const go=()=>{setup();qbar();};
if(CDMS.Tools&&CDMS.Tools.init){const ti=CDMS.Tools.init;CDMS.Tools.init=function(){const x=ti.apply(this,arguments);go();return x;};}
go();
/* cadangan: bila pita dibangun terlambat */
let n=0;const iv=setInterval(()=>{go();if(($(".editor-toolbar")&&$(".editor-toolbar").dataset.v110s&&$(".qbar"))||++n>40)clearInterval(iv);},250);
window.addEventListener("resize",()=>{fade($(".editor-toolbar"));fade($(".ribbon-tabs"));fade($(".qbar"));});
})();
