/* V69: Panel Penata (panel melayang yang tetap terbuka saat bekerja di kanvas) + tombol baru di bar aksi cepat dan topbar.
   Tab: Susun (sebar jarak tepat, rata ke objek acuan, grid, lingkaran), Ukuran (samakan, skala %, penuhi halaman, transparansi, sudut),
   Latar (latar/bingkai di sekeliling pilihan), Warna (gradasi bertahap, warna acak, rotasi acak), Pilih (sejenis, warna sama, balik pilihan).
   Grup selalu diperlakukan sebagai satu unit. Semua aksi bisa di-undo. */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,sels,pick,T,nr}=M;
if(!M.HUBS)return;
const $=s=>document.querySelector(s);
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const ic=n=>CDMS.Icons.svg(n);

/* ---------- helper ---------- */
const cur=()=>sels().filter(o=>!o.locked);
function unitsOf(a){const seen=new Set(),out=[];
 a.forEach(o=>{if(seen.has(o.id))return;const m=o.groupId?S.objects.filter(p=>p.groupId===o.groupId&&!p.locked):[o];m.forEach(p=>seen.add(p.id));out.push(m);});return out;}
const bbx=u=>{const x=Math.min(...u.map(o=>o.x)),y=Math.min(...u.map(o=>o.y)),x2=Math.max(...u.map(o=>o.x+(o.w||0))),y2=Math.max(...u.map(o=>o.y+(o.h||0)));return {x,y,x2,y2,w:x2-x,h:y2-y};};
const mv=(u,dx,dy)=>u.forEach(o=>{o.x=Math.round(o.x+dx);o.y=Math.round(o.y+dy);});
const need=n=>{const us=unitsOf(cur());if(us.length<n){T(n<=1?"Pilih objek dulu":"Pilih "+n+" objek atau lebih");return null;}return us;};
const num=(id,d)=>{const e=$("#"+id),v=e?parseFloat(e.value):NaN;return isFinite(v)?v:d;};
const done=m=>{C.render();if(m)T(m);};
const hex=c=>/^#[0-9a-f]{6}$/i.test(c||"");
const lerp=(a,b,t)=>{const p=s=>[1,3,5].map(i=>parseInt(s.slice(i,i+2),16));const A=p(a),B=p(b);return "#"+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,"0")).join("");};
function scaleAll(a,f,cx,cy){a.forEach(o=>{o.x=Math.round(cx+(o.x-cx)*f);o.y=Math.round(cy+(o.y-cy)*f);o.w=Math.max(1,Math.round((o.w||0)*f));if(o.h)o.h=Math.max(1,Math.round(o.h*f));if(o.fontSize)o.fontSize=Math.max(6,Math.round(o.fontSize*f));});}
const allMembers=us=>us.flat();

/* ---------- aksi: Susun ---------- */
function sebar(ax){const us=need(2);if(!us)return;const gap=num("p69gap",24);Hi.snapshot();
 const k=ax==="h"?"x":"y",sz=ax==="h"?"w":"h",s=us.map(u=>({u,b:bbx(u)})).sort((p,q)=>p.b[k]-q.b[k]);let pos=s[0].b[k]+s[0].b[sz];
 s.slice(1).forEach(e=>{const d=pos+gap-e.b[k];ax==="h"?mv(e.u,d,0):mv(e.u,0,d);pos+=gap+e.b[sz];});done("Disebar, jarak "+gap+" px");}
function rata(k){const us=need(2);if(!us)return;Hi.snapshot();const a=bbx(us[0]);
 us.slice(1).forEach(u=>{const b=bbx(u);let dx=0,dy=0;
  if(k==="l")dx=a.x-b.x;if(k==="c")dx=(a.x+a.x2)/2-(b.x+b.x2)/2;if(k==="r")dx=a.x2-b.x2;
  if(k==="t")dy=a.y-b.y;if(k==="m")dy=(a.y+a.y2)/2-(b.y+b.y2)/2;if(k==="b")dy=a.y2-b.y2;mv(u,dx,dy);});
 done("Dirata ke objek yang dipilih pertama");}
function grid(){const us=need(2);if(!us)return;const cols=Math.max(1,Math.min(20,Math.round(num("p69cols",3)))),gap=Math.max(0,num("p69gap",24));Hi.snapshot();
 const it2=us.map(u=>({u,b:bbx(u)})).sort((p,q)=>Math.abs(p.b.y-q.b.y)>20?p.b.y-q.b.y:p.b.x-q.b.x);
 const cw=Math.max(...it2.map(e=>e.b.w)),ch=Math.max(...it2.map(e=>e.b.h)),ox=Math.min(...it2.map(e=>e.b.x)),oy=Math.min(...it2.map(e=>e.b.y));
 it2.forEach((e,i)=>{const cx=ox+(i%cols)*(cw+gap),cy=oy+Math.floor(i/cols)*(ch+gap);mv(e.u,cx+(cw-e.b.w)/2-e.b.x,cy+(ch-e.b.h)/2-e.b.y);});
 done(it2.length+" unit disusun dalam grid "+cols+" kolom");}
function lingkaran(){const us=need(3);if(!us)return;Hi.snapshot();const all=bbx(allMembers(us)),cx=(all.x+all.x2)/2,cy=(all.y+all.y2)/2;
 let r=num("p69rad",0);if(!(r>0))r=Math.max(80,Math.max(all.w,all.h)/2);
 us.forEach((u,i)=>{const b=bbx(u),a=-Math.PI/2+i*2*Math.PI/us.length;mv(u,cx+r*Math.cos(a)-(b.x+b.x2)/2,cy+r*Math.sin(a)-(b.y+b.y2)/2);});
 done(us.length+" unit disusun melingkar");}

/* ---------- aksi: Ukuran ---------- */
function samakan(dim){const us=need(2);if(!us)return;Hi.snapshot();const a=bbx(us[0]);let n=0;
 us.slice(1).forEach(u=>{if(u.length!==1)return;const o=u[0];if(dim!=="h")o.w=a.w;if(dim!=="w")o.h=a.h;n++;});
 done(n?n+" objek disamakan dengan objek pertama":"Grup tidak bisa disamakan ukurannya");}
function skala(f){const us=need(1);if(!us)return;Hi.snapshot();const m=allMembers(us),b=bbx(m);scaleAll(m,f,(b.x+b.x2)/2,(b.y+b.y2)/2);done("Skala "+Math.round(f*100)+"%");}
function penuhi(){const us=need(1);if(!us)return;const mg=Math.max(0,num("p69mg",48));Hi.snapshot();const m=allMembers(us),b=bbx(m);
 const f=Math.min((S.page.width-2*mg)/Math.max(1,b.w),(S.page.height-2*mg)/Math.max(1,b.h));scaleAll(m,f,b.x,b.y);
 const nb=bbx(m);mv(m,S.page.width/2-(nb.x+nb.x2)/2,S.page.height/2-(nb.y+nb.y2)/2);done("Dipenuhkan di halaman (margin "+mg+" px)");}
let gest=false;
function liveSet(fn,label){const a=cur();if(!a.length)return T("Pilih objek dulu");if(!gest){Hi.snapshot();gest=true;}a.forEach(fn);C.render();}

/* ---------- aksi: Latar ---------- */
function latar(mode){const us=need(1);if(!us)return;const m=allMembers(us),b=bbx(m),pad=Math.max(0,num("p69pad",32)),rx=Math.max(0,num("p69rx",24)),col=$("#p69col").value;Hi.snapshot();
 const o={id:crypto.randomUUID(),type:"rect",name:mode==="latar"?"Latar pilihan":"Bingkai pilihan",x:Math.round(b.x-pad),y:Math.round(b.y-pad),w:Math.round(b.w+2*pad),h:Math.round(b.h+2*pad),
  fill:mode==="latar"?col:"none",stroke:mode==="latar"?"#20243a":col,strokeWidth:mode==="latar"?0:Math.max(1,num("p69sw",4)),opacity:100,rotation:0,rx};
 if(mode==="latar"){const i=Math.min(...m.map(p=>S.objects.indexOf(p)).filter(i=>i>=0));S.objects.splice(Math.max(0,i),0,o);}else S.objects.push(o);
 done(mode==="latar"?"Latar ditambahkan di belakang pilihan":"Bingkai ditambahkan");}

/* ---------- aksi: Warna ---------- */
const warnai=(u,c)=>u.forEach(o=>{if(o.type!=="image"&&o.type!=="line"){o.fill=c;delete o.grad;}});
function gradasi(){const us=need(2);if(!us)return;Hi.snapshot();const a=$("#p69c1").value,b=$("#p69c2").value;us.forEach((u,i)=>warnai(u,lerp(a,b,i/(us.length-1))));done("Gradasi warna diterapkan ke "+us.length+" unit");}
const PAL=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4cc9f0","#f72585","#80ed99","#ff9f1c"];
function acak(){const us=need(1);if(!us)return;Hi.snapshot();us.forEach(u=>warnai(u,PAL[Math.floor(Math.random()*PAL.length)]));done("Warna acak diterapkan");}
function rotAcak(){const us=need(1);if(!us)return;const d=Math.max(0,Math.min(90,num("p69rot",8)));Hi.snapshot();let n=0;
 us.forEach(u=>{if(u.length!==1)return;u[0].rotation=nr(Math.round((u[0].rotation||0)+(Math.random()*2-1)*d));n++;});done(n?n+" objek diputar acak ±"+d+"°":"Grup dilewati");}

/* ---------- aksi: Pilih & cepat ---------- */
function sejenis(by){const a=sels();if(!a.length)return T("Pilih objek dulu");const r=a[0],p=S.objects.filter(o=>!o.hidden&&!o.locked&&(by==="type"?o.type===r.type:o.fill===r.fill&&o.type!=="image"));pick(p);T(p.length+" objek dipilih");}
function balik(){const set=new Set(sels().map(o=>o.id));const p=S.objects.filter(o=>!o.hidden&&!o.locked&&!set.has(o.id));pick(p);T(p.length+" objek dipilih");}
function putar90(){const us=need(1);if(!us)return;Hi.snapshot();
 us.forEach(u=>{if(u.length===1){u[0].rotation=nr((u[0].rotation||0)+90);return;}
  const b=bbx(u),gx=(b.x+b.x2)/2,gy=(b.y+b.y2)/2;
  u.forEach(o=>{const mx=o.x+(o.w||0)/2-gx,my=o.y+(o.h||0)/2-gy,nx=gx-my,ny=gy+mx;o.x=Math.round(nx-(o.w||0)/2);o.y=Math.round(ny-(o.h||0)/2);o.rotation=nr((o.rotation||0)+90);});});
 done();}
function sembunyi(){const a=cur();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();a.forEach(o=>{o.hidden=true;});S.selected=null;S.selectedIds=[];done("Disembunyikan (tampilkan lagi lewat panel Layer)");}
function kunci(){const a=cur();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();a.forEach(o=>{o.locked=true;});done(a.length+" objek dikunci");}

/* ---------- panel ---------- */
const H={sebarH:()=>sebar("h"),sebarV:()=>sebar("v"),grid,lingkaran,
 rl:()=>rata("l"),rc:()=>rata("c"),rr:()=>rata("r"),rt:()=>rata("t"),rm:()=>rata("m"),rb:()=>rata("b"),
 sw:()=>samakan("w"),sh:()=>samakan("h"),swh:()=>samakan("wh"),
 s50:()=>skala(.5),s90:()=>skala(.9),s110:()=>skala(1.1),s200:()=>skala(2),sx:()=>skala(num("p69pct",100)/100),penuhi,
 latar:()=>latar("latar"),bingkai:()=>latar("bingkai"),gradasi,acak,rotAcak,
 type:()=>sejenis("type"),fill:()=>sejenis("fill"),inv:balik,putar:putar90,sembunyi,kunci};
const TABS=[["susun","Susun"],["ukuran","Ukuran"],["latar","Latar"],["warna","Warna"],["pilih","Pilih"]];
const b=(k,l,i)=>`<button data-h="${k}">${i?ic(i):""}<span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const BODY={
 susun:`<div class="p69row">${fld("p69gap","Jarak (px)",24,'min="0"')}${fld("p69cols","Kolom grid",3,'min="1" max="20"')}${fld("p69rad","Radius lingkaran (0 = otomatis)",0,'min="0"')}</div>
  <div class="p69btns">${b("sebarH","Sebar mendatar","arrange")}${b("sebarV","Sebar menurun","arrange")}${b("grid","Susun grid","grid")}${b("lingkaran","Susun lingkaran","ellipse")}</div>
  <div class="p69h">Rata ke objek yang dipilih pertama</div><div class="p69btns c3">${[["rl","Kiri"],["rc","Tengah"],["rr","Kanan"],["rt","Atas"],["rm","Tengah V"],["rb","Bawah"]].map(x=>b(x[0],x[1])).join("")}</div>`,
 ukuran:`<div class="p69h">Samakan dengan objek pertama</div><div class="p69btns c3">${b("sw","Lebar")}${b("sh","Tinggi")}${b("swh","Keduanya")}</div>
  <div class="p69h">Skala</div><div class="p69btns c4">${b("s50","50%")}${b("s90","90%")}${b("s110","110%")}${b("s200","200%")}</div>
  <div class="p69row">${fld("p69pct","Skala kustom (%)",150,'min="5" max="1000"')}${fld("p69mg","Margin halaman (px)",48,'min="0"')}</div>
  <div class="p69btns">${b("sx","Terapkan skala")}${b("penuhi","Penuhi halaman","arrange")}</div>
  <label class="p69rg">Transparansi <input id="p69op" type="range" min="0" max="100" value="100"></label>
  <label class="p69rg">Sudut persegi <input id="p69cr" type="range" min="0" max="200" value="0"></label>`,
 latar:`<p class="muted">Tambahkan kotak di sekeliling objek/grup terpilih: latar (di belakang) atau bingkai garis (di atas).</p>
  <div class="p69row">${fld("p69pad","Jarak tepi (px)",32,'min="0"')}${fld("p69rx","Sudut (px)",24,'min="0"')}${fld("p69sw","Tebal bingkai",4,'min="1"')}<label>Warna<input id="p69col" type="color" value="#ffffff"></label></div>
  <div class="p69btns">${b("latar","Latar di belakang","rect")}${b("bingkai","Bingkai garis","rect")}</div>`,
 warna:`<div class="p69row"><label>Dari<input id="p69c1" type="color" value="#6d5dfc"></label><label>Ke<input id="p69c2" type="color" value="#00d6c9"></label>${fld("p69rot","Rotasi acak ± (°)",8,'min="0" max="90"')}</div>
  <div class="p69btns">${b("gradasi","Gradasi bertahap","color")}${b("acak","Warna acak","color")}${b("rotAcak","Rotasi acak","rotate")}</div>
  <p class="muted">Gradasi bertahap mewarnai unit sesuai urutan dipilih (Shift + klik).</p>`,
 pilih:`<div class="p69btns">${b("type","Pilih sejenis","similar")}${b("fill","Pilih warna sama","color")}${b("inv","Balik pilihan","multi")}</div>
  <div class="p69h">Aksi cepat</div><div class="p69btns c3">${b("putar","Putar 90°","rotate")}${b("sembunyi","Sembunyikan","eyeoff")}${b("kunci","Kunci","lock")}</div>`};
let el=null,tab="susun";
function build(){try{const t=localStorage.getItem("cdms-p69-tab");if(t&&TABS.some(x=>x[0]===t))tab=t;}catch(e){}el=document.createElement("section");el.className="p69";el.hidden=true;el.setAttribute("aria-label","Panel Penata");
 el.innerHTML=`<header class="p69hd"><b>${ic("panel")}Penata</b><span class="p69info" id="p69info"></span><button class="p69x" data-h="min" title="Ciutkan">–</button><button class="p69x" data-h="close" title="Tutup">×</button></header>
 <nav class="p69tabs">${TABS.map(t=>`<button data-t="${t[0]}">${t[1]}</button>`).join("")}</nav>
 <div class="p69body">${TABS.map(t=>`<div class="p69pane" data-pane="${t[0]}">${BODY[t[0]]}</div>`).join("")}</div>`;
 document.body.appendChild(el);
 el.addEventListener("pointerdown",e=>e.stopPropagation());
 el.addEventListener("click",e=>{const t=e.target.closest("[data-t]");if(t){tab=t.dataset.t;show();try{localStorage.setItem("cdms-p69-tab",tab);}catch(x){}return;}
  const h=e.target.closest("[data-h]");if(!h)return;if(h.dataset.h==="close")return toggle(false);if(h.dataset.h==="min"){el.classList.toggle("p69-min");return;}const pn=h.closest("[data-pane]"),pk=pn&&pn.dataset.pane,key=h.dataset.h,f=(pk&&HT[pk]&&HT[pk][key])||(pk&&!HT[pk]&&HB&&HB[key])||H[key];if(f)f();});
 el.addEventListener("input",e=>{if(e.target.id==="p69op")liveSet(o=>{o.opacity=+e.target.value;});
  if(e.target.id==="p69cr")liveSet(o=>{if(o.type==="rect")o.rx=+e.target.value;});});
 el.addEventListener("change",()=>{gest=false;});
 /* geser panel (desktop) lewat header */
 const hd=el.querySelector(".p69hd");let d=null;
 hd.addEventListener("pointerdown",e=>{if(e.target.closest("button")||matchMedia("(max-width:720px)").matches)return;const r=el.getBoundingClientRect();d={dx:e.clientX-r.left,dy:e.clientY-r.top};hd.setPointerCapture(e.pointerId);});
 hd.addEventListener("pointermove",e=>{if(!d)return;el.style.left=Math.max(0,Math.min(innerWidth-120,e.clientX-d.dx))+"px";el.style.top=Math.max(0,Math.min(innerHeight-60,e.clientY-d.dy))+"px";el.style.right="auto";el.style.bottom="auto";});
 hd.addEventListener("pointerup",()=>{d=null;});
 show();}
function show(){if(!el)return;el.querySelectorAll("[data-t]").forEach(b=>b.classList.toggle("on",b.dataset.t===tab));el.querySelectorAll("[data-pane]").forEach(p=>p.hidden=p.dataset.pane!==tab);}
function info(){if(!el||el.hidden)return;const a=sels();const e=$("#p69info");if(!e)return;
 if(!a.length){e.textContent="Belum ada pilihan";return;}const us=unitsOf(a),b=bbx(a);e.textContent=a.length+" objek · "+us.length+" unit · "+Math.round(b.w)+"×"+Math.round(b.h);
 const op=$("#p69op");if(op&&document.activeElement!==op)op.value=a[0].opacity??100;}
function toggle(on){if(!el)build();el.hidden=on===undefined?!el.hidden:!on;document.body.classList.toggle("p69-open",!el.hidden);
 document.querySelectorAll("[data-p69]").forEach(b=>b.classList.toggle("on",!el.hidden));info();}
const rr=C.render;C.render=function(){const r=rr.apply(this,arguments);try{info();}catch(e){}return r;};

/* ---------- tombol baru: topbar, bar aksi cepat, menu ---------- */
const ta=$(".top-actions");if(ta&&!ta.querySelector("[data-p69]"))ta.insertAdjacentHTML("afterbegin",`<button class="icon-btn p69tb" data-p69="toggle" title="Panel Penata">${ic("panel")}</button>`);
const mbt=$(".mobile-bottom-tools");if(mbt&&!mbt.querySelector("[data-p69]")){const last=mbt.lastElementChild;const bt=document.createElement("button");bt.className="p69bt";bt.dataset.p69="toggle";bt.innerHTML=ic("panel")+"<span>Penata</span>";last?mbt.insertBefore(bt,last):mbt.appendChild(bt);}
document.addEventListener("click",e=>{if(e.target.closest("[data-p69]"))toggle();});
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-p69="toggle" title="Panel Penata">${ic("panel")}</button><button data-qy="putar" title="Putar 90°">${ic("rotate")}</button><button data-qy="sembunyi" title="Sembunyikan">${ic("eyeoff")}</button><button data-qy="type" title="Pilih sejenis">${ic("similar")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-qy]");if(x&&H[x.dataset.qy])H[x.dataset.qy]();});}
MENUS.penata=()=>[
 {h:"Panel",items:[it("Buka / tutup panel Penata",()=>toggle(),"panel")]},
 {h:"Cepat",items:[it("Sebar mendatar (jarak 24 px)",()=>{const e=$("#p69gap");if(e)e.value=24;sebar("h");},"arrange"),it("Sebar menurun (jarak 24 px)",()=>{const e=$("#p69gap");if(e)e.value=24;sebar("v");},"arrange"),it("Penuhi halaman",penuhi,"arrange"),it("Pilih sejenis",()=>sejenis("type"),"similar"),it("Putar 90°",putar90,"rotate")]}];
BT.push(["penata","panel","Penata"]);hubAdd("atur","penata");
function openTab(t){if(!el)build();tab=t;show();try{localStorage.setItem("cdms-p69-tab",t);}catch(e){}el.classList.remove("p69-min");if(el.hidden)toggle(true);}
/* V90: handler per tab (kunci yang sama di tab berbeda tidak lagi saling menimpa); HB = handler tab bawaan sebelum tab tambahan */
let HB=null;const HT={};
function addTab(k,l,html,handlers){if(!HB)HB=Object.assign({},H);TABS.push([k,l]);BODY[k]=html;HT[k]=handlers||{};Object.assign(H,handlers||{});}
CDMS.Penata={H,TABS,BODY,addTab,openTab,info,cur,liveSet,num,toggle,unitsOf,sebar,grid,lingkaran,rata,samakan,skala,penuhi,latar,gradasi,putar90};
})();
