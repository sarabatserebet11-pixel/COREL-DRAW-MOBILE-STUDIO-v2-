/* V18: Cari fitur (Ctrl+K) + menu Layer, Mockup, Preset teks, Tata */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height,E=CDMS.escape,rnd=(a,b)=>a+Math.random()*(b-a);
const bgc=()=>/^#[0-9a-f]{6}$/i.test(String(S.page.background))?S.page.background:"#ffffff";
const txt=(text,x,y,size,fill,x2)=>({type:"text",name:"Teks",text,x:Math.round(x),y:Math.round(y),w:50,h:30,fontSize:Math.round(size),fill,...x2});
function grp(arr,post){Hi.snapshot();const g=uid();arr.forEach(o=>Object.assign(o,{id:uid(),groupId:g,opacity:o.opacity??100,rotation:o.rotation||0,stroke:o.stroke||"none",strokeWidth:o.strokeWidth||0}));S.objects.push(...arr);pick(arr);if(post){post();C.render();}}
const mid=(t,r)=>{t.x=Math.round(r.x+(r.w-t.w)/2);t.y=Math.round(r.y+(r.h-t.h)/2);};

/* ---- cari fitur ---- */
function launcher(){const rows=[];
 BT.forEach(b=>{let secs;try{secs=MENUS[b[0]]();}catch(e){return;}secs.forEach(s=>s.items.forEach(x=>{if(x.keep)return;const l=x.l||(x.cell||"").replace(/<svg[\s\S]*?<\/svg>/g,"").replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim();if(l)rows.push({l,m:b[2],s:s.h,f:x.f});}));});
 N.openModal("Cari fitur",`<div class="st-pane"><input id="fq" placeholder="Ketik: neon, grid, emoji, tabel…" autocomplete="off"><div id="fr" class="fr"></div></div>`);
 const draw=()=>{const q=$("#fq").value.toLowerCase().trim(),hits=rows.filter(r=>!q||(r.l+" "+r.m+" "+r.s).toLowerCase().includes(q)).slice(0,40);
  $("#fr").innerHTML=hits.map((r,i)=>`<button class="fr-i" data-i="${i}"><b>${E(r.l)}</b><small>${E(r.m)} › ${E(r.s)}</small></button>`).join("")||'<p class="st-note">Tidak ada hasil.</p>';
  $("#fr").querySelectorAll("[data-i]").forEach(b=>b.onclick=()=>{N.closeModal();hits[+b.dataset.i].f();});};
 $("#fq").oninput=draw;draw();setTimeout(()=>{const q=$("#fq");if(q)q.focus();},60);}
document.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){const ed=$("#editor");if(ed&&!ed.classList.contains("hidden")){e.preventDefault();launcher();}}});
document.addEventListener("click",e=>{if(e.target.closest("[data-find]"))launcher();});

/* ---- layer ---- */
const NAMES={rect:"Persegi",ellipse:"Elips",star:"Bintang",polygon:"Poligon",line:"Garis",path:"Vektor",text:"Teks",image:"Gambar"};
function rename(){const a=sels()[0];if(!a)return T("Pilih satu objek dulu");N.openModal("Ganti nama objek",'<div class="st-pane"><input id="rnI" maxlength="40"><button class="btn primary" id="rnOk">Simpan nama</button></div>');$("#rnI").value=a.name||"";$("#rnOk").onclick=()=>{Hi.snapshot();a.name=$("#rnI").value.trim()||a.type;N.closeModal();C.render();};}
const re=(fn,msg)=>{Hi.snapshot();fn();C.render();if(msg)T(msg);};
MENUS.layer=()=>[
 {h:"Nama",items:[it("Ganti nama objek…",rename,"text"),it("Beri nama otomatis",()=>re(()=>S.objects.forEach((o,i)=>{o.name=(NAMES[o.type]||o.type)+" "+(i+1);}),"Semua layer diberi nama"),"layers")]},
 {h:"Urutan",items:[it("Balik urutan semua layer",()=>re(()=>S.objects.reverse()),"redo"),it("Urutkan: besar di belakang",()=>re(()=>S.objects.sort((a,b)=>b.w*b.h-a.w*a.h)),"layers"),it("Urutkan: atas ke bawah",()=>re(()=>S.objects.sort((a,b)=>b.y-a.y)),"layers")]},
 {h:"Pilih & kunci",items:[it("Pilih seluruh grup",()=>{const a=sels()[0];if(!a||!a.groupId)return T("Objek ini tidak dalam grup");pick(S.objects.filter(o=>o.groupId===a.groupId));},"group"),it("Kunci yang tidak dipilih",()=>{const s=new Set(sels().map(o=>o.id));if(!s.size)return T("Pilih objek dulu");re(()=>S.objects.forEach(o=>{if(!s.has(o.id))o.locked=true;}),"Objek lain dikunci");},"lock"),it("Hapus objek tersembunyi",()=>{const n=S.objects.filter(o=>o.hidden).length;if(!n)return T("Tidak ada objek tersembunyi");re(()=>{S.objects=S.objects.filter(o=>!o.hidden);S.selected=null;S.selectedIds=[];},n+" objek dihapus");},"trash")]}];

/* ---- mockup ---- */
const phone=()=>{const w=Math.round(W()*.28),h=w*2,x=Math.round((W()-w)/2),y=Math.round((H()-h)/2),p=Math.round(w*.04);grp([{type:"rect",name:"Bodi ponsel",x,y,w,h,rx:w*.14,fill:"#111827",stroke:"#4b5563",strokeWidth:4},{type:"rect",name:"Layar",x:x+p,y:y+p*1.6,w:w-2*p,h:h-p*3.2,rx:w*.1,fill:"#e9edf7"},{type:"rect",name:"Notch",x:Math.round(x+w*.35),y:y+Math.round(p*.7),w:Math.round(w*.3),h:Math.round(w*.05),rx:12,fill:"#111827"}]);};
const browser=()=>{const w=Math.round(W()*.7),h=Math.round(w*.6),x=Math.round((W()-w)/2),y=Math.round((H()-h)/2),b=Math.round(h*.1),d=Math.round(b*.28);grp([{type:"rect",name:"Jendela",x,y,w,h,rx:16,fill:"#ffffff",stroke:"#d9deea",strokeWidth:3,fx:"shadow",fxAmount:20},{type:"rect",name:"Bilah atas",x,y,w,h:b,rx:16,fill:"#eef1f7"},{type:"ellipse",name:"Titik 1",x:x+d,y:y+Math.round((b-d)/2),w:d,h:d,fill:"#ff6b6b"},{type:"ellipse",name:"Titik 2",x:x+d*2.6,y:y+Math.round((b-d)/2),w:d,h:d,fill:"#ffc857"},{type:"ellipse",name:"Titik 3",x:x+d*4.2,y:y+Math.round((b-d)/2),w:d,h:d,fill:"#3ddc84"},{type:"rect",name:"Kolom URL",x:Math.round(x+d*6),y:Math.round(y+b*.2),w:Math.round(w-d*7),h:Math.round(b*.6),rx:b*.3,fill:"#ffffff",stroke:"#d9deea",strokeWidth:2}]);};
const sticky=()=>{const w=Math.round(W()*.3),x=Math.round((W()-w)/2),y=Math.round((H()-w)/2);grp([{type:"rect",name:"Kertas",x,y,w,h:w,rx:6,fill:"#ffe66d",fx:"shadow",fxAmount:16},txt("Catatan:\nTulis di sini",x+w*.1,y+w*.1,w*.09,"#5a4b00")]);};
const ribbon=()=>{const w=Math.round(W()*.5),h=Math.round(w*.24),r={type:"path",name:"Pita",x:Math.round((W()-w)/2),y:Math.round((H()-h)/2),w,h,vw:100,vh:100,d:"M0 10H100L92 50L100 90H0L8 50Z",fill:"#ff4f6d"},t=txt("PROMO",0,0,h*.4,"#ffffff",{bold:true});grp([r,t],()=>mid(t,r));};
const ticket=()=>{const w=Math.round(W()*.5),h=Math.round(w*.4),x=Math.round((W()-w)/2),y=Math.round((H()-h)/2),d=Math.round(h*.22),r={type:"rect",name:"Tiket",x,y,w,h,rx:18,fill:"#6d5dfc"},t=txt("TIKET",0,0,h*.3,"#ffffff",{bold:true});grp([r,{type:"ellipse",name:"Lubang kiri",x:Math.round(x-d/2),y:Math.round(y+h/2-d/2),w:d,h:d,fill:bgc()},{type:"ellipse",name:"Lubang kanan",x:Math.round(x+w-d/2),y:Math.round(y+h/2-d/2),w:d,h:d,fill:bgc()},{type:"line",name:"Garis sobek",x:Math.round(x+w*.72),y:Math.round(y+h*.1),w:0,h:Math.round(h*.8),stroke:"#ffffff",strokeWidth:3,dash:"4 3",fill:"none"},t],()=>{t.x=Math.round(x+(w*.72-t.w)/2);t.y=Math.round(y+(h-t.h)/2);});};
const chat=()=>{const w=Math.round(W()*.4),h=Math.round(w*.7),r={type:"path",name:"Bubble",x:Math.round((W()-w)/2),y:Math.round((H()-h)/2),w,h,vw:100,vh:100,d:"M10 14H90V66H48L26 88V66H10Z",fill:"#6d5dfc"},t=txt("Halo!",0,0,h*.2,"#ffffff",{bold:true});grp([r,t],()=>{t.x=Math.round(r.x+(r.w-t.w)/2);t.y=Math.round(r.y+(r.h*.5-t.h)/2);});};
MENUS.mock=()=>[{h:"Bingkai & komponen",items:[it("Ponsel",phone,"rect"),it("Jendela browser",browser,"rect"),it("Catatan tempel",sticky,"rect"),it("Pita promo",ribbon,"rect"),it("Tiket",ticket,"rect"),it("Chat bubble",chat,"rect")]}];

/* ---- preset teks ---- */
const STY=[["Judul tebal",{bold:true,fontFamily:"Impact, 'Arial Black', sans-serif",fill:"#111111",k:.12}],["Subjudul",{fontFamily:"Arial, sans-serif",fill:"#68728a",k:.05}],["Caption kecil",{fontFamily:"Arial, sans-serif",fill:"#8a93aa",k:.03}],["Elegan serif",{fontFamily:"Georgia, serif",italic:true,fill:"#3a2d5c",k:.07}],["Mono kode",{fontFamily:"'Courier New', monospace",bold:true,fill:"#00b8c9",k:.045}],["Neon",{fontFamily:"Arial, sans-serif",bold:true,fill:"#ffffff",k:.09,fx:"glow",fxColor:"#00d6c9",fxAmount:14}]];
function style(p){const{k,...r}=p,a=sels().filter(o=>o.type==="text"),sz=Math.round(W()*k),full={bold:false,italic:false,fx:"none",...r};Hi.snapshot();
 if(a.length)a.forEach(o=>Object.assign(o,full,{fontSize:sz}));
 else{const o={id:uid(),type:"text",name:"Teks gaya",text:"Teks gaya",x:Math.round(W()*.2),y:Math.round(H()*.4),w:200,h:60,fontSize:sz,stroke:"none",strokeWidth:0,opacity:100,rotation:0,...full};S.objects.push(o);pick([o]);o.x=Math.round((W()-o.w)/2);o.y=Math.round((H()-o.h)/2);}
 C.render();}
MENUS.tsty=()=>[{h:"Terapkan ke teks terpilih (atau buat teks baru)",items:STY.map(s=>it(s[0],()=>style(s[1]),"text"))}];

/* ---- tata ---- */
function arrange(fn,min,msg){const a=sels();if(a.length<min)return T(min>1?"Pilih "+min+" objek atau lebih":"Pilih objek dulu");Hi.snapshot();fn(a);C.render();if(msg)T(msg);}
const cen=o=>({x:o.x+o.w/2,y:o.y+(o.h||0)/2}),put=(o,x,y)=>{o.x=Math.round(x-o.w/2);o.y=Math.round(y-(o.h||0)/2);};
MENUS.tata=()=>[
 {h:"Susun otomatis",items:[it("Susun melingkar",()=>arrange(a=>{const r=Math.min(W(),H())*.3;a.forEach((o,i)=>{const t=2*Math.PI*i/a.length-Math.PI/2;put(o,W()/2+r*Math.cos(t),H()/2+r*Math.sin(t));});},2),"redo"),
  it("Susun grid rapi",()=>arrange(a=>{const c=Math.ceil(Math.sqrt(a.length)),r=Math.ceil(a.length/c),cw=Math.max(...a.map(o=>o.w))*1.15,ch=Math.max(...a.map(o=>o.h||0))*1.15,x0=W()/2-cw*c/2+cw/2,y0=H()/2-ch*r/2+ch/2;a.forEach((o,i)=>put(o,x0+(i%c)*cw,y0+Math.floor(i/c)*ch));},2),"dup"),
  it("Susun tangga",()=>arrange(a=>{const b=a[0];a.forEach((o,i)=>{o.x=Math.round(b.x+i*40);o.y=Math.round(b.y+i*40);});},2),"layers")]},
 {h:"Acak (kreatif)",items:[it("Acak posisi",()=>arrange(a=>a.forEach(o=>{o.x=Math.round(rnd(0,Math.max(1,W()-o.w)));o.y=Math.round(rnd(0,Math.max(1,H()-(o.h||0))));}),1),"multi"),
  it("Acak rotasi",()=>arrange(a=>a.forEach(o=>{o.rotation=Math.round(rnd(-45,45));}),1),"redo"),
  it("Acak ukuran",()=>arrange(a=>a.forEach(o=>{const f=rnd(.6,1.4),c=cen(o);o.w=Math.max(1,Math.round(o.w*f));o.h=Math.round((o.h||0)*f);if(o.fontSize)o.fontSize=Math.max(8,Math.round(o.fontSize*f));put(o,c.x,c.y);}),1),"plus")]}];

/* ---- pasang tombol ---- */
BT.push(["layer","layers","Layer"],["mock","mockup","Mockup"],["tsty","fontA","Preset"],["tata","layout","Tata"]);
const ti=CDMS.Tools.init;
CDMS.Tools.init=function(){ti.call(this);const tb=$(".editor-toolbar"),first=tb&&tb.querySelector("[data-menu]");
 if(tb&&first&&!tb.querySelector("[data-find]"))first.insertAdjacentHTML("beforebegin",`<button class="tool" data-find title="Cari fitur (Ctrl+K)">${CDMS.Icons.svg("search")}<span>Cari</span></button>`);};
})();
