/* V82: tab baru Ganti (cari & ganti teks, ubah huruf BESAR/kecil/Judul/Kalimat, awalan/akhiran, rapikan spasi, penomoran urut) dan Ukur (garis dimensi lebar/tinggi pilihan dengan label px, jarak antar dua objek) di panel Penata + tombol cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const uid=()=>crypto.randomUUID();
const val=(id,d)=>{const e=$("#"+id);return e&&e.value!==undefined&&e.value!==""?e.value:d;};
const chk=(id,d)=>{const e=$("#"+id);return e?e.checked:d;};
const base=(t,x,y,w,h,f)=>({id:uid(),type:t,name:t[0].toUpperCase()+t.slice(1),x:Math.round(x),y:Math.round(y),w:Math.max(1,Math.round(w)),h:Math.max(1,Math.round(h)),fill:f,stroke:"#20243a",strokeWidth:0,opacity:100,rotation:0});
const bbox=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y));return{x,y,w:Math.max(...a.map(o=>o.x+(o.w||0)))-x,h:Math.max(...a.map(o=>o.y+(o.h||0)))-y};};
function units(){const seen=new Map();M.sels().forEach(o=>{if(o.locked)return;const k=o.groupId||o.id;if(!seen.has(k))seen.set(k,o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]);});return [...seen.values()].map(m=>({m,r:bbox(m)}));}
function ukur(o){const est=Math.round((o.text||"").length*o.fontSize*(o.bold?.6:.56)+8);try{if(CDMS.PusatTeks){const w=CDMS.PusatTeks.ukur(o);if(w>0)return w;}}catch(e){}return est;}
/* ---- Ganti ---- */
function target(){const sel=M.sels();let a;
 if(chk("p82all",false)||!sel.length)a=S.objects.filter(o=>o.type==="text");
 else{const s=new Set();sel.forEach(o=>(o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]).forEach(p=>s.add(p)));a=[...s].filter(o=>o.type==="text");}
 return a.filter(o=>!o.locked);}
function ubah(fn,msg){const a=target();if(!a.length)return T("Tidak ada teks (pilih teks, atau centang Semua teks)");
 const ch=a.filter(o=>{const n=fn(o.text||"",o);return n!==(o.text||"");});if(!ch.length)return T("Tidak ada teks yang berubah");
 Hi.snapshot();ch.forEach(o=>{const cx=o.x+o.w/2;o.text=fn(o.text||"",o);const w=ukur(o);o.w=Math.round(w);o.x=Math.round(cx-w/2);});C.render();T(ch.length+" teks "+msg);}
const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
function ganti(){const f=val("p82a","");if(!f)return T("Isi teks yang dicari dulu");const t=val("p82b","");let n=0;const re=new RegExp(esc(f),chk("p82cs",false)?"g":"gi");
 n=target().reduce((c,o)=>c+((o.text||"").match(re)||[]).length,0);ubah(x=>x.replace(re,()=>t),"diperbarui");if(n)T(n+" kemunculan diganti");}
const judul=s=>s.toLowerCase().replace(/(^|[\s\-\/(])(\p{L})/gu,(m,a,c)=>a+c.toUpperCase());
const kalimat=s=>s.toLowerCase().replace(/(^|[.!?]\s+|\n)(\p{L})/gu,(m,a,c)=>a+c.toUpperCase());
function urutNomor(){const a=target().sort((p,q)=>(p.y-q.y)||(p.x-q.x));if(!a.length)return T("Pilih teks yang akan dinomori");
 const tpl=val("p82tp","Item {n}"),st=Math.round(num("p82st",1));Hi.snapshot();a.forEach((o,i)=>{const cx=o.x+o.w/2;o.text=tpl.includes("{n}")?tpl.replace(/\{n\}/g,st+i):tpl+" "+(st+i);const w=ukur(o);o.w=Math.round(w);o.x=Math.round(cx-w/2);});C.render();T(a.length+" teks dinomori dari "+st+" (atas ke bawah)");}
/* ---- Ukur ---- */
function lab(s,cx,y,fs,col){const o=base("text",0,y,10,Math.round(fs*1.3),col);o.text=s;o.fontSize=fs;o.bold=true;const w=ukur(o);o.w=Math.round(w);o.x=Math.round(cx-w/2);o.name="Label dimensi";return o;}
function gar(x,y,w,h,d,col,tw){const o=base("path",x,y,w,h,"none");o.d=d;o.vw=w;o.vh=h;o.stroke=col;o.strokeWidth=tw;o.name="Garis dimensi";return o;}
const opt=()=>({col:val("p82c","#ef4444"),tw:Math.max(1,num("p82t",3)),off:Math.max(0,num("p82o",30)),fs:Math.max(8,num("p82f",26))});
function dW(r,x0,x1,y,o){const w=Math.max(2,x1-x0);return[gar(x0,y-8,w,16,`M0 8H${w}M0 0V16M${w} 0V16`,o.col,o.tw),lab(Math.round(w)+" px",(x0+x1)/2,y+12,o.fs,o.col)];}
function dH(y0,y1,x,o){const h=Math.max(2,y1-y0),l=lab(Math.round(h)+" px",0,0,o.fs,o.col);l.x=Math.round(x+16);l.y=Math.round((y0+y1)/2-o.fs*.6);return[gar(x-8,y0,16,h,`M8 0V${h}M0 0H16M0 ${h}H16`,o.col,o.tw),l];}
function kirim(a,nm){const g=uid();a.forEach(o=>o.groupId=g);Hi.snapshot();S.objects.push(...a);pick(a);T(nm+" dibuat");}
function dimensi(mode){const m=M.sels();if(!m.length)return T("Pilih objek dulu");const exp=new Set();m.forEach(o=>(o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]).forEach(p=>exp.add(p)));const r=bbox([...exp]),o=opt(),a=[];
 if(mode!=="h")a.push(...dW(r,r.x,r.x+r.w,r.y+r.h+o.off,o));if(mode!=="w")a.push(...dH(r.y,r.y+r.h,r.x+r.w+o.off,o));
 kirim(a,mode==="w"?"Dimensi lebar":mode==="h"?"Dimensi tinggi":"Dimensi lebar & tinggi");}
function jarak(){const u=units();if(u.length<2)return T("Pilih 2 objek/grup");const A=u[0].r,B=u[1].r,o=opt();
 const gx=B.x>=A.x+A.w?B.x-(A.x+A.w):A.x>=B.x+B.w?A.x-(B.x+B.w):-1,gy=B.y>=A.y+A.h?B.y-(A.y+A.h):A.y>=B.y+B.h?A.y-(B.y+B.h):-1;
 if(gx<0&&gy<0)return T("Objek saling bertumpuk");
 if(gx>=gy){const L=A.x<B.x?A:B,R=A.x<B.x?B:A,y=Math.min(L.y+L.h,R.y+R.h)>Math.max(L.y,R.y)?(Math.max(L.y,R.y)+Math.min(L.y+L.h,R.y+R.h))/2:L.y+L.h/2;kirim(dW(L,L.x+L.w,R.x,y,o),"Dimensi jarak mendatar");}
 else{const U=A.y<B.y?A:B,D=A.y<B.y?B:A,x=Math.max(U.x,D.x)<Math.min(U.x+U.w,D.x+D.w)?(Math.max(U.x,D.x)+Math.min(U.x+U.w,D.x+D.w))/2:U.x+U.w/2;kirim(dH(U.y+U.h,D.y,x,o),"Dimensi jarak menurun");}}
const H={gnt:ganti,up:()=>ubah(s=>s.toUpperCase(),"diubah ke BESAR"),low:()=>ubah(s=>s.toLowerCase(),"diubah ke kecil"),ttl:()=>ubah(judul,"diubah ke Huruf Judul"),snt:()=>ubah(kalimat,"diubah ke huruf kalimat"),
 add:()=>{const p=val("p82pre",""),q=val("p82suf","");if(!p&&!q)return T("Isi awalan atau akhiran dulu");ubah(s=>p+s+q,"diberi awalan/akhiran");},
 trim:()=>ubah(s=>s.split("\n").map(l=>l.replace(/\s+/g," ").trim()).join("\n").trim(),"dirapikan"),num:urutNomor,
 dw:()=>dimensi("w"),dh:()=>dimensi("h"),dwh:()=>dimensi("wh"),dj:jarak};
const cb=(id,l,on)=>`<label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 6px"><input id="${id}" type="checkbox" ${on?"checked":""}> ${l}</label>`;
const tx=(id,l,v)=>`<label>${l}<input id="${id}" type="text" value="${v}"></label>`;
P.addTab("ganti","Ganti",`<div class="p69row">${tx("p82a","Cari","")}${tx("p82b","Ganti dengan","")}</div>${cb("p82cs","Peka huruf besar/kecil",false)}${cb("p82all","Semua teks di desain (bukan hanya pilihan)",false)}
 <div class="p69btns">${b("gnt","Cari & ganti")}${b("trim","Rapikan spasi")}</div>
 <div class="p69h" style="margin-top:12px">Ubah huruf</div><div class="p69btns c4">${b("up","BESAR")}${b("low","kecil")}${b("ttl","Judul")}${b("snt","Kalimat")}</div>
 <div class="p69h" style="margin-top:12px">Awalan / akhiran</div><div class="p69row">${tx("p82pre","Awalan","")}${tx("p82suf","Akhiran","")}</div><div class="p69btns">${b("add","Tambahkan")}</div>
 <div class="p69h" style="margin-top:12px">Penomoran urut (atas ke bawah)</div><div class="p69row">${tx("p82tp","Templat ({n} = nomor)","Item {n}")}${fld("p82st","Mulai dari",1)}</div><div class="p69btns">${b("num","Nomori teks terpilih")}</div>`,H);
P.addTab("ukur","Ukur",`<p class="muted">Buat garis dimensi bergaya gambar teknik di sekitar pilihan.</p>
 <div class="p69row" style="margin-top:8px">${fld("p82o","Jarak dari objek",30,'min="0"')}${fld("p82t","Tebal garis",3,'min="1"')}${fld("p82f","Ukuran huruf",26,'min="8"')}<label>Warna<input id="p82c" type="color" value="#ef4444"></label></div>
 <div class="p69btns c3">${b("dw","Lebar")}${b("dh","Tinggi")}${b("dwh","Keduanya")}</div>
 <div class="p69btns" style="margin-top:8px">${b("dj","Jarak antar 2 objek")}</div><p class="muted" style="margin-top:8px">Jarak antar objek memakai 2 objek/grup yang dipilih pertama dan kedua.</p>`,H);
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q12="ganti" title="Cari & ganti teks">${ic("text")}</button><button data-q12="besar" title="BESAR / kecil (teks)">${ic("props")}</button><button data-q12="dimensi" title="Dimensi pilihan">${ic("tall")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q12]");if(!x)return;const k=x.dataset.q12;
  if(k==="ganti")P.openTab("ganti");
  else if(k==="besar"){const a=target();if(!a.length)return T("Pilih teks dulu");const up=!a.every(o=>(o.text||"")===(o.text||"").toUpperCase());ubah(s=>up?s.toUpperCase():s.toLowerCase(),up?"diubah ke BESAR":"diubah ke kecil");}
  else dimensi("wh");});}
MENUS.penata82=()=>[{h:"Tab Penata",items:[it("Ganti (cari, huruf, nomor)",()=>P.openTab("ganti"),"text"),it("Ukur (dimensi, jarak)",()=>P.openTab("ukur"),"tall")]},{h:"Cepat",items:[it("Huruf BESAR",H.up,"text"),it("Huruf Judul",H.ttl,"text"),it("Dimensi lebar & tinggi",()=>dimensi("wh"),"tall"),it("Jarak antar 2 objek",jarak,"wide")]}];
BT.push(["penata82","panel","Penata 13"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata82");
})();
