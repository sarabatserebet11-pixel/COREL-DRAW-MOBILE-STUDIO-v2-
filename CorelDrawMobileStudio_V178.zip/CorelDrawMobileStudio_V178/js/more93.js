/* V105: dua grup menu baru (helper bersama dari CDMS.Util97, tanpa kode duplikat).
   "Ilustrasi" (ikon art105): Wajah (5 ekspresi), Robot (maskot dari bentuk dasar), Cuaca (cerah, berawan, hujan, salju, malam).
   "Alat Desain" (ikon tools105): Penggaris (skala piksel, mendatar / menurun), Barcode (batang dekoratif dari teks), Swatch (deretan warna palet + kode hex).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U||!U.kartu||!U.kontras||!U.mkPal||!U.toHex)return;
const{ramp,grup,shape,text,line,path,finish,defHub,W,H,poly,ask,idx,tx,clamp,mkPal,kontras,parse,toHex,chips,kartu,mix}=U,R=Math.round;
const PL=mkPal("pal105","senja"),pal=PL.pal,palMenu=PL.menu,pc=(P,t)=>ramp(P.c.slice(1),t);
/* garis lurus bebas arah (objek line hanya menggambar dari kiri-atas ke kanan-bawah) */
const seg=(x1,y1,x2,y2,col,sw,name)=>{const x=Math.min(x1,x2),y=Math.min(y1,y2),w=Math.max(1,R(Math.abs(x2-x1))),h=Math.max(1,R(Math.abs(y2-y1)));
 return path(x,y,w,h,w,h,"M"+R(x1-x)+" "+R(y1-y)+"L"+R(x2-x)+" "+R(y2-y),"none",col,sw,{name});};

/* ================= ILUSTRASI ================= */
const WJ=[["Senyum","s"],["Tertawa","t"],["Sedih","d"],["Kaget","k"],["Kedip","e"]],WC=[["Kuning","#fbbf24"],["Oranye","#fb923c"],["Hijau","#4ade80"],["Biru","#60a5fa"]],WS=[["Kecil",.14],["Sedang",.22],["Besar",.34]];
function wajah(){const w=W(),h=H(),ex=S.wjE105||"s",col=WC[S.wjC105||0][1],r=Math.min(w,h)*WS[S.wjS105??1][1],cx=w/2,cy=h/2,dk="#1f2937",sw=Math.max(3,R(r*.07));Hi.snapshot();
 const out=[shape("ellipse",cx-r,cy-r,r*2,r*2,col,{name:"Wajah",stroke:mix(col,"#000000",.3),strokeWidth:Math.max(3,R(r*.05))})],ey=cy-r*.2,e1=cx-r*.35,e2=cx+r*.35,er=r*.09;
 if(ex!=="d"&&ex!=="k")[-1,1].forEach(k=>out.push(shape("ellipse",cx+k*r*.62-r*.11,cy+r*.12,r*.22,r*.14,"#f472b6",{name:"Pipi",opacity:40})));
 if(ex==="k")[e1,e2].forEach((x,i)=>out.push(shape("ellipse",x-r*.17,ey-r*.2,r*.34,r*.4,"#ffffff",{name:"Mata "+(i+1),stroke:dk,strokeWidth:Math.max(2,R(r*.04))}),shape("ellipse",x-r*.06,ey-r*.06,r*.12,r*.12,dk,{name:"Pupil "+(i+1)})));
 else{out.push(shape("ellipse",e1-er,ey-er*1.4,er*2,er*2.8,dk,{name:"Mata 1"}));
  out.push(ex==="e"?line(e2-r*.12,ey,r*.24,0,dk,sw,{name:"Mata kedip"}):shape("ellipse",e2-er,ey-er*1.4,er*2,er*2.8,dk,{name:"Mata 2"}));}
 const w2=R(r),h2=R(r*.5),mx=cx-w2/2,my=cy+r*.2,mp=(d,fill,stroke)=>path(mx,my,w2,h2,w2,h2,d,fill,stroke,fill==="none"?sw:0,{name:"Mulut"});
 if(ex==="k")out.push(shape("ellipse",cx-r*.12,cy+r*.25,r*.24,r*.34,dk,{name:"Mulut"}));
 else if(ex==="t")out.push(mp("M0 0L"+w2+" 0Q"+R(w2/2)+" "+R(h2*1.9)+" 0 0Z","#7f1d1d","none"));
 else if(ex==="d")out.push(mp("M0 "+R(h2*.8)+"Q"+R(w2/2)+" "+R(-h2*.6)+" "+w2+" "+R(h2*.8),"none",dk));
 else out.push(mp("M0 "+R(h2*.1)+"Q"+R(w2/2)+" "+R(h2*1.5)+" "+w2+" "+R(h2*.1),"none",dk));
 finish(grup(out,"Wajah"),"Wajah "+WJ.find(x=>x[1]===ex)[0].toLowerCase()+" dipasang");}
MENUS.wjh105=()=>[{h:"Ekspresi",items:WJ.map(x=>tc(x[0],()=>{S.wjE105=x[1];},{keep:1,on:(S.wjE105||"s")===x[1]}))},idx("Warna",WC,"wjC105",0),idx("Ukuran",WS,"wjS105",1),{h:"Buat",items:[it("Pasang wajah di tengah halaman",wajah,"face105")]}];

const RC=[["Biru","#3b82f6"],["Hijau","#22c55e"],["Merah","#ef4444"],["Abu","#9ca3af"]],RS=[["Kecil",.6],["Sedang",.8],["Besar",1]];
function robot(){const w=W(),h=H(),col=RC[S.rbC105||0][1],dk=mix(col,"#000000",.35),lt=mix(col,"#ffffff",.45),u=Math.min(h*.9/1.6,w*.8/1.1)*RS[S.rbS105??1][1],cx=w/2,top=(h-u*1.6)/2,sw=Math.max(2,R(u*.025)),st={stroke:dk,strokeWidth:sw};Hi.snapshot();
 const hy=top+u*.14,hh=u*.5,hw=u*.7,by=hy+hh+u*.06,bh=u*.6,bw=u*.8,ay=by+bh*.05,lg=by+bh;
 const out=[line(cx,top+u*.04,0,u*.1,dk,Math.max(3,sw*1.5),{name:"Antena"}),shape("ellipse",cx-u*.05,top-u*.01,u*.1,u*.1,"#ef4444",{name:"Bola antena"}),
  shape("rect",cx-hw/2-u*.05,hy+hh*.3,u*.05,hh*.4,dk,{name:"Telinga kiri",rx:2}),shape("rect",cx+hw/2,hy+hh*.3,u*.05,hh*.4,dk,{name:"Telinga kanan",rx:2}),shape("rect",cx-u*.06,hy+hh,u*.12,u*.08,dk,{name:"Leher"}),
  shape("rect",cx-u*.28,lg,u*.18,u*.3,col,{name:"Kaki kiri",rx:R(u*.05),...st}),shape("rect",cx+u*.1,lg,u*.18,u*.3,col,{name:"Kaki kanan",rx:R(u*.05),...st}),
  shape("rect",cx-u*.32,lg+u*.24,u*.26,u*.08,dk,{name:"Telapak kiri",rx:R(u*.03)}),shape("rect",cx+u*.06,lg+u*.24,u*.26,u*.08,dk,{name:"Telapak kanan",rx:R(u*.03)}),
  shape("rect",cx-bw/2-u*.16,ay,u*.12,u*.45,col,{name:"Lengan kiri",rx:R(u*.06),...st}),shape("rect",cx+bw/2+u*.04,ay,u*.12,u*.45,col,{name:"Lengan kanan",rx:R(u*.06),...st}),
  shape("ellipse",cx-bw/2-u*.17,ay+u*.4,u*.14,u*.14,lt,{name:"Tangan kiri",...st}),shape("ellipse",cx+bw/2+u*.03,ay+u*.4,u*.14,u*.14,lt,{name:"Tangan kanan",...st}),
  shape("rect",cx-bw/2,by,bw,bh,col,{name:"Badan",rx:R(u*.1),...st}),shape("rect",cx-u*.2,by+bh*.25,u*.4,bh*.4,lt,{name:"Panel",rx:R(u*.05)}),
  shape("ellipse",cx-u*.1,by+bh*.38,u*.07,u*.07,"#ef4444",{name:"Lampu 1"}),shape("ellipse",cx+u*.03,by+bh*.38,u*.07,u*.07,"#22c55e",{name:"Lampu 2"}),
  shape("rect",cx-hw/2,hy,hw,hh,col,{name:"Kepala",rx:R(u*.1),...st})];
 [-1,1].forEach((k,i)=>out.push(shape("ellipse",cx+k*u*.16-u*.075,hy+hh*.22,u*.15,u*.15,"#ffffff",{name:"Mata "+(i+1),stroke:dk,strokeWidth:sw}),shape("ellipse",cx+k*u*.16-u*.03,hy+hh*.22+u*.045,u*.06,u*.06,dk,{name:"Pupil "+(i+1)})));
 out.push(shape("rect",cx-u*.15,hy+hh*.65,u*.3,u*.07,dk,{name:"Mulut",rx:3}));for(let i=1;i<4;i++)out.push(line(cx-u*.15+i*u*.075,hy+hh*.65,0,u*.07,lt,Math.max(1,R(sw*.6)),{name:"Gigi "+i}));
 finish(grup(out,"Robot"),"Robot "+RC[S.rbC105||0][0].toLowerCase()+" dipasang");}
MENUS.rbt105=()=>[idx("Warna",RC,"rbC105",0),idx("Ukuran",RS,"rbS105",1),{h:"Buat",items:[it("Pasang robot di tengah halaman",robot,"robot105")]}];

const CU=[["Cerah","c"],["Berawan","b"],["Hujan","h"],["Salju","s"],["Malam","m"]],CZ=[["Kecil",.2],["Sedang",.3],["Besar",.4]],SKY={c:"#bfdbfe",b:"#dbeafe",h:"#94a3b8",s:"#e0f2fe",m:"#0f172a"};
function cuaca(){const w=W(),h=H(),st=S.cuG105||"c",s=Math.min(w,h)*CZ[S.cuZ105??1][1],cx=w/2,cy=h/2;Hi.snapshot();
 const awan=(x,y,k,col)=>[shape("rect",x-k,y-k*.1,k*2,k*.7,col,{name:"Awan dasar",rx:R(k*.35)}),shape("ellipse",x-k*.8,y-k*.6,k*.8,k*.8,col,{name:"Awan 1"}),shape("ellipse",x-k*.4,y-k*.9,k*1.1,k*1.1,col,{name:"Awan 2"})];
 const mat=(x,y,r)=>{const a=[shape("ellipse",x-r,y-r,r*2,r*2,"#fbbf24",{name:"Matahari"})];for(let i=0;i<12;i++){const an=i*Math.PI/6,c=Math.cos(an),n=Math.sin(an);a.push(seg(x+c*r*1.3,y+n*r*1.3,x+c*r*1.75,y+n*r*1.75,"#f59e0b",Math.max(3,R(r*.14)),"Sinar "+(i+1)));}return a;};
 const out=[];if(S.cuL105!=="n")out.push(shape("rect",cx-s*1.7,cy-s*1.5,s*3.4,s*3,SKY[st],{name:"Langit",rx:R(s*.25)}));
 if(st==="c")out.push(...mat(cx,cy,s*.6));
 else if(st==="b")out.push(...mat(cx+s*.45,cy-s*.45,s*.4),...awan(cx-s*.1,cy+s*.2,s*.9,"#ffffff"));
 else if(st==="h"){out.push(...awan(cx,cy-s*.3,s,"#6b7280"));for(let i=0;i<7;i++){const x=cx-s*.8+i*s*.27,y=cy+s*.5+(i%2)*s*.2;out.push(line(x,y,s*.1,s*.35,"#3b82f6",Math.max(3,R(s*.07)),{name:"Hujan "+(i+1)}));}}
 else if(st==="s"){out.push(...awan(cx,cy-s*.3,s,"#cbd5e1"));for(let i=0;i<7;i++){const x=cx-s*.75+i*s*.25,y=cy+s*.55+(i%2)*s*.25,d=s*.16;out.push(shape("ellipse",x-d/2,y-d/2,d,d,"#ffffff",{name:"Salju "+(i+1),stroke:"#93c5fd",strokeWidth:2}));}}
 else{out.push(shape("ellipse",cx-s*.7,cy-s*.7,s*1.4,s*1.4,"#fde68a",{name:"Bulan"}));[[-.25,-.2,.3],[.2,.15,.22],[-.1,.35,.15]].forEach((c,i)=>out.push(shape("ellipse",cx+c[0]*s-c[2]*s/2,cy+c[1]*s-c[2]*s/2,c[2]*s,c[2]*s,"#fcd34d",{name:"Kawah "+(i+1),opacity:70})));
  [[-1.3,-1.1,.12],[1.2,-1.0,.1],[-1.1,.9,.1],[1.3,.8,.14],[.9,-1.25,.08],[-.7,-1.25,.09]].forEach((c,i)=>{const x=cx+c[0]*s,y=cy+c[1]*s,d=c[2]*s;out.push(poly([[x,y-d*2],[x+d*.5,y-d*.5],[x+d*2,y],[x+d*.5,y+d*.5],[x,y+d*2],[x-d*.5,y+d*.5],[x-d*2,y],[x-d*.5,y-d*.5]],"#fef9c3","Bintang "+(i+1)));});}
 finish(grup(out,"Cuaca"),"Cuaca "+CU.find(x=>x[1]===st)[0].toLowerCase()+" dipasang");}
MENUS.cua105=()=>[{h:"Cuaca",items:CU.map(x=>tc(x[0],()=>{S.cuG105=x[1];},{keep:1,on:(S.cuG105||"c")===x[1]}))},idx("Ukuran",CZ,"cuZ105",1),{h:"Langit",items:[["Dengan latar","y"],["Tanpa latar","n"]].map(x=>tc(x[0],()=>{S.cuL105=x[1];},{keep:1,on:(S.cuL105||"y")===x[1]}))},{h:"Buat",items:[it("Pasang cuaca di tengah halaman",cuaca,"weather105")]}];

/* ================= ALAT DESAIN ================= */
const GW=[["Kuning","#fde047"],["Kayu","#e6c27a"],["Biru muda","#bfdbfe"]];
function penggaris(){const w=W(),h=H(),hor=(S.pgO105||"h")==="h",len=hor?w:h,st0=S.pgS105||20,st=Math.max(st0,Math.ceil(len/160)),th=clamp(Math.min(w,h)*.06,28,70),col=GW[S.pgW105||0][1],fs=R(clamp(th*.28,7,22)),n=Math.floor(len/st),out=[];Hi.snapshot();
 const pos=hor?[0,h*.04]:[w*.04,0];
 out.push(shape("rect",pos[0],pos[1],hor?len:th,hor?th:len,col,{name:"Penggaris",stroke:"#92400e",strokeWidth:2}));
 for(let i=0;i<=n;i++){const d=i*st,big=i%5===0,tl=th*(big?.42:.22),sw=big?3:2;
  out.push(hor?line(d,pos[1],0,tl,"#7c2d12",sw,{name:"Skala "+d}):line(pos[0],d,tl,0,"#7c2d12",sw,{name:"Skala "+d}));
  if(big&&i)out.push(hor?tx(String(d),d,pos[1]+tl+fs*.3,fs,"#7c2d12",{name:"Angka "+d}):text(String(d),pos[0]+tl+fs*.4,d-fs*.6,fs,"#7c2d12",{name:"Angka "+d}));}
 finish(grup(out,"Penggaris"),"Penggaris "+(hor?"mendatar":"menurun")+" (skala "+st+" px)");}
MENUS.pgr105=()=>[{h:"Arah",items:[["Mendatar","h"],["Menurun","v"]].map(x=>tc(x[0],()=>{S.pgO105=x[1];},{keep:1,on:(S.pgO105||"h")===x[1]}))},chips("Jarak tanda (px)",[10,20,50],"pgS105",20),idx("Warna",GW,"pgW105",0),{h:"Buat",items:[it("Pasang penggaris di tepi halaman",penggaris,"ruler105")]}];

const BK=[["Hitam","#111827"],["Biru tua","#1e3a8a"],["Hijau tua","#14532d"]];
function barcode(){const q=ask("Teks barcode (maks 16 huruf/angka):","CDMS-0105");if(q===null)return;const t=q.trim().slice(0,16);if(!t)return T("Teks kosong");Hi.snapshot();
 const w=W(),h=H(),col=BK[S.bkC105||0][1];let bits="101";
 for(let i=0;i<t.length;i++){const v=(t.charCodeAt(i)*131+i*17+7)&255;bits+=v.toString(2).padStart(8,"0")+"0";}bits+="101";
 const runs=[];for(let i=0;i<bits.length;){let j=i;while(j<bits.length&&bits[j]===bits[i])j++;if(bits[i]==="1")runs.push([i,j-i]);i=j;}
 const cw=Math.min(w*.8,h*.6*1.8),ch=cw*.55,x=(w-cw)/2,y=(h-ch)/2,pd=cw*.06,u=(cw-2*pd)/bits.length,fs=R(clamp(cw*.07,8,32)),out=[kartu(x,y,cw,ch,cw*.03)];
 runs.forEach((r,i)=>out.push(shape("rect",x+pd+r[0]*u,y+pd,r[1]*u,ch-2*pd-fs*1.6,col,{name:"Batang "+(i+1)})));
 out.push(tx(t,x+cw/2,y+ch-pd-fs*1.1,fs,col,{name:"Teks barcode",bold:true}));
 finish(grup(out,"Barcode"),"Barcode dekoratif dipasang");}
MENUS.brk105=()=>[idx("Warna",BK,"bkC105",0),{h:"Buat",items:[it("Buat barcode dekoratif…",barcode,"barcode105")]}];

const hx=c=>{const p=parse(c);return p?toHex(p).toUpperCase():String(c);};
function swatch(){const P=pal(),w=W(),h=H(),n=S.swN105||5,bulat=(S.swG105||"k")==="b",sz=Math.min(w*.88/n,h*.5),gap=sz*.08,tot=n*sz+(n-1)*gap,cw=tot+sz*.5,fs=R(clamp(sz*.14,7,24)),ch=sz+fs*3.2+sz*.4,x0=(w-tot)/2,y0=(h-sz-fs*2.2)/2,out=[kartu((w-cw)/2,(h-ch)/2,cw,ch,sz*.12)];Hi.snapshot();
 for(let i=0;i<n;i++){const c=pc(P,n>1?i/(n-1):0),x=x0+i*(sz+gap);
  out.push(shape(bulat?"ellipse":"rect",x,y0,sz,sz,c,{name:"Warna "+(i+1),...(bulat?{}:{rx:R(sz*.1)})}),tx(hx(c),x+sz/2,y0+sz+fs*.8,fs,"#374151",{name:"Kode "+(i+1),bold:true}));}
 finish(grup(out,"Swatch"),n+" warna palet "+P.n);}
MENUS.swa105=()=>[palMenu(),chips("Jumlah warna",[3,5,7],"swN105",5),{h:"Bentuk",items:[["Kotak","k"],["Bulat","b"]].map(x=>tc(x[0],()=>{S.swG105=x[1];},{keep:1,on:(S.swG105||"k")===x[1]}))},{h:"Buat",items:[it("Buat deretan warna + kode hex",swatch,"swatch105")]}];

/* ================= tombol & grup ================= */
BT.push(["wjh105","face105","Wajah"],["rbt105","robot105","Robot"],["cua105","weather105","Cuaca"],["pgr105","ruler105","Penggaris"],["brk105","barcode105","Barcode"],["swa105","swatch105","Swatch"]);
defHub("ilustrasi105","art105","Ilustrasi",["wjh105","rbt105","cua105"]);
defHub("alat105","tools105","Alat Desain",["pgr105","brk105","swa105"]);
CDMS.Ilustrasi105={wajah,robot,cuaca,penggaris,barcode,swatch};
Object.assign(U,{seg});
})();
