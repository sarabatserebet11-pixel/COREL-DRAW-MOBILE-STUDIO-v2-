/* V58: menu Logo (monogram/logo dari nama, 8 gaya) dan Papan (Gantt, Kanban, peta pikiran, SWOT, bagan organisasi, Venn) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,N=CDMS.Navigation,{MENUS,BT,it,T}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,STAR,AC,INK,MUTE,LINE}=K;
const $=s=>document.querySelector(s);
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const WHT="#ffffff";
/* ---------- Logo ---------- */
const SHIELD="M50 2L92 16V50C92 74 74 92 50 98C26 92 8 74 8 50V16Z",HEX="M50 2L93 26V74L50 98L7 74V26Z";
function inisial(n){const w=String(n).trim().split(/\s+/).filter(Boolean);if(!w.length)return"CD";return(w.length>1?w[0][0]+w[1][0]:w[0].slice(0,2)).toUpperCase();}
const nfs=(t,maxw,maxfs)=>Math.max(16,Math.min(maxfs,Math.floor(maxw/(Math.max(1,t.length)*.6))));
const LG=[
 ["Lingkaran",(n,i,c)=>({w:300,h:360,a:[E(0,0,300,300,c,{name:"Logo"}),E(14,14,272,272,"none",{stroke:WHT,strokeWidth:4,opacity:70}),X(i,150,150,120,WHT,{bold:1}),X(n.toUpperCase(),150,336,nfs(n,300,30),INK,{bold:1})]})],
 ["Kotak bulat",(n,i,c)=>({w:300,h:360,a:[R(0,0,300,300,c,{rx:72,name:"Logo"}),X(i,150,150,120,WHT,{bold:1}),X(n.toUpperCase(),150,336,nfs(n,300,30),INK,{bold:1})]})],
 ["Perisai",(n,i,c)=>({w:300,h:360,a:[P(20,0,260,300,SHIELD,c,{name:"Logo"}),X(i,150,140,110,WHT,{bold:1}),X(n.toUpperCase(),150,336,nfs(n,300,30),INK,{bold:1})]})],
 ["Heksagon",(n,i,c)=>({w:300,h:360,a:[P(0,0,300,300,HEX,c,{name:"Logo"}),X(i,150,150,110,WHT,{bold:1}),X(n.toUpperCase(),150,336,nfs(n,300,30),INK,{bold:1})]})],
 ["Cincin ganda",(n,i,c)=>({w:300,h:360,a:[E(5,5,290,290,"none",{stroke:c,strokeWidth:10,name:"Logo"}),E(30,30,240,240,"none",{stroke:c,strokeWidth:3}),X(i,150,150,110,c,{bold:1}),X(n.toUpperCase(),150,336,nfs(n,300,30),INK,{bold:1})]})],
 ["Bintang",(n,i,c)=>({w:300,h:360,a:[P(0,0,300,300,STAR,c,{name:"Logo"}),X(i,150,176,84,WHT,{bold:1}),X(n.toUpperCase(),150,336,nfs(n,300,30),INK,{bold:1})]})],
 ["Horizontal",(n,i,c)=>({w:560,h:160,a:[R(0,0,160,160,c,{rx:40,name:"Logo"}),X(i,80,80,72,WHT,{bold:1}),X(n,190,64,nfs(n,360,46),INK,{left:1,bold:1}),X("Tagline singkat di sini",190,114,24,MUTE,{left:1})]})],
 ["Tumpuk",(n,i,c)=>({w:420,h:300,a:[X(i,210,90,130,c,{bold:1,name:"Logo"}),R(60,170,300,6,c,{rx:3}),X(n.toUpperCase(),210,224,nfs(n,420,36),INK,{bold:1}),X("EST. 2026",210,272,20,MUTE)]})]
];
let cur=null;
COMP["Logo"]=()=>cur;
function dlg(){N.openModal("Buat logo",`<div class="st-pane"><div class="st-grid"><label>Nama merek<input id="lgN" type="text" value="Kopi Senja" maxlength="30"></label><label>Gaya<select id="lgS">${LG.map((g,i)=>`<option value="${i}">${g[0]}</option>`).join("")}</select></label><label>Warna<input id="lgC" type="color" value="${AC}"></label></div><button class="btn primary" id="aOk">Buat logo</button></div>`);
 $("#aOk").onclick=()=>{const n=($("#lgN").value||"").trim()||"Merek",g=LG[+$("#lgS").value]||LG[0],c=$("#lgC").value||AC;N.closeModal();cur=g[1](n,inisial(n),c);place("Logo");T("Logo "+g[0]+" ditambahkan");};}
MENUS.logo=()=>[
 {h:"Logo dari nama",items:[it("Buat logo…",dlg,"star")]},
 {h:"Pilih gaya (nama contoh)",items:LG.map(g=>it(g[0],()=>{cur=g[1]("Kopi Senja","KS",AC);place("Logo");T("Logo "+g[0]+" ditambahkan");},"star"))}];
BT.push(["logo","emblem","Logo"]);
hubAdd("pustaka","logo");
/* ---------- Papan ---------- */
const COLS=["#6d5dfc","#00a6d6","#00c9a7","#ffb020"];
const GT=[["Riset",0,2],["Desain",1,2.5],["Produksi",2.5,2.5],["Peluncuran",4.5,1.5]];
const KB=[["Rencana","#6d5dfc",["Riset pasar","Susun anggaran","Buat jadwal"]],["Proses","#ffb020",["Desain logo","Tulis konten"]],["Selesai","#00c9a7",["Brief klien","Survei awal"]]];
const SW=[["Kekuatan","S",0,0,"#dcfce7","#15803d"],["Kelemahan","W",290,0,"#fee2e2","#b91c1c"],["Peluang","O",0,260,"#dbeafe","#1d4ed8"],["Ancaman","T",290,260,"#fef3c7","#b45309"]];
const node=(x,y,w,h,t,fill,col)=>[R(x,y,w,h,fill,{rx:h/2,name:t}),X(t,x+w/2,y+h/2,22,col,{bold:1})];
Object.assign(COMP,{
 "Gantt 4 tugas":()=>({w:640,h:300,a:[...[0,1,2,3,4,5].flatMap(c=>[R(160+c*80,40,80,250,c%2?"#f6f7fc":"#ffffff",{name:"Minggu "+(c+1)}),X("M"+(c+1),200+c*80,20,20,MUTE,{bold:1})]),...GT.flatMap((g,i)=>{const y=60+i*60;return [X(g[0],0,y+22,22,INK,{left:1,bold:1}),R(160+g[1]*80,y+4,g[2]*80,36,COLS[i],{rx:18,name:"Tugas "+g[0]})];})]}),
 "Kanban 3 kolom":()=>({w:670,h:430,a:KB.flatMap((k,i)=>{const x=i*230;return [R(x,0,210,430,"#f1f3fa",{rx:24,name:k[0]}),R(x+16,16,178,44,k[1],{rx:22}),X(k[0],x+105,38,24,WHT,{bold:1}),...k[2].flatMap((t,j)=>[R(x+16,76+j*110,178,96,WHT,{rx:16,stroke:"#00000014",strokeWidth:2}),X(t,x+32,124+j*110,22,INK,{left:1,bold:1})])];})}),
 "Peta pikiran":()=>({w:640,h:420,a:[R(318,64,4,86,LINE),R(318,270,4,86,LINE),R(160,208,80,4,LINE),R(400,208,80,4,LINE),E(240,150,160,120,AC,{name:"Ide utama"}),X("Ide utama",320,210,26,WHT,{bold:1}),...node(240,0,160,64,"Cabang 1","#ece9ff",AC),...node(240,356,160,64,"Cabang 2","#ece9ff",AC),...node(0,178,160,64,"Cabang 3","#ece9ff",AC),...node(480,178,160,64,"Cabang 4","#ece9ff",AC)]}),
 "SWOT":()=>({w:560,h:500,a:SW.flatMap(q=>[R(q[2],q[3],270,240,q[4],{rx:28,name:q[0]}),X(q[1],q[2]+224,q[3]+56,72,q[5],{bold:1,opacity:30}),X(q[0],q[2]+24,q[3]+48,28,q[5],{left:1,bold:1}),E(q[2]+24,q[3]+98,14,14,q[5]),X("Tulis poin di sini",q[2]+50,q[3]+106,21,MUTE,{left:1}),E(q[2]+24,q[3]+148,14,14,q[5]),X("Poin kedua",q[2]+50,q[3]+156,21,MUTE,{left:1})])}),
 "Bagan organisasi":()=>({w:600,h:194,a:[R(298,64,4,26,LINE),R(90,88,420,4,LINE),...[90,300,510].map(c=>R(c-2,90,4,40,LINE)),...node(210,0,180,64,"Pimpinan",AC,WHT),...[["Divisi A",0],["Divisi B",210],["Divisi C",420]].flatMap(d=>node(d[1],130,180,64,d[0],"#ece9ff",AC))]}),
 "Diagram Venn":()=>({w:500,h:300,a:[E(0,0,300,300,AC,{opacity:60,name:"Lingkaran A"}),E(200,0,300,300,"#00c9a7",{opacity:60,name:"Lingkaran B"}),X("A",100,150,40,INK,{bold:1}),X("B",400,150,40,INK,{bold:1}),X("A & B",250,150,26,INK,{bold:1})]})
});
MENUS.papan=()=>[
 {h:"Proyek",items:["Gantt 4 tugas","Kanban 3 kolom","Peta pikiran"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Analisis",items:["SWOT","Bagan organisasi","Diagram Venn"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["papan","board","Papan"]);
hubAdd("pustaka","papan");
CDMS.Logo={inisial};
})();
