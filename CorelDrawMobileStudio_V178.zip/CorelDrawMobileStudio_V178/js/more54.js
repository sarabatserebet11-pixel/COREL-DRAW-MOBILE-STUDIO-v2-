/* V65: menu Kebiasaan (pelacak kebiasaan, air minum, mood, tidur, jadwal olahraga, kartu nutrisi) dan Perjalanan (boarding pass, itinerari, daftar bawaan, pemesanan hotel, rute perjalanan, hitung mundur liburan) */
(()=>{
const M=CDMS.Menus,{MENUS,BT,it}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,STAR,AC,INK,MUTE,LINE}=K;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const WHT="#ffffff",GRN="#16a34a",BLU="#2f80ed",ORG="#f59e0b",RED="#ef4444",CARD="#00000018";
const card=(w,h,name,a,bg=WHT)=>({w,h,a:[R(0,0,w,h,bg,{rx:28,stroke:CARD,strokeWidth:3,name}),...a]});
/* ---------- Kebiasaan ---------- */
const HARI=["S","S","R","K","J","S","M"];
Object.assign(COMP,{
 "Pelacak kebiasaan":()=>card(600,440,"Pelacak kebiasaan",[X("Kebiasaan Minggu Ini",32,52,32,INK,{left:1,bold:1}),...HARI.map((h,i)=>X(h,264+i*46,106,20,MUTE,{bold:1})),...[["Olahraga",[1,1,0,1,1,0,0],AC],["Baca buku",[1,1,1,1,0,1,0],"#00c9a7"],["Minum air",[1,0,1,1,1,1,1],BLU],["Tidur cepat",[0,1,1,0,1,0,0],ORG]].flatMap((r,j)=>{const y=170+j*66;return [X(r[0],32,y,24,INK,{left:1,bold:1}),...r[1].map((d,i)=>E(246+i*46,y-17,36,36,d?r[2]:"#eef0fa"))];})]),
 "Air minum":()=>card(420,500,"Pelacak air minum",[X("Air Minum",210,52,32,INK,{bold:1}),X("5 / 8 gelas",210,92,22,MUTE),...Array.from({length:8},(_,i)=>{const c=i%4,r=Math.floor(i/4);return R(36+c*92,140+r*130,72,100,i<5?BLU:"#e3ecfb",{rx:16,name:"Gelas "+(i+1)});}),R(36,410,348,22,"#e3ecfb",{rx:11}),R(36,410,218,22,BLU,{rx:11}),X("62% target tercapai",210,462,22,BLU,{bold:1})]),
 "Pelacak mood":()=>card(600,260,"Pelacak mood",[X("Mood Minggu Ini",32,52,30,INK,{left:1,bold:1}),...[["#00c9a7",1],["#ffc857",0],["#00c9a7",1],["#ff6b6b",-1],["#ffc857",0],["#00c9a7",1],["#6d5dfc",1]].flatMap((m,i)=>{const x=32+i*78;return [E(x,100,64,64,m[0]),E(x+16,120,8,8,INK),E(x+40,120,8,8,INK),m[1]>0?P(x+18,134,28,14,"M0 0Q50 100 100 0","none",{stroke:INK,strokeWidth:4}):m[1]<0?P(x+18,138,28,14,"M0 100Q50 0 100 100","none",{stroke:INK,strokeWidth:4}):R(x+20,142,24,4,INK,{rx:2}),X(HARI[i],x+32,196,20,MUTE,{bold:1})];})]),
 "Pelacak tidur":()=>card(520,360,"Pelacak tidur",[X("Tidur Semalam",32,52,30,INK,{left:1,bold:1}),X("7j 20m",32,128,72,AC,{left:1,bold:1}),X("Skor tidur 86 / 100",32,184,24,MUTE,{left:1}),R(32,230,456,34,"#eef0fa",{rx:17}),R(32,230,120,34,"#8b7cff",{rx:17}),R(160,230,200,34,AC,{rx:17}),R(368,230,60,34,"#c9c2ff",{rx:17}),X("Ringan",92,294,20,MUTE),X("Dalam",260,294,20,MUTE),X("REM",398,294,20,MUTE)]),
 "Jadwal olahraga":()=>card(560,500,"Jadwal olahraga",[X("Jadwal Olahraga",32,52,32,INK,{left:1,bold:1}),...[["Sen","Lari 5 km","#ef4444"],["Rab","Angkat beban","#6d5dfc"],["Jum","Yoga 45 menit","#00c9a7"],["Min","Bersepeda","#f59e0b"]].flatMap((r,i)=>{const y=100+i*96;return [R(32,y,496,80,"#f6f7fc",{rx:22}),R(32,y,14,80,r[2],{rx:7}),X(r[0],84,y+40,26,r[2],{left:1,bold:1}),X(r[1],160,y+40,26,INK,{left:1,bold:1})];})]),
 "Kartu nutrisi":()=>card(440,520,"Kartu nutrisi",[X("Info Nilai Gizi",32,52,30,INK,{left:1,bold:1}),R(32,82,376,6,INK,{rx:3}),X("Kalori",32,130,24,MUTE,{left:1}),X("320 kkal",408,130,32,INK,{left:1,bold:1,x:236}),...[["Protein","18 g",.6,AC],["Karbohidrat","42 g",.75,ORG],["Lemak","9 g",.3,RED],["Serat","6 g",.45,GRN]].flatMap((r,i)=>{const y=190+i*80;return [X(r[0],32,y,22,INK,{left:1,bold:1}),X(r[1],408,y,22,MUTE,{left:1,x:340}),R(32,y+24,376,16,"#eef0fa",{rx:8}),R(32,y+24,Math.round(376*r[2]),16,r[3],{rx:8})];})])
});
MENUS.kebiasaan=()=>[
 {h:"Pelacak",items:["Pelacak kebiasaan","Air minum","Pelacak mood","Pelacak tidur"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Kesehatan",items:["Jadwal olahraga","Kartu nutrisi"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["kebiasaan","checklist","Kebiasaan"]);
hubAdd("pustaka","kebiasaan");
/* ---------- Perjalanan ---------- */
const PESAWAT="M50 0L58 38L100 62V74L58 58L56 86L72 98V100L50 94L28 100V98L44 86L42 58L0 74V62L42 38Z";
Object.assign(COMP,{
 "Boarding pass":()=>({w:700,h:280,a:[R(0,0,700,280,WHT,{rx:28,stroke:CARD,strokeWidth:3,name:"Boarding pass"}),R(0,0,700,70,BLU,{rx:28}),R(0,40,700,30,BLU),X("BOARDING PASS",32,36,26,WHT,{left:1,bold:1}),X("Kelas Ekonomi",668,36,22,"#dbe8ff",{left:1,x:500}),X("CGK",32,130,64,INK,{left:1,bold:1}),P(300,98,70,70,PESAWAT,BLU),X("DPS",668,130,64,INK,{left:1,bold:1,x:490}),X("Jakarta",32,180,22,MUTE,{left:1}),X("Denpasar",668,180,22,MUTE,{left:1,x:490}),R(32,206,636,3,LINE),X("Penumpang",32,236,18,MUTE,{left:1}),X("NAMA PENUMPANG",32,262,24,INK,{left:1,bold:1}),X("Gerbang",300,236,18,MUTE,{left:1}),X("B7",300,262,24,INK,{left:1,bold:1}),X("Kursi",460,236,18,MUTE,{left:1}),X("14A",460,262,24,INK,{left:1,bold:1}),X("Berangkat",570,236,18,MUTE,{left:1}),X("08.45",570,262,24,INK,{left:1,bold:1})]}),
 "Itinerari":()=>card(560,520,"Itinerari",[X("Itinerari 3 Hari",32,54,34,INK,{left:1,bold:1}),R(32,84,90,5,ORG,{rx:3}),...[["Hari 1","Tiba · check-in · pantai sore"],["Hari 2","Wisata kota · kuliner malam"],["Hari 3","Oleh-oleh · pulang"]].flatMap((r,i)=>{const y=120+i*128;return [R(32,y,496,108,"#fff5e0",{rx:22}),R(32,y,110,108,ORG,{rx:22}),R(100,y,42,108,ORG),X(r[0],87,y+54,26,WHT,{bold:1}),X(r[1],164,y+54,22,INK,{left:1,bold:1})];})]),
 "Daftar bawaan":()=>card(440,520,"Daftar bawaan",[X("Daftar Bawaan",32,54,32,INK,{left:1,bold:1}),R(32,84,90,5,GRN,{rx:3}),...["Paspor / KTP","Tiket & pemesanan","Pengisi daya","Obat pribadi","Pakaian ganti","Kamera"].flatMap((t,i)=>{const y=130+i*62;return [R(32,y-18,36,36,i<3?GRN:WHT,{rx:10,stroke:GRN,strokeWidth:3}),i<3?X("✓",50,y,26,WHT,{bold:1}):null,X(t,90,y,24,INK,{left:1,bold:i<3}),].filter(Boolean);})]),
 "Pemesanan hotel":()=>card(520,400,"Pemesanan hotel",[R(20,20,480,170,"#dbe8ff",{rx:20}),P(60,60,90,90,"M50 10L95 50H80V95H20V50H5Z",BLU),X("Hotel Nama",32,226,34,INK,{left:1,bold:1}),...[0,1,2,3,4].map(i=>P(32+i*36,248,30,30,STAR,i<4?"#ffc857":"#d5daea")),X("Check-in 12 Des · Check-out 14 Des",32,308,22,MUTE,{left:1}),R(32,336,456,4,LINE),X("Rp 650.000",32,372,34,BLU,{left:1,bold:1}),X("/ malam",250,376,22,MUTE,{left:1})]),
 "Rute perjalanan":()=>({w:640,h:220,a:[R(0,0,640,220,"#f1f3fa",{rx:28,name:"Rute perjalanan"}),P(60,70,520,80,"M0 80C20 0 40 0 50 50C60 100 80 100 100 20","none",{stroke:BLU,strokeWidth:6}),E(40,130,40,40,GRN),E(560,40,40,40,RED),X("Asal",60,190,22,INK,{bold:1}),X("Tujuan",580,108,22,INK,{bold:1}),R(240,12,160,40,WHT,{rx:20}),X("4 jam 30 menit",320,32,18,BLU,{bold:1})]}),
 "Hitung mundur liburan":()=>({w:520,h:300,a:[R(0,0,520,300,"#ff8a4c",{rx:36,name:"Hitung mundur liburan"}),E(390,24,100,100,"#ffc857",{opacity:70}),X("LIBURAN DIMULAI",32,56,24,"#fff1e6",{left:1,bold:1}),X("23",32,150,110,WHT,{left:1,bold:1}),X("hari lagi",232,168,32,"#fff1e6",{left:1,bold:1}),R(32,214,456,4,"#ffffff60",{rx:2}),X("Pulau Impian · 15 – 20 Des",32,258,26,WHT,{left:1,bold:1})]})
});
MENUS.perjalanan=()=>[
 {h:"Tiket & rute",items:["Boarding pass","Rute perjalanan","Pemesanan hotel"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Persiapan",items:["Itinerari","Daftar bawaan","Hitung mundur liburan"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["perjalanan","pin","Perjalanan"]);
hubAdd("pustaka","perjalanan");
})();
