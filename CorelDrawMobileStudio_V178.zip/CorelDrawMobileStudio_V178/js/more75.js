/* V87: grup menu baru "Isolasi" (masuk ke grup/pilihan: objek lain dikunci dan diredupkan sementara, keluar memulihkan) + tab Anggota & Isolasi di panel Penata
   (rata, sebar, samakan ukuran, susun grid, balik urutan di dalam grup; kunci/sembunyikan selain pilihan) + tombol cepat */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,P=CDMS.Penata,{MENUS,BT,it,sels,pick,T,cell}=M;
if(!M.HUBS||!P)return;
const addTab=(k,l,html,h)=>{const nh={};Object.keys(h).forEach(x=>{nh["x87_"+x]=h[x];});P.addTab(k,l,html.replace(/data-h="([^"]+)"/g,'data-h="x87_$1"'),nh);};
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n);
const num=(id,d)=>{const e=$("#"+id),v=e?parseFloat(e.value):NaN;return isFinite(v)?v:d;};
const b=(k,l,i)=>`<button data-h="${k}">${i?ic(i):""}<span>${l}</span></button>`;
const bbox=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y)),x2=Math.max(...a.map(o=>o.x+(o.w||0))),y2=Math.max(...a.map(o=>o.y+(o.h||0)));return{x,y,x2,y2,w:x2-x,h:y2-y};};
function expand(a){const g=new Set(a.filter(o=>o.groupId).map(o=>o.groupId)),s=new Set(a);S.objects.forEach(o=>{if(o.groupId&&g.has(o.groupId))s.add(o);});return[...s];}
/* ---- isolasi ---- */
const aktif=()=>S.objects.some(o=>o.isoWas);
function pulih(){let n=0;S.objects.forEach(o=>{if(!o.isoWas)return;if(o.isoWas.l)o.locked=true;else delete o.locked;o.opacity=o.isoWas.op;if(o.opacity===undefined)delete o.opacity;delete o.isoWas;n++;});return n;}
function masuk(){const t=expand(sels());if(!t.length)return T("Pilih grup atau objek dulu");Hi.snapshot();pulih();const set=new Set(t);let n=0;
 S.objects.forEach(o=>{if(set.has(o))return;o.isoWas={l:!!o.locked,op:o.opacity};o.locked=true;o.opacity=Math.min(o.opacity===undefined?100:o.opacity,20);n++;});
 if(!n)return T("Tidak ada objek lain untuk diisolasi");pick(t);banner();T("Mode isolasi: "+t.length+" objek aktif, "+n+" objek lain dikunci & diredupkan");}
function keluar(quiet){if(!aktif()){if(!quiet)T("Tidak sedang dalam isolasi");return;}Hi.snapshot();const n=pulih();C.render();banner();if(!quiet)T("Keluar isolasi, "+n+" objek dipulihkan");}
function toggleIso(){aktif()?keluar():masuk();}
function banner(){let e=$("#p87bar");if(!aktif()){if(e)e.remove();return;}
 if(!e){e=document.createElement("div");e.id="p87bar";e.innerHTML=`<span>${ic("target")} Mode isolasi</span><button data-p87="out">Keluar</button>`;(document.querySelector(".workspace")||document.body).appendChild(e);}}
document.addEventListener("click",e=>{const x=e.target.closest&&e.target.closest("[data-p87]");if(x&&x.dataset.p87==="out")keluar();});
/* proyek yang dibuka tidak boleh membawa sisa isolasi */
const lp=C.loadProject;C.loadProject=function(){const r=lp.apply(this,arguments);if(pulih())C.render();banner();return r;};
/* ---- kunci / sembunyi selain pilihan ---- */
function selain(prop,msg){const t=new Set(expand(sels()));if(!t.size)return T("Pilih objek dulu");const o2=S.objects.filter(o=>!t.has(o)&&!o.isoWas);if(!o2.length)return T("Tidak ada objek lain");Hi.snapshot();o2.forEach(o=>{o[prop]=true;});C.render();T(msg+" ("+o2.length+" objek)");}
function bukaSemua(){const a=S.objects.filter(o=>(o.locked||o.hidden)&&!o.isoWas);if(!a.length)return T("Tidak ada objek terkunci atau tersembunyi");Hi.snapshot();a.forEach(o=>{delete o.locked;delete o.hidden;});C.render();T(a.length+" objek dibuka & ditampilkan");}
/* ---- anggota grup ---- */
function himpunan(){const a=sels();if(!a.length)return null;const gs=new Map();a.forEach(o=>{if(o.groupId)gs.set(o.groupId,1);});
 if(gs.size)return[...gs.keys()].map(g=>S.objects.filter(o=>o.groupId===g&&!o.locked));const l=a.filter(o=>!o.locked);return l.length>=2?[l]:null;}
function perHimp(fn,msg){const h=himpunan();if(!h)return T("Pilih grup (atau 2 objek lebih) dulu");const s=h.filter(m=>m.length>=2);if(!s.length)return T("Grup perlu minimal 2 anggota");Hi.snapshot();s.forEach(fn);C.render();T(msg+" ("+s.length+" grup)");}
function rata(k){perHimp(m=>{const r=bbox(m);m.forEach(o=>{const w=o.w||0,h=o.h||0;
 if(k==="l")o.x=r.x;if(k==="c")o.x=Math.round(r.x+(r.w-w)/2);if(k==="r")o.x=Math.round(r.x2-w);
 if(k==="t")o.y=r.y;if(k==="m")o.y=Math.round(r.y+(r.h-h)/2);if(k==="b")o.y=Math.round(r.y2-h);});},"Anggota diratakan");}
function sebar(ax,tepat){perHimp(m=>{if(m.length<2)return;const k=ax==="h"?"x":"y",z=ax==="h"?"w":"h",s=[...m].sort((p,q)=>p[k]-q[k]),r=bbox(m),tot=s.reduce((t,o)=>t+(o[z]||0),0);
 const gap=tepat?Math.max(0,num("p87gap",20)):(r[z]-tot)/Math.max(1,s.length-1);let p=s[0][k];s.forEach(o=>{o[k]=Math.round(p);p+=(o[z]||0)+gap;});},tepat?"Anggota disebar dengan jarak tepat":"Anggota disebar rata");}
function samakan(k,mode){perHimp(m=>{const v=mode==="min"?Math.min(...m.map(o=>o[k]||1)):Math.max(...m.map(o=>o[k]||1));m.forEach(o=>{if(o[k]!==undefined)o[k]=v;});},"Anggota disamakan ("+(k==="w"?"lebar":"tinggi")+")");}
function gridDalam(){perHimp(m=>{const c=Math.max(1,Math.round(num("p87cols",3))),gap=Math.max(0,num("p87gap",20)),r=bbox(m),cw=Math.max(...m.map(o=>o.w||0)),ch=Math.max(...m.map(o=>o.h||0));
 m.forEach((o,i)=>{o.x=Math.round(r.x+(i%c)*(cw+gap)+(cw-(o.w||0))/2);o.y=Math.round(r.y+Math.floor(i/c)*(ch+gap)+(ch-(o.h||0))/2);});},"Anggota disusun dalam grid");}
function balikUrut(){perHimp(m=>{const idx=m.map(o=>S.objects.indexOf(o)).sort((p,q)=>p-q),rev=[...m].sort((p,q)=>S.objects.indexOf(q)-S.objects.indexOf(p)),arr=S.objects.slice();idx.forEach((i,j)=>{arr[i]=rev[j];});S.objects=arr;},"Urutan layer anggota dibalik");}
const H={ms:masuk,kl:()=>keluar(),ks:()=>selain("locked","Objek lain dikunci"),hs:()=>selain("hidden","Objek lain disembunyikan"),bs:bukaSemua,
 rl:()=>rata("l"),rc:()=>rata("c"),rr:()=>rata("r"),rt:()=>rata("t"),rm:()=>rata("m"),rb:()=>rata("b"),
 sh:()=>sebar("h"),sv:()=>sebar("v"),th:()=>sebar("h",true),tv:()=>sebar("v",true),
 mw:()=>samakan("w","max"),mh:()=>samakan("h","max"),nw:()=>samakan("w","min"),nh:()=>samakan("h","min"),gd:gridDalam,bu:balikUrut};
addTab("iso","Isolasi",`<p class="muted" style="margin:0 0 8px">Pilih grup atau objek, lalu masuk isolasi: objek lain dikunci dan diredupkan sementara sehingga mudah mengedit isi grup. Keluar memulihkan keadaan semula.</p>
 <div class="p69btns">${b("ms","Masuk isolasi","target")}${b("kl","Keluar isolasi","close")}</div>
 <div class="p69h" style="margin-top:12px">Permanen (bisa di-undo)</div><div class="p69btns">${b("ks","Kunci selain pilihan","lock")}${b("hs","Sembunyikan selain pilihan","eyeoff")}</div>
 <div class="p69btns" style="margin-top:6px">${b("bs","Buka semua kunci & tampilkan","eye")}</div>`,H);
addTab("angg","Anggota",`<p class="muted" style="margin:0 0 8px">Menata isi grup terpilih (tiap grup sendiri-sendiri). Tanpa grup: berlaku pada 2 objek atau lebih yang dipilih.</p>
 <div class="p69h">Rata di dalam grup</div><div class="p69btns c3">${b("rl","Kiri","al")}${b("rc","Tengah H","align")}${b("rr","Kanan","ar")}${b("rt","Atas","au")}${b("rm","Tengah V","align")}${b("rb","Bawah","ad")}</div>
 <div class="p69h" style="margin-top:12px">Sebar</div><div class="p69row"><label>Jarak (px)<input id="p87gap" type="number" value="20" min="0"></label><label>Kolom grid<input id="p87cols" type="number" value="3" min="1"></label></div>
 <div class="p69btns c4">${b("sh","Rata H")}${b("sv","Rata V")}${b("th","Jarak H")}${b("tv","Jarak V")}</div>
 <div class="p69h" style="margin-top:12px">Samakan ukuran</div><div class="p69btns c4">${b("mw","Lebar maks")}${b("mh","Tinggi maks")}${b("nw","Lebar min")}${b("nh","Tinggi min")}</div>
 <div class="p69btns" style="margin-top:8px">${b("gd","Susun grid di grup")}${b("bu","Balik urutan layer")}</div>`,H);
/* ---- tombol cepat, menu, hub ---- */
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q87="iso" title="Masuk / keluar isolasi">${ic("target")}</button><button data-q87="angg" title="Tata anggota grup">${ic("align")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q87]");if(!x)return;if(x.dataset.q87==="iso")toggleIso();else P.openTab("angg");});}
MENUS.iso1=()=>[{h:"Isolasi",items:[it("Masuk isolasi (pilihan / grup)",masuk,"target"),it("Keluar isolasi",()=>keluar(),"close"),it("Panel Isolasi",()=>P.openTab("iso"),"panel")]}];
MENUS.iso2=()=>[{h:"Selain pilihan",items:[it("Kunci selain pilihan",()=>selain("locked","Objek lain dikunci"),"lock"),it("Sembunyikan selain pilihan",()=>selain("hidden","Objek lain disembunyikan"),"eyeoff"),it("Buka semua kunci & tampilkan",bukaSemua,"eye")]}];
MENUS.iso3=()=>[{h:"Rata anggota",items:[it("Kiri",()=>rata("l"),"al"),it("Tengah horizontal",()=>rata("c"),"align"),it("Kanan",()=>rata("r"),"ar"),it("Atas",()=>rata("t"),"au"),it("Tengah vertikal",()=>rata("m"),"align"),it("Bawah",()=>rata("b"),"ad")]},{h:"Sebar & ukuran",items:[it("Sebar rata horizontal",()=>sebar("h"),"distribute"),it("Sebar rata vertikal",()=>sebar("v"),"distribute"),it("Samakan lebar (maks)",()=>samakan("w","max"),"wide"),it("Samakan tinggi (maks)",()=>samakan("h","max"),"tall"),it("Susun grid di grup",gridDalam,"grid"),it("Balik urutan layer",balikUrut,"layers"),it("Panel Anggota",()=>P.openTab("angg"),"panel")]}];
BT.push(["iso1","target","Isolasi"],["iso2","lock","Selain"],["iso3","align","Anggota"]);
const ISO=["iso1","iso2","iso3"],ai=M.HUBS.findIndex(h=>h[0]==="kelompok");
M.HUBS.splice(ai<0?M.HUBS.length:ai+1,0,["isolasi","target","Isolasi",ISO]);
MENUS.hub_isolasi=()=>[{h:"Isolasi",items:ISO.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($('[data-menu="hub_isolasi"]'),k),0));})}];
window.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.shiftKey&&(e.key==="I"||e.key==="i")){const t=e.target;if(t&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))return;e.preventDefault();e.stopImmediatePropagation();toggleIso();}},true);
})();
