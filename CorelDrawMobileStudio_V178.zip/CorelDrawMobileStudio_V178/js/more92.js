/* V104: dua grup menu baru (helper bersama dari CDMS.Util97, tanpa kode duplikat).
   "Perencana" (ikon planner104): Kalender (bulan apa pun, awal pekan Senin/Minggu, hari ini disorot), Centang (daftar tugas bercentang), Jadwal (tabel pekan + jam).
   "Pengumuman" (ikon notice104): Diskon (bintang bergerigi + label + nilai), Undangan (kartu berbingkai ganda), Kupon (tiket bertakik + kode).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U||!U.kontras||!U.mkPal||!U.bagi)return;
const{ramp,grup,shape,text,line,path,finish,defHub,W,H,poly,ask,wrap,idx,tx,clamp,mkPal,kontras,parse,chips,bagi}=U,R=Math.round;
const PL=mkPal("pal104","biru"),pal=PL.pal,palMenu=PL.menu,pc=(P,t)=>ramp(P.c.slice(1),t);
const kartu=(x,y,w,h,rx)=>shape("rect",x,y,w,h,"#ffffff",{name:"Kartu",rx:R(rx),stroke:"#e5e7eb",strokeWidth:2});

/* ================= PERENCANA ================= */
const BLN=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"],HRI=["Sen","Sel","Rab","Kam","Jum","Sab","Min"];
function kalender(){const n=new Date(),q=ask("Bulan/Tahun (mis. 10/2026):",(n.getMonth()+1)+"/"+n.getFullYear());if(q===null)return;const m=q.match(/(\d{1,2})\D+(\d{4})/);
 if(!m||+m[1]<1||+m[1]>12||+m[2]<1900||+m[2]>2200)return T("Format: bulan/tahun, mis. 10/2026");const mo=+m[1],yr=+m[2];Hi.snapshot();
 const P=pal(),w=W(),h=H(),senin=(S.klM104||"s")==="s",off=senin?(new Date(yr,mo-1,1).getDay()+6)%7:new Date(yr,mo-1,1).getDay(),nd=new Date(yr,mo,0).getDate(),rows=Math.ceil((off+nd)/7),
  cw=w*.88,pd=cw*.03,cell=(cw-2*pd)/7,tH=cell*.95,hH=cell*.55,rh=Math.min(cell*.95,(h*.86-2*pd-tH-hH)/rows),ch=2*pd+tH+hH+rows*rh,x=(w-cw)/2,y=(h-ch)/2,x0=x+pd,gy=y+pd+tH+hH,
  fs=R(clamp(Math.min(cell*.32,rh*.34),8,34)),ft=R(clamp(cell*.5,10,48)),hc=pc(P,.2),ac=pc(P,.8),out=[kartu(x,y,cw,ch,cell*.2)];
 out.push(tx(BLN[mo-1]+" "+yr,w/2,y+pd+tH/2-ft*.55,ft,"#111827",{name:"Judul bulan",bold:true}),shape("rect",x0,y+pd+tH,cw-2*pd,hH,hc,{name:"Baris hari",rx:R(hH*.25)}));
 (senin?HRI:[HRI[6],...HRI.slice(0,6)]).forEach((s,i)=>out.push(tx(s,x0+i*cell+cell/2,y+pd+tH+hH/2-fs*.45,R(fs*.8),kontras(hc),{name:"Hari "+s,bold:true})));
 for(let r=1;r<rows;r++)out.push(line(x0,gy+r*rh,cw-2*pd,0,"#e5e7eb",2,{name:"Garis "+r}));
 for(let d=1;d<=nd;d++){const k=off+d-1,r=Math.floor(k/7),c=k%7,cx=x0+c*cell+cell/2,cy=gy+r*rh+rh/2,libur=senin?c===6:c===0,ini=n.getMonth()===mo-1&&n.getFullYear()===yr&&n.getDate()===d;
  if(ini){const e=Math.min(cell,rh)*.8;out.push(shape("ellipse",cx-e/2,cy-e/2,e,e,ac,{name:"Hari ini"}));}
  out.push(tx(String(d),cx,cy-fs*.55,fs,ini?kontras(ac):libur?"#dc2626":"#111827",{name:"Tanggal "+d,bold:ini}));}
 finish(grup(out,"Kalender"),"Kalender "+BLN[mo-1]+" "+yr);}
MENUS.kal104=()=>[palMenu(),{h:"Awal pekan",items:[["Senin","s"],["Minggu","m"]].map(x=>tc(x[0],()=>{S.klM104=x[1];},{keep:1,on:(S.klM104||"s")===x[1]}))},{h:"Buat",items:[it("Buat kalender bulanan…",kalender,"calendar104")]}];

function centang(){const q=ask("Item (pisahkan koma; 2-8; awali + jika sudah selesai):","+Riset,+Sketsa,Revisi,Kirim");if(q===null)return;
 const D=q.split(",").map(s=>s.trim()).filter(Boolean).slice(0,8).map(s=>{const ok=s[0]==="+";return[(ok?s.slice(1):s).trim().slice(0,28),ok];}).filter(d=>d[0]);if(D.length<2)return T("Butuh minimal 2 item");Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=D.length,ml=Math.max(...D.map(d=>d[0].length)),cw=w*.8,fs=R(clamp(Math.min(cw/(ml*.6+4.5),h*.7/(n*2)),9,36)),rh=fs*2,pd=fs*1.2,ch=2*pd+n*rh,x=(w-cw)/2,y=(h-ch)/2,ac=pc(P,.7),bs=fs*1.3,out=[kartu(x,y,cw,ch,fs*.8)];
 D.forEach((d,i)=>{const ry=y+pd+i*rh,by=ry+rh/2-bs/2,bx=x+pd,tx0=bx+bs+fs*.7;
  out.push(shape("rect",bx,by,bs,bs,d[1]?ac:"#ffffff",{name:"Kotak "+(i+1),rx:R(bs*.22),stroke:ac,strokeWidth:Math.max(2,R(fs*.12))}));
  if(d[1]){const c=R(bs*.6);out.push(path(bx+bs*.2,by+bs*.2,c,c,c,c,"M"+R(c*.08)+" "+R(c*.55)+"L"+R(c*.38)+" "+R(c*.85)+"L"+R(c*.92)+" "+R(c*.15),"none","#ffffff",Math.max(3,R(fs*.2)),{name:"Centang "+(i+1)}));}
  out.push(text(d[0],tx0,ry+rh/2-fs*.6,fs,d[1]?"#9ca3af":"#111827",{name:"Item "+(i+1)}));
  if(d[1])out.push(line(tx0,ry+rh/2,d[0].length*fs*.6,0,"#9ca3af",Math.max(2,R(fs*.1)),{name:"Coret "+(i+1)}));});
 finish(grup(out,"Daftar centang"),"Daftar centang "+n+" item");}
MENUS.cek104=()=>[palMenu(),{h:"Buat",items:[it("Buat daftar centang…",centang,"check104")]}];

function jadwal(){const P=pal(),w=W(),h=H(),dn=S.jwD104||5,r=S.jwR104||6;Hi.snapshot();
 const cw=w*.9,pd=cw*.03,tw=cw-2*pd,c0=tw*.15,cc=(tw-c0)/dn,hH=Math.min(h*.07,cc*.5),rh=Math.min((h*.8-hH-2*pd)/r,cc*.7),ch=2*pd+hH+r*rh,x=(w-cw)/2,y=(h-ch)/2,x0=x+pd,y0=y+pd,
  fs=R(clamp(Math.min(cc*.3,rh*.3,hH*.5),7,24)),hc=pc(P,.2),out=[kartu(x,y,cw,ch,pd)];
 out.push(shape("rect",x0,y0,tw,hH,hc,{name:"Header",rx:R(hH*.2)}),tx("Jam",x0+c0/2,y0+hH/2-fs*.55,fs,kontras(hc),{name:"Judul jam",bold:true}));
 HRI.slice(0,dn).forEach((s,i)=>out.push(tx(s,x0+c0+i*cc+cc/2,y0+hH/2-fs*.55,fs,kontras(hc),{name:"Hari "+s,bold:true})));
 for(let i=0;i<r;i++){const ry=y0+hH+i*rh;out.push(shape("rect",x0,ry,tw,rh,i%2?"#f3f4f6":"#ffffff",{name:"Baris "+(i+1)}),tx(String(8+i).padStart(2,"0")+":00",x0+c0/2,ry+rh/2-fs*.55,fs,"#374151",{name:"Waktu "+(i+1)}));}
 for(let j=0;j<dn;j++)out.push(line(x0+c0+j*cc,y0+hH,0,r*rh,"#d1d5db",2,{name:"Kolom "+(j+1)}));
 finish(grup(out,"Jadwal"),"Jadwal "+dn+" hari × "+r+" jam");}
MENUS.jdw104=()=>[palMenu(),chips("Hari",[5,6,7],"jwD104",5),chips("Jam (baris)",[4,6,8],"jwR104",6),{h:"Buat",items:[it("Buat jadwal pekanan di tengah",jadwal,"schedule104")]}];

/* ================= PENGUMUMAN ================= */
const DW=[["Merah","#dc2626"],["Kuning","#facc15"],["Biru","#2563eb"],["Hijau","#16a34a"]];
function diskon(){const q=ask("Label | Nilai (maks 10 huruf tiap bagian):","DISKON | 50%");if(q===null)return;const[a,b]=bagi(q),lb=a.slice(0,10),vl=b.slice(0,10);if(!vl)return T("Nilai kosong (Label | Nilai)");Hi.snapshot();
 const w=W(),h=H(),col=DW[S.dkW104||0][1],fg=kontras(col),R0=Math.min(w,h)*.38,N=20,cx=w/2,cy=h/2,P=[];
 for(let k=0;k<2*N;k++){const an=k*Math.PI/N-Math.PI/2,r=k%2?R0*.84:R0;P.push([cx+r*Math.cos(an),cy+r*Math.sin(an)]);}
 const vf=Math.min(R0*.5,R0*1.25/(Math.max(vl.length,2)*.6)),lf=lb?Math.min(R0*.2,R0*1.1/(Math.max(lb.length,2)*.6)):0,tot=(lb?lf*1.3:0)+vf*1.2,ty=cy-tot/2,
  out=[poly(P,col,"Bintang diskon"),shape("ellipse",cx-R0*.72,cy-R0*.72,R0*1.44,R0*1.44,"none",{name:"Cincin",stroke:fg,strokeWidth:Math.max(2,R(R0*.02)),opacity:70})];
 if(lb)out.push(tx(lb,cx,ty,R(lf),fg,{name:"Label",bold:true}));
 out.push(tx(vl,cx,ty+(lb?lf*1.3:0),R(vf),fg,{name:"Nilai",bold:true}));
 finish(grup(out,"Diskon"),"Lencana diskon dipasang");}
MENUS.dsk104=()=>[idx("Warna",DW,"dkW104",0),{h:"Buat",items:[it("Buat lencana diskon di tengah…",diskon,"sale104")]}];

const UW=[["Emas","#b8860b"],["Merah","#b91c1c"],["Hijau","#166534"],["Biru","#1e3a8a"]];
function undangan(){const q=ask("Judul | Tanggal | Tempat (judul maks 40 huruf):","Pernikahan Rina & Adi | Sabtu, 14 Maret 2027 | Gedung Serbaguna, Bandung");if(q===null)return;const p=String(q).split("|").map(s=>s.trim()),t=(p[0]||"").slice(0,40),d=(p[1]||"").slice(0,40),pl=(p[2]||"").slice(0,48);if(!t)return T("Judul kosong");Hi.snapshot();
 const w=W(),h=H(),col=UW[S.unW104||0][1],cw=Math.min(w*.84,h*.8/1.4),ch=Math.min(h*.8,cw*1.4),x=(w-cw)/2,y=(h-ch)/2,cx=w/2,fk=R(clamp(cw*.04,7,24)),ys=y+ch*.1,yd=ys+fk*2.6,
  out=[shape("rect",x,y,cw,ch,"#fffaf0",{name:"Kartu",rx:R(cw*.03)}),shape("rect",x+cw*.04,y+cw*.04,cw*.92,ch-cw*.08,"none",{name:"Bingkai luar",stroke:col,strokeWidth:Math.max(3,R(cw*.012)),rx:R(cw*.02)}),
  shape("rect",x+cw*.065,y+cw*.065,cw*.87,ch-cw*.13,"none",{name:"Bingkai dalam",stroke:col,strokeWidth:Math.max(1,R(cw*.004)),rx:R(cw*.012)}),
  tx("U N D A N G A N",cx,ys,fk,col,{name:"Label",bold:true}),poly([[cx,yd-fk*.6],[cx+fk*.6,yd],[cx,yd+fk*.6],[cx-fk*.6,yd]],col,"Hiasan"),
  line(cx-cw*.2,yd,cw*.14,0,col,2,{name:"Garis kiri"}),line(cx+cw*.06,yd,cw*.14,0,col,2,{name:"Garis kanan"})];
 let fs=cw*.09,L;for(let k=0;k<12;k++){L=wrap(t,Math.max(6,Math.floor(cw*.76/(fs*.6))));if((L.length<=4&&L.length*fs*1.25<=ch*.3)||fs<=9)break;fs*=.88;}
 fs=R(Math.max(9,fs));let yy=yd+fk*1.6;L.forEach((s,i)=>out.push(tx(s,cx,yy+i*fs*1.25,fs,"#1f2937",{name:"Judul "+(i+1),bold:true})));yy+=L.length*fs*1.25+fk*.8;
 const f2=R(clamp(cw*.05,8,28));out.push(line(cx-cw*.12,yy,cw*.24,0,col,2,{name:"Pemisah"}));yy+=fk*1.2;
 [d,pl].filter(Boolean).forEach((s,j)=>wrap(s,Math.max(8,Math.floor(cw*.76/(f2*.6)))).forEach(z=>{out.push(tx(z,cx,yy,f2,j?"#4b5563":col,{name:j?"Tempat":"Tanggal",bold:!j}));yy+=f2*1.35;}));
 finish(grup(out,"Undangan"),"Kartu undangan dipasang");}
MENUS.und104=()=>[idx("Warna",UW,"unW104",0),{h:"Buat",items:[it("Buat kartu undangan…",undangan,"invite104")]}];

const KW=[["Merah","#dc2626"],["Biru","#2563eb"],["Hijau","#16a34a"],["Emas","#d97706"]];
function kupon(){const q=ask("Nilai | Kode | Keterangan (nilai maks 12 huruf):","DISKON 20% | HEMAT20 | Berlaku s.d. akhir bulan");if(q===null)return;const p=String(q).split("|").map(s=>s.trim()),v=(p[0]||"").slice(0,12),kd=(p[1]||"").slice(0,12),kt=(p[2]||"").slice(0,40);if(!v)return T("Nilai kosong");Hi.snapshot();
 const w=W(),h=H(),col=KW[S.kpW104||0][1],fg=kontras(col),cw=w*.86,ch=Math.min(h*.3,cw*.42),x=(w-cw)/2,y=(h-ch)/2,sp=x+cw*.7,r=ch*.09,bg=parse(S.page.background||"")?S.page.background:"#ffffff",cl=x+cw*.35,
  vf=Math.min(ch*.3,cw*.62/(v.length*.6+.5)),kf=kt?Math.min(vf*.4,cw*.6/(kt.length*.6)):0,vy=kt?y+ch/2-vf*.9:y+ch/2-vf*.6,
  out=[shape("rect",x,y,cw,ch,col,{name:"Kupon",rx:R(ch*.08)}),shape("ellipse",sp-r,y-r,r*2,r*2,bg,{name:"Takik atas"}),shape("ellipse",sp-r,y+ch-r,r*2,r*2,bg,{name:"Takik bawah"}),
   line(sp,y+r*1.6,0,ch-r*3.2,fg,3,{name:"Perforasi",dash:"8 6",opacity:70}),tx(v,cl,vy,R(vf),fg,{name:"Nilai",bold:true})];
 if(kt)out.push(tx(kt,cl,vy+vf*1.4,R(Math.max(8,kf)),fg,{name:"Keterangan",opacity:85}));
 const rc=x+cw*.85,kf2=kd?Math.min(ch*.14,cw*.26/(Math.max(kd.length,4)*.6)):0;
 out.push(tx(kd?"KODE":"KUPON",rc,y+ch/2-(kd?kf2*1.6:ch*.07),R(Math.max(8,kd?kf2*.7:ch*.14)),fg,{name:"Label kode",opacity:80}));
 if(kd)out.push(tx(kd,rc,y+ch/2-kf2*.2,R(Math.max(8,kf2)),fg,{name:"Kode",bold:true}));
 finish(grup(out,"Kupon"),"Kupon dipasang");}
MENUS.kpn104=()=>[idx("Warna",KW,"kpW104",0),{h:"Buat",items:[it("Buat kupon di tengah…",kupon,"coupon104")]}];

/* ================= tombol & grup ================= */
BT.push(["kal104","calendar104","Kalender"],["cek104","check104","Centang"],["jdw104","schedule104","Jadwal"],["dsk104","sale104","Diskon"],["und104","invite104","Undangan"],["kpn104","coupon104","Kupon"]);
defHub("perencana104","planner104","Perencana",["kal104","cek104","jdw104"]);
defHub("umum104","notice104","Pengumuman",["dsk104","und104","kpn104"]);
Object.assign(U,{kartu});
CDMS.Perencana104={kalender,centang,jadwal,diskon,undangan,kupon};
})();
