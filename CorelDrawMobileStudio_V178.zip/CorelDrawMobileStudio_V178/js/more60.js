/* V71: tab baru Layer dan Kanvas di panel Penata + tombol baru di bar aksi cepat (tengah H/V di halaman, tampilkan semua, isolasi) */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const done=m=>{C.render();if(m)T(m);};
const sel=()=>M.sels();
const unitBox=a=>({x:Math.min(...a.map(o=>o.x)),y:Math.min(...a.map(o=>o.y)),x2:Math.max(...a.map(o=>o.x+(o.w||0))),y2:Math.max(...a.map(o=>o.y+(o.h||0)))});
/* ---- Layer ---- */
function tampil(){const n=S.objects.filter(o=>o.hidden).length;if(!n)return T("Tidak ada objek tersembunyi");Hi.snapshot();S.objects.forEach(o=>{o.hidden=false;});done(n+" objek ditampilkan");}
function bukaKunci(){const n=S.objects.filter(o=>o.locked).length;if(!n)return T("Tidak ada objek terkunci");Hi.snapshot();S.objects.forEach(o=>{o.locked=false;});done(n+" kunci dibuka");}
function isolasi(){const a=sel();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const ids=new Set(a.map(o=>o.id));let n=0;S.objects.forEach(o=>{if(!ids.has(o.id)&&!o.hidden){o.hidden=true;n++;}});done("Isolasi: "+n+" objek disembunyikan (klik Tampilkan semua untuk kembali)");}
function kunciLain(){const a=sel();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const ids=new Set(a.map(o=>o.id));let n=0;S.objects.forEach(o=>{if(!ids.has(o.id)&&!o.locked){o.locked=true;n++;}});done(n+" objek lain dikunci");}
function hapusSembunyi(){const n=S.objects.filter(o=>o.hidden).length;if(!n)return T("Tidak ada objek tersembunyi");Hi.snapshot();S.objects=S.objects.filter(o=>!o.hidden);S.selected=null;S.selectedIds=[];done(n+" objek tersembunyi dihapus");}
function nama(){const a=sel();if(!a.length)return T("Pilih objek dulu");const pre=($("#p71nm").value||"Objek").trim(),st=Math.round(num("p71st",1));Hi.snapshot();
 [...a].sort((p,q)=>p.y-q.y||p.x-q.x).forEach((o,i)=>{o.name=pre+" "+(st+i);});done(a.length+" objek diberi nama");}
function urutPos(){const a=sel();if(a.length<2)return T("Pilih 2 objek atau lebih");Hi.snapshot();const ids=new Set(a.map(o=>o.id)),idx=S.objects.map((o,i)=>ids.has(o.id)?i:-1).filter(i=>i>=0);
 const s=[...a].sort((p,q)=>p.y-q.y||p.x-q.x);idx.forEach((i,k)=>{S.objects[i]=s[k];});done("Tumpukan diurutkan dari atas-kiri (paling belakang) ke bawah-kanan");}
function balikTumpuk(){const a=sel();if(a.length<2)return T("Pilih 2 objek atau lebih");Hi.snapshot();const ids=new Set(a.map(o=>o.id)),idx=S.objects.map((o,i)=>ids.has(o.id)?i:-1).filter(i=>i>=0),v=idx.map(i=>S.objects[i]).reverse();idx.forEach((i,k)=>{S.objects[i]=v[k];});done("Urutan tumpukan dibalik");}
/* ---- Kanvas ---- */
const ukur=(w,h,m)=>{w=Math.round(Math.max(50,Math.min(8000,w)));h=Math.round(Math.max(50,Math.min(8000,h)));Hi.snapshot();S.page.width=w;S.page.height=h;done(m||("Kanvas "+w+" × "+h));};
function pangkas(){const a=S.objects.filter(o=>!o.hidden&&(o.w||o.h));if(!a.length)return T("Kanvas kosong");const pad=Math.max(0,num("p71pd",40)),bx=unitBox(a);Hi.snapshot();
 S.objects.forEach(o=>{o.x=Math.round(o.x-bx.x+pad);o.y=Math.round(o.y-bx.y+pad);});S.page.width=Math.round(bx.x2-bx.x+2*pad);S.page.height=Math.round(bx.y2-bx.y+2*pad);done("Kanvas dipangkas ke konten");}
function tambah(){const l=num("p71l",0),t=num("p71t",0),r=num("p71r",0),bt=num("p71bt",0);if(!(l||t||r||bt))return T("Isi tambahan ruang dulu");const mv=$("#p71mv").checked;Hi.snapshot();
 if(mv)S.objects.forEach(o=>{o.x=Math.round(o.x+l);o.y=Math.round(o.y+t);});S.page.width=Math.max(50,Math.round(S.page.width+l+r));S.page.height=Math.max(50,Math.round(S.page.height+t+bt));done("Ruang kanvas ditambah");}
const H={tampil,bukaKunci,isolasi,kunciLain,hapusSembunyi,nama,urutPos,balikTumpuk,
 tukar:()=>ukur(S.page.height,S.page.width,"Orientasi ditukar"),setUk:()=>ukur(num("p71w",1080),num("p71h",1080)),
 pangkas,tambah,
 bg:()=>{Hi.snapshot();S.page.background=$("#p71bg").value;done("Warna latar kanvas diubah");},
 u1:()=>ukur(1080,1080),u2:()=>ukur(1080,1350),u3:()=>ukur(1080,1920),u4:()=>ukur(1920,1080),u5:()=>ukur(2480,3508,"A4 300 dpi (2480 × 3508)"),u6:()=>ukur(1200,630)};
P.addTab("layer","Layer",`<div class="p69btns">${b("tampil","Tampilkan semua")}${b("bukaKunci","Buka semua kunci")}${b("isolasi","Isolasi pilihan")}${b("kunciLain","Kunci yang lain")}</div>
 <div class="p69h">Urutan tumpukan (terpilih)</div><div class="p69btns">${b("urutPos","Urut menurut posisi")}${b("balikTumpuk","Balik urutan")}</div>
 <div class="p69h">Beri nama berurutan</div><div class="p69row"><label>Awalan<input id="p71nm" type="text" value="Objek"></label>${fld("p71st","Mulai dari",1)}</div>
 <div class="p69btns">${b("nama","Beri nama")}${b("hapusSembunyi","Hapus yang tersembunyi")}</div>`,H);
P.addTab("kanvas","Kanvas",`<div class="p69btns c3">${b("u1","1:1")}${b("u2","4:5")}${b("u3","Story")}${b("u4","16:9")}${b("u5","A4")}${b("u6","Link")}</div>
 <div class="p69row" style="margin-top:10px">${fld("p71w","Lebar",S.page?S.page.width:1080,'min="50"')}${fld("p71h","Tinggi",S.page?S.page.height:1080,'min="50"')}<label>Latar<input id="p71bg" type="color" value="#ffffff"></label></div>
 <div class="p69btns c3">${b("setUk","Atur ukuran")}${b("tukar","Tukar W×H")}${b("bg","Terapkan latar")}</div>
 <div class="p69h">Pangkas / tambah ruang</div><div class="p69row">${fld("p71pd","Margin pangkas",40,'min="0"')}</div>
 <div class="p69btns">${b("pangkas","Pangkas ke konten")}</div>
 <div class="p69row" style="margin-top:10px">${fld("p71l","Kiri",0)}${fld("p71t","Atas",0)}${fld("p71r","Kanan",0)}${fld("p71bt","Bawah",0)}</div>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px"><input id="p71mv" type="checkbox" checked> Geser objek mengikuti sisi kiri/atas</label>
 <div class="p69btns" style="margin-top:8px">${b("tambah","Tambah ruang")}</div>`,H);
/* ---- tombol bar aksi cepat ---- */
function tengahHalaman(ax){const a=sel();if(!a.length)return T("Pilih objek dulu");const ms=[];a.forEach(o=>{(o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]).forEach(p=>{if(!ms.includes(p))ms.push(p);});});
 const bx=unitBox(ms);Hi.snapshot();const dx=ax==="h"?Math.round(S.page.width/2-(bx.x+bx.x2)/2):0,dy=ax==="v"?Math.round(S.page.height/2-(bx.y+bx.y2)/2):0;ms.forEach(o=>{o.x+=dx;o.y+=dy;});done(ax==="h"?"Ditengahkan mendatar":"Ditengahkan menurun");}
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<button data-qw="th" title="Tengah mendatar di halaman">${ic("arrange")}</button><button data-qw="tv" title="Tengah menurun di halaman">${ic("tall")}</button><button data-qw="iso" title="Isolasi pilihan">${ic("eye")}</button><button data-qw="all" title="Tampilkan semua">${ic("eyeoff")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-qw]");if(!x)return;const k=x.dataset.qw;if(k==="th")tengahHalaman("h");else if(k==="tv")tengahHalaman("v");else if(k==="iso")isolasi();else tampil();});}
MENUS.penata71=()=>[{h:"Tab Penata",items:[it("Layer (tampil, kunci, nama)",()=>P.openTab("layer"),"layers"),it("Kanvas (ukuran, pangkas, ruang)",()=>P.openTab("kanvas"),"grid")]},{h:"Cepat",items:[it("Tampilkan semua objek",tampil,"eye"),it("Buka semua kunci",bukaKunci,"unlock"),it("Pangkas kanvas ke konten",pangkas,"grid")]}];
BT.push(["penata71","panel","Penata++"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata71");
})();
