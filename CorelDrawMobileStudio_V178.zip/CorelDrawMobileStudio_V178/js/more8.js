/* V21: menu Pena (kuas, simetri, penghalus), Kolase (layout + isi foto), Ukur */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,edit,sels,T,it,tc,cell}=M,uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;
S.penColor=S.penColor||"#6d5dfc";S.penWidth=S.penWidth||6;S.penSmooth=true;S.sym="off";

/* ---- pena: warna, tebal, penghalus, simetri ---- */
function smooth(o){const n=(o.d||"").match(/-?\d+(\.\d+)?/g);if(!n||n.length<8)return;let p=[];for(let i=0;i+1<n.length;i+=2)p.push([+n[i],+n[i+1]]);
 const q=[p[0]];p.forEach(v=>{const l=q[q.length-1];if(Math.hypot(v[0]-l[0],v[1]-l[1])>4)q.push(v);});if(q.length<3)return;
 let d=`M${q[0][0]} ${q[0][1]}`;for(let i=0;i<q.length-1;i++){const p0=q[i-1]||q[i],p1=q[i],p2=q[i+1],p3=q[i+2]||p2,f=v=>v.toFixed(1);d+=`C${f(p1[0]+(p2[0]-p0[0])/6)} ${f(p1[1]+(p2[1]-p0[1])/6)} ${f(p2[0]-(p3[0]-p1[0])/6)} ${f(p2[1]-(p3[1]-p1[1])/6)} ${f(p2[0])} ${f(p2[1])}`;}o.d=d;}
const cp=(o,g)=>({...o,id:uid(),groupId:g,name:"Simetri"}),hflip=c=>{c.x=Math.round(W()-c.x-c.w);c.flipH=!c.flipH;return c;},vflip=c=>{c.y=Math.round(H()-c.y-c.h);c.flipV=!c.flipV;return c;};
function rot(o,c,k,n){const an=2*Math.PI*k/n,cs=Math.cos(an),sn=Math.sin(an),px=W()/2,py=H()/2,x=o.x+o.w/2-px,y=o.y+o.h/2-py;c.x=Math.round(px+x*cs-y*sn-o.w/2);c.y=Math.round(py+x*sn+y*cs-o.h/2);c.rotation=Math.round((((o.rotation||0)+an*180/Math.PI+540)%360)-180);return c;}
function symmetry(o){const m=S.sym,g=o.groupId||(o.groupId=uid()),out=[];
 if(m==="h")out.push(hflip(cp(o,g)));else if(m==="v")out.push(vflip(cp(o,g)));else if(m==="4")out.push(hflip(cp(o,g)),vflip(cp(o,g)),vflip(hflip(cp(o,g))));
 else if(/^[rk]\d+$/.test(m)){const n=+m.slice(1),bases=[o];if(m[0]==="k"){const b=hflip(cp(o,g));out.push(b);bases.push(b);}
  bases.forEach(b=>{for(let k=1;k<n;k++)out.push(rot(b,cp(b,g),k,n));});}
 S.objects.push(...out);}
const fp=C.finishPath;
C.finishPath=function(){const n=S.objects.length;fp.apply(this,arguments);if(S.objects.length<=n)return;const o=S.objects[S.objects.length-1];if(o.type!=="path")return;
 o.stroke=S.penColor;o.strokeWidth=S.penWidth;if(S.penSmooth)smooth(o);if(S.sym&&S.sym!=="off")symmetry(o);this.render();};
const PC=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#ffffff","#20243a","#ff7ac8","#3ddc84"],SYM=[["off","Mati"],["h","Cermin horizontal"],["v","Cermin vertikal"],["4","4 arah"],["r6","Radial 6"],["r8","Radial 8"],["r12","Radial 12"],["k6","Kaleidoskop 6"],["k8","Kaleidoskop 8"]];
MENUS.pen=()=>[
 {h:"Warna kuas",items:PC.map(c=>cell(`<i style="background:${c};border:1px solid var(--line)"></i>`,()=>{S.penColor=c;CDMS.setTool("pen");T("Warna kuas diatur");}))},
 {h:"Ketebalan kuas",items:[2,4,6,10,16,26].map(w=>tc(w+" px",()=>{S.penWidth=w;CDMS.setTool("pen");T("Ketebalan "+w+" px");}))},
 {h:"Simetri menggambar",items:SYM.map(x=>it((S.sym===x[0]?"✓ ":"")+x[1],()=>{S.sym=x[0];CDMS.setTool("pen");T("Simetri: "+x[1]);},"pen"))},
 {h:"Penghalus",items:[it((S.penSmooth?"✓ ":"")+"Haluskan goresan",()=>{S.penSmooth=!S.penSmooth;T(S.penSmooth?"Penghalus aktif":"Penghalus mati");},"pen")]}];

/* ---- kolase ---- */
const LAY={"2 kolom":[[0,0,.5,1],[.5,0,.5,1]],"2 baris":[[0,0,1,.5],[0,.5,1,.5]],"1 besar + 2":[[0,0,.6,1],[.6,0,.4,.5],[.6,.5,.4,.5]],"Grid 2×2":[[0,0,.5,.5],[.5,0,.5,.5],[0,.5,.5,.5],[.5,.5,.5,.5]],"Grid 3×2":[0,1,2].flatMap(i=>[0,1].map(j=>[i/3,j/2,1/3,.5]))};
function layout(r){Hi.snapshot();const m=Math.round(W()*.05),gap=Math.round(W()*.02),aw=W()-2*m,ah=H()-2*m;
 const arr=r.map((q,i)=>({id:uid(),type:"rect",name:"Slot foto "+(i+1),x:Math.round(m+q[0]*aw+gap/2),y:Math.round(m+q[1]*ah+gap/2),w:Math.round(q[2]*aw-gap),h:Math.round(q[3]*ah-gap),rx:12,fill:"#e3e7f2",stroke:"#aab3cc",strokeWidth:3,dash:"6 4",opacity:100,rotation:0}));
 S.objects.push(...arr);S.selected=arr[0].id;S.selectedIds=[arr[0].id];C.render();T(arr.length+" slot foto dibuat. Pilih slot lalu isi dengan foto.");}
function fillSlot(){const a=sels()[0];if(!a||a.type==="image"||a.type==="text")return T("Pilih satu slot (bentuk) dulu");
 const inp=document.createElement("input");inp.type="file";inp.accept="image/*";
 inp.onchange=()=>{const f=inp.files[0];if(!f)return;if(f.size>8*1048576)return T("Ukuran foto maksimal 8 MB");const r=new FileReader();
  r.onload=()=>{Hi.snapshot();const img={id:uid(),type:"image",name:"Foto",href:String(r.result),x:a.x,y:a.y,w:a.w,h:a.h,fit:"cover",strokeWidth:0,opacity:100,rotation:a.rotation||0};
   if(a.type==="ellipse")img.mask="circle";else if(a.rx>0)img.mask="round";S.objects.splice(S.objects.indexOf(a),1,img);S.selected=img.id;S.selectedIds=[img.id];C.render();};r.readAsDataURL(f);};inp.click();}
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);if(o.type==="image"&&o.fit)s=s.replace('preserveAspectRatio="none"',`preserveAspectRatio="xMidYMid ${o.fit==="cover"?"slice":"meet"}"`);return s;};
const fit=v=>edit(o=>{if(v)o.fit=v;else delete o.fit;},"",o=>o.type==="image");
MENUS.collage=()=>[
 {h:"Layout kolase",items:Object.keys(LAY).map(k=>tc(k,()=>layout(LAY[k])))},
 {h:"Isi slot",items:[it("Isi slot terpilih dengan foto…",fillSlot,"image")]},
 {h:"Pas foto di bingkai",items:[tc("Isi (potong)",()=>fit("cover")),tc("Muat penuh",()=>fit("contain")),tc("Regang",()=>fit(""))]}];

/* ---- ukur ---- */
const cm=(px,d)=>(px/d*2.54).toFixed(1);
MENUS.meas=()=>[{h:"Ukur objek",items:[
 it("Ukuran objek terpilih",()=>{const a=sels()[0];if(!a)return T("Pilih objek dulu");T(`${a.w} × ${Math.round(a.h||0)} px · ${cm(a.w,300)} × ${cm(a.h||0,300)} cm @300 dpi`);},"arrange"),
 it("Jarak antar 2 objek",()=>{const a=sels();if(a.length<2)return T("Pilih 2 objek (tombol Multi)");const p=a[0],q=a[1],dx=Math.max(0,Math.max(p.x,q.x)-Math.min(p.x+p.w,q.x+q.w)),dy=Math.max(0,Math.max(p.y,q.y)-Math.min(p.y+(p.h||0),q.y+(q.h||0)));T(`Jarak tepi: ${Math.round(dx)} px mendatar · ${Math.round(dy)} px tegak`);},"arrange"),
 it("Sudut antar 2 pusat objek",()=>{const a=sels();if(a.length<2)return T("Pilih 2 objek");const p=a[0],q=a[1],an=Math.atan2((q.y+(q.h||0)/2)-(p.y+(p.h||0)/2),(q.x+q.w/2)-(p.x+p.w/2))*180/Math.PI;T("Sudut: "+an.toFixed(1)+"°");},"redo"),
 it("Luas objek terhadap halaman",()=>{const a=sels()[0];if(!a)return T("Pilih objek dulu");T("Menempati "+((a.w*(a.h||0))/(W()*H())*100).toFixed(1)+"% dari halaman");},"grid")]},
 {h:"Halaman",items:[
 it("Ukuran halaman (cm)",()=>T(`${W()} × ${H()} px = ${cm(W(),300)} × ${cm(H(),300)} cm @300 dpi · ${cm(W(),150)} × ${cm(H(),150)} cm @150 dpi`),"canvas" in MENUS?"grid":"grid"),
 it("Statistik objek",()=>{const c={};S.objects.forEach(o=>{c[o.type]=(c[o.type]||0)+1;});T(S.objects.length+" objek: "+Object.entries(c).map(e=>e[1]+" "+e[0]).join(", "));},"layers")]}];

BT.push(["pen","pen","Pena"],["collage","collage","Kolase"],["meas","measure","Ukur"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("buat").push("pen","collage");hub("kanvas").push("meas");
})();
