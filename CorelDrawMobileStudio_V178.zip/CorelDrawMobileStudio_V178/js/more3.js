/* V16: menu Grafik, Hiasan, Bantu + cubit-zoom 2 jari */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height,NS="http://www.w3.org/2000/svg",T=M.T,pick=M.pick;
const PAL=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4f83ff","#ff7ac8","#3ddc84","#ff9a3c"],rnd=(a,b)=>a+Math.random()*(b-a),pk=a=>a[Math.random()*a.length|0];
const txt=(text,x,y,size,fill,x2)=>({type:"text",name:"Teks",text,x:Math.round(x),y:Math.round(y),w:50,h:30,fontSize:Math.round(size),fill,...x2});
function grp(arr,post){Hi.snapshot();const g=uid();arr.forEach(o=>Object.assign(o,{id:uid(),groupId:g,opacity:o.opacity??100,rotation:o.rotation||0,stroke:o.stroke||"none",strokeWidth:o.strokeWidth||0}));S.objects.push(...arr);pick(arr);if(post){post();C.render();}}
const nums=s=>String(s).split(/[,;\s]+/).map(Number).filter(v=>Number.isFinite(v)&&v>=0).slice(0,12),labs=s=>String(s).split(/[,;]+/).map(x=>x.trim()).filter(Boolean);
function ask(title,html,cb){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">Buat</button></div>`);$("#aOk").onclick=cb;}
const askVals=cb=>ask("Data grafik",'<label>Nilai (pisahkan koma, maks 12)<input id="cV" value="40, 70, 55, 90"></label><label>Label (opsional)<input id="cL" value="Jan, Feb, Mar, Apr"></label>',cb);

/* ---- grafik ---- */
function bar(){const v=nums($("#cV").value),l=labs($("#cL").value);if(!v.length)return T("Isi nilai angka dulu");N.closeModal();
 const w=Math.round(W()*.7),h=Math.round(w*.55),x0=Math.round((W()-w)/2),y0=Math.round((H()-h)/2),mx=Math.max(...v,1),slot=w/v.length,fs=Math.max(14,Math.round(w*.035)),arr=[{type:"line",name:"Sumbu",x:x0,y:y0+h,w,h:0,stroke:"#8a93aa",strokeWidth:3,fill:"none"}],pairs=[];
 v.forEach((n,i)=>{const bh=Math.max(2,Math.round(n/mx*h)),b={type:"rect",name:"Batang "+(i+1),x:Math.round(x0+i*slot+slot*.15),y:y0+h-bh,w:Math.round(slot*.7),h:bh,rx:6,fill:PAL[i%8]};arr.push(b);
  const t=txt(String(n),b.x,b.y-fs*1.4,fs,"#20243a",{bold:true});arr.push(t);pairs.push([t,b]);
  if(l[i]){const u=txt(l[i],b.x,y0+h+fs*.5,fs*.9,"#68728a");arr.push(u);pairs.push([u,b]);}});
 grp(arr,()=>pairs.forEach(p=>{p[0].x=Math.round(p[1].x+(p[1].w-p[0].w)/2);}));}
function pie(donut){const v=nums($("#cV").value);if(!v.some(x=>x>0))return T("Isi nilai angka dulu");N.closeModal();
 const z=Math.round(Math.min(W(),H())*.5),x=Math.round((W()-z)/2),y=Math.round((H()-z)/2),tot=v.reduce((a,b)=>a+b,0),P=a=>[50+50*Math.cos(a),50+50*Math.sin(a)],arr=[];let a0=-Math.PI/2;
 v.forEach((n,i)=>{if(!n)return;const fr=n/tot;if(fr>=.9999){arr.push({type:"ellipse",name:"Irisan",x,y,w:z,h:z,fill:PAL[i%8]});return;}
  const a1=a0+fr*2*Math.PI,p0=P(a0),p1=P(a1);arr.push({type:"path",name:"Irisan "+(i+1)+" ("+Math.round(fr*100)+"%)",x,y,w:z,h:z,vw:100,vh:100,d:`M50 50L${p0[0].toFixed(2)} ${p0[1].toFixed(2)}A50 50 0 ${fr>.5?1:0} 1 ${p1[0].toFixed(2)} ${p1[1].toFixed(2)}Z`,fill:PAL[i%8],stroke:"#ffffff",strokeWidth:3});a0=a1;});
 if(donut){const d=Math.round(z*.55);arr.push({type:"ellipse",name:"Lubang",x:Math.round(x+(z-d)/2),y:Math.round(y+(z-d)/2),w:d,h:d,fill:/^#[0-9a-f]{6}$/i.test(S.page.background)?S.page.background:"#ffffff"});}
 grp(arr);}
function ring(){const p=Math.max(0,Math.min(100,Number($("#rP").value)||0));N.closeModal();
 const z=Math.round(Math.min(W(),H())*.4),x=Math.round((W()-z)/2),y=Math.round((H()-z)/2),sw=Math.round(z*.1),k=Math.round(z*.92),ko=Math.round((z-k)/2),
 arr=[{type:"ellipse",name:"Jalur",x:x+ko,y:y+ko,w:k,h:k,fill:"none",stroke:"#d9deea",strokeWidth:sw}];
 if(p>=100)arr.push({type:"ellipse",name:"Progres",x:x+ko,y:y+ko,w:k,h:k,fill:"none",stroke:"#6d5dfc",strokeWidth:sw});
 else if(p>0){const a=-Math.PI/2+p/100*2*Math.PI;arr.push({type:"path",name:"Progres",x,y,w:z,h:z,vw:100,vh:100,d:`M50 4A46 46 0 ${p>50?1:0} 1 ${(50+46*Math.cos(a)).toFixed(2)} ${(50+46*Math.sin(a)).toFixed(2)}`,fill:"none",stroke:"#6d5dfc",strokeWidth:sw});}
 const t=txt(Math.round(p)+"%",x,y,z*.22,"#20243a",{bold:true});arr.push(t);grp(arr,()=>{t.x=Math.round(x+(z-t.w)/2);t.y=Math.round(y+(z-t.h)/2);});}
function table(){const r=Math.max(2,Math.min(8,+$("#tR").value||4)),c=Math.max(2,Math.min(6,+$("#tC").value||3));N.closeModal();
 const cw=Math.round(W()*.8/c),ch=Math.round(Math.min(H()*.8/r,cw*.45)),x0=Math.round((W()-cw*c)/2),y0=Math.round((H()-ch*r)/2),fs=Math.max(12,Math.round(ch*.32)),arr=[];
 for(let i=0;i<r;i++)for(let j=0;j<c;j++){const x=x0+j*cw,y=y0+i*ch,hd=i===0;arr.push({type:"rect",name:`Sel ${i+1}-${j+1}`,x,y,w:cw,h:ch,fill:hd?"#6d5dfc":(i%2?"#ffffff":"#f1f3f9"),stroke:"#d9deea",strokeWidth:2});arr.push(txt(hd?"Judul "+(j+1):"Isi",x+fs*.6,y+(ch-fs*1.2)/2,fs,hd?"#ffffff":"#20243a",{bold:hd}));}
 grp(arr);}
MENUS.chart=()=>[
 {h:"Grafik dari data",items:[it("Diagram batang…",()=>askVals(bar),"chart"),it("Diagram lingkaran…",()=>askVals(()=>pie(false)),"chart"),it("Donat…",()=>askVals(()=>pie(true)),"chart")]},
 {h:"Komponen data",items:[it("Cincin progres…",()=>ask("Cincin progres",'<label>Persen (0-100)<input id="rP" type="number" min="0" max="100" value="72"></label>',ring),"chart"),it("Tabel…",()=>ask("Tabel",'<div class="st-grid"><label>Baris<input id="tR" type="number" min="2" max="8" value="4"></label><label>Kolom<input id="tC" type="number" min="2" max="6" value="3"></label></div>',table),"insert")]}];

/* ---- hiasan ---- */
function deco(kind){Hi.snapshot();const w=W(),h=H(),out=[],g=uid();
 if(kind==="confetti")for(let i=0;i<45;i++){const s=rnd(w*.012,w*.03);out.push({type:"rect",x:rnd(0,w),y:rnd(0,h),w:s,h:s*rnd(.4,1),rx:2,fill:pk(PAL),rotation:Math.round(rnd(-180,180))});}
 if(kind==="stars")for(let i=0;i<24;i++){const s=rnd(w*.02,w*.07);out.push({type:"star",x:rnd(0,w-s),y:rnd(0,h-s),w:s,h:s,fill:pk(["#ffc857","#ffffff","#00d6c9"]),opacity:Math.round(rnd(45,95)),rotation:Math.round(rnd(-30,30))});}
 if(kind==="bubbles")for(let i=0;i<22;i++){const s=rnd(w*.03,w*.14);out.push({type:"ellipse",x:rnd(0,w-s),y:rnd(0,h-s),w:s,h:s,fill:"#ffffff",opacity:Math.round(rnd(12,30)),stroke:"#ffffff",strokeWidth:2});}
 if(kind==="dots"){const gx=w/10,r=Math.min(gx*.16,16);for(let i=0;i<10;i++)for(let j=0;j<Math.round(h/gx);j++)out.push({type:"ellipse",x:Math.round(i*gx+gx/2-r),y:Math.round(j*gx+gx/2-r),w:r*2,h:r*2,fill:"#8a93aa",opacity:35});}
 if(kind==="stripes"){const n=14,st=(w+h)/n;for(let i=1;i<=n;i++){const t=i*st,xa=Math.max(0,t-h),xb=Math.min(w,t);if(xb>xa)out.push({type:"line",x:xa,y:t-xb,w:xb-xa,h:xb-xa,flipH:true,fill:"none",stroke:"#ffffff",strokeWidth:8,opacity:14});}}
 out.forEach(o=>Object.assign(o,{id:uid(),groupId:g,deco:true,name:"Hiasan "+kind,x:Math.round(o.x),y:Math.round(o.y),w:Math.round(o.w),h:Math.round(o.h),opacity:o.opacity??100,rotation:o.rotation||0,stroke:o.stroke||"none",strokeWidth:o.strokeWidth||0}));
 S.objects.unshift(...out);S.selected=null;S.selectedIds=[];C.render();T(out.length+" hiasan ditambahkan di belakang");}
MENUS.deco=()=>[
 {h:"Hiasan latar (di belakang)",items:[it("Konfeti",()=>deco("confetti"),"sticker"),it("Bintang-bintang",()=>deco("stars"),"star"),it("Gelembung",()=>deco("bubbles"),"ellipse"),it("Pola titik",()=>deco("dots"),"grid"),it("Garis diagonal",()=>deco("stripes"),"line")]},
 {h:"Bersihkan",items:[it("Hapus semua hiasan",()=>{const n=S.objects.filter(o=>o.deco).length;if(!n)return T("Belum ada hiasan");Hi.snapshot();S.objects=S.objects.filter(o=>!o.deco);S.selected=null;S.selectedIds=[];C.render();T(n+" hiasan dihapus");},"trash")]}];

/* ---- panduan tata letak (tidak ikut ekspor) ---- */
const AID=[["thirds","Sepertiga"],["golden","Rasio emas"],["cross","Garis tengah"],["diag","Diagonal"],["col12","12 kolom"],["col3","3 kolom"],["margin","Margin aman 5%"],["g20","Grid kecil 20"],["g40","Grid sedang 40"],["g80","Grid besar 80"]];
MENUS.aid=()=>[{h:"Panduan tata letak",items:AID.map(x=>it(((S.aid||[]).includes(x[0])?"✓ ":"")+x[1],()=>{const a=S.aid||(S.aid=[]),i=a.indexOf(x[0]);i<0?a.push(x[0]):a.splice(i,1);C.render();},"ruler",{keep:1}))},
 {h:"Aksi",items:[it("Matikan semua panduan",()=>{S.aid=[];C.render();},"eyeoff")]}];
const rr=C.render;
C.render=function(){rr.call(this);const old=this.svg.querySelector("#cdAid");if(old)old.remove();const a=S.aid;if(!a||!a.length)return;
 const w=W(),h=H(),k=Math.max(1,w/(this.svg.getBoundingClientRect().width||w)),sw=(1.3*k).toFixed(2),da=(8*k).toFixed(1)+" "+(6*k).toFixed(1);let m="";
 const ln=(x1,y1,x2,y2,c)=>{m+=`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${c}" stroke-width="${sw}" stroke-dasharray="${da}"/>`;};
 if(a.includes("thirds"))[1/3,2/3].forEach(f=>{ln(w*f,0,w*f,h,"#ff4f9a");ln(0,h*f,w,h*f,"#ff4f9a");});
 if(a.includes("golden"))[.382,.618].forEach(f=>{ln(w*f,0,w*f,h,"#ffc857");ln(0,h*f,w,h*f,"#ffc857");});
 if(a.includes("cross")){ln(w/2,0,w/2,h,"#00aaff");ln(0,h/2,w,h/2,"#00aaff");}
 if(a.includes("col12"))for(let i=1;i<12;i++)ln(w*i/12,0,w*i/12,h,"#ff9a3c");
 if(a.includes("col3"))[1/3,2/3].forEach(f=>ln(w*f,0,w*f,h,"#ff9a3c"));
 if(a.includes("margin")){const m=.05;ln(w*m,0,w*m,h,"#ff4f9a");ln(w*(1-m),0,w*(1-m),h,"#ff4f9a");ln(0,h*m,w,h*m,"#ff4f9a");ln(0,h*(1-m),w,h*(1-m),"#ff4f9a");}
 if(a.includes("diag")){ln(0,0,w,h,"#3ddc84");ln(w,0,0,h,"#3ddc84");}
 [["g20",20],["g40",40],["g80",80]].forEach(([id,s])=>{if(!a.includes(id))return;for(let x=s;x<w;x+=s)ln(x,0,x,h,"#8a93aa");for(let y=s;y<h;y+=s)ln(0,y,w,y,"#8a93aa");});
 const g=document.createElementNS(NS,"g");g.id="cdAid";g.setAttribute("pointer-events","none");g.setAttribute("opacity",".7");g.innerHTML=m;this.svg.appendChild(g);};

/* ---- cubit 2 jari: zoom + geser ---- */
const pts=new Map();let p0=null;
const arr=()=>[...pts.values()],dist=()=>{const[a,b]=arr();return Math.hypot(a.x-b.x,a.y-b.y);},mid=()=>{const[a,b]=arr();return{x:(a.x+b.x)/2,y:(a.y+b.y)/2};};
const inC=e=>e.target.closest&&e.target.closest("#designCanvas");
document.addEventListener("pointerdown",e=>{if(e.pointerType!=="touch"||!inC(e))return;pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(pts.size===2){S.drag=null;S.drawPath=null;const r=$("#zoomRange");p0={d:dist()||1,z:+(r&&r.value)||100,m:mid()};}
 if(pts.size>=2){e.stopPropagation();e.preventDefault();}},true);
document.addEventListener("pointermove",e=>{if(!pts.has(e.pointerId))return;pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(pts.size===2&&p0){e.stopPropagation();const v=$("#canvasViewport"),m=mid();if(v){v.scrollLeft-=m.x-p0.m.x;v.scrollTop-=m.y-p0.m.y;}p0.m=m;C.setZoom(Math.max(25,Math.min(200,Math.round(p0.z*dist()/p0.d))));}},true);
["pointerup","pointercancel"].forEach(t=>document.addEventListener(t,e=>{pts.delete(e.pointerId);if(pts.size<2)p0=null;},true));

BT.push(["chart","chart","Grafik"],["deco","deco","Hiasan"],["aid","ruler","Bantu"]);
})();
