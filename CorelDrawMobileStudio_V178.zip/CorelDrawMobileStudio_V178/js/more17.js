/* V30: mode presentasi (slideshow), ekspor video WebM, utilitas halaman */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,P=CDMS.Pages,{MENUS,BT,T,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID();
S.presDur=S.presDur||3;S.presFx=S.presFx||"fade";
const nm=()=>(S.projectName||"desain").replace(/[^\w-]+/g,"_");
/* svg satu halaman (untuk slideshow & video) */
function pageSvg(pg,fit){const keep=S.objects;S.objects=pg.objects;let body="";try{body=C.docMarkup(pg);}finally{S.objects=keep;}
 const w=pg.page.width,h=pg.page.height,b=String(pg.page.background||"#fff");let fill=b,defs="";
 if(b.startsWith("grad:")){const[a,c,m]=b.slice(5).split(",");defs=`<defs><linearGradient id="pgG" x1="0" y1="0" x2="${m==="v"?0:1}" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${c}"/></linearGradient></defs>`;fill="url(#pgG)";}
 const fs=document.querySelector("#cdFonts"),fcss=fs&&fs.textContent?`<style>${fs.textContent}</style>`:"";
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${fit?"100%":w}" height="${fit?"100%":h}">${fcss}${defs}<rect width="${w}" height="${h}" fill="${fill}"/>${body}</svg>`;}

M.pageSvg=pageSvg;
/* ---- presentasi ---- */
function present(fromStart,auto){P.sync();const n=S.pages.length;let i=fromStart?0:S.pageIdx,run=!!auto,timer=null;
 const ov=document.createElement("div");ov.className="pres";ov.innerHTML='<div class="pres-stage"></div><div class="pres-bar"><button data-p="prev">◀</button><b id="presInd"></b><button data-p="next">▶</button><button data-p="auto" id="presAuto">⏵ Putar</button><button data-p="x">✕ Tutup</button></div>';document.body.appendChild(ov);
 const stage=ov.querySelector(".pres-stage"),show=()=>{stage.classList.remove("fx-fade","fx-slide");void stage.offsetWidth;if(S.presFx!=="none")stage.classList.add("fx-"+S.presFx);stage.innerHTML=pageSvg(S.pages[i],true);ov.querySelector("#presInd").textContent=(i+1)+" / "+n;};
 const go=d=>{i=(i+d+n)%n;show();},tick=()=>{clearInterval(timer);if(run)timer=setInterval(()=>go(1),S.presDur*1000);ov.querySelector("#presAuto").textContent=run?"⏸ Jeda":"⏵ Putar";};
 const close=()=>{clearInterval(timer);document.removeEventListener("keydown",key,true);ov.remove();};
 function key(e){if(e.key==="Escape"){e.stopPropagation();close();}else if(e.key==="ArrowRight"||e.key===" "){e.preventDefault();e.stopPropagation();go(1);}else if(e.key==="ArrowLeft"){e.stopPropagation();go(-1);}}
 document.addEventListener("keydown",key,true);
 ov.addEventListener("click",e=>{const b=e.target.closest("[data-p]");if(!b){go(1);return;}const a=b.dataset.p;if(a==="prev")go(-1);else if(a==="next")go(1);else if(a==="auto"){run=!run;tick();}else close();});
 show();tick();}

/* ---- video WebM ---- */
const loadImg=svg=>new Promise((res,rej)=>{const u=URL.createObjectURL(new Blob([svg],{type:"image/svg+xml;charset=utf-8"})),im=new Image();im.onload=()=>{URL.revokeObjectURL(u);res(im);};im.onerror=()=>{URL.revokeObjectURL(u);rej(new Error("gambar gagal"));};im.src=u;});
async function exportVideo(sec){
 if(!window.MediaRecorder)return T("Browser tidak mendukung perekaman video");P.sync();const mime=["video/webm;codecs=vp9","video/webm;codecs=vp8","video/webm"].find(t=>MediaRecorder.isTypeSupported(t));if(!mime)return T("Format WebM tidak didukung browser ini");
 const pgs=S.pages,w0=pgs[0].page.width,h0=pgs[0].page.height,k=Math.min(1,720/Math.max(w0,h0)),cw=Math.round(w0*k/2)*2,ch=Math.round(h0*k/2)*2;T("Merender video…");
 let imgs;try{imgs=await Promise.all(pgs.map(pg=>loadImg(pageSvg(pg,false))));}catch(e){return T("Gagal merender halaman");}
 const cv=document.createElement("canvas");cv.width=cw;cv.height=ch;const x=cv.getContext("2d"),rec=new MediaRecorder(cv.captureStream(30),{mimeType:mime,videoBitsPerSecond:4e6}),chunks=[];
 rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
 const draw=(im,a)=>{const s=Math.min(cw/im.width,ch/im.height),w=im.width*s,h=im.height*s;x.globalAlpha=a;x.drawImage(im,(cw-w)/2,(ch-h)/2,w,h);x.globalAlpha=1;};
 const done=new Promise(r=>{rec.onstop=r;});rec.start(200);const t0=performance.now(),total=pgs.length*sec*1000,fade=Math.min(450,sec*400);
 await new Promise(res=>{const step=()=>{const t=performance.now()-t0;if(t>=total){res();return;}const i=Math.min(pgs.length-1,Math.floor(t/(sec*1000))),lt=t-i*sec*1000;x.fillStyle="#000";x.fillRect(0,0,cw,ch);
  if(i>0&&lt<fade){draw(imgs[i-1],1);draw(imgs[i],lt/fade);}else draw(imgs[i],1);setTimeout(step,33);};step();});
 rec.stop();await done;const blob=new Blob(chunks,{type:"video/webm"});if(!blob.size)return T("Video kosong, coba lagi");CDMS.Export.download(blob,nm()+".webm");T("Video disimpan ("+Math.round(blob.size/1024)+" KB)");}

/* ---- menu presentasi ---- */
MENUS.present=()=>[
 {h:"Putar",items:[it("Mulai dari halaman ini",()=>present(false,false),"eye"),it("Mulai dari awal",()=>present(true,false),"eye"),it("Putar otomatis dari awal",()=>present(true,true),"redo")]},
 {h:"Durasi per halaman",items:[1.5,3,5,8].map(d=>tc(d+" dtk"+(S.presDur===d?" ✓":""),()=>{S.presDur=d;T("Durasi "+d+" detik");}))},
 {h:"Transisi",items:[["Pudar","fade"],["Geser","slide"],["Tanpa","none"]].map(x=>tc(x[0]+(S.presFx===x[1]?" ✓":""),()=>{S.presFx=x[1];T("Transisi: "+x[0]);}))},
 {h:"Ekspor video (WebM)",items:[it("Video, 2 dtk per halaman",()=>exportVideo(2),"export"),it("Video, 4 dtk per halaman",()=>exportVideo(4),"export")]}];

/* ---- utilitas halaman ---- */
function numberPages(){P.sync();const n=S.pages.length;S.pages.forEach((pg,i)=>{pg.objects=pg.objects.filter(o=>o.name!=="Nomor halaman");const W=pg.page.width,H=pg.page.height,fs=Math.round(W*.025),t=(i+1)+" / "+n;
  pg.objects.push({id:uid(),type:"text",name:"Nomor halaman",text:t,x:Math.round(W/2-fs*.3*t.length),y:Math.round(H-fs*2.4),w:fs*t.length*.6,h:fs*1.2,fontSize:fs,fill:"#8a93aa",bold:true,stroke:"none",strokeWidth:0,opacity:100,rotation:0});});
 S.objects=S.pages[S.pageIdx].objects;C.render();T("Nomor halaman ditambahkan ke "+n+" halaman");}
function unnumber(){P.sync();S.pages.forEach(pg=>{pg.objects=pg.objects.filter(o=>o.name!=="Nomor halaman");});S.objects=S.pages[S.pageIdx].objects;C.render();T("Nomor halaman dihapus");}
function bgAll(){P.sync();const b=S.page.background;S.pages.forEach(pg=>{pg.page.background=b;});T("Latar diterapkan ke semua halaman");}
function sizeAll(){P.sync();const W=S.page.width,H=S.page.height;S.pages.forEach((pg,i)=>{if(i===S.pageIdx)return;const ow=pg.page.width,oh=pg.page.height;if(ow===W&&oh===H)return;const s=Math.min(W/ow,H/oh),dx=(W-ow*s)/2,dy=(H-oh*s)/2;
  pg.objects.forEach(o=>{o.x=Math.round(o.x*s+dx);o.y=Math.round(o.y*s+dy);o.w=Math.max(1,Math.round(o.w*s));o.h=Math.round((o.h||0)*s);if(o.fontSize)o.fontSize=Math.max(1,Math.round(o.fontSize*s));if(o.strokeWidth)o.strokeWidth=+(o.strokeWidth*s).toFixed(2);});pg.page.width=W;pg.page.height=H;});T("Ukuran semua halaman disamakan");}
const op=MENUS.pages;
MENUS.pages=()=>[...op(),{h:"Utilitas semua halaman",items:[it("Beri nomor halaman",numberPages,"text"),it("Hapus nomor halaman",unnumber,"trash"),it("Latar halaman ini ke semua",bgAll,"color"),it("Samakan ukuran ke halaman ini",sizeAll,"arrange")]}];

BT.push(["present","present","Presentasi"]);M.HUBS.find(h=>h[0]==="berkas")[3].push("present");
})();
