/* V32: menu Font (unggah font kustom), Cetak (PDF multi-halaman), Anotasi */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,P=CDMS.Pages,{MENUS,BT,edit,pick,T,it}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height,NS="http://www.w3.org/2000/svg";
const nm=()=>(S.projectName||"desain").replace(/[^\w-]+/g,"_");

/* ---- font kustom (tersimpan, ikut ekspor lewat <style> di dalam SVG) ---- */
const FK="cdms_fonts";let fonts=[],dirty=true;try{fonts=JSON.parse(localStorage.getItem(FK)||"[]");}catch(e){}
const rr=C.render;
C.render=function(){if(dirty&&this.svg){let st=this.svg.querySelector("#cdFonts");if(!st){st=document.createElementNS(NS,"style");st.id="cdFonts";this.svg.insertBefore(st,this.svg.firstChild);}st.textContent=fonts.map(f=>`@font-face{font-family:'${f.name}';src:url(${f.data});}`).join("\n");dirty=false;fonts.forEach(f=>{if(document.fonts)document.fonts.load(`16px '${f.name}'`).then(()=>C.render()).catch(()=>{});});}rr.call(this);};
function upload(){const inp=document.createElement("input");inp.type="file";inp.accept=".ttf,.otf,.woff,.woff2";
 inp.onchange=()=>{const f=inp.files[0];if(!f)return;if(f.size>1.5*1048576)return T("Ukuran font maksimal 1,5 MB");const r=new FileReader();
  r.onload=()=>{const name=f.name.replace(/\.[^.]+$/,"").replace(/[^\w]+/g,"")||"FontKu";fonts=fonts.filter(x=>x.name!==name);fonts.push({name,data:String(r.result)});
   try{localStorage.setItem(FK,JSON.stringify(fonts));}catch(e){T("Font hanya untuk sesi ini (penyimpanan penuh)");}dirty=true;C.render();T("Font "+name+" ditambahkan");};r.readAsDataURL(f);};inp.click();}
MENUS.font=()=>[{h:"Font unggahan",items:[it("Unggah font (.ttf .otf .woff)…",upload,"plus"),...fonts.map(f=>it(f.name,()=>edit(o=>{o.fontFamily=`'${f.name}', sans-serif`;},"Font diterapkan",o=>o.type==="text"),"text"))]},
 {h:"Kelola",items:[it("Hapus semua font unggahan",()=>{fonts=[];try{localStorage.removeItem(FK);}catch(e){}dirty=true;C.render();T("Font unggahan dihapus");},"trash")]}];

/* ---- PDF multi-halaman ---- */
const loadImg=svg=>new Promise((res,rej)=>{const u=URL.createObjectURL(new Blob([svg],{type:"image/svg+xml;charset=utf-8"})),im=new Image();im.onload=()=>{URL.revokeObjectURL(u);res(im);};im.onerror=()=>{URL.revokeObjectURL(u);rej(new Error("render gagal"));};im.src=u;});
async function pdf(scale,only){P.sync();const pgs=only?[S.pages[S.pageIdx]]:S.pages,jp=[];T("Menyusun PDF…");
 try{for(const pg of pgs){const w=pg.page.width,h=pg.page.height,im=await loadImg(M.pageSvg(pg,false)),s=Math.min(scale,Math.sqrt(36e6/(w*h))),cw=Math.round(w*s),ch=Math.round(h*s),cv=document.createElement("canvas");cv.width=cw;cv.height=ch;const x=cv.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,cw,ch);x.drawImage(im,0,0,cw,ch);
  const b=await new Promise(r=>cv.toBlob(r,"image/jpeg",.92));jp.push({buf:new Uint8Array(await b.arrayBuffer()),pw:cw,ph:ch,wpt:(w*.75).toFixed(2),hpt:(h*.75).toFixed(2)});}}catch(e){return T("Gagal membuat PDF");}
 const enc=new TextEncoder(),parts=[],offs=[];let len=0;const put=u=>{parts.push(u);len+=u.length;},str=s=>put(enc.encode(s)),n=jp.length,cnt=2+n*3;
 str("%PDF-1.4\n");offs[1]=len;str("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
 offs[2]=len;str(`2 0 obj\n<< /Type /Pages /Kids [${jp.map((_,i)=>(3+i*3)+" 0 R").join(" ")}] /Count ${n} >>\nendobj\n`);
 jp.forEach((j,i)=>{const pg=3+i*3,ct=pg+1,im=pg+2,cs=`q ${j.wpt} 0 0 ${j.hpt} 0 0 cm /Im0 Do Q`;
  offs[pg]=len;str(`${pg} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${j.wpt} ${j.hpt}] /Resources << /XObject << /Im0 ${im} 0 R >> >> /Contents ${ct} 0 R >>\nendobj\n`);
  offs[ct]=len;str(`${ct} 0 obj\n<< /Length ${cs.length} >>\nstream\n${cs}\nendstream\nendobj\n`);
  offs[im]=len;str(`${im} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${j.pw} /Height ${j.ph} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${j.buf.length} >>\nstream\n`);put(j.buf);str("\nendstream\nendobj\n");});
 const xr=len;let t=`xref\n0 ${cnt+1}\n0000000000 65535 f \n`;for(let i=1;i<=cnt;i++)t+=String(offs[i]).padStart(10,"0")+" 00000 n \n";t+=`trailer\n<< /Size ${cnt+1} /Root 1 0 R >>\nstartxref\n${xr}\n%%EOF\n`;str(t);
 CDMS.Export.download(new Blob(parts,{type:"application/pdf"}),nm()+".pdf");T("PDF disimpan: "+n+" halaman");}
MENUS.cetak=()=>[{h:"PDF",items:[it("PDF semua halaman",()=>pdf(1.5,false),"export"),it("PDF halaman ini saja",()=>pdf(1.5,true),"export"),it("PDF kualitas tinggi (2×)",()=>pdf(2,false),"export")]},{h:"Info",items:[it("Ukuran halaman PDF mengikuti kanvas (96 dpi)",()=>{},"settings")]}];

/* ---- anotasi ---- */
function grp(arr,post){Hi.snapshot();const g=uid();arr.forEach(o=>Object.assign(o,{id:uid(),groupId:g,opacity:o.opacity??100,rotation:o.rotation||0,stroke:o.stroke||"none",strokeWidth:o.strokeWidth||0}));S.objects.push(...arr);pick(arr);if(post){post();C.render();}}
const tx=(text,x,y,size,fill,ex)=>({type:"text",name:"Teks",text,x:Math.round(x),y:Math.round(y),w:50,h:30,fontSize:Math.round(size),fill,bold:true,...ex});
const marker=()=>{const n=S.objects.filter(o=>o.name==="Penanda").length+1,d=Math.round(W()*.06),r={type:"ellipse",name:"Penanda",x:Math.round(W()/2-d/2),y:Math.round(H()/2-d/2),w:d,h:d,fill:"#ff4f6d",stroke:"#ffffff",strokeWidth:4},t=tx(String(n),0,0,d*.55,"#ffffff",{name:"Nomor penanda"});grp([r,t],()=>{t.x=Math.round(r.x+(r.w-t.w)/2);t.y=Math.round(r.y+(r.h-t.h)/2);});};
const hl=()=>{const w=Math.round(W()*.4),h=Math.round(W()*.06);grp([{type:"rect",name:"Sorot",x:Math.round((W()-w)/2),y:Math.round(H()/2-h/2),w,h,rx:6,fill:"#ffe44d",opacity:60,bm:"multiply"}]);};
const focus=()=>{const w=Math.round(W()*.4),h=Math.round(W()*.25),x=Math.round((W()-w)/2),y=Math.round((H()-h)/2);grp([{type:"rect",name:"Kotak fokus",x,y,w,h,rx:10,fill:"none",stroke:"#ff4f6d",strokeWidth:6,dash:"6 4"},tx("Perhatikan",x,y-W()*.06,W()*.04,"#ff4f6d",{name:"Label fokus"})]);};
const callout=()=>{const w=Math.round(W()*.34),h=Math.round(w*.38),x=Math.round(W()/2-w/2),y=Math.round(H()/2-h/2),t=tx("Catatan di sini",0,0,h*.3,"#5a4b00",{name:"Isi catatan"});grp([{type:"rect",name:"Balon catatan",x,y,w,h,rx:18,fill:"#fff6c4",stroke:"#e0c200",strokeWidth:3,fx:"shadow",fxAmount:14},t,{type:"line",name:"Penunjuk",x:Math.round(x+w*.18),y:y+h,w:Math.round(W()*.1),h:Math.round(W()*.1),flipH:true,stroke:"#e0a800",strokeWidth:6,fill:"none",arrow:"end"}],()=>{t.x=Math.round(x+(w-t.w)/2);t.y=Math.round(y+(h-t.h)/2);});};
const censor=pat=>{const w=Math.round(W()*.3),h=Math.round(W()*.07);grp([{type:"rect",name:"Sensor",x:Math.round((W()-w)/2),y:Math.round(H()/2-h/2),w,h,rx:6,fill:pat?"#555555":"#111111",...(pat?{pat:"check"}:{})}]);};
MENUS.annot=()=>[{h:"Penanda & sorotan",items:[it("Penanda angka (otomatis berurutan)",marker,"ellipse"),it("Sorot seperti stabilo",hl,"pen"),it("Kotak fokus + label",focus,"rect")]},
 {h:"Catatan & sensor",items:[it("Balon catatan + penunjuk",callout,"rect"),it("Sensor hitam",()=>censor(false),"rect"),it("Sensor kotak-kotak",()=>censor(true),"grid")]}];

BT.push(["font","fontA","Font"],["cetak","print","Cetak"],["annot","note","Anotasi"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("teks").push("font");hub("berkas").push("cetak");hub("pustaka").push("annot");
})();
