/* V83: tab baru Ikon (12 ikon garis: centang, silang, plus, panah, lokasi, rumah, surat, jam, bel, kaca pembesar, tanda seru, tanda tanya; ukuran, tebal, warna, lingkaran latar opsional) dan Mockup (ponsel, tablet, laptop, jendela peramban, polaroid; warna bodi dan layar; otomatis muat halaman) di panel Penata + tombol cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const uid=()=>crypto.randomUUID();
const val=(id,d)=>{const e=$("#"+id);return e&&e.value?e.value:d;};
const chk=(id,d)=>{const e=$("#"+id);return e?e.checked:d;};
const base=(t,x,y,w,h,f)=>({id:uid(),type:t,name:t[0].toUpperCase()+t.slice(1),x:Math.round(x),y:Math.round(y),w:Math.max(1,Math.round(w)),h:Math.max(1,Math.round(h)),fill:f,stroke:"#20243a",strokeWidth:0,opacity:100,rotation:0});
const bbox=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y));return{x,y,w:Math.max(...a.map(o=>o.x+(o.w||0)))-x,h:Math.max(...a.map(o=>o.y+(o.h||0)))-y};};
function pusat(){const m=M.sels();if(chk("p83at",false)&&m.length){const exp=new Set();m.forEach(o=>(o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]).forEach(p=>exp.add(p)));const r=bbox([...exp]);return{x:r.x+r.w/2,y:r.y+r.h/2};}return{x:S.page.width/2,y:S.page.height/2};}
function taruh(a,nm,c){const g=uid();a.forEach(o=>{o.groupId=g;o.x=Math.round(o.x+c.x);o.y=Math.round(o.y+c.y);});Hi.snapshot();S.objects.push(...a);pick(a);T(nm+" disisipkan");}
function ukur(o){const est=Math.round((o.text||"").length*o.fontSize*(o.bold?.6:.56)+8);try{if(CDMS.PusatTeks){const w=CDMS.PusatTeks.ukur(o);if(w>0)return w;}}catch(e){}return est;}
/* ---- Ikon ---- */
const IKON=[["Centang","M18 54L40 76L82 26"],["Silang","M24 24L76 76M76 24L24 76"],["Plus","M50 16V84M16 50H84"],["Panah","M16 50H82M56 24L82 50L56 76"],
 ["Lokasi","M50 92C28 64 20 52 20 38A30 30 0 0 1 80 38C80 52 72 64 50 92ZM50 28A10 10 0 1 0 50.1 28Z"],["Rumah","M12 50L50 16L88 50M24 42V86H76V42M42 86V62H58V86"],
 ["Surat","M12 24H88V76H12ZM12 26L50 56L88 26"],["Jam","M14 50A36 36 0 1 0 86 50A36 36 0 1 0 14 50ZM50 28V50L66 60"],
 ["Bel","M50 12V20M24 70C28 60 28 52 28 44A22 22 0 0 1 72 44C72 52 72 60 76 70ZM42 78A8 8 0 0 0 58 78"],["Kaca","M44 14A30 30 0 1 0 44.1 14ZM66 66L88 88"],
 ["Seru","M50 18V58M50 74V78"],["Tanya","M32 36A18 18 0 1 1 52 54C50 56 50 60 50 64M50 76V80"]];
function ikon(i,opsi){const [nm,d]=IKON[i],s=Math.max(16,num("p83is",160)),tw=Math.max(1,num("p83it",8)),col=val("p83ic","#20243a"),lat=opsi&&opsi.lat!==undefined?opsi.lat:chk("p83bg",false),lc=opsi&&opsi.lc||val("p83ib","#ffc857"),ic2=opsi&&opsi.col||col,a=[];
 if(lat){const D=s*1.6,e=base("ellipse",-D/2,-D/2,D,D,lc);e.name="Latar ikon";a.push(e);}
 const o=base("path",-s/2,-s/2,s,s,"none");o.d=d;o.vw=100;o.vh=100;o.name="Ikon "+nm;o.stroke=ic2;o.strokeWidth=tw;a.push(o);
 taruh(a,"Ikon "+nm,pusat());}
/* ---- Mockup ---- */
const R=(x,y,w,h,f,x2)=>{const o=base("rect",x,y,w,h,f);Object.assign(o,{rx:0},x2||{});if(o.rx)o.rx=Math.round(o.rx);return o;};
const E=(x,y,w,h,f)=>base("ellipse",x,y,w,h,f);
function fitS(w,h){const s=Math.max(60,num("p83s",360)),k=Math.min(1,S.page.width*.92/(s*w),S.page.height*.92/(s*h));return s*k;}
function mock(kind){const body=val("p83bc","#111827"),scr=val("p83sc","#ffffff");let a=[],nm="";
 if(kind==="ph"){const s=fitS(1,2.05),w=s,h=s*2.05;nm="Mockup ponsel";a=[R(-w/2,-h/2,w,h,body,{rx:s*.14,name:"Bodi ponsel"}),R(-w/2+s*.04,-h/2+s*.04,w-s*.08,h-s*.08,scr,{rx:s*.11,name:"Layar"}),R(-s*.16,-h/2+s*.065,s*.32,s*.045,body,{rx:s*.022,name:"Notch"}),R(-s*.175,h/2-s*.09,s*.35,Math.max(2,s*.014),body,{rx:s*.007,name:"Bar beranda"})];}
 else if(kind==="tb"){const s=fitS(1.6,1.2),w=s*1.6,h=s*1.2;nm="Mockup tablet";a=[R(-w/2,-h/2,w,h,body,{rx:s*.1,name:"Bodi tablet"}),R(-w/2+s*.06,-h/2+s*.06,w-s*.12,h-s*.12,scr,{rx:s*.04,name:"Layar"}),E(w/2-s*.035,-s*.012,s*.024,s*.024,"#374151")];a[2].name="Kamera";}
 else if(kind==="lp"){const s=fitS(1.7,1.2),w=s*1.4,h=s*.92,bw=s*1.7;nm="Mockup laptop";const pb=base("path",-bw/2,h/2-s*.02,bw,s*.06,"#cbd5e1");pb.d="M2 0H98L100 100H0Z";pb.vw=100;pb.vh=100;pb.name="Alas laptop";
  a=[R(-w/2,-h/2-s*.1,w,h,body,{rx:s*.04,name:"Bodi layar"}),R(-w/2+s*.035,-h/2-s*.1+s*.035,w-s*.07,h-s*.07,scr,{rx:s*.015,name:"Layar"}),pb];}
 else if(kind==="br"){const s=fitS(1.6,1.1),w=s*1.6,h=s*1.1,th=s*.12;nm="Mockup peramban";const r=R(-w/2,-h/2,w,h,"#ffffff",{rx:s*.035,name:"Jendela"});r.stroke="#d1d5db";r.strokeWidth=2;
  const d=s*.035,y=-h/2+th/2-d/2;a=[r,R(-w/2+2,-h/2+2,w-4,th,"#e5e7eb",{rx:s*.03,name:"Bilah judul"}),E(-w/2+s*.05,y,d,d,"#ef4444"),E(-w/2+s*.05+d*1.6,y,d,d,"#f59e0b"),E(-w/2+s*.05+d*3.2,y,d,d,"#22c55e"),R(-w/2+s*.05+d*5,-h/2+th*.22,w-s*.05-d*5-s*.06,th*.56,"#ffffff",{rx:th*.28,name:"Kolom alamat"}),R(-w/2+s*.05,-h/2+th+s*.05,w-s*.1,h-th-s*.1,scr,{rx:s*.01,name:"Konten"})];a[2].name="Titik merah";a[3].name="Titik kuning";a[4].name="Titik hijau";}
 else{const s=fitS(1,1.2),w=s,h=s*1.2;nm="Polaroid";const r=R(-w/2,-h/2,w,h,"#ffffff",{rx:s*.015,name:"Kertas"});r.stroke="#e5e7eb";r.strokeWidth=2;
  const t=base("text",0,0,10,Math.round(s*.1),"#4a5070");t.text=val("p83cp","Kenangan");t.fontSize=Math.round(s*.08);t.bold=false;const tw=ukur(t);t.w=Math.round(tw);t.x=Math.round(-tw/2);t.y=Math.round(h/2-s*.17);t.name="Keterangan";
  a=[r,R(-w/2+s*.07,-h/2+s*.07,s*.86,s*.86,"#d9dcea",{name:"Foto"}),t];}
 taruh(a,nm,pusat());}
const H={};IKON.forEach((_,i)=>{H["ik"+i]=()=>ikon(i);});
Object.assign(H,{ph:()=>mock("ph"),tb:()=>mock("tb"),lp:()=>mock("lp"),br:()=>mock("br"),pl:()=>mock("pl")});
const cb=(id,l,on)=>`<label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 6px"><input id="${id}" type="checkbox" ${on?"checked":""}> ${l}</label>`;
P.addTab("ikon","Ikon",`<div class="p69btns c4">${IKON.map((x,i)=>b("ik"+i,x[0])).join("")}</div>
 <div class="p69row" style="margin-top:10px">${fld("p83is","Ukuran",160,'min="16"')}${fld("p83it","Tebal garis",8,'min="1"')}<label>Warna ikon<input id="p83ic" type="color" value="#20243a"></label><label>Warna latar<input id="p83ib" type="color" value="#ffc857"></label></div>
 ${cb("p83bg","Dengan lingkaran latar",false)}${cb("p83at","Letakkan di tengah objek terpilih",false)}<p class="muted">Ikon berupa kurva garis yang bisa diubah warna, tebal, dan ukurannya.</p>`,H);
P.addTab("mockup","Mockup",`<div class="p69btns c3">${b("ph","Ponsel")}${b("tb","Tablet")}${b("lp","Laptop")}${b("br","Peramban")}${b("pl","Polaroid")}</div>
 <div class="p69row" style="margin-top:10px">${fld("p83s","Ukuran dasar",360,'min="60"')}<label>Warna bodi<input id="p83bc" type="color" value="#111827"></label><label>Warna layar<input id="p83sc" type="color" value="#ffffff"></label><label>Teks polaroid<input id="p83cp" type="text" value="Kenangan"></label></div>
 <p class="muted">Setiap mockup berupa satu grup dan otomatis dikecilkan agar muat di halaman. Tempel gambar di atas layar/foto lalu atur posisinya.</p>`,H);
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q13="ikon" title="Ikon garis">${ic("sticker")}</button><button data-q13="mockup" title="Mockup perangkat">${ic("tall")}</button><button data-q13="centang" title="Centang bulat">${ic("eye")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q13]");if(!x)return;const k=x.dataset.q13;
  if(k==="ikon")P.openTab("ikon");else if(k==="mockup")P.openTab("mockup");else ikon(0,{lat:true,lc:"#16a34a",col:"#ffffff"});});}
MENUS.penata83=()=>[{h:"Tab Penata",items:[it("Ikon (12 ikon garis)",()=>P.openTab("ikon"),"sticker"),it("Mockup (ponsel, laptop, peramban)",()=>P.openTab("mockup"),"tall")]},{h:"Cepat",items:[it("Centang bulat hijau",()=>ikon(0,{lat:true,lc:"#16a34a",col:"#ffffff"}),"sticker"),it("Mockup ponsel",()=>mock("ph"),"tall"),it("Mockup peramban",()=>mock("br"),"tall")]}];
BT.push(["penata83","panel","Penata 14"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata83");
})();
