/* V86: grup menu baru "Kelompok" di toolbar + tab Grup & Otomatis di panel Penata (daftar grup, nama grup, kunci/sembunyi per grup,
   gabung, keluarkan anggota, tambah ke grup, duplikat, rapatkan layer, grup otomatis menurut jenis/warna/baris/kolom/tumpang tindih) + tombol cepat + Ctrl+Shift+G */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,P=CDMS.Penata,{MENUS,BT,it,sels,pick,T,cell}=M;
if(!M.HUBS||!P)return;
const addTab=(k,l,html,h)=>{const nh={};Object.keys(h).forEach(x=>{nh["x86_"+x]=h[x];});P.addTab(k,l,html.replace(/data-h="([^"]+)"/g,'data-h="x86_$1"'),nh);};
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),uid=()=>crypto.randomUUID();
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const val=(id,d)=>{const e=$("#"+id);return e&&e.value!==""?e.value:d;};
const chk=(id,d)=>{const e=$("#"+id);return e?e.checked:d;};
const b=(k,l,i)=>`<button data-h="${k}">${i?ic(i):""}<span>${l}</span></button>`;
const bbox=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y)),x2=Math.max(...a.map(o=>o.x+(o.w||0))),y2=Math.max(...a.map(o=>o.y+(o.h||0)));return{x,y,x2,y2,w:x2-x,h:y2-y};};
/* ---- data grup ---- */
function groups(){const m=new Map();S.objects.forEach(o=>{if(!o.groupId)return;if(!m.has(o.groupId))m.set(o.groupId,[]);m.get(o.groupId).push(o);});return m;}
const gname=(mem,i)=>{const n=mem.find(o=>o.groupName);return n?n.groupName:"Grup "+(i+1);};
const selGids=()=>new Set(sels().filter(o=>o.groupId).map(o=>o.groupId));
/* perluas pilihan ke seluruh anggota grup yang tersentuh */
function expand(a){const g=new Set(a.filter(o=>o.groupId).map(o=>o.groupId)),s=new Set(a);S.objects.forEach(o=>{if(o.groupId&&g.has(o.groupId))s.add(o);});return[...s];}
const members=gids=>S.objects.filter(o=>o.groupId&&gids.has(o.groupId));
function bersihTunggal(){const n=[...groups().values()].filter(m=>m.length<2);n.forEach(m=>m.forEach(o=>{delete o.groupId;delete o.groupName;}));return n.length;}
function refresh(msg){C.render();draw();if(msg)T(msg);}
/* ---- aksi dasar ---- */
function gabung(){const a=expand(sels());if(a.length<2)return T("Pilih 2 objek atau lebih (atau beberapa grup)");
 const gids=new Set(a.filter(o=>o.groupId).map(o=>o.groupId));if(gids.size===1&&a.every(o=>o.groupId))return T("Objek yang dipilih sudah satu grup");
 const nm=(a.find(o=>o.groupName)||{}).groupName;Hi.snapshot();const g=uid();a.forEach(o=>{o.groupId=g;if(nm)o.groupName=nm;else delete o.groupName;});bersihTunggal();pick(a);draw();T(gids.size>1?gids.size+" grup digabung ("+a.length+" objek)":"Objek dikelompokkan ("+a.length+")");}
function lepas(){const a=expand(sels()).filter(o=>o.groupId);if(!a.length)return T("Pilih grup dulu");const n=new Set(a.map(o=>o.groupId)).size;Hi.snapshot();a.forEach(o=>{delete o.groupId;delete o.groupName;});refresh(n+" grup dilepas");}
function keluarkan(){const a=sels().filter(o=>o.groupId);if(!a.length)return T("Pilih objek yang ada di dalam grup");
 const gs=groups(),sisa=[...new Set(a.map(o=>o.groupId))].every(g=>gs.get(g).every(o=>a.includes(o)));if(sisa)return T("Seluruh anggota terpilih; gunakan Lepas grup, atau pilih sebagian anggota (Multi / Shift)");
 Hi.snapshot();a.forEach(o=>{delete o.groupId;delete o.groupName;});bersihTunggal();refresh(a.length+" objek dikeluarkan dari grup");}
function tambahKe(gid){const gs=groups();if(!gs.has(gid))return;const loose=sels().filter(o=>!o.groupId);if(!loose.length)return T("Pilih objek yang belum berkelompok, lalu ketuk + pada grup");
 const nm=(gs.get(gid).find(o=>o.groupName)||{}).groupName;Hi.snapshot();loose.forEach(o=>{o.groupId=gid;if(nm)o.groupName=nm;});refresh(loose.length+" objek ditambahkan ke grup");}
function pilihAnggota(){const a=expand(sels()).filter(o=>o.groupId);if(!a.length)return T("Pilih grup dulu");pick(a);draw();T(a.length+" objek anggota dipilih");}
function pilihSemua(){const a=S.objects.filter(o=>o.groupId&&!o.hidden);if(!a.length)return T("Belum ada grup");pick(a);draw();T(new Set(a.map(o=>o.groupId)).size+" grup dipilih");}
function pilihLepas(){const a=S.objects.filter(o=>!o.groupId&&!o.hidden);if(!a.length)return T("Semua objek sudah berkelompok");pick(a);draw();T(a.length+" objek tanpa grup dipilih");}
/* ---- status ---- */
function targetGids(){const g=selGids();return g.size?g:null;}
function setFlag(gids,prop,v,msg){const a=members(gids);if(!a.length)return T("Pilih grup dulu");Hi.snapshot();a.forEach(o=>{if(v)o[prop]=true;else delete o[prop];});if(prop==="hidden"&&v){S.selected=null;S.selectedIds=[];}refresh(msg+" ("+gids.size+" grup)");}
function kunci(v){const g=targetGids();if(!g)return T("Pilih grup dulu");setFlag(g,"locked",v,v?"Grup dikunci":"Kunci grup dibuka");}
function sembunyi(){const g=targetGids();if(!g)return T("Pilih grup dulu");setFlag(g,"hidden",true,"Grup disembunyikan");}
function tampilSemua(){const a=S.objects.filter(o=>o.groupId&&(o.hidden||o.locked));if(!a.length)return T("Tidak ada grup yang tersembunyi atau terkunci");Hi.snapshot();a.forEach(o=>{delete o.hidden;delete o.locked;});refresh("Semua grup ditampilkan dan dibuka kuncinya");}
function beriNama(){const g=targetGids();if(!g)return T("Pilih grup dulu");const nm=String(val("p86name","")).trim();if(!nm)return T("Isi nama grup dulu");Hi.snapshot();members(g).forEach(o=>{o.groupName=nm;});refresh("Grup diberi nama “"+nm+"”");}
function duplikat(){const g=targetGids();if(!g)return T("Pilih grup dulu");Hi.snapshot();const baru=[];
 g.forEach(gid=>{const asli=S.objects.filter(o=>o.groupId===gid),id2=uid(),nm=(asli.find(o=>o.groupName)||{}).groupName;
  asli.forEach(o=>{const c=JSON.parse(JSON.stringify(o));c.id=uid();c.groupId=id2;c.x=Math.round(o.x+24);c.y=Math.round(o.y+24);delete c.locked;delete c.hidden;if(nm)c.groupName=nm+" salinan";baru.push(c);});});
 S.objects.push(...baru);pick(baru);draw();T(g.size+" grup diduplikat");}
function hapus(){const g=targetGids();if(!g)return T("Pilih grup dulu");const a=members(g);Hi.snapshot();S.objects=S.objects.filter(o=>!a.includes(o));S.selected=null;S.selectedIds=[];refresh(g.size+" grup dihapus ("+a.length+" objek)");}
function tengah(){const g=targetGids();if(!g)return T("Pilih grup dulu");Hi.snapshot();g.forEach(gid=>{const m=S.objects.filter(o=>o.groupId===gid),r=bbox(m),dx=(S.page.width-r.w)/2-r.x,dy=(S.page.height-r.h)/2-r.y;m.forEach(o=>{o.x=Math.round(o.x+dx);o.y=Math.round(o.y+dy);});});refresh("Grup ditengahkan di halaman");}
function rapatkan(){const gs=groups(),g=targetGids()||new Set(gs.keys());if(!g.size)return T("Belum ada grup");Hi.snapshot();let n=0;
 g.forEach(gid=>{const arr=S.objects,mem=arr.filter(o=>o.groupId===gid);if(mem.length<2)return;const top=Math.max(...mem.map(o=>arr.indexOf(o))),at=arr.slice(0,top+1).filter(o=>o.groupId!==gid).length,rest=arr.filter(o=>o.groupId!==gid);
  const before=arr.map(o=>o.id).join();rest.splice(at,0,...mem);S.objects=rest;if(S.objects.map(o=>o.id).join()!==before)n++;});
 refresh(n?n+" grup dirapatkan di urutan layer":"Layer grup sudah rapat");}
function bersihkan(){Hi.snapshot();const n=bersihTunggal();refresh(n?n+" grup beranggota satu dibersihkan":"Tidak ada grup yang perlu dibersihkan");}
/* ---- grup otomatis ---- */
const JENIS={rect:"Persegi",ellipse:"Elips",star:"Bintang",line:"Garis",text:"Teks",image:"Gambar",path:"Bentuk",polygon:"Poligon"};
const hexOk=c=>typeof c==="string"&&/^#[0-9a-f]{6}$/i.test(c.trim());
function warnaKunci(o){const c=hexOk(o.fill)?o.fill:(Array.isArray(o.grad)&&hexOk(o.grad[0])?o.grad[0]:null);return c?c.toLowerCase():"tanpa isi";}
function klaster(a,sumbu){const k=sumbu==="y"?"y":"x",sz=sumbu==="y"?"h":"w",s=[...a].sort((p,q)=>p[k]-q[k]),out=[];let cur=null,ujung=-Infinity;
 s.forEach(o=>{if(!cur||o[k]>ujung){cur=[];out.push(cur);ujung=-Infinity;}cur.push(o);ujung=Math.max(ujung,o[k]+(o[sz]||0));});return out;}
function tumpang(a,gap){const p=a.map((_,i)=>i),f=i=>{while(p[i]!==i){p[i]=p[p[i]];i=p[i];}return i;},r=a.map(o=>({x:o.x-gap,y:o.y-gap,x2:o.x+(o.w||0)+gap,y2:o.y+(o.h||0)+gap}));
 for(let i=0;i<a.length;i++)for(let j=i+1;j<a.length;j++)if(r[i].x<r[j].x2&&r[j].x<r[i].x2&&r[i].y<r[j].y2&&r[j].y<r[i].y2)p[f(i)]=f(j);
 const m=new Map();a.forEach((o,i)=>{const k=f(i);if(!m.has(k))m.set(k,[]);m.get(k).push(o);});return[...m.values()];}
function otomatis(mode){const lepasSaja=chk("p86only",true),a=S.objects.filter(o=>!o.locked&&!o.hidden&&(!lepasSaja||!o.groupId));if(a.length<2)return T("Butuh minimal 2 objek yang bisa dikelompokkan");
 let sets=[],nama=i=>"Grup "+i;
 if(mode==="jenis"){const m=new Map();a.forEach(o=>{if(!m.has(o.type))m.set(o.type,[]);m.get(o.type).push(o);});sets=[...m.entries()].map(([k,v])=>({v,n:JENIS[k]||k}));}
 else if(mode==="warna"){const m=new Map();a.forEach(o=>{const k=warnaKunci(o);if(!m.has(k))m.set(k,[]);m.get(k).push(o);});sets=[...m.entries()].map(([k,v])=>({v,n:"Warna "+k.toUpperCase()}));}
 else if(mode==="baris")sets=klaster(a,"y").map((v,i)=>({v,n:"Baris "+(i+1)}));
 else if(mode==="kolom")sets=klaster(a,"x").map((v,i)=>({v,n:"Kolom "+(i+1)}));
 else sets=tumpang(a,Math.max(0,parseFloat(val("p86gap",0))||0)).map((v,i)=>({v,n:"Gugus "+(i+1)}));
 sets=sets.filter(s=>s.v.length>=2);if(!sets.length)return T("Tidak ada kelompok dengan 2 objek atau lebih");
 Hi.snapshot();const touched=new Set(sets.flatMap(s=>s.v));
 /* anggota grup lama yang diambil dikeluarkan dari grup asalnya agar tidak tertinggal sendirian */
 touched.forEach(o=>{delete o.groupId;delete o.groupName;});
 sets.forEach(s=>{const g=uid();s.v.forEach(o=>{o.groupId=g;o.groupName=s.n;});});bersihTunggal();
 draw();C.render();T(sets.length+" grup dibuat dari "+touched.size+" objek");}
/* ---- daftar grup (tab Grup) ---- */
function draw(){const box=$("#p86list");if(!box)return;const gs=groups(),sg=selGids();let i=0;
 box.innerHTML=gs.size?[...gs.entries()].map(([gid,m])=>{const nm=gname(m,i++),lk=m.every(o=>o.locked),hd=m.every(o=>o.hidden);
  return `<div class="p86row${sg.has(gid)?" on":""}"><button class="p86nm" data-p86="sel" data-g="${gid}" title="Pilih grup"><b>${esc(nm)}</b><small>${m.length} objek</small></button><button data-p86="add" data-g="${gid}" title="Tambahkan objek terpilih ke grup">${ic("plus")}</button><button data-p86="lock" data-g="${gid}" class="${lk?"on":""}" title="Kunci / buka">${ic(lk?"lock":"unlock")}</button><button data-p86="eye" data-g="${gid}" class="${hd?"on":""}" title="Tampil / sembunyi">${ic(hd?"eyeoff":"eye")}</button></div>`;}).join(""):'<div class="kosong">Belum ada grup. Pilih beberapa objek lalu ketuk Kelompokkan.</div>';
 const inf=$("#p86info");if(inf){const tot=[...gs.values()].reduce((t,m)=>t+m.length,0);inf.textContent=gs.size+" grup · "+tot+" dari "+S.objects.length+" objek";}}
function klikBaris(e){const x=e.target.closest&&e.target.closest("[data-p86]");if(!x)return false;const gid=x.dataset.g,m=S.objects.filter(o=>o.groupId===gid);if(!m.length)return true;
 const k=x.dataset.p86;
 if(k==="sel"){pick(m.filter(o=>!o.hidden));draw();}
 else if(k==="add")tambahKe(gid);
 else if(k==="lock"){const v=!m.every(o=>o.locked);setFlag(new Set([gid]),"locked",v,v?"Grup dikunci":"Kunci grup dibuka");}
 else if(k==="eye"){const v=!m.every(o=>o.hidden);setFlag(new Set([gid]),"hidden",v,v?"Grup disembunyikan":"Grup ditampilkan");}
 return true;}
const H={gb:gabung,lp:lepas,kl:keluarkan,pa:pilihAnggota,pg:pilihSemua,pt:pilihLepas,kc:()=>kunci(true),bk:()=>kunci(false),sm:sembunyi,tp:tampilSemua,nm:beriNama,dp:duplikat,hp:hapus,tg:tengah,rp:rapatkan,bs:bersihkan,sr:draw,
 a1:()=>otomatis("jenis"),a2:()=>otomatis("warna"),a3:()=>otomatis("baris"),a4:()=>otomatis("kolom"),a5:()=>otomatis("tumpang")};
addTab("grup","Grup",`<div class="p69h">Daftar grup <span id="p86info" class="muted" style="font-weight:400"></span></div><div id="p86list" class="p86list"></div>
 <p class="muted" style="margin:-2px 0 8px">Ketuk nama untuk memilih grup. + menambahkan objek terpilih ke grup itu; gembok dan mata mengunci atau menyembunyikan satu grup.</p>
 <div class="p69btns c3">${b("gb","Kelompokkan","group")}${b("lp","Lepas","ungroup")}${b("kl","Keluarkan","minus")}</div>
 <div class="p69h" style="margin-top:12px">Nama grup</div><div class="p69row"><label>Nama baru<input id="p86name" type="text" maxlength="40" placeholder="mis. Header"></label></div>
 <div class="p69btns">${b("nm","Beri nama","text")}${b("dp","Duplikat grup","copy")}</div>
 <div class="p69h" style="margin-top:12px">Pilih</div><div class="p69btns c3">${b("pa","Anggota")}${b("pg","Semua grup")}${b("pt","Tanpa grup")}</div>
 <div class="p69h" style="margin-top:12px">Status & tata</div><div class="p69btns c3">${b("kc","Kunci","lock")}${b("bk","Buka kunci","unlock")}${b("sm","Sembunyikan","eyeoff")}${b("tp","Tampilkan semua","eye")}${b("tg","Tengahkan","arrange")}${b("rp","Rapatkan layer","layers")}</div>
 <div class="p69btns" style="margin-top:6px">${b("bs","Bersihkan grup tunggal")}${b("hp","Hapus grup","trash")}</div>`,H);
addTab("oto","Otomatis",`<p class="muted" style="margin:0 0 8px">Buat banyak grup sekaligus. Tiap grup memakai nama otomatis dan bisa diubah di tab Grup.</p>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 8px"><input id="p86only" type="checkbox" checked> Hanya objek yang belum berkelompok</label>
 <div class="p69btns">${b("a1","Menurut jenis","shapes")}${b("a2","Menurut warna isi","color")}${b("a3","Menurut baris","distribute")}${b("a4","Menurut kolom","align")}</div>
 <div class="p69h" style="margin-top:12px">Tumpang tindih</div><div class="p69row"><label>Celah toleransi (px)<input id="p86gap" type="number" value="0" min="0"></label></div>
 <div class="p69btns">${b("a5","Gugus yang bersentuhan","stack")}</div>
 <p class="muted" style="margin:10px 0 0">Objek terkunci dan tersembunyi dilewati. Grup dengan satu anggota tidak dibuat. Semua bisa di-undo.</p>`,H);
document.addEventListener("click",e=>{if(klikBaris(e))return;if(e.target.closest&&e.target.closest(".p69 [data-t=grup]"))setTimeout(draw,0);});
/* segarkan daftar saat seleksi/objek berubah */
let raf=0;const r0=C.render;C.render=function(){const v=r0.apply(this,arguments);if(!raf&&$("#p86list")){raf=requestAnimationFrame(()=>{raf=0;draw();});}return v;};
/* ---- tombol cepat, menu, hub ---- */
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q86="panel" title="Panel grup">${ic("stack")}</button><button data-q86="gabung" title="Kelompokkan / gabung grup">${ic("group")}</button><button data-q86="kunci" title="Kunci / buka grup">${ic("lock")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q86]");if(!x)return;const k=x.dataset.q86;
  if(k==="panel"){P.openTab("grup");draw();}else if(k==="gabung")gabung();else{const g=targetGids();if(!g)return T("Pilih grup dulu");kunci(!members(g).every(o=>o.locked));}});}
MENUS.kel1=()=>[{h:"Kelola grup",items:[it("Kelompokkan / gabung grup",gabung,"group"),it("Lepas kelompok",lepas,"ungroup"),it("Keluarkan dari grup",keluarkan,"minus"),it("Duplikat grup",duplikat,"copy"),it("Hapus grup",hapus,"trash")]},{h:"Pilih",items:[it("Pilih seluruh anggota",pilihAnggota,"select"),it("Pilih semua grup",pilihSemua,"group"),it("Pilih objek tanpa grup",pilihLepas,"select")]}];
MENUS.kel2=()=>[{h:"Status grup",items:[it("Kunci grup",()=>kunci(true),"lock"),it("Buka kunci grup",()=>kunci(false),"unlock"),it("Sembunyikan grup",sembunyi,"eyeoff"),it("Tampilkan & buka semua grup",tampilSemua,"eye")]},{h:"Tata",items:[it("Beri nama grup…",()=>{P.openTab("grup");draw();setTimeout(()=>{const e=$("#p86name");if(e)e.focus();},60);},"text"),it("Tengahkan grup di halaman",tengah,"arrange"),it("Rapatkan layer grup",rapatkan,"layers"),it("Bersihkan grup beranggota satu",bersihkan,"trash")]}];
MENUS.kel3=()=>[{h:"Grup otomatis (objek tanpa grup)",items:[it("Menurut jenis objek",()=>otomatis("jenis"),"shapes"),it("Menurut warna isi",()=>otomatis("warna"),"color"),it("Menurut baris",()=>otomatis("baris"),"distribute"),it("Menurut kolom",()=>otomatis("kolom"),"align"),it("Menurut objek yang bersentuhan",()=>otomatis("tumpang"),"stack")]},{h:"Panel",items:[it("Buka tab Otomatis",()=>P.openTab("oto"),"sparkles")]}];
MENUS.kelpanel=()=>[{h:"Panel Grup",items:[it("Buka daftar grup",()=>{P.openTab("grup");draw();},"stack"),it("Buka grup otomatis",()=>P.openTab("oto"),"sparkles")]}];
BT.push(["kel1","group","Kelola"],["kel2","lock","Status"],["kel3","sparkles","Otomatis"],["kelpanel","stack","Panel grup"]);
const KEL=["kel1","kel2","kel3","kelpanel"];
const ai=M.HUBS.findIndex(h=>h[0]==="atur");
M.HUBS.splice(ai<0?M.HUBS.length:ai+1,0,["kelompok","group","Kelompok",KEL]);
MENUS.hub_kelompok=()=>[{h:"Kelompok",items:KEL.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($('[data-menu="hub_kelompok"]'),k),0));})}];
/* Ctrl+Shift+G = lepas kelompok (menimpa Ctrl+G biasa yang mengelompokkan) */
window.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.shiftKey&&(e.key==="G"||e.key==="g")){const t=e.target;if(t&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))return;e.preventDefault();e.stopImmediatePropagation();lepas();}},true);
const ot=P.openTab;P.openTab=function(){const r=ot.apply(this,arguments);setTimeout(()=>{draw();},0);return r;};
})();
