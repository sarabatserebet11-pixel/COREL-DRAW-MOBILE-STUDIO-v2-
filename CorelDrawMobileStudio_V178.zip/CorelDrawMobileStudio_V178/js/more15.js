/* V28: menu Huruf (pisah huruf/kata + efek per huruf) dan Bayangan (pengaturan kustom) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID();
function ask(title,html,cb){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">Terapkan</button></div>`);$("#aOk").onclick=cb;}
function hslHex(h,s,l){h=((h%360)+360)%360;s/=100;l/=100;const f=n=>{const k=(n+h/30)%12,a=s*Math.min(l,1-l);return Math.round(255*(l-a*Math.max(-1,Math.min(k-3,9-k,1)))).toString(16).padStart(2,"0");};return"#"+f(0)+f(8)+f(4);}

/* ---- pisah huruf / kata ---- */
function split(mode){const a=sels().filter(o=>o.type==="text"&&!o.rotation);if(!a.length)return T("Pilih teks (tanpa rotasi) dulu");Hi.snapshot();const out=[],meta=new Map();
 a.forEach(o=>{const fs=o.fontSize||64,g=uid();String(o.text||"").split("\n").forEach((ln,li)=>{const units=mode==="word"?ln.split(/(\s+)/).filter(Boolean):[...ln];
  units.forEach(u=>{if(!u.trim()){out.push({sp:fs*.32*u.length,k:o.id,li});return;}const c={...o,id:uid(),groupId:g,text:u,name:(mode==="word"?"Kata ":"Huruf ")+u};delete c.align;delete c.lh;out.push(c);meta.set(c.id,{k:o.id,li,ox:o.x,oy:o.y+li*fs*(o.lh||1.2)});});});});
 const real=out.filter(c=>c.id),i=S.objects.indexOf(a[0]),set=new Set(a.map(o=>o.id));S.objects=S.objects.filter(o=>!set.has(o.id));S.objects.splice(i,0,...real);pick(real);
 let key="",cx=0;out.forEach(c=>{const kk=c.k||meta.get(c.id).k,ll=c.li??meta.get(c.id).li;if(kk+"|"+ll!==key){key=kk+"|"+ll;cx=0;}if(c.sp){cx+=c.sp;return;}const m=meta.get(c.id);c.x=Math.round(m.ox+cx);c.y=Math.round(m.oy);cx+=c.w;});
 C.render();T(real.length+" bagian dibuat");}
const texts=()=>sels().filter(o=>o.type==="text").sort((p,q)=>p.x-q.x);
function eff(fn,msg){const a=texts();if(a.length<2)return T("Pilih beberapa huruf (hasil Pisah huruf)");Hi.snapshot();const y0=Math.min(...a.map(o=>o.y));fn(a,y0);C.render();if(msg)T(msg);}
MENUS.huruf=()=>[
 {h:"Pisah teks",items:[it("Pisah per huruf",()=>split("char"),"text"),it("Pisah per kata",()=>split("word"),"text")]},
 {h:"Efek per huruf",items:[
  it("Warna pelangi",()=>eff(a=>a.forEach((o,i)=>{o.fill=hslHex(i*360/a.length,85,58);})),"color"),
  it("Melompat",()=>eff((a,y0)=>a.forEach((o,i)=>{const fs=o.fontSize||64;o.y=Math.round(y0+(i%2?fs*.14:0));o.rotation=(i%2?8:-8);})),"redo"),
  it("Tangga turun",()=>eff((a,y0)=>a.forEach((o,i)=>{o.y=Math.round(y0+i*(o.fontSize||64)*.12);})),"arrange"),
  it("Gelombang",()=>eff((a,y0)=>a.forEach((o,i)=>{const fs=o.fontSize||64;o.y=Math.round(y0+fs*.25*(1+Math.sin(i*.9)));})),"redo"),
  it("Rapikan kembali",()=>eff((a,y0)=>a.forEach(o=>{o.y=Math.round(y0);o.rotation=0;})),"undo")]}];

/* ---- bayangan kustom ---- */
const rgba=(h,a)=>{const n=parseInt(h.slice(1),16);return `rgba(${n>>16},${(n>>8)&255},${n&255},${a})`;};
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);const k=o.sh;
 if(k){const f=`drop-shadow(${k.x}px ${k.y}px ${k.b}px ${rgba(k.c,k.o)})`;s=s.includes('style="filter:')?s.replace('style="filter:',`style="filter:${f} `):s.replace('style="cursor:',`style="filter:${f};cursor:`);}
 return s;};
const setSh=(x,y,b,c,o)=>edit(ob=>{ob.sh={x,y,b,c,o};},"Bayangan diterapkan");
function custom(){const a=sels()[0],k=(a&&a.sh)||{x:8,y:10,b:14,c:"#000000",o:.4};
 ask("Bayangan kustom",`<div class="st-grid"><label>Geser X<input id="shX" type="number" value="${k.x}"></label><label>Geser Y<input id="shY" type="number" value="${k.y}"></label></div><div class="st-grid"><label>Blur<input id="shB" type="number" min="0" value="${k.b}"></label><label>Warna<input id="shC" type="color" value="${k.c}"></label></div><label>Transparansi<input id="shO" type="range" min="5" max="100" value="${Math.round(k.o*100)}"></label>`,()=>{const v=[+$("#shX").value||0,+$("#shY").value||0,Math.max(0,+$("#shB").value||0),$("#shC").value,(+$("#shO").value||40)/100];N.closeModal();setSh(...v);});}
MENUS.shadow=()=>[
 {h:"Preset bayangan",items:[it("Lembut",()=>setSh(0,6,14,"#000000",.25),"layers"),it("Tegas",()=>setSh(6,8,2,"#000000",.5),"layers"),it("Jatuh jauh",()=>setSh(18,22,26,"#000000",.35),"layers"),it("Ambient (tanpa arah)",()=>setSh(0,0,28,"#000000",.4),"layers"),it("Berwarna ungu",()=>setSh(0,10,20,"#6d5dfc",.6),"color")]},
 {h:"Kustom",items:[it("Atur bayangan sendiri…",custom,"settings"),it("Hapus bayangan",()=>edit(o=>{delete o.sh;},"Bayangan dihapus"),"trash")]}];

BT.push(["huruf","fontA","Huruf"],["shadow","shadow","Bayangan"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("teks").push("huruf");hub("warna").push("shadow");
})();
