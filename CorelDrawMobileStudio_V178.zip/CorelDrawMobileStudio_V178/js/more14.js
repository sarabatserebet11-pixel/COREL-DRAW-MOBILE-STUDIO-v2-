/* V27: gambar bentuk dengan drag, filter tambahan, menu Zoom dan Poligon+ */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc,cell}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;

/* ---- gambar bentuk dengan menyeret ---- */
const SH=["rect","ellipse","star","polygon","line"],pd=C.pointerDown,pm=C.pointerMove;
C.pointerDown=function(e){const tool=S.tool,n=S.objects.length;pd.call(this,e);
 if(SH.includes(tool)&&S.objects.length>n){const o=S.objects[S.objects.length-1];S.drag={mode:"draw",id:o.id,start:this.point(e),active:false};this.svg.setPointerCapture&&this.svg.setPointerCapture(e.pointerId);}};
C.pointerMove=function(e){const d=S.drag;
 if(d&&d.mode==="draw"){const o=S.objects.find(x=>x.id===d.id);if(!o)return;const p=this.point(e);let dx=p.x-d.start.x,dy=p.y-d.start.y;
  if(!d.active){if(Math.hypot(dx,dy)<10)return;d.active=true;}
  if(e.shiftKey&&o.type!=="line"){const m=Math.max(Math.abs(dx),Math.abs(dy));dx=(dx<0?-1:1)*m;dy=(dy<0?-1:1)*m;}
  o.x=Math.round(Math.min(d.start.x,d.start.x+dx));o.y=Math.round(Math.min(d.start.y,d.start.y+dy));o.w=Math.max(1,Math.round(Math.abs(dx)));o.h=o.type==="line"?Math.round(Math.abs(dy)):Math.max(1,Math.round(Math.abs(dy)));
  if(o.type==="line"){if(dx*dy<0)o.flipH=true;else delete o.flipH;}
  this.render();return;}
 pm.call(this,e);};

/* ---- filter tambahan ---- */
const F=(id,b)=>`<filter id="${id}" x="-20%" y="-20%" width="140%" height="140%">${b}</filter>`;
Object.assign(M.FXS,{
 pixel:id=>F(id,'<feFlood x="4" y="4" height="2" width="2"/><feComposite width="10" height="10"/><feTile result="a"/><feComposite in="SourceGraphic" in2="a" operator="in"/><feMorphology operator="dilate" radius="4"/>'),
 edge:id=>F(id,'<feMorphology in="SourceAlpha" operator="dilate" radius="3" result="d"/><feComposite in="d" in2="SourceAlpha" operator="out" result="o"/><feFlood flood-color="#20243a"/><feComposite in2="o" operator="in"/>'),
 nowhite:id=>F(id,'<feColorMatrix type="matrix" values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 -1 -1 -1 2.6 0"/>'),
 noblack:id=>F(id,'<feColorMatrix type="matrix" values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 1 1 1 -.4 0"/>'),
 sepia:id=>F(id,'<feColorMatrix type="matrix" values=".393 .769 .189 0 0 .349 .686 .168 0 0 .272 .534 .131 0 0 0 0 0 1 0"/>'),
 invert:id=>F(id,'<feComponentTransfer><feFuncR type="table" tableValues="1 0"/><feFuncG type="table" tableValues="1 0"/><feFuncB type="table" tableValues="1 0"/></feComponentTransfer>')});
const os=MENUS.sfx;
MENUS.sfx=()=>{const s=os();s.splice(1,0,{h:"Filter tambahan",items:[["Pikselasi","pixel"],["Hanya kontur luar","edge"],["Hapus latar putih","nowhite"],["Hapus latar hitam","noblack"],["Sepia","sepia"],["Negatif","invert"]].map(x=>it(x[0],()=>edit(o=>{o.svgfx=x[1];},"Filter diterapkan"),"studio"))});return s;};

/* ---- zoom ---- */
function zoomTo(list){if(!list.length)return T("Belum ada objek");const x0=Math.min(...list.map(o=>o.x)),y0=Math.min(...list.map(o=>o.y)),x1=Math.max(...list.map(o=>o.x+o.w)),y1=Math.max(...list.map(o=>o.y+(o.h||0))),vp=$("#canvasViewport"),v=vp.getBoundingClientRect(),s=C.svg.getBoundingClientRect().width/W(),z=+($("#zoomRange")&&$("#zoomRange").value)||100,f=Math.min(v.width*.8/(Math.max(1,x1-x0)*s),v.height*.8/(Math.max(1,y1-y0)*s));
 C.setZoom(Math.max(25,Math.min(200,Math.round(z*f))));
 requestAnimationFrame(()=>{const r=C.svg.getBoundingClientRect(),s2=r.width/W();vp.scrollLeft+=r.left+((x0+x1)/2)*s2-(v.left+v.width/2);vp.scrollTop+=r.top+((y0+y1)/2)*s2-(v.top+v.height/2);});}
MENUS.zoom=()=>[{h:"Zoom cepat",items:[25,50,75,100,150,200].map(z=>tc(z+"%",()=>C.setZoom(z)))},
 {h:"Zoom cerdas",items:[it("Zoom ke objek terpilih",()=>zoomTo(sels()),"search"),it("Zoom ke semua objek",()=>zoomTo(S.objects),"search"),it("Pas ke layar",()=>C.setZoom(100),"grid")]}];

/* ---- poligon & bintang beraturan ---- */
const NAMES={3:"Segitiga",4:"Belah ketupat",5:"Segi lima",6:"Segi enam",7:"Segi tujuh",8:"Segi delapan",10:"Segi sepuluh",12:"Segi dua belas"};
const f1=v=>v.toFixed(1),P=(r,a)=>[50+r*Math.cos(a),50+r*Math.sin(a)];
const dPoly=n=>"M"+Array.from({length:n},(_,i)=>P(48,-Math.PI/2+2*Math.PI*i/n).map(f1).join(" ")).join("L")+"Z";
const dStar=(n,k)=>"M"+Array.from({length:2*n},(_,i)=>P(i%2?48*k:48,-Math.PI/2+Math.PI*i/n).map(f1).join(" ")).join("L")+"Z";
const dGear=t=>{const st=2*Math.PI/t,pts=[];for(let i=0;i<t;i++){const b=-Math.PI/2+i*st;[[-.3,38],[-.15,48],[.15,48],[.3,38]].forEach(q=>pts.push(P(q[1],b+q[0]*st).map(f1).join(" ")));}return"M"+pts.join("L")+"Z";};
const PC=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4f83ff","#ff7ac8"];let ci=0;
function addShape(name,d){Hi.snapshot();const z=Math.round(Math.min(W(),H())*.25),o={id:uid(),type:"path",name,x:Math.round((W()-z)/2),y:Math.round((H()-z)/2),w:z,h:z,vw:100,vh:100,d,fill:PC[ci++%6],stroke:"none",strokeWidth:0,opacity:100,rotation:0};S.objects.push(o);pick([o]);}
const pv=(d,c)=>`<svg class="s" viewBox="0 0 100 100"><path d="${d}" fill="${c}"/></svg>`;
MENUS.ngon=()=>[{h:"Poligon beraturan",items:[3,4,5,6,7,8,10,12].map((n,i)=>cell(pv(dPoly(n),PC[i%6])+`<span>${NAMES[n]}</span>`,()=>addShape(NAMES[n],dPoly(n))))},
 {h:"Bintang & roda gigi",items:[[5,.45,"Bintang 5"],[6,.5,"Bintang 6"],[8,.6,"Bintang 8"],[12,.75,"Bintang 12"]].map((x,i)=>cell(pv(dStar(x[0],x[1]),PC[i%6])+`<span>${x[2]}</span>`,()=>addShape(x[2],dStar(x[0],x[1])))).concat([[8,"Roda gigi 8"],[12,"Roda gigi 12"]].map(x=>cell(pv(dGear(x[0]),"#8a93aa")+`<span>${x[1]}</span>`,()=>addShape(x[1],dGear(x[0])))))}];

BT.push(["zoom","zoom","Zoom"],["ngon","polygon","Poligon+"]);
const hub=n=>M.HUBS.find(h=>h[0]===n)[3];hub("kanvas").push("zoom");hub("buat").push("ngon");
})();
