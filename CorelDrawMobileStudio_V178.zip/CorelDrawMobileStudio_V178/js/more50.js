/* V61: menu Gaya Huruf (teks terpilih: bergantian, terbalik, spasi lebar, judul cerdas, slug, hapus aksen, ulang kata) dan Ucapan (6 kartu ucapan siap edit) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,tc,sels,T}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,STAR,AC,INK,MUTE}=K;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const WHT="#ffffff";
/* ---------- Gaya Huruf ---------- */
function fit(o){const f=CDMS.Rapikan&&CDMS.Rapikan.fit;if(f)f(o);}
function tedit(fn,label){const a=sels().filter(o=>o.type==="text");if(!a.length)return T("Pilih teks dulu");
 Hi.snapshot();let n=0;a.forEach(o=>{const r=fn(String(o.text||""));if(r!=null&&r!==o.text){o.text=r;fit(o);n++;}});C.render();T(n?label+" · "+n+" teks":"Tidak ada yang berubah");}
const KECIL=new Set(["di","ke","dari","dan","atau","yang","untuk","pada","dengan","dalam","oleh","serta","the","of","and","in","to","a"]);
const OPS={
 bergantian:s=>{let i=0;return Array.from(s).map(c=>/\p{L}/u.test(c)?(i++%2?c.toUpperCase():c.toLowerCase()):c).join("");},
 terbalik:s=>s.split("\n").map(l=>Array.from(l).reverse().join("")).join("\n"),
 balikKata:s=>s.split("\n").map(l=>l.split(/\s+/).reverse().join(" ")).join("\n"),
 lebar:s=>s.split("\n").map(l=>l.split(/ +/).map(w=>Array.from(w).join(" ")).join("   ")).join("\n"),
 rapat:s=>s.split("\n").map(l=>l.split(/ {3,}/).map(w=>/^\S( \S)+$/.test(w)?w.replace(/ /g,""):w).join(" ")).join("\n"),
 judul:s=>s.toLowerCase().replace(/(^|[\s(“"'-])(\p{L})(\p{L}*)/gu,(m,a,b,c,off)=>{const w=b+c;return a+((off>0&&KECIL.has(w))?w:b.toUpperCase()+c);}),
 slug:s=>s.normalize("NFD").replace(/[̀-ͯ]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,""),
 aksen:s=>s.normalize("NFD").replace(/[̀-ͯ]/g,"").normalize("NFC"),
 hashtag:s=>s.split(/\s+/).filter(Boolean).map(w=>"#"+w.normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^\p{L}\p{N}]/gu,"")).filter(w=>w.length>1).join(" "),
 ulang:s=>s.trim()?s+" "+s.trim()+" "+s.trim():s
};
MENUS.gayahuruf=()=>[
 {h:"Gaya",items:[tc("aLtErNaTiNg",()=>tedit(OPS.bergantian,"Huruf bergantian")),tc("Judul cerdas (Kapital Tiap Kata, kecuali di/ke/dan…)",()=>tedit(OPS.judul,"Judul cerdas")),tc("Spasi lebar T E K S",()=>tedit(OPS.lebar,"Spasi lebar")),tc("Rapatkan spasi lebar",()=>tedit(OPS.rapat,"Spasi dirapatkan"))]},
 {h:"Balik",items:[tc("Huruf terbalik",()=>tedit(OPS.terbalik,"Huruf dibalik")),tc("Urutan kata terbalik",()=>tedit(OPS.balikKata,"Kata dibalik"))]},
 {h:"Konversi",items:[tc("Slug-url-seperti-ini",()=>tedit(OPS.slug,"Slug")),tc("#Hashtag dari kata",()=>tedit(OPS.hashtag,"Hashtag")),tc("Hapus aksen (é → e)",()=>tedit(OPS.aksen,"Aksen dihapus")),tc("Ulang 3 kali",()=>tedit(OPS.ulang,"Diulang"))]}];
BT.push(["gayahuruf","fontA","Gaya Huruf"]);
hubAdd("teks","gayahuruf");
/* ---------- Ucapan ---------- */
const dot=(x,y,d,c)=>E(x,y,d,d,c);
const kartu=(w,h,bg,name,a)=>({w,h,a:[R(0,0,w,h,bg,{rx:36,name}),...a]});
Object.assign(COMP,{
 "Ulang tahun":()=>kartu(560,700,"#fff1f6","Ucapan ulang tahun",[...[[60,70,"#ff6b9d"],[150,40,"#ffc857"],[250,60,"#6d5dfc"],[350,36,"#00c9a7"],[440,66,"#ff6b9d"]].map(d=>dot(d[0],d[1],34,d[2])),R(160,300,240,150,"#ff6b9d",{rx:24}),R(160,300,240,44,"#ffc857",{rx:22}),R(274,230,12,70,INK,{rx:6}),E(268,196,24,40,"#ffb020"),X("Selamat",280,520,40,INK,{bold:1}),X("Ulang Tahun!",280,580,56,"#e11d74",{bold:1}),X("Semoga panjang umur dan bahagia",280,640,22,MUTE)]),
 "Terima kasih":()=>kartu(560,700,"#e9fbf7","Ucapan terima kasih",[P(180,100,200,180,"M50 88C10 58 6 34 22 20C34 10 46 16 50 28C54 16 66 10 78 20C94 34 90 58 50 88Z","#00c9a7"),ring(130,60,300,"#00c9a7",4),X("Terima",280,400,64,INK,{bold:1}),X("Kasih",280,478,84,"#00a98d",{bold:1}),R(210,530,140,6,"#00c9a7",{rx:3}),X("Atas dukungan dan kepercayaan Anda",280,590,24,MUTE)]),
 "Selamat Lebaran":()=>kartu(560,700,"#0f3d33","Ucapan Lebaran",[E(150,70,260,260,"#ffd166"),E(210,40,240,240,"#0f3d33"),P(380,90,60,60,STAR,"#ffd166"),R(100,420,360,4,"#ffd166",{rx:2}),X("Selamat Hari Raya",280,380,34,"#ffd166",{bold:1}),X("IDULFITRI",280,490,70,WHT,{bold:1}),X("Mohon maaf lahir dan batin",280,570,26,"#cdeee3"),X("Taqabbalallahu minna wa minkum",280,630,20,"#9fd8c8")]),
 "Tahun Baru":()=>kartu(560,700,"#12122b","Ucapan tahun baru",[...[[90,80,"#ffc857"],[430,120,"#ff6b9d"],[240,50,"#00c9a7"],[470,300,"#6d5dfc"],[60,280,"#ff6b9d"]].map(d=>P(d[0],d[1],44,44,STAR,d[2])),X("2027",280,300,150,"#ffc857",{bold:1}),X("SELAMAT TAHUN BARU",280,430,36,WHT,{bold:1}),R(180,470,200,5,"#ff6b9d",{rx:3}),X("Semoga tahun ini penuh berkah",280,540,26,"#c8cee6"),X("dan kesempatan baru",280,584,26,"#c8cee6")]),
 "17 Agustus":()=>kartu(560,700,WHT,"Ucapan 17 Agustus",[R(0,0,560,300,"#d62839",{rx:36}),R(0,270,560,32,"#d62839"),R(0,300,560,2,"#ffffff"),X("DIRGAHAYU",280,110,64,WHT,{bold:1}),X("Republik Indonesia",280,190,38,WHT,{bold:1}),X("17",280,400,160,"#d62839",{bold:1}),X("AGUSTUS",280,520,50,INK,{bold:1}),X("Merdeka! Bersatu, berdaulat, maju",280,610,24,MUTE)]),
 "Selamat Natal":()=>kartu(560,700,"#0e3b2e","Ucapan Natal",[P(150,70,260,300,"M50 0L90 45H68L100 85H60V100H40V85H0L32 45H10Z","#1f8a4c"),P(255,40,50,50,STAR,"#ffd166"),dot(190,240,24,"#ef4444"),dot(310,290,24,"#ffd166"),dot(240,170,20,"#ffd166"),X("Selamat Natal",280,450,60,WHT,{bold:1}),X("& Tahun Baru",280,520,40,"#ffd166",{bold:1}),X("Damai dan sukacita bagi semua",280,600,24,"#bfe3d2")])
});
function ring(x,y,d,c,w){return E(x,y,d,d,"none",{stroke:c,strokeWidth:w});}
MENUS.ucapan=()=>[
 {h:"Perayaan pribadi",items:["Ulang tahun","Terima kasih"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Hari besar",items:["Selamat Lebaran","Tahun Baru","17 Agustus","Selamat Natal"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["ucapan","heart","Ucapan"]);
hubAdd("pustaka","ucapan");
CDMS.GayaHuruf={OPS};
})();
