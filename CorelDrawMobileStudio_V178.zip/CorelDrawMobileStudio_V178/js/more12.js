/* V25: panel layer (naik/turun, ganti nama), lanjutkan sesi, menu Bantuan, gradien kustom, nama grup lebih jelas */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,T,it}=M,$=s=>document.querySelector(s),E=CDMS.escape;
function ask(title,html,cb,label){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">${label||"Terapkan"}</button></div>`);$("#aOk").onclick=cb;}

/* ---- nama grup toolbar tidak bentrok dengan alat ---- */
M.HUBS.find(h=>h[0]==="atur")[2]="Objek";M.HUBS.find(h=>h[0]==="teks")[2]="Huruf";

/* ---- panel layer: naik/turun + dobel-klik ganti nama ---- */
const lr=CDMS.Layers.render;
CDMS.Layers.render=function(){lr.apply(this,arguments);const root=$("#layersList");if(!root)return;
 root.querySelectorAll("[data-layer]").forEach(r=>{if(r.querySelector("[data-mv]"))return;const id=r.dataset.layer;r.insertAdjacentHTML("beforeend",`<button data-mv="up" data-id="${id}" title="Naik (ke depan)">▲</button><button data-mv="dn" data-id="${id}" title="Turun (ke belakang)">▼</button>`);});};
const root=$("#layersList");
if(root){
 root.addEventListener("click",e=>{const b=e.target.closest("[data-mv]");if(!b)return;e.stopPropagation();const i=S.objects.findIndex(o=>o.id===b.dataset.id),j=b.dataset.mv==="up"?i+1:i-1;if(i<0||j<0||j>=S.objects.length)return;Hi.snapshot();const t=S.objects[i];S.objects[i]=S.objects[j];S.objects[j]=t;C.render();},true);
 root.addEventListener("dblclick",e=>{const n=e.target.closest(".layer-name"),r=e.target.closest("[data-layer]");if(!n||!r)return;const o=S.objects.find(x=>x.id===r.dataset.layer);if(!o)return;
  ask("Ganti nama layer",'<input id="lnI" maxlength="40">',()=>{Hi.snapshot();o.name=$("#lnI").value.trim()||o.type;N.closeModal();C.render();},"Simpan");$("#lnI").value=o.name||"";});
}

/* ---- lanjutkan sesi terakhir (dashboard) ---- */
const AB="cdms_autobackup",nb=$('[data-action="new"]');let saved=null;
try{saved=JSON.parse(localStorage.getItem(AB)||localStorage.getItem("cdms_v9_autobackup")||"null");}catch(e){}
if(nb&&saved&&saved.objects&&saved.objects.length&&!$("#resumeBtn")){
 nb.insertAdjacentHTML("afterend",'<button class="btn subtle large" id="resumeBtn">Lanjutkan sesi terakhir</button>');
 $("#resumeBtn").onclick=()=>{try{C.loadProject(saved);N.showEditor();}catch(e){T("Sesi tidak bisa dibuka");}};}

/* ---- gradien kustom ---- */
const isHex=c=>/^#[0-9a-f]{6}$/i.test(String(c));
function hslHex(h,s,l){h=((h%360)+360)%360;s/=100;l=Math.max(0,Math.min(100,l))/100;const f=n=>{const k=(n+h/30)%12,a=s*Math.min(l,1-l);return Math.round(255*(l-a*Math.max(-1,Math.min(k-3,9-k,1)))).toString(16).padStart(2,"0");};return"#"+f(0)+f(8)+f(4);}
function toHsl(hex){const[r,g,b]=[1,3,5].map(i=>parseInt(hex.substr(i,2),16)/255),mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;}return[h,s*100,l*100];}
const ok=o=>o.type!=="image"&&o.type!=="line";
function gradCustom(){ask("Gradien kustom",'<div class="st-grid"><label>Warna awal<input id="gcA" type="color" value="#6d5dfc"></label><label>Warna akhir<input id="gcB" type="color" value="#00d6c9"></label></div><label>Arah<select id="gcM"><option value="d">Diagonal</option><option value="h">Horizontal</option><option value="v">Vertikal</option><option value="r">Radial</option></select></label>',()=>{const g=[$("#gcA").value,$("#gcB").value,$("#gcM").value];N.closeModal();edit(o=>{o.grad=g;delete o.pat;},"Gradien diterapkan",ok);});}
const oc=MENUS.color;
MENUS.color=()=>[...oc(),{h:"Gradien lanjutan",items:[
 it("Gradien kustom…",gradCustom,"color"),
 it("Balik warna gradien",()=>edit(o=>{o.grad=[o.grad[1],o.grad[0],o.grad[2]];},"Gradien dibalik",o=>!!o.grad),"redo"),
 it("Gradien dari warna objek",()=>edit(o=>{const[h,s,l]=toHsl(o.fill);o.grad=[o.fill,hslHex(h+40,s,Math.min(80,l+12)),"d"];delete o.pat;},"Gradien dibuat",o=>ok(o)&&isHex(o.fill)),"color")]}];

/* ---- bantuan ---- */
const row=(k,v)=>`<tr><td style="padding:6px 10px 6px 0;white-space:nowrap"><b>${k}</b></td><td style="padding:6px 0;color:var(--muted)">${v}</td></tr>`;
function shortcuts(){N.openModal("Pintasan keyboard",`<table style="width:100%;border-collapse:collapse;font-size:13px">${[["Ctrl+S","Simpan proyek"],["Ctrl+Z / Y","Urungkan / ulangi"],["Ctrl+C / X / V","Salin / potong / tempel"],["Ctrl+D","Duplikat objek"],["Ctrl+A","Pilih semua"],["Ctrl+G","Kelompokkan"],["Ctrl+K","Cari fitur"],["Delete","Hapus objek"],["Panah","Geser 1 px (Shift: 10 px)"],["Shift + klik","Pilih banyak objek"],["Seret area kosong","Seleksi kotak (Shift: tambah ke seleksi)"],["/","Buka pencarian fitur"],["Dobel-klik teks","Edit isi teks"],["Alt + seret objek","Gandakan sambil menggeser (Option di Mac)"],["Klik kanan / tekan lama","Menu cepat objek (salin, urutan, kunci, dll.)"],["Titik kurva","Menu Simpul > Tambah titik kurva (atau klik kanan objek): ketuk garis lalu seret; Esc untuk selesai"],["Ctrl + roda mouse","Zoom kanvas (juga cubit di trackpad)"],["Spasi + seret","Geser kanvas (atau tombol tengah mouse)"],["+ / - / 0","Zoom masuk / keluar / 100%"],["Esc","Tutup menu / batal pilih"]].map(r=>row(r[0],r[1])).join("")}</table>`);}
function tips(){N.openModal("Gestur & tips",`<table style="width:100%;border-collapse:collapse;font-size:13px">${[["Cubit 2 jari","Zoom dan geser kanvas (HP)"],["Ketuk 2 kali teks","Edit isi teks"],["Tombol Multi","Pilih banyak objek di HP"],["Seret area kosong","Seleksi kotak beberapa objek sekaligus"],["Banner Pulihkan","Muncul di beranda jika sesi tertutup sebelum disimpan"],["Tombol Cari","Temukan fitur dari semua menu"],["Grup Pustaka","Ikon, 3D, infografis, emoji, mockup"],["Bar aksi cepat","Muncul di dekat objek terpilih"],["Panel layer","Ketuk ▲ ▼ untuk urutan, ketuk 2 kali nama untuk ganti nama"]].map(r=>row(r[0],r[1])).join("")}</table>`);}
function health(){const n=S.objects.length,out=S.objects.filter(o=>o.x+o.w<0||o.y+(o.h||0)<0||o.x>S.page.width||o.y>S.page.height).length,hid=S.objects.filter(o=>o.hidden).length,lock=S.objects.filter(o=>o.locked).length,emp=S.objects.filter(o=>o.type==="text"&&!String(o.text||"").trim()).length,mb=S.objects.reduce((a,o)=>a+(o.type==="image"?(o.href||"").length*.75:0),0)/1048576;
 const L=[[n+" objek di halaman "+S.page.width+" × "+S.page.height,"ok"],[out?out+" objek berada di luar kanvas (hapus lewat menu Pilih)":"Tidak ada objek di luar kanvas",out?"warn":"ok"],[hid?hid+" objek disembunyikan":"Tidak ada objek tersembunyi",hid?"warn":"ok"],[lock?lock+" objek terkunci":"Tidak ada objek terkunci",lock?"warn":"ok"],[emp?emp+" teks kosong":"Tidak ada teks kosong",emp?"warn":"ok"],["Gambar tertanam: "+mb.toFixed(2)+" MB"+(mb>4?" (besar, simpan lokal bisa gagal; gunakan cadangan .cdms)":""),mb>4?"warn":"ok"]];
 N.openModal("Cek kesehatan proyek",`<div class="st-pane">${L.map(x=>`<p class="st-note" style="color:${x[1]==="ok"?"var(--text)":"#ffc857"}">${x[1]==="ok"?"✔":"⚠"} ${E(x[0])}</p>`).join("")}</div>`);}
MENUS.help=()=>[{h:"Bantuan",items:[it("Pintasan keyboard",shortcuts,"settings"),it("Gestur & tips",tips,"select"),it("Cek kesehatan proyek",health,"layers")]}];
BT.push(["help","help","Bantuan"]);M.HUBS.find(h=>h[0]==="berkas")[3].push("help");
document.addEventListener("keydown",e=>{if(e.key==="?"&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)){const ed=$("#editor");if(ed&&!ed.classList.contains("hidden"))shortcuts();}});
})();
