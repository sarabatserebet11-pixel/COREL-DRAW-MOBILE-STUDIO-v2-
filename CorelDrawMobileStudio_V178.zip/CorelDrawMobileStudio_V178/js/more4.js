/* V17: menu Efek, Palet, Emoji, Ekspor + miring (skew) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc,cell}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height,NS="http://www.w3.org/2000/svg";

/* ---- miring ---- */
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);if(o.skx||o.sky)s=s.replace(/ scale\(([-\d.]+) ([-\d.]+)\)/,m=>` skewX(${o.skx||0}) skewY(${o.sky||0})${m}`);return s;};

/* ---- efek salinan ---- */
function copies(fn,only){const a=sels().filter(o=>o.type!=="line"&&(!only||only(o)));if(!a.length)return T("Pilih objek dulu");Hi.snapshot();
 a.forEach(o=>{const g=o.groupId||(o.groupId=uid());fn(o,(p,front)=>{const c={...o,id:uid(),fxOf:o.id,groupId:g,locked:false,name:(o.name||o.type)+" efek",...p};delete c.fx;delete c.v7Effect;const i=S.objects.indexOf(o);S.objects.splice(front?i+1:i,0,c);});});C.render();}
const reflect=()=>copies((o,add)=>add({y:Math.round(o.y+(o.h||0)+4),flipV:!o.flipV,rotation:-(o.rotation||0),opacity:30},true));
const glitch=()=>copies((o,add)=>{add({x:o.x-8,fill:"#ff2a6d",opacity:75});add({x:o.x+8,fill:"#05d9e8",opacity:75});},o=>o.type!=="image");
const halo=c=>copies((o,add)=>add(o.type==="text"?{textOutline:true,stroke:c,strokeWidth:16,fill:c}:{fill:"none",stroke:c,strokeWidth:16}),o=>o.type!=="image");
const neon=c=>edit(o=>{o.fx="glow";o.fxColor=c;o.fxAmount=16;if(o.type==="text")o.fill="#ffffff";else{o.stroke=c;o.strokeWidth=5;o.fill="none";}},"Neon diterapkan",o=>o.type!=="image"&&o.type!=="line");
const clearCopies=()=>{const n=S.objects.filter(o=>o.fxOf).length;if(!n)return T("Tidak ada efek salinan");Hi.snapshot();S.objects=S.objects.filter(o=>!o.fxOf);C.render();T(n+" efek salinan dihapus");};
const skew=(k,v)=>edit(o=>{if(k==="r"){delete o.skx;delete o.sky;}else o[k]=v;},"");
MENUS.fxm=()=>[
 {h:"Efek salinan",items:[it("Pantulan (reflection)",reflect,"flipV"),it("Glitch merah-cyan",glitch,"studio"),it("Halo putih",()=>halo("#ffffff"),"ellipse"),it("Halo ungu",()=>halo("#6d5dfc"),"ellipse"),it("Hapus semua efek salinan",clearCopies,"trash")]},
 {h:"Neon",items:[it("Neon cyan",()=>neon("#00d6c9"),"studio"),it("Neon magenta",()=>neon("#ff39bd"),"studio"),it("Neon kuning",()=>neon("#ffe44d"),"studio")]},
 {h:"Miring (skew)",items:[["X −20°","skx",-20],["X +20°","skx",20],["Y −15°","sky",-15],["Y +15°","sky",15],["Reset","r",0]].map(x=>tc(x[0],()=>skew(x[1],x[2])))}];

/* ---- palet harmoni ---- */
const h2r=h=>{const n=parseInt(h.slice(1),16);return[n>>16,(n>>8)&255,n&255];};
function toHsl(hex){const[r,g,b]=h2r(hex).map(v=>v/255),mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;}return[h,s*100,l*100];}
const hsl=(h,s,l)=>{h=((h%360)+360)%360;s/=100;l=Math.max(0,Math.min(100,l))/100;const f=n=>{const k=(n+h/30)%12,a=s*Math.min(l,1-l),v=l-a*Math.max(-1,Math.min(k-3,9-k,1));return Math.round(255*v).toString(16).padStart(2,"0");};return"#"+f(0)+f(8)+f(4);};
const SCH={comp:[0,180],triad:[0,120,240],analog:[-30,0,30],tetra:[0,90,180,270]};
function palette(kind){const a=sels()[0],base=a&&/^#[0-9a-f]{6}$/i.test(String(a.fill))?a.fill:"#6d5dfc",[h,s,l]=toHsl(base);let cols;
 if(kind==="mono")cols=[25,40,55,70,85].map(x=>hsl(h,s,x));
 else{cols=SCH[kind].map(d=>hsl(h+d,s,l));let i=0;while(cols.length<5){cols.push(hsl(h+SCH[kind][i%SCH[kind].length],s,l>60?l-22:l+22));i++;}}
 S.lastPalette=cols;Hi.snapshot();const g=uid(),side=Math.round(W()*.14),gap=Math.round(W()*.02),x0=Math.round((W()-(5*side+4*gap))/2),y0=Math.round(H()/2-side/2),fs=Math.round(side*.16),arr=[],pairs=[];
 cols.forEach((c,i)=>{const r={type:"rect",name:"Warna "+c,x:x0+i*(side+gap),y:y0,w:side,h:side,rx:16,fill:c},t={type:"text",name:"Kode "+c,text:c.toUpperCase(),x:r.x,y:y0+side+fs*.6,w:50,h:30,fontSize:fs,fill:"#68728a",bold:true};arr.push(r,t);pairs.push([t,r]);});
 arr.forEach(o=>Object.assign(o,{id:uid(),groupId:g,opacity:100,rotation:0,stroke:"none",strokeWidth:0}));S.objects.push(...arr);pick(arr);pairs.forEach(p=>{p[0].x=Math.round(p[1].x+(p[1].w-p[0].w)/2);});C.render();}
const applyPal=()=>{const p=S.lastPalette,a=sels().filter(o=>o.type!=="image"&&o.type!=="line");if(!p)return T("Buat palet dulu");if(!a.length)return T("Pilih objek dulu");Hi.snapshot();a.forEach((o,i)=>{o.fill=p[i%p.length];delete o.grad;delete o.pat;});C.render();};
MENUS.pal=()=>[{h:"Buat palet dari warna objek terpilih",items:[it("Komplementer",()=>palette("comp"),"color"),it("Triad",()=>palette("triad"),"color"),it("Analog",()=>palette("analog"),"color"),it("Tetradik",()=>palette("tetra"),"color"),it("Monokrom",()=>palette("mono"),"color")]},
 {h:"Terapkan",items:[it("Pakai palet terakhir ke objek terpilih",applyPal,"copy")]}];

/* ---- emoji ---- */
const EM=[["Wajah","😀😍😎🥳😂🤩"],["Simbol","❤️⭐🔥✨💯✅"],["Alam","🌸🌈☀️🌙🍀🌊"],["Objek","🍕🍔☕🎁🎵🚀"]];
function addEmoji(e){Hi.snapshot();const o={id:uid(),type:"text",name:"Emoji",text:e,x:Math.round(W()/2-60),y:Math.round(H()/2-60),w:120,h:120,fontSize:Math.round(W()*.14),fill:"#000000",stroke:"none",strokeWidth:0,opacity:100,rotation:0};S.objects.push(o);pick([o]);o.x=Math.round((W()-o.w)/2);o.y=Math.round((H()-o.h)/2);C.render();}
MENUS.emo=()=>EM.map(g=>({h:g[0],items:[...new Intl.Segmenter("id",{granularity:"grapheme"}).segment(g[1])].map(x=>x.segment).map(e=>cell(`<span style="font-size:24px">${e}</span>`,()=>addEmoji(e)))}));

/* ---- ekspor ---- */
const nm=()=>(S.projectName||"desain").replace(/[^\w-]+/g,"_");
function svgStr(tr){const sv=C.svg.cloneNode(true);["#overlayLayer","#cdGuides","#cdAid"].forEach(q=>{const e=sv.querySelector(q);if(e)e.remove();});if(tr){const b=sv.querySelector("#pageBackground");if(b)b.remove();}sv.setAttribute("xmlns",NS);sv.setAttribute("width",W());sv.setAttribute("height",H());sv.removeAttribute("style");return new XMLSerializer().serializeToString(sv);}
function blobOf(o,cb){let s=o.scale||2;while(W()*H()*s*s>40e6&&s>1)s--;const url=URL.createObjectURL(new Blob([svgStr(o.transparent)],{type:"image/svg+xml;charset=utf-8"})),im=new Image();
 im.onload=()=>{try{const c=document.createElement("canvas");c.width=W()*s;c.height=H()*s;const x=c.getContext("2d");if(o.type==="image/jpeg"){x.fillStyle="#fff";x.fillRect(0,0,c.width,c.height);}x.drawImage(im,0,0,c.width,c.height);c.toBlob(b=>{URL.revokeObjectURL(url);cb(b);},o.type||"image/png",.92);}catch(e){URL.revokeObjectURL(url);cb(null);}};
 im.onerror=()=>{URL.revokeObjectURL(url);cb(null);};im.src=url;}
const dl=(o,name)=>blobOf(o,b=>b?CDMS.Export.download(b,name):T("Ekspor gagal"));
MENUS.exp=()=>[
 {h:"Unduh",items:[it("PNG transparan",()=>dl({transparent:true,scale:2},nm()+"_transparan.png"),"export"),it("PNG HD 3×",()=>dl({scale:3},nm()+"_3x.png"),"export"),it("JPG",()=>dl({type:"image/jpeg",scale:2},nm()+".jpg"),"export"),it("Opsi ekspor lengkap…",()=>CDMS.Export.open(),"settings")]},
 {h:"Bagikan & lihat",items:[it("Salin gambar ke clipboard",()=>blobOf({scale:2},b=>{if(!b)return T("Gagal membuat gambar");if(navigator.clipboard&&window.ClipboardItem)navigator.clipboard.write([new ClipboardItem({"image/png":b})]).then(()=>T("Gambar disalin")).catch(()=>T("Clipboard tidak diizinkan"));else T("Browser tidak mendukung salin gambar");}),"copy"),
  it("Bagikan lewat aplikasi…",()=>blobOf({scale:2},b=>{if(!b)return T("Gagal membuat gambar");const f=new File([b],nm()+".png",{type:"image/png"});if(navigator.canShare&&navigator.canShare({files:[f]}))navigator.share({files:[f],title:S.projectName}).catch(()=>{});else T("Berbagi tidak didukung di browser ini");}),"export"),
  it("Pratinjau bersih",()=>blobOf({scale:1},b=>{if(!b)return T("Gagal membuat pratinjau");N.openModal("Pratinjau",`<img src="${URL.createObjectURL(b)}" style="width:100%;border-radius:10px;border:1px solid var(--line)">`);}),"eye")]}];

BT.push(["fxm","sparkles","Efek"],["pal","palette","Palet"],["emo","emoji","Emoji"],["exp","export","Ekspor"]);
})();
