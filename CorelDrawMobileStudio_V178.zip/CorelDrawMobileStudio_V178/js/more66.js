/* V77: tab baru Pola (titik/kotak/belah ketupat/garis dalam grid, area pilihan atau halaman, warna ganda ala papan catur, hasilnya grup yang bisa diedit) dan Sisip (judul, subjudul, paragraf contoh, daftar bullet/nomor dari teks, garis pemisah) di panel Penata + tombol cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const uid=()=>crypto.randomUUID(),done=m=>{C.render();if(m)T(m);};
const mem=()=>{const a=M.sels(),out=[];a.forEach(o=>{(o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]).forEach(p=>{if(!out.includes(p))out.push(p);});});return out;};
const base=(t,x,y,w,h,f)=>({id:uid(),type:t,name:t[0].toUpperCase()+t.slice(1),x:Math.round(x),y:Math.round(y),w:Math.round(w),h:Math.round(h),fill:f,stroke:"#20243a",strokeWidth:0,opacity:100,rotation:0});
/* ---- Pola ---- */
let shp="dot";
function pola(){const sz=Math.max(2,num("p77sz",24)),gap=Math.max(0,num("p77gp",16)),c1=$("#p77c1").value,c2=$("#p77c2").value,dua=$("#p77dua").checked;
 let ar={x:0,y:0,w:S.page.width,h:S.page.height};const m=mem();
 if($("#p77ar").value==="pilih"){if(!m.length)return T("Pilih objek sebagai area, atau ganti area ke Halaman");const x=Math.min(...m.map(o=>o.x)),y=Math.min(...m.map(o=>o.y));ar={x,y,w:Math.max(...m.map(o=>o.x+(o.w||0)))-x,h:Math.max(...m.map(o=>o.y+(o.h||0)))-y};}
 const st=sz+gap;let out=[];const gid=uid();
 if(shp==="gh"||shp==="gv"){const n=Math.floor((shp==="gh"?ar.h:ar.w)/st+ (gap?1:0)*0)+1;for(let i=0;i<n;i++){const p=i*st;if(p+sz>(shp==="gh"?ar.h:ar.w))break;out.push(shp==="gh"?base("rect",ar.x,ar.y+p,ar.w,sz,dua&&i%2?c2:c1):base("rect",ar.x+p,ar.y,sz,ar.h,dua&&i%2?c2:c1));}}
 else{const cols=Math.floor((ar.w+gap)/st),rows=Math.floor((ar.h+gap)/st);if(cols<1||rows<1)return T("Area terlalu kecil untuk ukuran ini");
  const ox=ar.x+(ar.w-(cols*st-gap))/2,oy=ar.y+(ar.h-(rows*st-gap))/2;
  for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){const f=dua&&(r+c)%2?c2:c1,x=ox+c*st,y=oy+r*st;
   if(shp==="dot")out.push(base("ellipse",x,y,sz,sz,f));else if(shp==="sq")out.push(base("rect",x,y,sz,sz,f));else{const o=base("rect",x+sz*.15,y+sz*.15,sz*.7,sz*.7,f);o.rotation=45;out.push(o);}}}
 if(!out.length)return T("Tidak ada pola yang muat");if(out.length>600)return T("Terlalu banyak objek ("+out.length+"). Perbesar ukuran atau jarak (maks. 600)");
 Hi.snapshot();out.forEach((o,i)=>{o.groupId=gid;o.name="Pola "+(i+1);});
 const idx=m.length&&$("#p77ar").value==="pilih"&&$("#p77bk").checked?Math.max(0,Math.min(...m.map(o=>S.objects.indexOf(o)).filter(i=>i>=0))):($("#p77bk").checked?0:S.objects.length);
 S.objects.splice(idx,0,...out);pick(out);T(out.length+" objek pola dibuat (satu grup)");}
/* ---- Sisip ---- */
const lines=()=>($("#p77tx").value||"").split("\n").map(s=>s.trim()).filter(Boolean);
function teks(txt,fs,bold,fill,w){const L=txt.split("\n"),W=w||Math.min(S.page.width-120,Math.max(...L.map(l=>l.length))*fs*.55+20);
 const o=base("text",(S.page.width-W)/2,S.page.height/2-fs,W,Math.round(L.length*fs*1.3+10),fill);o.text=txt;o.fontSize=fs;o.bold=!!bold;
 Hi.snapshot();S.objects.push(o);if(CDMS.PusatTeks&&!w){const m=CDMS.PusatTeks.ukur(o);o.w=m;o.x=Math.round((S.page.width-m)/2);}pick([o]);T("Teks disisipkan");}
const LOREM="Tulis paragraf Anda di sini. Teks contoh ini membantu Anda menata tata letak sebelum isi akhir siap.";
function para(){const fs=Math.round(S.page.width/36),maxc=Math.max(10,Math.floor((S.page.width-200)/(fs*.52)));const words=LOREM.split(" "),ls=[];let cur="";words.forEach(w=>{if((cur+" "+w).trim().length>maxc){ls.push(cur);cur=w;}else cur=(cur+" "+w).trim();});if(cur)ls.push(cur);teks(ls.join("\n"),fs,false,"#20243a");}
function daftar(num){const L=lines();if(!L.length)return T("Tulis isi daftar dulu (satu baris per butir)");teks(L.map((s,i)=>(num?(i+1)+". ":"• ")+s).join("\n"),Math.round(S.page.width/30),false,"#20243a");}
function pemisah(){const w=Math.round(S.page.width*.6),o=base("line",(S.page.width-w)/2,S.page.height/2,w,0,"none");o.stroke="#20243a";o.strokeWidth=4;Hi.snapshot();S.objects.push(o);pick([o]);T("Garis pemisah disisipkan");}
const H={sd:()=>{shp="dot";sUI();},sq:()=>{shp="sq";sUI();},sb:()=>{shp="bk";sUI();},sgh:()=>{shp="gh";sUI();},sgv:()=>{shp="gv";sUI();},pola,
 judul:()=>teks("Judul Besar",Math.round(S.page.width/10),true,"#20243a"),sub:()=>teks("Subjudul singkat di sini",Math.round(S.page.width/22),false,"#4a5070"),para,
 bul:()=>daftar(false),nom:()=>daftar(true),pem:pemisah};
function sUI(){document.querySelectorAll(".p69 [data-sh]").forEach(x=>x.classList.toggle("on",x.dataset.sh===shp));}
P.addTab("pola","Pola",`<div class="p69btns c3">${[["sd","dot","Titik"],["sq","sq","Kotak"],["sb","bk","Belah"],["sgh","gh","Garis ━"],["sgv","gv","Garis ┃"]].map(x=>`<button data-h="${x[0]}" data-sh="${x[1]}"><span>${x[2]}</span></button>`).join("")}</div>
 <div class="p69row" style="margin-top:10px">${fld("p77sz","Ukuran",24,'min="2"')}${fld("p77gp","Jarak",16,'min="0"')}<label>Warna 1<input id="p77c1" type="color" value="#6d5dfc"></label><label>Warna 2<input id="p77c2" type="color" value="#00d6c9"></label>
 <label>Area<select id="p77ar"><option value="hal">Halaman</option><option value="pilih">Objek terpilih</option></select></label></div>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 6px"><input id="p77dua" type="checkbox"> Dua warna selang-seling</label>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 8px"><input id="p77bk" type="checkbox" checked> Letakkan di belakang</label>
 <div class="p69btns">${b("pola","Buat pola")}</div><p class="muted" style="margin-top:8px">Hasil berupa satu grup (maks. 600 objek) yang bisa dipecah atau diwarnai ulang.</p>`,H);
P.addTab("sisip","Sisip",`<div class="p69btns c3">${b("judul","Judul")}${b("sub","Subjudul")}${b("para","Paragraf")}</div>
 <div class="p69row" style="margin-top:10px"><label style="grid-column:1/-1">Isi daftar (satu butir per baris)<textarea id="p77tx" rows="4" style="width:100%;padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--panel2);color:var(--text);font:inherit;font-size:13px">Butir pertama\nButir kedua\nButir ketiga</textarea></label></div>
 <div class="p69btns c3">${b("bul","Daftar •")}${b("nom","Daftar 1.")}${b("pem","Pemisah")}</div>`,H);
document.addEventListener("click",e=>{if(e.target.closest&&e.target.closest(".p69 [data-t=pola]"))sUI();});
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q7="pola" title="Pola">${ic("grid")}</button><button data-q7="sisip" title="Sisip teks">${ic("plus")}</button><button data-q7="tebal" title="Tebal / normal (teks)">${ic("text")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q7]");if(!x)return;const k=x.dataset.q7;
  if(k==="pola"){P.openTab("pola");sUI();}else if(k==="sisip")P.openTab("sisip");
  else{const a=M.sels().filter(o=>o.type==="text"&&!o.locked);if(!a.length)return T("Pilih teks dulu");Hi.snapshot();const on=!a.every(o=>o.bold);a.forEach(o=>{o.bold=on;if(CDMS.PusatTeks){const w=CDMS.PusatTeks.ukur(o),cx=o.x+o.w/2;o.w=w;o.x=Math.round(cx-w/2);}});done(on?"Teks ditebalkan":"Teks dinormalkan");}});}
MENUS.penata77=()=>[{h:"Tab Penata",items:[it("Pola (titik, kotak, garis)",()=>{P.openTab("pola");sUI();},"grid"),it("Sisip (judul, daftar, pemisah)",()=>P.openTab("sisip"),"plus")]}];
BT.push(["penata77","panel","Penata 8"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata77");
})();
