/* V68: bar aksi cepat diperluas - tombol Grup, Lepas grup, Tengahkan di halaman, Isi kartu (edit semua teks grup), dan Warna isi */
(()=>{
const S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,M=CDMS.Menus,I=CDMS.IsiKartu;
const qb=document.querySelector(".qbar");if(!qb||!I)return;
const ic=n=>CDMS.Icons.svg(n);
qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-qa="group" data-qv="group" title="Kelompokkan">${ic("group")}</button><button data-qa="ungroup" data-qv="ungroup" title="Lepas kelompok">${ic("ungroup")}</button><button data-qx="tengah" title="Tengahkan di halaman">${ic("arrange")}</button><button data-qx="isi" data-qv="isi" title="Edit isi kartu">${ic("text")}</button><label class="qcol" title="Warna isi">${ic("color")}<span class="qdot"></span><input type="color" data-qx="warna" value="#6d5dfc"></label>`);
const sel=()=>(S.selectedIds&&S.selectedIds.length?S.selectedIds:(S.selected?[S.selected]:[])).map(id=>S.objects.find(o=>o.id===id)).filter(Boolean);
const q=k=>qb.querySelector(`[data-qv="${k}"]`);
function vis(){const a=sel();if(!a.length)return;
 const gids=new Set(a.map(o=>o.groupId||"")),anyG=a.some(o=>o.groupId);
 q("group").hidden=!(a.length>=2&&!(gids.size===1&&anyG));
 q("ungroup").hidden=!anyG;
 q("isi").hidden=!(anyG&&I.teksGrup().length);
 const f=a.find(o=>/^#[0-9a-f]{6}$/i.test(o.fill||""));const col=f?f.fill:"#6d5dfc";
 const inp=qb.querySelector('input[data-qx="warna"]');if(inp&&inp.value!==col.toLowerCase())inp.value=col.toLowerCase();qb.querySelector(".qdot").style.setProperty("--qc",col);}
function tengah(){const u=I.cakupan();if(!u.length)return;Hi.snapshot();
 const x1=Math.min(...u.map(o=>o.x)),y1=Math.min(...u.map(o=>o.y)),x2=Math.max(...u.map(o=>o.x+(o.w||0))),y2=Math.max(...u.map(o=>o.y+(o.h||0)));
 const dx=Math.round(S.page.width/2-(x1+x2)/2),dy=Math.round(S.page.height/2-(y1+y2)/2);u.forEach(o=>{o.x+=dx;o.y+=dy;});C.render();CDMS.toast("Dipusatkan di halaman");}
qb.addEventListener("pointerdown",e=>e.stopPropagation());
qb.addEventListener("click",e=>{const b=e.target.closest("[data-qx]");if(!b||b.tagName==="INPUT")return;
 if(b.dataset.qx==="tengah")tengah();else if(b.dataset.qx==="isi")M.MENUS.isikartu()[0].items[0].f();});
let snap=false;const col=qb.querySelector('input[data-qx="warna"]');
col.addEventListener("click",()=>{snap=false;});
col.addEventListener("input",()=>{const a=I.cakupan().length&&sel().some(o=>o.groupId)?sel():sel();if(!a.length)return;if(!snap){Hi.snapshot();snap=true;}
 a.forEach(o=>{if(o.type!=="image")o.fill=col.value;});qb.querySelector(".qdot").style.setProperty("--qc",col.value);C.render();});
col.addEventListener("change",()=>{snap=false;});
const rr=C.render;C.render=function(){try{vis();}catch(e){}return rr.apply(this,arguments);};
})();
