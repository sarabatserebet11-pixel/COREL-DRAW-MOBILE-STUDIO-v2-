window.CDMS=window.CDMS||{};CDMS.Colors={set(hex){if(CDMS.state.selected)CDMS.Canvas.updateObject(CDMS.state.selected,{fill:hex});}};
