/* V72: tab baru Ulang (gandakan bertahap + cermin di halaman) dan Ekspor (pilihan jadi PNG/JPG/SVG, skala, margin, salin SVG) di panel Penata + tombol baru di bar aksi cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const nr=M.nr,done=m=>{C.render();if(m)T(m);};
function members(){const a=M.sels().filter(o=>!o.locked),out=[];a.forEach(o=>{(o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]).forEach(p=>{if(!out.includes(p))out.push(p);});});return out;}
const bb=a=>({x:Math.min(...a.map(o=>o.x)),y:Math.min(...a.map(o=>o.y)),x2:Math.max(...a.map(o=>o.x+(o.w||0))),y2:Math.max(...a.map(o=>o.y+(o.h||0)))});
const clone=(src,gm)=>src.map(o=>{const c=JSON.parse(JSON.stringify(o));c.id=crypto.randomUUID();if(o.groupId)c.groupId=gm[o.groupId]||(gm[o.groupId]=crypto.randomUUID());return c;});
/* ---- Ulang ---- */
function ulang(){const src=members();if(!src.length)return T("Pilih objek dulu");const n=Math.max(1,Math.min(50,Math.round(num("p72n",5)))),dx=num("p72dx",60),dy=num("p72dy",0),rot=num("p72rot",0),sc=Math.max(.05,num("p72sc",100)/100);
 Hi.snapshot();const g=bb(src),cx=(g.x+g.x2)/2,cy=(g.y+g.y2)/2,all=[];
 for(let i=1;i<=n;i++){const cp=clone(src,{}),f=Math.pow(sc,i);
  cp.forEach(o=>{if(f!==1){o.x=cx+(o.x-cx)*f;o.y=cy+(o.y-cy)*f;o.w=Math.max(1,(o.w||0)*f);if(o.h)o.h=Math.max(1,o.h*f);if(o.fontSize)o.fontSize=Math.max(6,Math.round(o.fontSize*f));}
   if(rot){const mx=o.x+(o.w||0)/2-cx,my=o.y+(o.h||0)/2-cy,a=rot*i*Math.PI/180,nx=cx+mx*Math.cos(a)-my*Math.sin(a),ny=cy+mx*Math.sin(a)+my*Math.cos(a);o.x=nx-(o.w||0)/2;o.y=ny-(o.h||0)/2;o.rotation=nr(Math.round((o.rotation||0)+rot*i));}
   o.x=Math.round(o.x+dx*i);o.y=Math.round(o.y+dy*i);o.w=Math.round(o.w);if(o.h)o.h=Math.round(o.h);});
  all.push(...cp);}
 S.objects.push(...all);pick(all);T(n+" salinan dibuat");}
function cermin(ax){const src=members();if(!src.length)return T("Pilih objek dulu");Hi.snapshot();const cp=clone(src,{}),W=S.page.width,Hh=S.page.height;
 cp.forEach(o=>{if(ax==="h"){o.x=Math.round(W-o.x-(o.w||0));o.flipH=!o.flipH;}else{o.y=Math.round(Hh-o.y-(o.h||0));o.flipV=!o.flipV;}o.rotation=nr(-(o.rotation||0));});
 S.objects.push(...cp);pick(cp);T("Cermin dibuat di seberang halaman");}
/* ---- Ekspor ---- */
function svgOf(a,pad){const bx=bb(a);let x0=bx.x-pad,y0=bx.y-pad,w=bx.x2-bx.x+2*pad,h=bx.y2-bx.y+2*pad;
 a.forEach(o=>{if(o.rotation){const w2=o.w||0,h2=o.h||0,r=Math.hypot(w2,h2)/2,cx=o.x+w2/2,cy=o.y+h2/2;x0=Math.min(x0,cx-r-pad);y0=Math.min(y0,cy-r-pad);w=Math.max(w,cx+r+pad-x0);h=Math.max(h,cy+r+pad-y0);}});
 return {x0,y0,w,h,svg:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${x0} ${y0} ${w} ${h}" width="${w}" height="${h}">${a.map(o=>C.objMarkup(o)).join("")}</svg>`};}
function ekspor(fmt,copy){const a=members();if(!a.length)return T("Pilih objek dulu");const pad=Math.max(0,num("p72pad",16)),sc=Math.max(.25,Math.min(6,num("p72scale",2)));
 const r=svgOf(a,pad);
 if(copy){try{navigator.clipboard.writeText(r.svg).then(()=>T("Kode SVG disalin"),()=>T("Gagal menyalin"));}catch(e){T("Gagal menyalin");}return;}
 if(fmt==="svg"){CDMS.Export.download(new Blob([r.svg],{type:"image/svg+xml"}),"pilihan.svg");return;}
 const W=Math.min(8000,Math.round(r.w*sc)),Hh=Math.min(8000,Math.round(r.h*sc)),url=URL.createObjectURL(new Blob([r.svg],{type:"image/svg+xml;charset=utf-8"})),im=new Image();
 im.onload=()=>{const cv=document.createElement("canvas");cv.width=W;cv.height=Hh;const x=cv.getContext("2d");if(fmt==="jpg"){x.fillStyle=$("#p72bg").value;x.fillRect(0,0,W,Hh);}x.drawImage(im,0,0,W,Hh);
  cv.toBlob(bl=>{URL.revokeObjectURL(url);bl?CDMS.Export.download(bl,"pilihan."+(fmt==="jpg"?"jpg":"png")):T("Gagal ekspor");},fmt==="jpg"?"image/jpeg":"image/png",.92);T("Ekspor "+W+" × "+Hh);};
 im.onerror=()=>{URL.revokeObjectURL(url);T("Gagal ekspor");};im.src=url;}
const H={ulang,cmH:()=>cermin("h"),cmV:()=>cermin("v"),xPng:()=>ekspor("png"),xJpg:()=>ekspor("jpg"),xSvg:()=>ekspor("svg"),xCopy:()=>ekspor("svg",true)};
P.addTab("ulang","Ulang",`<p class="muted">Gandakan objek/grup terpilih secara bertahap. Setiap salinan ke-n bergeser n× jarak, berputar n× sudut, dan berskala n×.</p>
 <div class="p69row">${fld("p72n","Jumlah salinan",5,'min="1" max="50"')}${fld("p72dx","Geser X",60)}${fld("p72dy","Geser Y",0)}${fld("p72rot","Putar (°)",0)}${fld("p72sc","Skala (%)",100,'min="5"')}</div>
 <div class="p69btns">${b("ulang","Gandakan bertahap")}</div>
 <div class="p69h">Cermin di halaman</div><div class="p69btns">${b("cmH","Cermin mendatar")}${b("cmV","Cermin menurun")}</div>`,H);
P.addTab("ekspor","Ekspor",`<p class="muted">Ekspor hanya objek/grup terpilih.</p>
 <div class="p69row">${fld("p72scale","Skala (×)",2,'min="0.25" max="6" step="0.25"')}${fld("p72pad","Margin (px)",16,'min="0"')}<label>Latar JPG<input id="p72bg" type="color" value="#ffffff"></label></div>
 <div class="p69btns c3">${b("xPng","PNG")}${b("xJpg","JPG")}${b("xSvg","SVG")}</div><div class="p69btns" style="margin-top:6px">${b("xCopy","Salin kode SVG")}</div>`,H);
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<button data-qv2="flipV" title="Balik menurun">${ic("flipV")}</button><button data-qv2="kiri" title="Putar 90° kiri">${ic("undo")}</button><button data-qv2="ulang" title="Gandakan bertahap">${ic("multi")}</button><button data-qv2="ekspor" title="Ekspor pilihan">${ic("export")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-qv2]");if(!x)return;const k=x.dataset.qv2;
  if(k==="ulang"||k==="ekspor")return P.openTab(k);
  const a=members();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();
  if(k==="flipV")a.forEach(o=>{o.flipV=!o.flipV;});
  else{const g=bb(a),cx=(g.x+g.x2)/2,cy=(g.y+g.y2)/2;if(a.length===1)a[0].rotation=nr((a[0].rotation||0)-90);else a.forEach(o=>{const mx=o.x+(o.w||0)/2-cx,my=o.y+(o.h||0)/2-cy;o.x=Math.round(cx+my-(o.w||0)/2);o.y=Math.round(cy-mx-(o.h||0)/2);o.rotation=nr((o.rotation||0)-90);});}
  done();});}
MENUS.penata72=()=>[{h:"Tab Penata",items:[it("Ulang (gandakan bertahap, cermin)",()=>P.openTab("ulang"),"multi"),it("Ekspor pilihan (PNG/JPG/SVG)",()=>P.openTab("ekspor"),"export")]},{h:"Cepat",items:[it("Cermin mendatar di halaman",()=>cermin("h"),"flipH"),it("Cermin menurun di halaman",()=>cermin("v"),"flipV"),it("Salin kode SVG pilihan",()=>ekspor("svg",true),"copy")]}];
BT.push(["penata72","panel","Penata 3"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata72");
})();
