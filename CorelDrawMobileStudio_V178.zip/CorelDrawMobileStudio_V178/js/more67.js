/* V78: tab baru Bentuk (12 bentuk siap pakai: segitiga, panah, hati, plus, awan, gelembung bicara, tetesan, perisai, sabit, petir, segi enam, jajar genjang) dan Bingkai (bingkai halaman tunggal/ganda, bungkus objek dengan kotak/sudut/pil, watermark teks berulang) di panel Penata + tombol cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const uid=()=>crypto.randomUUID();
const val=(id,d)=>{const e=$("#"+id);return e&&e.value?e.value:d;};
const mem=()=>{const a=M.sels(),out=[];a.forEach(o=>{(o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]).forEach(p=>{if(!out.includes(p))out.push(p);});});return out;};
const bbox=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y));return{x,y,w:Math.max(...a.map(o=>o.x+(o.w||0)))-x,h:Math.max(...a.map(o=>o.y+(o.h||0)))-y};};
const base=(t,x,y,w,h,f)=>({id:uid(),type:t,name:t[0].toUpperCase()+t.slice(1),x:Math.round(x),y:Math.round(y),w:Math.max(1,Math.round(w)),h:Math.max(1,Math.round(h)),fill:f,stroke:"#20243a",strokeWidth:0,opacity:100,rotation:0});
/* ---- Bentuk ---- */
const BENTUK=[
 ["Segitiga","M50 4L96 94H4Z"],
 ["Panah","M4 38H58V14L96 50L58 86V62H4Z"],
 ["Hati","M50 90C10 60 4 32 22 16C36 4 50 14 50 28C50 14 64 4 78 16C96 32 90 60 50 90Z"],
 ["Plus","M38 4H62V38H96V62H62V96H38V62H4V38H38Z"],
 ["Awan","M26 80C8 80 4 54 24 50C22 30 48 20 58 36C74 26 94 40 86 58C100 62 96 80 80 80Z"],
 ["Bicara","M10 10H90Q96 10 96 16V62Q96 68 90 68H44L24 92V68H10Q4 68 4 62V16Q4 10 10 10Z"],
 ["Tetesan","M50 4C50 4 90 46 90 64A40 40 0 0 1 10 64C10 46 50 4 50 4Z"],
 ["Perisai","M50 4L90 18V50C90 74 70 90 50 98C30 90 10 74 10 50V18Z"],
 ["Sabit","M62 6A46 46 0 1 0 94 70A38 38 0 0 1 62 6Z"],
 ["Petir","M58 2L16 56H44L36 98L84 40H54Z"],
 ["Segi enam","M25 6H75L98 50L75 94H25L2 50Z"],
 ["Jajar genjang","M24 20H96L76 80H4Z"]];
function sisipBentuk(i){const [nm,d]=BENTUK[i],sz=Math.max(20,num("p78sz",240)),m=mem();
 let cx=S.page.width/2,cy=S.page.height/2;
 if(val("p78tp","hal")==="pilih"&&m.length){const r=bbox(m);cx=r.x+r.w/2;cy=r.y+r.h/2;}
 const o=base("path",cx-sz/2,cy-sz/2,sz,sz,val("p78f","#6d5dfc"));o.d=d;o.vw=100;o.vh=100;o.name=nm;o.stroke=val("p78s","#20243a");o.strokeWidth=Math.max(0,num("p78w",0));
 Hi.snapshot();S.objects.push(o);pick([o]);T(nm+" disisipkan");}
/* ---- Bingkai ---- */
function bingkaiHalaman(ganda){const tb=Math.max(1,num("p78t",20)),jr=Math.max(0,num("p78j",30)),rx=Math.max(0,num("p78r",24)),w=S.page.width,h=S.page.height,col=val("p78c","#20243a");
 const mk=(inset,tebal,r)=>{const o=base("rect",inset,inset,w-inset*2,h-inset*2,"none");o.type="rect";o.stroke=col;o.strokeWidth=tebal;o.rx=Math.max(0,r);return o;};
 if(w-jr*2<tb*3||h-jr*2<tb*3)return T("Jarak terlalu besar untuk ukuran halaman");
 const a=[mk(jr,tb,rx)];if(ganda){const g=Math.round(tb*2.2),t2=Math.max(1,Math.round(tb/3));if(w-(jr+g)*2>t2*3&&h-(jr+g)*2>t2*3)a.push(mk(jr+g,t2,rx-g));}
 const gid=uid();a.forEach((o,i)=>{o.groupId=gid;o.name=(ganda?"Bingkai ganda ":"Bingkai ")+(i+1);});
 Hi.snapshot();S.objects.push(...a);pick(a);T(ganda?"Bingkai ganda ditambahkan":"Bingkai halaman ditambahkan");}
function bungkus(){const m=mem().filter(o=>!o.locked);if(!m.length)return T("Pilih objek yang akan dibungkus");
 const pd=Math.max(0,num("p78pd",24)),mode=val("p78md","pil"),per=val("p78un","semua")==="per",f=val("p78bf","#ffc857"),op=Math.max(0,Math.min(100,num("p78bo",100)));
 const sets=[];if(per){const seen=new Map();m.forEach(o=>{const k=o.groupId||o.id;if(!seen.has(k))seen.set(k,[]);seen.get(k).push(o);});seen.forEach(v=>sets.push(v));}else sets.push(m);
 Hi.snapshot();const made=[];
 sets.forEach((s,i)=>{const r=bbox(s),w=r.w+pd*2,h=r.h+pd*2,o=base("rect",r.x-pd,r.y-pd,w,h,f);o.name="Bungkus "+(i+1);o.opacity=op;o.rx=mode==="kotak"?0:mode==="sudut"?Math.round(Math.min(w,h)*.18):Math.round(Math.min(w,h)/2);
  const idx=Math.min(...s.map(p=>S.objects.indexOf(p)).filter(k=>k>=0));S.objects.splice(Math.max(0,idx),0,o);made.push(o);});
 pick(made);T(made.length+" pembungkus dibuat di belakang objek");}
function watermark(){const txt=(val("p78wt","DRAFT")||"").trim();if(!txt)return T("Tulis teks watermark dulu");
 const fs=Math.max(8,num("p78wf",56)),gp=Math.max(0,num("p78wg",120)),op=Math.max(1,Math.min(100,num("p78wo",15))),ang=num("p78wa",-30),W=S.page.width,H=S.page.height;
 const tw=Math.round(txt.length*fs*.58+20),th=Math.round(fs*1.3),sx=tw+gp,sy=th+gp,cols=Math.ceil(W/sx)+1,rows=Math.ceil(H/sy)+1;
 if(cols*rows>80)return T("Terlalu banyak ("+cols*rows+"). Perbesar huruf atau jarak (maks. 80)");
 const gid=uid(),out=[];
 for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){const x=c*sx+(r%2?sx/2:0)-sx/2,y=r*sy-sy/2,o=base("text",x,y,tw,th,val("p78wc","#20243a"));o.text=txt;o.fontSize=fs;o.bold=true;o.opacity=op;o.rotation=ang;o.groupId=gid;o.name="Watermark "+(out.length+1);
  if(CDMS.PusatTeks){const w2=CDMS.PusatTeks.ukur(o);o.x=Math.round(x+(tw-w2)/2);o.w=w2;}out.push(o);}
 Hi.snapshot();S.objects.push(...out);pick(out);T(out.length+" watermark ditambahkan (satu grup)");}
const H={bh:()=>bingkaiHalaman(false),bg:()=>bingkaiHalaman(true),bw:bungkus,wm:watermark};
BENTUK.forEach((_,i)=>{H["sh"+i]=()=>sisipBentuk(i);});
P.addTab("bentuk","Bentuk",`<div class="p78shp">${BENTUK.map((s,i)=>`<button data-h="sh${i}" title="${s[0]}"><svg viewBox="0 0 100 100" aria-hidden="true"><path d="${s[1]}"/></svg><span>${s[0]}</span></button>`).join("")}</div>
 <div class="p69row" style="margin-top:10px">${fld("p78sz","Ukuran",240,'min="20"')}${fld("p78w","Tebal garis",0,'min="0" max="40"')}<label>Warna isi<input id="p78f" type="color" value="#6d5dfc"></label><label>Warna garis<input id="p78s" type="color" value="#20243a"></label>
 <label>Letak<select id="p78tp"><option value="hal">Tengah halaman</option><option value="pilih">Tengah objek terpilih</option></select></label></div>
 <p class="muted">Ketuk bentuk untuk menyisipkannya. Hasilnya kurva yang bisa diubah ukuran, warna, gradien, dan filternya.</p>`,H);
P.addTab("bingkai","Bingkai",`<div class="p69h">Bingkai halaman</div>
 <div class="p69row">${fld("p78t","Tebal",20,'min="1"')}${fld("p78j","Jarak tepi",30,'min="0"')}${fld("p78r","Sudut",24,'min="0"')}<label>Warna<input id="p78c" type="color" value="#20243a"></label></div>
 <div class="p69btns">${b("bh","Bingkai tunggal")}${b("bg","Bingkai ganda")}</div>
 <div class="p69h" style="margin-top:12px">Bungkus objek terpilih</div>
 <div class="p69row">${fld("p78pd","Ruang dalam",24,'min="0"')}${fld("p78bo","Opasitas %",100,'min="0" max="100"')}<label>Warna<input id="p78bf" type="color" value="#ffc857"></label>
 <label>Bentuk<select id="p78md"><option value="pil">Pil</option><option value="sudut">Sudut bulat</option><option value="kotak">Kotak</option></select></label>
 <label>Jumlah<select id="p78un"><option value="semua">Satu untuk semua</option><option value="per">Satu per objek/grup</option></select></label></div>
 <div class="p69btns">${b("bw","Bungkus (di belakang)")}</div>
 <div class="p69h" style="margin-top:12px">Watermark berulang</div>
 <div class="p69row"><label style="grid-column:1/-1">Teks<input id="p78wt" type="text" value="DRAFT"></label>${fld("p78wf","Ukuran huruf",56,'min="8"')}${fld("p78wg","Jarak",120,'min="0"')}${fld("p78wo","Opasitas %",15,'min="1" max="100"')}${fld("p78wa","Sudut °",-30)}<label>Warna<input id="p78wc" type="color" value="#20243a"></label></div>
 <div class="p69btns">${b("wm","Tambah watermark")}</div><p class="muted" style="margin-top:8px">Watermark berupa satu grup (maks. 80 teks) yang bisa dihapus sekaligus.</p>`,H);
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q8="bentuk" title="Bentuk siap pakai">${ic("star")}</button><button data-q8="bingkai" title="Bingkai halaman">${ic("rect")}</button><button data-q8="bungkus" title="Bungkus objek dengan pil">${ic("group")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q8]");if(!x)return;const k=x.dataset.q8;
  if(k==="bentuk")P.openTab("bentuk");else if(k==="bingkai")P.openTab("bingkai");
  else{const md=$("#p78md");if(!md)P.openTab("bingkai");bungkus();}});}
MENUS.penata78=()=>[{h:"Tab Penata",items:[it("Bentuk (12 bentuk siap pakai)",()=>P.openTab("bentuk"),"star"),it("Bingkai (halaman, bungkus, watermark)",()=>P.openTab("bingkai"),"rect")]},{h:"Cepat",items:[it("Bingkai halaman tunggal",()=>bingkaiHalaman(false),"rect"),it("Bingkai halaman ganda",()=>bingkaiHalaman(true),"rect"),it("Bungkus pilihan dengan pil",bungkus,"group")]}];
BT.push(["penata78","panel","Penata 9"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata78");
})();
