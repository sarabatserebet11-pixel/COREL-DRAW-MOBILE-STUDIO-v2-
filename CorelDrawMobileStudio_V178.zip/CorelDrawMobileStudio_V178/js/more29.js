/* V41: menu Pintar - tata otomatis, sebar, acak, potong kanvas ke isi, statistik */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,sels,T,it,tc,box}=M;
const hh=o=>o.h||0,rnd=(a,b)=>a+Math.random()*(b-a),byPos=a=>[...a].sort((p,q)=>p.y-q.y||p.x-q.x);
const run=(n,fn,msg)=>{const a=sels().filter(o=>!o.locked&&!o.hidden);if(a.length<n)return T(n>1?"Pilih minimal "+n+" objek":"Pilih objek dulu");Hi.snapshot();fn(a);C.render();if(msg)T(msg);};
const flow=(dir,gap)=>run(2,a=>{const b=box(a);let c=dir==="h"?b.x0:b.y0;byPos(a).forEach(o=>{if(dir==="h"){o.x=Math.round(c);c+=o.w+gap;}else{o.y=Math.round(c);c+=hh(o)+gap;}});},dir==="h"?"Disusun mendatar":"Disusun menurun");
const grid=(cols,gap)=>run(2,a=>{const b=box(a),cw=Math.max(...a.map(o=>o.w))+gap,ch=Math.max(...a.map(hh))+gap;byPos(a).forEach((o,i)=>{o.x=Math.round(b.x0+(i%cols)*cw+(cw-gap-o.w)/2);o.y=Math.round(b.y0+Math.floor(i/cols)*ch+(ch-gap-hh(o))/2);});},"Grid "+cols+" kolom");
const ring=()=>run(3,a=>{const b=box(a),cx=(b.x0+b.x1)/2,cy=(b.y0+b.y1)/2,r=Math.max(80,Math.min(b.x1-b.x0,b.y1-b.y0)/2);a.forEach((o,i)=>{const t=i/a.length*Math.PI*2-Math.PI/2;o.x=Math.round(cx+Math.cos(t)*r-o.w/2);o.y=Math.round(cy+Math.sin(t)*r-hh(o)/2);});},"Disebar melingkar");
const scatter=()=>run(1,a=>a.forEach(o=>{o.x=Math.round(rnd(0,Math.max(0,S.page.width-o.w)));o.y=Math.round(rnd(0,Math.max(0,S.page.height-hh(o))));}),"Posisi diacak");
const tilt=()=>run(1,a=>a.forEach(o=>{o.rotation=Math.round(rnd(-25,25));}),"Rotasi diacak");
const sizes=()=>run(1,a=>a.forEach(o=>{const k=rnd(.7,1.3);o.w=Math.max(1,Math.round(o.w*k));if(o.h)o.h=Math.max(1,Math.round(o.h*k));}),"Ukuran diacak");
function fitPage(){const a=S.objects.filter(o=>!o.hidden);if(!a.length)return T("Kanvas kosong");Hi.snapshot();const m=40,b=box(a);a.forEach(o=>{o.x=Math.round(o.x-b.x0+m);o.y=Math.round(o.y-b.y0+m);});S.page.width=Math.round(b.x1-b.x0+m*2);S.page.height=Math.round(b.y1-b.y0+m*2);C.render();T("Kanvas dipotong ke isi: "+S.page.width+" × "+S.page.height);}
function pickBy(fn,msg){const a=S.objects.filter(o=>!o.hidden&&!o.locked);if(!a.length)return T("Tidak ada objek");const o=fn(a);M.pick([o]);T(msg);}
function stats(){const t={},cols={};S.objects.forEach(o=>{t[o.type]=(t[o.type]||0)+1;if(o.fill&&/^#/.test(o.fill))cols[o.fill]=(cols[o.fill]||0)+1;});
 const top=Object.entries(cols).sort((a,b)=>b[1]-a[1]).slice(0,8);
 N.openModal("Statistik desain",`<div class="st-pane"><p><b>${S.objects.length}</b> objek · kanvas ${S.page.width} × ${S.page.height}</p><p>${Object.entries(t).map(([k,v])=>k+": "+v).join(" · ")||"Kosong"}</p><div style="display:flex;gap:6px;flex-wrap:wrap">${top.map(([c,n])=>`<span title="${c} (${n})" style="width:34px;height:34px;border-radius:8px;border:1px solid var(--line);background:${c}"></span>`).join("")}</div></div>`);}
MENUS.pintar=()=>[
 {h:"Tata otomatis (objek terpilih)",items:[it("Susun mendatar",()=>flow("h",20),"arrange"),it("Susun menurun",()=>flow("v",20),"arrange"),...[2,3,4].map(n=>it("Grid "+n+" kolom",()=>grid(n,24),"transform")),it("Sebar melingkar",ring,"transform")]},
 {h:"Acak kreatif",items:[tc("Acak posisi",scatter),tc("Acak rotasi",tilt),tc("Acak ukuran",sizes)]},
 {h:"Pilih cepat",items:[tc("Objek terbesar",()=>pickBy(a=>a.reduce((p,q)=>p.w*hh(p)>=q.w*hh(q)?p:q),"Objek terbesar dipilih")),tc("Objek terkecil",()=>pickBy(a=>a.reduce((p,q)=>p.w*hh(p)<=q.w*hh(q)?p:q),"Objek terkecil dipilih"))]},
 {h:"Kanvas & info",items:[it("Potong kanvas ke isi",fitPage,"copy"),it("Statistik desain",stats,"eye")]}];
BT.push(["pintar","studio","Pintar"]);M.HUBS.find(h=>h[0]==="atur")[3].push("pintar");
})();
