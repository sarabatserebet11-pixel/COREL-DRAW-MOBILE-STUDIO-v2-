/* V29: multi-halaman (slide/carousel), Boolean kurangi, ujung panah garis */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),E=CDMS.escape;
const P=CDMS.Pages={};S.pages=[null];S.pageIdx=0;
const cur=()=>({objects:S.objects,page:{width:S.page.width,height:S.page.height,background:S.page.background}});
P.sync=()=>{if(!Array.isArray(S.pages)||!S.pages.length)S.pages=[null];if(S.pageIdx>=S.pages.length)S.pageIdx=S.pages.length-1;S.pages[S.pageIdx]=cur();};
function load(pg){S.objects=pg.objects;S.page={width:pg.page.width,height:pg.page.height,background:pg.page.background};S.selected=null;S.selectedIds=[];S.history=[];S.future=[];C.render();}
P.go=i=>{P.sync();if(i<0||i>=S.pages.length||i===S.pageIdx)return;S.pageIdx=i;load(S.pages[i]);};
P.add=clone=>{P.sync();const base=S.pages[S.pageIdx],pg=clone?JSON.parse(JSON.stringify(base)):{objects:[],page:{...base.page}};
 if(clone){const map={};pg.objects.forEach(o=>{map[o.id]=uid();});pg.objects.forEach(o=>{const old=o.id;o.id=map[old];if(o.clipBy&&map[o.clipBy])o.clipBy=map[o.clipBy];if(o.clipSub&&map[o.clipSub])o.clipSub=map[o.clipSub];if(o.fxOf&&map[o.fxOf])o.fxOf=map[o.fxOf];});}
 S.pages.splice(S.pageIdx+1,0,pg);S.pageIdx++;load(pg);T("Halaman "+(S.pageIdx+1)+" dari "+S.pages.length);};
P.del=()=>{if(S.pages.length<2)return T("Minimal harus ada satu halaman");P.sync();S.pages.splice(S.pageIdx,1);S.pageIdx=Math.min(S.pageIdx,S.pages.length-1);load(S.pages[S.pageIdx]);T("Halaman dihapus");};
P.move=d=>{P.sync();const j=S.pageIdx+d;if(j<0||j>=S.pages.length)return;[S.pages[S.pageIdx],S.pages[j]]=[S.pages[j],S.pages[S.pageIdx]];S.pageIdx=j;C.render();};
const reset=()=>{S.pages=[null];S.pageIdx=0;};
const nd=C.newDocument;C.newDocument=function(){nd.apply(this,arguments);reset();};
const lp=C.loadProject;C.loadProject=function(p){lp.call(this,p);reset();if(p&&Array.isArray(p.pages)&&p.pages.length>1){S.pages=p.pages;S.pageIdx=Math.min(p.pageIdx||0,p.pages.length-1);const pg=S.pages[S.pageIdx];if(pg&&pg.objects){S.objects=pg.objects;S.page={width:pg.page.width,height:pg.page.height,background:pg.page.background};}}C.render();};
CDMS.Storage.save=function(){P.sync();const item={name:S.projectName,width:S.page.width,height:S.page.height,background:S.page.background,objects:S.objects,updated:Date.now()};if(S.pages.length>1){item.pages=S.pages;item.pageIdx=S.pageIdx;}
 let list=this.list();const i=list.findIndex(x=>x.name===item.name);if(i>=0)list.splice(i,1);list.unshift(item);list=list.slice(0,20);
 try{localStorage.setItem(this.key,JSON.stringify(list));N.renderRecents();CDMS.toast("Proyek tersimpan"+(S.pages.length>1?" ("+S.pages.length+" halaman)":""));}catch(e){try{this.downloadJSON(item,String(item.name||"proyek").replace(/[^\w-]+/g,"_")+".cdms");CDMS.toast("Penyimpanan penuh, berkas cadangan .cdms diunduh.");}catch(_){CDMS.toast("Penyimpanan penuh dan cadangan gagal dibuat.");}}};

/* ---- indikator & navigasi cepat ---- */
const bl=$(".canvas-bottomline");
if(bl&&!bl.querySelector(".pg-nav"))bl.insertAdjacentHTML("afterbegin",'<div class="pg-nav" hidden><button class="icon-btn" data-pg="prev" title="Halaman sebelumnya">◀</button><b id="pgInd">1/1</b><button class="icon-btn" data-pg="next" title="Halaman berikutnya">▶</button></div>');
document.addEventListener("click",e=>{const b=e.target.closest("[data-pg]");if(b)P.go(S.pageIdx+(b.dataset.pg==="next"?1:-1));});
const rr=C.render;
C.render=function(){rr.call(this);const n=S.pages.length,nav=$(".pg-nav"),lab=$("#documentLabel");if(nav){nav.hidden=n<2;$("#pgInd").textContent=(S.pageIdx+1)+"/"+n;}if(lab&&n>1)lab.textContent=S.projectName+" · Hal "+(S.pageIdx+1)+"/"+n;};

/* ---- daftar halaman & ekspor semua ---- */
function list(){P.sync();N.openModal("Daftar halaman",`<div class="modal-grid">${S.pages.map((pg,i)=>`<button data-gp="${i}" style="${i===S.pageIdx?"border-color:var(--accent)":""}"><svg viewBox="0 0 ${pg.page.width} ${pg.page.height}" style="width:100%;height:70px;background:#fff;border-radius:6px"><rect width="${pg.page.width}" height="${pg.page.height}" fill="${E(String(pg.page.background).startsWith("grad:")?pg.page.background.slice(5).split(",")[0]:pg.page.background)}"/>${C.docMarkup(pg)}</svg><span>Halaman ${i+1}</span></button>`).join("")}</div>`);
 document.querySelectorAll("[data-gp]").forEach(b=>b.onclick=()=>{N.closeModal();P.go(+b.dataset.gp);});}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function exportAll(){P.sync();const n=S.pages.length,back=S.pageIdx,nm=S.projectName;T("Mengekspor "+n+" halaman…");
 for(let i=0;i<n;i++){P.go(i);await sleep(350);S.projectName=nm+"_hal"+(i+1);CDMS.Export.png(2);await sleep(1100);}
 S.projectName=nm;P.go(back);}
MENUS.pages=()=>[
 {h:"Halaman "+(S.pageIdx+1)+" dari "+S.pages.length,items:[it("Tambah halaman kosong",()=>P.add(false),"plus"),it("Duplikat halaman ini",()=>P.add(true),"copy"),it("Hapus halaman ini",()=>P.del(),"trash")]},
 {h:"Navigasi",items:[it("Halaman sebelumnya",()=>P.go(S.pageIdx-1),"undo"),it("Halaman berikutnya",()=>P.go(S.pageIdx+1),"redo"),it("Daftar halaman…",list,"layers")]},
 {h:"Susun & ekspor",items:[it("Geser halaman ke kiri",()=>P.move(-1),"undo"),it("Geser halaman ke kanan",()=>P.move(1),"redo"),it("Ekspor semua halaman (PNG)",exportAll,"export")]}];

/* ---- boolean kurangi & ujung panah ---- */
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);
 if(o.clipSub&&!o.rotation&&!o.flipH&&!o.flipV){const q=S.objects.find(x=>x.id===o.clipSub);
  if(q&&!q.clipSub&&!q.clipBy){const id="sb-"+o.id,inner=om.call(this,{...q,opacity:100,locked:false}).replace(` data-id="${q.id}"`,"");
   s=s.replace("<g ",`<g mask="url(#${id})" `).replace(">",`><mask id="${id}" maskUnits="userSpaceOnUse" x="-6000" y="-6000" width="12000" height="12000"><rect x="-6000" y="-6000" width="12000" height="12000" fill="#fff"/><g style="filter:brightness(0)" transform="translate(${-o.x} ${-o.y})">${inner}</g></mask>`);}}
 if(o.type==="line"&&o.arrow){const w=o.w||1,h=o.h||0,sw=o.strokeWidth??2,L=Math.max(16,sw*4.5),col=o.stroke||"#20243a",ang=Math.atan2(h,w),
  head=(x,y,a)=>{const a1=a+Math.PI-.45,a2=a+Math.PI+.45;return `<polygon points="${x},${y} ${x+L*Math.cos(a1)},${y+L*Math.sin(a1)} ${x+L*Math.cos(a2)},${y+L*Math.sin(a2)}" fill="${col}"/>`;};let hs="";
  if(o.arrow==="end"||o.arrow==="both")hs+=head(w,h,ang);if(o.arrow==="start"||o.arrow==="both")hs+=head(0,0,ang+Math.PI);if(o.arrow==="dot")hs+=`<circle cx="${w}" cy="${h}" r="${Math.max(6,sw*2)}" fill="${col}"/>`;
  s=s.replace(/<\/g>$/,hs+"</g>");}
 return s;};
function subSet(){const a=sels();if(a.length<2)return T("Pilih 2 objek: yang dikurangi dulu, lalu pengurang (tombol Multi)");const c=a[0],m=a[1];if(c.rotation||c.flipH||c.flipV)return T("Objek pertama harus tanpa rotasi atau balik");if(m.clipSub||m.clipBy)return T("Pengurang tidak boleh berklip");
 Hi.snapshot();c.clipSub=m.id;m.hidden=true;S.selected=c.id;S.selectedIds=[c.id];C.render();T("Objek dikurangi. Lepas lewat menu Klip.");}
function subFree(){const a=sels().filter(o=>o.clipSub);if(!a.length)return T("Pilih objek yang dikurangi");Hi.snapshot();a.forEach(o=>{const m=S.objects.find(x=>x.id===o.clipSub);if(m)m.hidden=false;delete o.clipSub;});C.render();}
const ok=MENUS.klip;MENUS.klip=()=>[...ok(),{h:"Boolean (kurangi)",items:[it("Kurangi: objek 1 − objek 2",subSet,"rect"),it("Lepas pengurangan",subFree,"unlock")]}];
const os=MENUS.style;
MENUS.style=()=>[...os(),{h:"Ujung garis (objek Garis)",items:[["Tanpa ujung",""],["Panah akhir","end"],["Panah awal","start"],["Panah ganda","both"],["Titik akhir","dot"]].map(x=>it(x[0],()=>edit(o=>{if(x[1])o.arrow=x[1];else delete o.arrow;},"",o=>o.type==="line"),"line"))}];

BT.push(["pages","pages","Halaman"]);M.HUBS.find(h=>h[0]==="kanvas")[3].push("pages");
})();
