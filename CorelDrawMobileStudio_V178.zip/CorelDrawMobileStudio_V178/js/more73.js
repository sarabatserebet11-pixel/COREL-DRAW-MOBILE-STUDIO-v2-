/* V84: tab baru Spektrum (daftar warna di desain dan jumlah pemakainya, pilih objek menurut warna, ganti satu warna di seluruh desain, balikkan warna, abu-abu, terang/gelap, saturasi) dan Skala (skala persen, ubah rasio, bulatkan ke kelipatan, pas lebar/tinggi halaman) di panel Penata + tombol cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const val=(id,d)=>{const e=$("#"+id);return e&&e.value?e.value:d;};
const chk=(id,d)=>{const e=$("#"+id);return e?e.checked:d;};
const bbox=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y));return{x,y,w:Math.max(...a.map(o=>o.x+(o.w||0)))-x,h:Math.max(...a.map(o=>o.y+(o.h||0)))-y};};
const norm=c=>{if(typeof c!=="string")return null;c=c.trim().toLowerCase();if(/^#[0-9a-f]{6}$/.test(c))return c;if(/^#[0-9a-f]{3}$/.test(c))return"#"+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];return null;};
const rgb=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));
const toHex=a=>"#"+a.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0")).join("");
function h2hsl(h){const[r0,g0,b0]=rgb(h),r=r0/255,g=g0/255,bl=b0/255,mx=Math.max(r,g,bl),mn=Math.min(r,g,bl),l=(mx+mn)/2;let H=0,Sx=0;if(mx!==mn){const d=mx-mn;Sx=l>.5?d/(2-mx-mn):d/(mx+mn);H=mx===r?(g-bl)/d+(g<bl?6:0):mx===g?(bl-r)/d+2:(r-g)/d+4;H*=60;}return[H,Sx,l];}
function hsl2h(H,Sx,L){H=((H%360)+360)%360;const k=n=>(n+H/30)%12,a=Sx*Math.min(L,1-L),f=n=>L-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)));return toHex([f(0)*255,f(8)*255,f(4)*255]);}
const lum=h=>{const p=rgb(h).map(v=>v/255).map(v=>v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4));return .2126*p[0]+.7152*p[1]+.0722*p[2];};
/* ---- target & pemetaan warna ---- */
function terpilih(){const sel=M.sels();if(!sel.length)return null;const s=new Set();sel.forEach(o=>(o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]).forEach(p=>s.add(p)));return[...s].filter(o=>!o.locked);}
function sasaran(){const t=terpilih();return t||S.objects.filter(o=>!o.locked);}
function petakan(o,fn){let n=0;["fill","stroke"].forEach(k=>{const c=norm(o[k]);if(c&&o.type!=="image"){const v=fn(c);if(v!==c){o[k]=v;n++;}}});
 if(Array.isArray(o.grad)&&o.type!=="image"){const g=o.grad.slice(),a=norm(g[0]),b2=norm(g[1]);const n0=g[0],n1=g[1];if(a)g[0]=fn(a);if(b2)g[1]=fn(b2);if(g[0]!==n0||g[1]!==n1){o.grad=g;n++;}}return n;}
function terap(fn,msg){const a=sasaran();if(!a.length)return T("Desain masih kosong");Hi.snapshot();let n=0;a.forEach(o=>{if(petakan(o,fn))n++;});C.render();draw();T(n?msg+" ("+n+" objek"+(terpilih()?"":", seluruh desain")+")":"Tidak ada warna yang berubah");}
/* ---- Spektrum ---- */
function inventori(){const m=new Map();S.objects.forEach(o=>{if(o.type==="image")return;const add=c=>{c=norm(c);if(!c)return;if(!m.has(c))m.set(c,new Set());m.get(c).add(o.id);};
 if(o.type!=="line"&&o.type!=="path"||(norm(o.fill)))add(o.fill);if((o.strokeWidth||0)>0||o.type==="line"||o.type==="path")add(o.stroke);});
 return[...m.entries()].map(([c,s])=>[c,s]).sort((p,q)=>q[1].size-p[1].size);}
function draw(){const box=$("#p84list");if(!box)return;const inv=inventori().slice(0,24);
 box.innerHTML=inv.length?inv.map(([c,s])=>`<button data-p84c="${c}" title="${c.toUpperCase()} · ${s.size} objek" style="background:${c};color:${lum(c)>.45?"#000":"#fff"}">${s.size}</button>`).join(""):'<div class="kosong">Belum ada warna di desain.</div>';
 const inf=$("#p84info");if(inf)inf.textContent=inv.length+" warna berbeda"+(inventori().length>24?" (24 teratas ditampilkan)":"");}
function pilihWarna(c){const ids=new Set((inventori().find(x=>x[0]===c)||[0,new Set()])[1]);const a=S.objects.filter(o=>ids.has(o.id));if(!a.length)return;pick(a);const f=$("#p84from");if(f)f.value=c;T(a.length+" objek berwarna "+c.toUpperCase()+" dipilih");}
function gantiWarna(){const f=norm(val("p84from","#6d5dfc")),t=norm(val("p84to","#00d6c9"));if(!f||!t)return T("Warna tidak valid");if(f===t)return T("Warna asal dan tujuan sama");
 const only=chk("p84sel",false),a=only?terpilih():S.objects.filter(o=>!o.locked);if(!a||!a.length)return T(only?"Pilih objek dulu":"Desain kosong");Hi.snapshot();let n=0;a.forEach(o=>{if(petakan(o,c=>c===f?t:c))n++;});C.render();draw();T(n?"Warna diganti pada "+n+" objek":"Warna itu tidak ditemukan");}
const inv=c=>toHex(rgb(c).map(v=>255-v));
const abu=c=>{const[r,g,b2]=rgb(c),y=r*.299+g*.587+b2*.114;return toHex([y,y,y]);};
const terang=sg=>{const k=Math.max(0,Math.min(100,num("p84pc",15)))/100;return c=>{const[h,s,l]=h2hsl(c);return hsl2h(h,s,sg>0?l+(1-l)*k:l*(1-k));};};
const jenuh=sg=>{const k=Math.max(0,Math.min(100,num("p84pc",15)))/100;return c=>{const[h,s,l]=h2hsl(c);return hsl2h(h,sg>0?Math.min(1,s+(1-s)*k):s*(1-k),l);};};
/* ---- Skala ---- */
function skalaXY(m,kx,ky,ax,ay){const kf=Math.min(kx,ky);m.forEach(o=>{o.x=Math.round(ax+(o.x-ax)*kx);o.y=Math.round(ay+(o.y-ay)*ky);if(o.w)o.w=Math.max(1,Math.round(o.w*kx));if(o.h)o.h=Math.max(1,Math.round(o.h*ky));if(o.fontSize)o.fontSize=Math.max(1,Math.round(o.fontSize*kf));if(o.rx)o.rx=Math.round(o.rx*kf);if(o.strokeWidth)o.strokeWidth=Math.round(o.strokeWidth*kf*10)/10;});}
function satuan(){const t=terpilih();if(!t||!t.length)return null;if(val("p84md","bersama")==="bersama")return[{m:t,r:bbox(t)}];
 const seen=new Map();t.forEach(o=>{const k=o.groupId||o.id;if(!seen.has(k))seen.set(k,[]);seen.get(k).push(o);});return[...seen.values()].map(m=>({m,r:bbox(m)}));}
function skalaPct(p){const u=satuan();if(!u)return T("Pilih objek dulu");const k=Math.max(1,p)/100,tengah=val("p84an","tengah")==="tengah";Hi.snapshot();
 u.forEach(({m,r})=>skalaXY(m,k,k,tengah?r.x+r.w/2:r.x,tengah?r.y+r.h/2:r.y));C.render();T("Diskalakan ke "+Math.round(k*100)+"%");}
function rasio(rw,rh){const u=satuan();if(!u)return T("Pilih objek dulu");const tahanW=val("p84rm","lebar")==="lebar";Hi.snapshot();
 u.forEach(({m,r})=>{if(r.w<1||r.h<1)return;let nw=r.w,nh=r.h;if(tahanW)nh=r.w*rh/rw;else nw=r.h*rw/rh;skalaXY(m,nw/r.w,nh/r.h,r.x,r.y);});C.render();T("Rasio "+rw+":"+rh+" diterapkan (tahan "+(tahanW?"lebar":"tinggi")+")");}
function bulat(ukuran){const t=terpilih();if(!t||!t.length)return T("Pilih objek dulu");const n=Math.max(1,Math.round(num("p84n",10)));Hi.snapshot();
 t.forEach(o=>{if(ukuran){if(o.w)o.w=Math.max(n,Math.round(o.w/n)*n);if(o.h)o.h=Math.max(n,Math.round(o.h/n)*n);}else{o.x=Math.round(o.x/n)*n;o.y=Math.round(o.y/n)*n;}});C.render();T((ukuran?"Ukuran":"Posisi")+" dibulatkan ke kelipatan "+n);}
function pas(sumbu){const t=terpilih();if(!t||!t.length)return T("Pilih objek dulu");const r=bbox(t),mg=Math.max(0,num("p84m",0)),k=sumbu==="w"?(S.page.width-mg*2)/Math.max(1,r.w):(S.page.height-mg*2)/Math.max(1,r.h);
 Hi.snapshot();skalaXY(t,k,k,r.x,r.y);const r2=bbox(t);const dx=sumbu==="w"?mg-r2.x:(S.page.width-r2.w)/2-r2.x,dy=sumbu==="h"?mg-r2.y:(S.page.height-r2.h)/2-r2.y;t.forEach(o=>{o.x=Math.round(o.x+dx);o.y=Math.round(o.y+dy);});C.render();T(sumbu==="w"?"Dipas ke lebar halaman":"Dipas ke tinggi halaman");}
const H={sr:draw,gw:gantiWarna,iv:()=>terap(inv,"Warna dibalikkan"),ab:()=>terap(abu,"Diubah ke abu-abu"),tr:()=>terap(terang(1),"Warna dicerahkan"),gl:()=>terap(terang(-1),"Warna digelapkan"),js:()=>terap(jenuh(1),"Saturasi dinaikkan"),jk:()=>terap(jenuh(-1),"Saturasi diturunkan"),
 s50:()=>skalaPct(50),s75:()=>skalaPct(75),s125:()=>skalaPct(125),s150:()=>skalaPct(150),s200:()=>skalaPct(200),sk:()=>skalaPct(num("p84k",110)),
 r11:()=>rasio(1,1),r43:()=>rasio(4,3),r32:()=>rasio(3,2),r169:()=>rasio(16,9),r916:()=>rasio(9,16),r45:()=>rasio(4,5),
 bp:()=>bulat(false),bu:()=>bulat(true),pw:()=>pas("w"),ph:()=>pas("h")};
const cb=(id,l,on)=>`<label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 6px"><input id="${id}" type="checkbox" ${on?"checked":""}> ${l}</label>`;
const sel2=(id,l,o)=>`<label>${l}<select id="${id}">${o.map(x=>`<option value="${x[0]}">${x[1]}</option>`).join("")}</select></label>`;
P.addTab("spek","Spektrum",`<div class="p69h">Warna di desain <span id="p84info" class="muted" style="font-weight:400"></span></div><div id="p84list" class="p84sw"></div>
 <p class="muted" style="margin:-4px 0 8px">Ketuk warna untuk memilih semua objek berwarna itu (angka = jumlah objek).</p>
 <div class="p69row"><label>Ganti dari<input id="p84from" type="color" value="#6d5dfc"></label><label>Menjadi<input id="p84to" type="color" value="#00d6c9"></label></div>
 ${cb("p84sel","Hanya objek terpilih",false)}<div class="p69btns">${b("gw","Ganti warna")}${b("sr","Segarkan daftar")}</div>
 <div class="p69h" style="margin-top:12px">Ubah warna (pilihan, atau seluruh desain jika tidak ada pilihan)</div>
 <div class="p69row">${fld("p84pc","Kekuatan %",15,'min="0" max="100"')}</div>
 <div class="p69btns c3">${b("iv","Balikkan")}${b("ab","Abu-abu")}${b("tr","Lebih terang")}${b("gl","Lebih gelap")}${b("js","Lebih pekat")}${b("jk","Lebih pudar")}</div>`,H);
P.addTab("skala","Skala",`<div class="p69row">${sel2("p84md","Mode",[["bersama","Bersama (satu kotak)"],["per","Per objek/grup"]])}${sel2("p84an","Titik tumpu",[["tengah","Tengah"],["kiri","Kiri atas"]])}</div>
 <div class="p69h">Skala persen</div><div class="p69btns c3">${b("s50","50%")}${b("s75","75%")}${b("s125","125%")}${b("s150","150%")}${b("s200","200%")}</div>
 <div class="p69row" style="margin-top:8px">${fld("p84k","Persen khusus",110,'min="1"')}</div><div class="p69btns">${b("sk","Terapkan persen")}</div>
 <div class="p69h" style="margin-top:12px">Ubah rasio</div><div class="p69row">${sel2("p84rm","Pertahankan",[["lebar","Lebar"],["tinggi","Tinggi"]])}</div>
 <div class="p69btns c3">${b("r11","1:1")}${b("r43","4:3")}${b("r32","3:2")}${b("r169","16:9")}${b("r916","9:16")}${b("r45","4:5")}</div>
 <div class="p69h" style="margin-top:12px">Bulatkan & pas halaman</div><div class="p69row">${fld("p84n","Kelipatan",10,'min="1"')}${fld("p84m","Margin halaman",0,'min="0"')}</div>
 <div class="p69btns c4">${b("bp","Posisi")}${b("bu","Ukuran")}${b("pw","Pas lebar")}${b("ph","Pas tinggi")}</div>`,H);
document.addEventListener("click",e=>{const x=e.target.closest&&e.target.closest("[data-p84c]");if(x){pilihWarna(x.dataset.p84c);return;}if(e.target.closest&&e.target.closest(".p69 [data-t=spek]"))setTimeout(draw,0);});
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q14="spek" title="Warna di desain">${ic("similar")}</button><button data-q14="skala" title="Skala & rasio">${ic("wide")}</button><button data-q14="balik" title="Balikkan warna pilihan">${ic("flipH")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q14]");if(!x)return;const k=x.dataset.q14;
  if(k==="spek"){P.openTab("spek");draw();}else if(k==="skala")P.openTab("skala");else{if(!terpilih())return T("Pilih objek dulu");terap(inv,"Warna dibalikkan");}});}
MENUS.penata84=()=>[{h:"Tab Penata",items:[it("Spektrum (warna di desain, ganti)",()=>{P.openTab("spek");draw();},"similar"),it("Skala (persen, rasio, bulatkan)",()=>P.openTab("skala"),"wide")]},{h:"Cepat",items:[it("Balikkan warna",()=>terap(inv,"Warna dibalikkan"),"flipH"),it("Ubah ke abu-abu",()=>terap(abu,"Diubah ke abu-abu"),"similar"),it("Skala 125%",()=>skalaPct(125),"wide"),it("Skala 80%",()=>skalaPct(80),"wide")]}];
BT.push(["penata84","panel","Penata 15"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata84");
})();
