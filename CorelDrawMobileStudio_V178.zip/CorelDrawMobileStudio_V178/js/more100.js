/* V112: menu hub bisa dipakai dengan keyboard. Saat menu terbuka, sel pertama difokuskan; panah menggeser
   fokus antar sel, Home/End ke sel pertama/terakhir. Panah tidak lagi menggeser objek di kanvas saat menu terbuka. */
(()=>{
function wire(pop){if(pop.dataset.v112)return;pop.dataset.v112="1";
 const cells=()=>[...pop.querySelectorAll(".mn-cell,.mn-item")].filter(c=>c.offsetParent!==null);
 pop.addEventListener("keydown",e=>{const k=e.key;if(!/^(Arrow(Left|Right|Up|Down)|Home|End)$/.test(k))return;
  const l=cells(),i=l.indexOf(document.activeElement);if(!l.length)return;e.preventDefault();e.stopPropagation();
  if(i<0){l[0].focus();return;}
  let n=i;
  if(k==="ArrowRight")n=Math.min(l.length-1,i+1);else if(k==="ArrowLeft")n=Math.max(0,i-1);
  else if(k==="Home")n=0;else if(k==="End")n=l.length-1;
  else{const r=l[i].getBoundingClientRect(),dir=k==="ArrowDown"?1:-1;let best=-1,bd=1e9;
   l.forEach((c,j)=>{if(j===i)return;const q=c.getBoundingClientRect(),dy=(q.top-r.top)*dir;if(dy<=4)return;const d=dy*4+Math.abs(q.left-r.left);if(d<bd){bd=d;best=j;}});
   if(best>=0)n=best;}
  l[n].focus();});
 const f=cells()[0];if(f&&matchMedia("(pointer:fine)").matches)try{f.focus({preventScroll:true});}catch(e){}}
new MutationObserver(ms=>{ms.forEach(m=>m.addedNodes.forEach(n=>{if(n.nodeType===1&&n.classList&&n.classList.contains("mn-pop"))wire(n);}));}).observe(document.body,{childList:true});
})();
