/* V55: menu Dokumen (voucher, label harga, name tag, kop surat, papan skor, menu restoran, sampul, formulir) dan Sudut+ (radius persen, samakan, tambah/kurangi) */
(()=>{
const M=CDMS.Menus,{MENUS,BT,it,tc,edit,sels,T}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,AC,INK,MUTE,LINE}=K;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const OK="M10 52L40 82L92 20";
Object.assign(COMP,{
 "Voucher hadiah":()=>({w:600,h:260,a:[R(0,0,600,260,"#fff7e6",{rx:24,stroke:"#ffc857",strokeWidth:6,name:"Voucher"}),R(24,24,552,212,"none",{rx:16,stroke:"#ffc857",strokeWidth:2}),X("VOUCHER HADIAH",300,70,30,"#b7791f",{bold:1}),X("Rp 100.000",300,140,68,INK,{bold:1}),X("Kode: GIFT-2026 · Berlaku 30 hari",300,206,22,MUTE)]}),
 "Label harga":()=>({w:300,h:300,a:[E(0,0,300,300,"#ff4f6d",{name:"Label harga"}),E(14,14,272,272,"none",{stroke:"#ffffff",strokeWidth:4}),X("HANYA",150,78,26,"#ffe3e8",{bold:1}),X("99K",150,152,90,"#ffffff",{bold:1}),X("per item",150,230,24,"#ffe3e8")]}),
 "Name tag":()=>({w:480,h:320,a:[R(0,0,480,320,"#ffffff",{rx:24,stroke:"#00000018",strokeWidth:3,name:"Name tag"}),R(0,0,480,100,"#e5484d",{rx:24}),R(0,70,480,30,"#e5484d"),X("HELLO",240,36,34,"#ffffff",{bold:1}),X("my name is",240,76,22,"#ffe3e3"),R(40,150,400,90,"#f4f5fb",{rx:12}),X("Nama Anda",240,195,46,INK,{bold:1}),X("Peserta",240,280,24,MUTE)]}),
 "Kop surat":()=>({w:760,h:180,a:[E(0,20,110,110,AC,{name:"Kop surat"}),X("LOGO",55,75,24,"#ffffff",{bold:1}),X("NAMA PERUSAHAAN",140,46,40,INK,{left:1,bold:1}),X("Jl. Contoh No. 123, Jakarta 10110",140,88,22,MUTE,{left:1}),X("Telp (021) 555-0123 · info@contoh.id",140,118,22,MUTE,{left:1}),R(0,160,760,6,AC,{rx:3}),R(0,170,760,2,INK)]}),
 "Papan skor":()=>({w:560,h:260,a:[R(0,0,560,260,"#11162a",{rx:28,name:"Papan skor"}),X("TIM A",110,50,26,"#9aa6d0",{bold:1}),X("TIM B",450,50,26,"#9aa6d0",{bold:1}),X("3",110,140,110,"#ffffff",{bold:1}),X("2",450,140,110,"#ffffff",{bold:1}),X("-",280,136,80,"#6d5dfc",{bold:1}),R(210,206,140,36,"#ff4f6d",{rx:18}),X("72'",280,224,22,"#ffffff",{bold:1})]}),
 "Item menu restoran":()=>({w:520,h:160,a:[R(0,0,520,160,"#ffffff",{rx:20,stroke:"#00000018",strokeWidth:3,name:"Item menu"}),E(16,16,128,128,"#ffe9c7"),X("Nasi Goreng Spesial",164,50,30,INK,{left:1,bold:1}),X("Telur, ayam, kerupuk, acar",164,88,22,MUTE,{left:1}),X("Rp 28.000",164,128,28,"#e5484d",{left:1,bold:1})]}),
 "Sampul buku":()=>({w:420,h:600,a:[R(0,0,420,600,AC,{rx:12,name:"Sampul"}),R(0,0,26,600,"#000000",{opacity:18}),E(90,70,240,240,"#ffffff",{opacity:18}),X("JUDUL BUKU",223,370,52,"#ffffff",{bold:1}),X("Sub judul singkat di sini",223,420,24,"#e2dcff"),R(150,480,146,4,"#ffffff",{opacity:70}),X("Nama Penulis",223,530,28,"#ffffff")]}),
 "Garis isian":()=>({w:480,h:60,a:[X("Nama:",0,24,26,INK,{left:1,bold:1}),R(110,40,370,3,INK,{name:"Garis isian"})]}),
 "Kotak centang":()=>({w:300,h:56,a:[R(0,6,44,44,"#ffffff",{rx:8,stroke:INK,strokeWidth:4,name:"Kotak centang"}),P(10,16,26,24,OK,"none",{stroke:"#16a34a",strokeWidth:14}),X("Saya setuju",66,28,26,INK,{left:1})]}),
 "Kolom tanda tangan":()=>({w:360,h:200,a:[X("Jakarta, 23 Oktober 2026",180,24,22,MUTE),X("Hormat kami,",180,56,24,INK),R(40,150,280,3,INK,{name:"Tanda tangan"}),X("( Nama Lengkap )",180,180,24,INK,{bold:1})]})
});
MENUS.dokumen=()=>[
 {h:"Bisnis & promosi",items:["Voucher hadiah","Label harga","Papan skor","Item menu restoran"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Dokumen & identitas",items:["Name tag","Kop surat","Sampul buku"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Formulir",items:["Garis isian","Kotak centang","Kolom tanda tangan"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["dokumen","doc","Dokumen"]);
hubAdd("pustaka","dokumen");
/* Sudut+: radius berdasarkan persen sisi terpendek (hanya persegi) */
const isR=o=>o.type==="rect";
const pct=p=>edit(o=>{o.rx=Math.round(Math.min(o.w,o.h)*p/100);},"Radius "+p+"%",isR);
MENUS.sudut2=()=>[
 {h:"Radius persen (sisi terpendek)",items:[0,10,20,30,40,50].map(p=>tc(p+"%",()=>pct(p)))},
 {h:"Ubah radius",items:[["+8",8],["+24",24],["−8",-8],["−24",-24]].map(x=>tc(x[0],()=>edit(o=>{o.rx=Math.max(0,Math.min(Math.round(Math.min(o.w,o.h)/2),(o.rx||0)+x[1]));},"",isR)))},
 {h:"Samakan",items:[it("Samakan dengan objek pertama",()=>{const a=sels().filter(isR);if(a.length<2)return T("Pilih 2+ persegi");const v=a[0].rx||0;edit(o=>{o.rx=Math.min(v,Math.round(Math.min(o.w,o.h)/2));},"Radius disamakan",isR);},"rect"),
  it("Pil penuh (bulat sempurna)",()=>edit(o=>{o.rx=Math.round(Math.min(o.w,o.h)/2);},"Bentuk pil",isR),"rect"),
  it("Radius acak",()=>edit(o=>{o.rx=Math.round(Math.random()*Math.min(o.w,o.h)/2);},"Radius acak",isR),"rect")]}];
BT.push(["sudut2","corner","Sudut+"]);
hubAdd("atur","sudut2");
})();
