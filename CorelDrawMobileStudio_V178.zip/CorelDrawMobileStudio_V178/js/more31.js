/* V43 (1/2): seleksi kotak (marquee), simpan otomatis + pemulihan, pintasan / */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,N=CDMS.Navigation,{T}=M,$=s=>document.querySelector(s),NS="http://www.w3.org/2000/svg";

/* ---- seleksi kotak: seret di area kosong dengan alat Pilih; Shift/Multi menambah seleksi ---- */
const rotBox=o=>{const w=o.w||0,h=o.h||0,cx=o.x+w/2,cy=o.y+h/2,t=(o.rotation||0)*Math.PI/180,c=Math.cos(t),s=Math.sin(t);
 const xs=[],ys=[];[[-w/2,-h/2],[w/2,-h/2],[w/2,h/2],[-w/2,h/2]].forEach(([x,y])=>{xs.push(cx+x*c-y*s);ys.push(cy+x*s+y*c);});
 return{x0:Math.min(...xs),x1:Math.max(...xs),y0:Math.min(...ys),y1:Math.max(...ys)};};
const hits=(a,b)=>{const x0=Math.min(a.x,b.x),x1=Math.max(a.x,b.x),y0=Math.min(a.y,b.y),y1=Math.max(a.y,b.y),ids=new Set();
 S.objects.forEach(o=>{if(o.hidden||o.locked)return;const r=rotBox(o);if(r.x1>=x0&&r.x0<=x1&&r.y1>=y0&&r.y0<=y1)ids.add(o.id);});
 S.objects.forEach(o=>{if(o.groupId&&ids.has(o.id))S.objects.forEach(q=>{if(q.groupId===o.groupId&&!q.locked&&!q.hidden)ids.add(q.id);});});
 return[...ids];};
let mq=null;
const k=()=>Math.max(.3,S.page.width/(C.svg.getBoundingClientRect().width||S.page.width));
const rect=()=>{let r=$("#cdMarquee");if(!r){r=document.createElementNS(NS,"rect");r.id="cdMarquee";r.setAttribute("pointer-events","none");r.setAttribute("fill","rgba(0,214,201,.12)");r.setAttribute("stroke","#00d6c9");C.svg.appendChild(r);}return r;};
const pd=C.pointerDown,pm=C.pointerMove;
C.pointerDown=function(e){const t=e.target,empty=S.tool==="select"&&!S.pipet&&e.button===0&&(t===this.svg||t.id==="pageBackground"),
 keep=empty&&(e.shiftKey||S.multi)?[...(S.selectedIds||[])]:[];
 pd.call(this,e);
 if(!empty)return;const p=this.point(e);mq={p,keep,on:false,last:""};
 try{this.svg.setPointerCapture&&this.svg.setPointerCapture(e.pointerId);}catch(_){}};
C.pointerMove=function(e){pm.call(this,e);if(!mq)return;const p=this.point(e),kk=k();
 if(!mq.on){if(Math.hypot(p.x-mq.p.x,p.y-mq.p.y)<5*kk)return;mq.on=true;}
 const r=rect(),x=Math.min(p.x,mq.p.x),y=Math.min(p.y,mq.p.y);
 r.setAttribute("x",x);r.setAttribute("y",y);r.setAttribute("width",Math.abs(p.x-mq.p.x));r.setAttribute("height",Math.abs(p.y-mq.p.y));
 r.setAttribute("stroke-width",1.5*kk);r.setAttribute("stroke-dasharray",`${6*kk} ${4*kk}`);
 const ids=[...new Set([...mq.keep,...hits(mq.p,p)])],key=ids.join();
 if(key!==mq.last){mq.last=key;S.selectedIds=ids;S.selected=ids[ids.length-1]||null;this.render();}};
window.addEventListener("pointerup",()=>{if(!mq)return;const r=$("#cdMarquee");if(r)r.remove();
 if(mq.on&&S.selectedIds&&S.selectedIds.length)T(S.selectedIds.length+" objek dipilih");
 else if(!mq.on&&mq.keep.length){S.selectedIds=mq.keep;S.selected=mq.keep[mq.keep.length-1]||null;C.render();}
 mq=null;});
window.addEventListener("pointercancel",()=>{const r=$("#cdMarquee");if(r)r.remove();mq=null;});

/* ---- simpan otomatis (draf) + banner pemulihan di beranda ---- */
const AK="cdms_autosave_v1",LS=()=>{try{return JSON.parse(localStorage.getItem(AK)||"null");}catch(e){return null;}};
let tm=0,warned=false;
const draft=()=>{if(CDMS.Pages&&CDMS.Pages.sync)CDMS.Pages.sync();const it={name:S.projectName,width:S.page.width,height:S.page.height,background:S.page.background,objects:S.objects,updated:Date.now()};
 if(S.pages&&S.pages.length>1){it.pages=S.pages;it.pageIdx=S.pageIdx;}return it;};
const edVisible=()=>{const e=$("#editor");return e&&!e.classList.contains("hidden");};
const flush=()=>{if(!edVisible())return;try{if(!S.objects.length&&!(S.pages&&S.pages.length>1)){localStorage.removeItem(AK);return;}localStorage.setItem(AK,JSON.stringify(draft()));}
 catch(e){try{localStorage.removeItem(AK);}catch(_){}if(!warned){warned=true;T("Simpan otomatis dimatikan (penyimpanan penuh). Simpan manual atau ekspor .cdms.");}}};
const rn=C.render;C.render=function(){const r=rn.apply(this,arguments);clearTimeout(tm);tm=setTimeout(flush,1800);return r;};
document.addEventListener("visibilitychange",()=>{if(document.hidden){clearTimeout(tm);flush();}});
window.addEventListener("pagehide",()=>{clearTimeout(tm);flush();});
const fmt=t=>{try{return new Date(t).toLocaleString("id-ID",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"});}catch(e){return"";}};
function banner(){const old=$("#restoreBanner");if(old)old.remove();const d=LS(),dash=$("#dashboard");if(!d||!dash||!Array.isArray(d.objects)||!d.objects.length)return;
 const saved=CDMS.Storage.list().find(x=>x.name===d.name);if(saved&&JSON.stringify(saved.objects)===JSON.stringify(d.objects)&&!d.pages)return;
 const b=document.createElement("div");b.id="restoreBanner";b.className="restore-banner";
 b.innerHTML=`<div><b>Sesi terakhir belum disimpan</b><small>${CDMS.escape?CDMS.escape(d.name||"Desain"):"Desain"} · ${d.objects.length} objek · ${fmt(d.updated)}</small></div><div class="rb-act"><button class="btn primary" data-rb="go">Pulihkan</button><button class="btn subtle" data-rb="no">Buang</button></div>`;
 const hero=dash.querySelector(".hero");hero?hero.insertAdjacentElement("afterend",b):dash.prepend(b);
 b.onclick=e=>{const a=e.target.closest("[data-rb]");if(!a)return;if(a.dataset.rb==="go"){C.loadProject(d);T("Sesi dipulihkan");}else{try{localStorage.removeItem(AK);}catch(_){}}b.remove();};}
const sd=N.showDashboard;N.showDashboard=function(){flush();const r=sd.apply(this,arguments);banner();return r;};
const wait=setInterval(()=>{if($("#app")&&!$("#app").classList.contains("hidden")){clearInterval(wait);banner();}},300);

/* ---- pintasan: tombol / membuka pencarian fitur (Ctrl+K sudah dipakai peluncur di more5.js) ---- */
document.addEventListener("keydown",e=>{if(e.key!=="/"||e.ctrlKey||e.metaKey||e.altKey||!edVisible()||!$("#modalBackdrop").classList.contains("hidden"))return;
 if(/INPUT|TEXTAREA|SELECT/.test((document.activeElement&&document.activeElement.tagName)||""))return;e.preventDefault();try{M.MENUS.hub_cari()[0].items[0].f();}catch(_){}});
/* ---- PWA: daftar service worker (hanya http/https) dan pintasan ?new=1 dari ikon aplikasi ---- */
if("serviceWorker" in navigator&&/^https?:$/.test(location.protocol))window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
if(/[?&]new=1/.test(location.search)){const w2=setInterval(()=>{if($("#app")&&!$("#app").classList.contains("hidden")){clearInterval(w2);C.newDocument(1080,1080);}},250);}
M.rotBox=rotBox;
})();
