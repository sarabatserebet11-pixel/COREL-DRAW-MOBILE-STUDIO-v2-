/* V40 (1/2): Filter+, Pola, Organik, Teks Kreatif, Palet Tren, Massal */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc,cell}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;
function ask(title,html,cb,label){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">${label||"Buat"}</button></div>`);$("#aOk").onclick=cb;}
const mk=(t,o)=>({id:uid(),type:t,name:t,x:0,y:0,w:100,h:100,fill:"#6d5dfc",stroke:"none",strokeWidth:0,opacity:100,rotation:0,...o});
const put=(o,back)=>{Hi.snapshot();back?S.objects.unshift(o):S.objects.push(o);pick([o]);};
const lum=h=>{const n=parseInt(h.slice(1),16);return .299*(n>>16)+.587*(n>>8&255)+.114*(n&255);};
const om=C.objMarkup;C.objMarkup=function(o){let s=om.call(this,o);if(o.clipSelf){const id="cs-"+o.id;s=s.replace(/^<g /,`<g clip-path="url(#${id})" `).replace(/^(<g [^>]*>)/,`$1<defs><clipPath id="${id}"><rect width="${o.w}" height="${o.h}"/></clipPath></defs>`);}return s;};
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);

/* ---- Filter+ ---- */
const F=(id,b)=>`<filter id="${id}" x="-30%" y="-30%" width="160%" height="160%" color-interpolation-filters="sRGB">${b}</filter>`,TU=(f,s)=>`<feTurbulence type="fractalNoise" baseFrequency="${f}" numOctaves="3" seed="5" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="${s}" xChannelSelector="R" yChannelSelector="G"/>`;
Object.assign(M.FXS,{
 glitchrgb:id=>F(id,'<feColorMatrix in="SourceGraphic" type="matrix" values="1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" result="r"/><feOffset in="r" dx="-9" result="r2"/><feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0" result="c"/><feOffset in="c" dx="9" result="c2"/><feBlend in="r2" in2="c2" mode="screen"/>'),
 sharpen:id=>F(id,'<feConvolveMatrix order="3" kernelMatrix="0 -1 0 -1 5 -1 0 -1 0" preserveAlpha="true"/>'),
 bloom:id=>F(id,'<feGaussianBlur in="SourceGraphic" stdDeviation="12" result="b"/><feColorMatrix in="b" type="matrix" values="1.5 0 0 0 0 0 1.5 0 0 0 0 0 1.5 0 0 0 0 0 1 0" result="b2"/><feMerge><feMergeNode in="b2"/><feMergeNode in="SourceGraphic"/></feMerge>'),
 watercolor:id=>F(id,TU(".02",16).replace("/>","/>")+'<feGaussianBlur stdDeviation="1.2"/>'),
 liquid:id=>F(id,TU(".006 .03",44)),
 scatter:id=>F(id,TU(".8",20)),
 vhs:id=>F(id,'<feOffset in="SourceGraphic" dx="6" result="o"/><feGaussianBlur in="o" stdDeviation="3 0" result="bl"/><feMerge><feMergeNode in="SourceGraphic"/><feMergeNode in="bl"/></feMerge>')});
const FX=[["Glitch RGB (geser warna)","glitchrgb"],["Pertajam","sharpen"],["Bloom (cahaya lembut)","bloom"],["Cat air","watercolor"],["Cair (liquid)","liquid"],["Hamburan piksel","scatter"],["Bayangan VHS","vhs"]];
MENUS.fxp=()=>[{h:"Efek kreatif (objek terpilih)",items:FX.map(x=>it(x[0],()=>edit(o=>{o.svgfx=x[1];},"Filter diterapkan",o=>o.type!=="line"),"studio"))},{h:"Hapus",items:[it("Hapus filter SVG",()=>edit(o=>{delete o.svgfx;},"Filter dihapus"),"trash")]}];

/* ---- Pola latar ---- */
function patD(k,s){const w=W(),h=H();let d="",x,y;
 if(k==="honey"){const R=s/2,dx=Math.sqrt(3)*R,dy=1.5*R;for(let j=-1;j*dy<h+R;j++)for(let i=-1;i*dx<w+dx;i++){const cx=i*dx+(j&1?dx/2:0),cy=j*dy;for(let a=0;a<6;a++){const t=Math.PI/6+a*Math.PI/3;d+=(a?"L":"M")+(cx+R*Math.cos(t)).toFixed(1)+" "+(cy+R*Math.sin(t)).toFixed(1);}d+="Z";}}
 else if(k==="wave"){for(y=s/2;y<h+s;y+=s){d+=`M0 ${y}`;for(x=0;x<w+s;x+=s)d+=`q${s/4} ${-s/3} ${s/2} 0t${s/2} 0`;}}
 else if(k==="chev"){for(y=0;y<h+s;y+=s*.7){d+=`M0 ${y}`;for(x=0;x<w+s;x+=s)d+=`l${s/2} ${-s*.3}l${s/2} ${s*.3}`;}}
 else if(k==="plus"){const a=s*.12;for(y=s/2;y<h;y+=s)for(x=s/2;x<w;x+=s)d+=`M${x-a} ${y}h${2*a}M${x} ${y-a}v${2*a}`;}
 else if(k==="lattice"){for(x=-h;x<w+s;x+=s)d+=`M${x} 0L${x+h} ${h}M${x+h} 0L${x} ${h}`;}
 else if(k==="scale"){let j=0;for(y=0;y<h+s;y+=s/2,j++)for(x=-s;x<w+s;x+=s)d+=`M${x+(j&1)*s/2} ${y}a${s/2} ${s/2} 0 0 1 ${s} 0`;}
 else{let sd=7;const rnd=()=>(sd=(sd*16807)%2147483647)/2147483647,c=Math.round(w*h/(s*s*5)),a=s*.22;for(let n=0;n<c;n++){x=rnd()*w;y=rnd()*h;const t=n%4;d+=t===0?`M${x-a} ${y}a${a} ${a} 0 1 0 ${2*a} 0a${a} ${a} 0 1 0 ${-2*a} 0`:t===1?`M${x} ${y-a}L${x+a} ${y+a}H${x-a}Z`:t===2?`M${x-a*1.5} ${y}q${a*.75} ${-a} ${a*1.5} 0t${a*1.5} 0`:`M${x-a} ${y}h${2*a}M${x} ${y-a}v${2*a}`;}}
 return d;}
const PK=[["Sarang lebah","honey"],["Gelombang","wave"],["Chevron","chev"],["Tanda plus","plus"],["Belah ketupat","lattice"],["Sisik ikan","scale"],["Memphis (acak)","memphis"]];
function askPat(n,k){ask("Pola "+n,`<label>Warna garis<input id="pC" type="color" value="#6d5dfc"></label><label>Ukuran sel <output id="pSo">70</output><input id="pS" type="range" min="30" max="160" value="70" oninput="pSo.value=this.value"></label><label>Transparansi garis <output id="pOo">40</output><input id="pO" type="range" min="10" max="100" value="40" oninput="pOo.value=this.value"></label><label class="chk"><input id="pB" type="checkbox"> Ganti warna latar halaman</label><label>Warna latar<input id="pBc" type="color" value="#f4f1ff"></label>`,()=>{const s=+$("#pS").value,c=$("#pC").value,op=+$("#pO").value,bg=$("#pB").checked&&$("#pBc").value;N.closeModal();Hi.snapshot();if(bg)S.page.background=bg;S.objects.unshift(mk("path",{name:"Pola "+n,x:0,y:0,w:W(),h:H(),vw:W(),vh:H(),d:patD(k,s),fill:"none",stroke:c,strokeWidth:3,opacity:op,locked:true,clipSelf:true}));S.selected=null;S.selectedIds=[];C.render();T("Pola dibuat di belakang (terkunci; pakai Pilih > Buka semua kunci untuk mengedit)");},"Buat pola");}
MENUS.pola=()=>[{h:"Pola satu halaman penuh (di belakang objek)",items:PK.map(p=>it(p[0],()=>askPat(p[0],p[1]),"grid"))},{h:"Hapus",items:[it("Hapus semua pola",()=>{Hi.snapshot();S.objects=S.objects.filter(o=>!/^Pola /.test(o.name||""));C.render();T("Pola dihapus");},"trash")]}];

/* ---- Organik ---- */
const PAL=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4f83ff","#ff7ac8"];let pi=0;
function blob(){const n=8,r=[];let sd=Math.random()*1e5|0;const rnd=()=>(sd=(sd*16807)%2147483647)/2147483647,P=[];for(let i=0;i<n;i++){const a=i/n*Math.PI*2,q=.68+rnd()*.32;P.push([50+Math.cos(a)*46*q,50+Math.sin(a)*46*q]);}
 let d=`M${P[0][0].toFixed(1)} ${P[0][1].toFixed(1)}`;for(let i=0;i<n;i++){const p0=P[(i+n-1)%n],p1=P[i],p2=P[(i+1)%n],p3=P[(i+2)%n];d+=`C${(p1[0]+(p2[0]-p0[0])/6).toFixed(1)} ${(p1[1]+(p2[1]-p0[1])/6).toFixed(1)} ${(p2[0]-(p3[0]-p1[0])/6).toFixed(1)} ${(p2[1]-(p3[1]-p1[1])/6).toFixed(1)} ${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;}return d+"Z";}
const sz=()=>Math.round(Math.min(W(),H())*.45);
function addBlob(k=1){Hi.snapshot();const z=sz(),out=[];for(let i=0;i<k;i++){const o=mk("path",{name:"Blob",vw:100,vh:100,d:blob(),fill:PAL[pi++%6],opacity:k>1?70:100,w:Math.round(z*(1-i*.18)),h:Math.round(z*(1-i*.18))});o.x=Math.round((W()-o.w)/2+i*z*.12);o.y=Math.round((H()-o.h)/2+i*z*.08);S.objects.push(o);out.push(o);}pick(out);}
function wave(top){const h=Math.round(H()*.3),o=mk("path",{name:"Pembatas gelombang",x:0,y:top?0:H()-h,w:W(),h,vw:100,vh:100,d:top?"M0 0H100V62C82 90 68 30 50 58S18 92 0 60Z":"M0 40C18 8 32 70 50 42S82 10 100 38V100H0Z",fill:PAL[pi++%6]});put(o);}
function sunburst(){const n=24,cx=W()/2,cy=H()/2,R=Math.hypot(W(),H());let d="";for(let i=0;i<n;i+=2){const a=i/n*Math.PI*2,b=(i+1)/n*Math.PI*2;d+=`M${cx} ${cy}L${(cx+R*Math.cos(a)).toFixed(0)} ${(cy+R*Math.sin(a)).toFixed(0)}L${(cx+R*Math.cos(b)).toFixed(0)} ${(cy+R*Math.sin(b)).toFixed(0)}Z`;}put(mk("path",{name:"Sunburst",x:0,y:0,w:W(),h:H(),vw:W(),vh:H(),d,fill:"#ffc857",opacity:35,clipSelf:true}),true);}
function burst(){let d="";const n=20;for(let i=0;i<n*2;i++){const a=i/(n*2)*Math.PI*2,r=i%2?40:50;d+=(i?"L":"M")+(50+r*Math.cos(a)).toFixed(1)+" "+(50+r*Math.sin(a)).toFixed(1);}const z=Math.round(Math.min(W(),H())*.32);put(mk("path",{name:"Burst",x:Math.round((W()-z)/2),y:Math.round((H()-z)/2),w:z,h:z,vw:100,vh:100,d:d+"Z",fill:"#ff6b6b",stroke:"#20243a",strokeWidth:4}));}
function swoosh(){put(mk("path",{name:"Swoosh",x:Math.round(W()*.1),y:Math.round(H()*.4),w:Math.round(W()*.8),h:Math.round(W()*.3),vw:100,vh:100,d:"M4 74C30 4 62 118 96 24",fill:"none",stroke:PAL[pi++%6],strokeWidth:14}));}
MENUS.organ=()=>[{h:"Bentuk organik",items:[it("Blob acak",()=>addBlob(1),"shapes"),it("3 blob bertumpuk",()=>addBlob(3),"shapes"),it("Burst label (starburst)",burst,"star"),it("Swoosh melengkung",swoosh,"curve")]},{h:"Latar & pembatas",items:[it("Pembatas gelombang bawah",()=>wave(false),"canvas"),it("Pembatas gelombang atas",()=>wave(true),"canvas"),it("Sunburst (sinar) di belakang",sunburst,"star")]}];

/* ---- Teks Kreatif ---- */
const tsel=fn=>{const a=sels().filter(o=>o.type==="text");if(!a.length)return T("Pilih teks dulu");Hi.snapshot();a.forEach(fn);C.render();};
const bb=o=>{const g=C.group.querySelector(`[data-id="${o.id}"]`);try{const b=g.getBBox();return{x:b.x,y:b.y,w:b.width,h:b.height};}catch(e){return{x:0,y:0,w:o.w,h:o.h};}};
const behind=(o,x)=>S.objects.splice(S.objects.indexOf(o),0,x);
function backing(fill,pill,txt){tsel(o=>{const b=bb(o),p=Math.round((o.fontSize||64)*(pill?.35:.12)),px=pill?p*1.6:p,r=mk("rect",{name:"Latar teks",x:Math.round(o.x+b.x-px),y:Math.round(o.y+b.y-p),w:Math.round(b.w+px*2),h:Math.round(b.h+p*2),fill,rotation:o.rotation||0});r.rx=pill?Math.round(r.h/2):6;behind(o,r);if(txt)o.fill=txt;});}
MENUS.txk=()=>[{h:"Garis & isi",items:[it("Outline kosong (isi transparan)",()=>tsel(o=>{const c=o.fill&&o.fill!=="none"?o.fill:"#ffffff";o.stroke=c;o.fill="none";o.textOutline=true;o.strokeWidth=Math.max(2,Math.round((o.fontSize||64)/22));}),"text"),it("Isi + garis kontras",()=>tsel(o=>{o.stroke=lum(/^#/.test(o.fill||"")?o.fill:"#222222")>140?"#20243a":"#ffffff";o.textOutline=true;o.strokeWidth=Math.max(3,Math.round((o.fontSize||64)/14));}),"text"),it("Hapus outline",()=>tsel(o=>{o.textOutline=false;if(o.fill==="none")o.fill=o.stroke||"#20243a";}),"trash")]},
 {h:"Latar di belakang teks",items:[it("Sorot stabilo kuning",()=>backing("#ffe45e",false,"#20243a"),"text"),it("Label pil ungu",()=>backing("#6d5dfc",true,"#ffffff"),"text"),it("Label pil putih",()=>backing("#ffffff",true,"#20243a"),"text")]},
 {h:"Bentuk teks",items:[it("Gema 3 lapis",()=>tsel(o=>{for(let i=3;i>=1;i--)behind(o,{...o,id:uid(),name:"Gema",x:o.x+i*14,y:o.y+i*14,opacity:[0,55,32,14][i]});}),"text"),it("Garis bawah",()=>tsel(o=>{const b=bb(o);S.objects.push(mk("line",{name:"Garis bawah",x:Math.round(o.x+b.x),y:Math.round(o.y+b.y+b.h+6),w:Math.round(b.w),h:0,stroke:/^#/.test(o.fill||"")?o.fill:"#6d5dfc",strokeWidth:Math.max(3,Math.round((o.fontSize||64)/12))}));}),"line"),it("Huruf vertikal (tumpuk)",()=>tsel(o=>{o.text=[...String(o.text||"").replace(/\n/g,"")].join("\n");}),"text"),it("Beri tanda kutip “ ”",()=>tsel(o=>{o.text="“"+String(o.text||"").replace(/^[“"]|[”"]$/g,"")+"”";}),"text")]}];

/* ---- Palet Tren ---- */
const PT=[["Pastel permen",["#ffd6e0","#ffefcf","#d4f0f0","#c9b6f2","#a8d8ea"]],["Retro 70-an",["#e07a5f","#f2cc8f","#81b29a","#3d405b","#f4f1de"]],["Hutan",["#2d6a4f","#52b788","#95d5b2","#d8f3dc","#1b4332"]],["Samudra",["#03045e","#0077b6","#00b4d8","#90e0ef","#caf0f8"]],["Senja",["#ff6b6b","#ffa94d","#ffd43b","#845ef7","#364fc7"]],["Monokrom",["#111111","#444444","#888888","#cccccc","#ffffff"]],["Kopi susu",["#3e2723","#6d4c41","#a1887f","#d7ccc8","#efebe9"]],["Neon malam",["#0b0f2b","#7b2ff7","#00f5d4","#f15bb5","#fee440"]]];
function applyPal(p){const tg=S.palScope==="all"?S.objects.filter(o=>!o.hidden):sels();if(!tg.length)return T("Pilih objek dulu");Hi.snapshot();const map={};let n=0;tg.forEach(o=>{if(o.type==="line"||o.type==="image")return;const f=(o.fill||"").toLowerCase();if(!/^#[0-9a-f]{6}$/.test(f))return;if(!(f in map))map[f]=p[n++%p.length];o.fill=map[f];});C.render();T("Palet diterapkan");}
MENUS.paltr=()=>[{h:"Cakupan",items:[tc("Objek terpilih",()=>{S.palScope="sel";},{keep:1,on:S.palScope!=="all"}),tc("Semua objek",()=>{S.palScope="all";},{keep:1,on:S.palScope==="all"})]},
 {h:"Palet siap pakai (warna objek dipetakan berurutan)",items:PT.map(p=>cell(`<span style="display:flex;width:100%;height:16px;border-radius:5px;overflow:hidden">${p[1].map(c=>`<i style="flex:1;background:${c}"></i>`).join("")}</span><span>${p[0]}</span>`,()=>applyPal(p[1])))},
 {h:"Tambahan",items:[it("Latar halaman ← warna paling terang (palet terakhir)",()=>{const p=PT.find(x=>x[0]===S.palLast)||PT[0];Hi.snapshot();S.page.background=[...p[1]].sort((a,b)=>lum(b)-lum(a))[0];C.render();},"color"),...PT.slice(0,3).map(p=>it("Swatch halaman: "+p[0],()=>{S.palLast=p[0];Hi.snapshot();const z=Math.round(W()*.12),g=uid(),x0=Math.round((W()-z*5-16*4)/2),out=p[1].map((c,i)=>mk("rect",{name:"Swatch",groupId:g,x:x0+i*(z+16),y:Math.round(H()-z*1.6),w:z,h:z,rx:20,fill:c,stroke:"#20243a",strokeWidth:2}));S.objects.push(...out);pick(out);},"rect"))]}];

/* ---- Massal ---- */
const all=()=>S.objects.filter(o=>!o.hidden&&!o.locked);
function bulk(fn,msg,f){const a=all().filter(f||(()=>true));if(!a.length)return T("Tidak ada objek yang cocok");Hi.snapshot();a.forEach(fn);C.render();T(msg||a.length+" objek diubah");}
function scAll(k){bulk(o=>{const px=W()/2,py=H()/2,cx=px+(o.x+o.w/2-px)*k,cy=py+(o.y+(o.h||0)/2-py)*k;o.w=Math.max(1,Math.round(o.w*k));if(o.h)o.h=Math.round(o.h*k);if(o.fontSize)o.fontSize=Math.max(4,Math.round(o.fontSize*k));o.x=Math.round(cx-o.w/2);o.y=Math.round(cy-(o.h||0)/2);},"Semua objek diskalakan");}
const SH=o=>["rect","ellipse","star","polygon"].includes(o.type),FM=[["Arial","Arial, sans-serif"],["Georgia","Georgia, serif"],["Impact","Impact, 'Arial Black', sans-serif"],["Courier","'Courier New', monospace"],["Trebuchet","'Trebuchet MS', sans-serif"]];
MENUS.mass=()=>[{h:"Semua teks → font",items:FM.map(f=>tc(f[0],()=>bulk(o=>{o.fontFamily=f[1];},"",o=>o.type==="text")))},
 {h:"Semua bentuk",items:[it("Hapus semua garis tepi",()=>bulk(o=>{o.strokeWidth=0;o.stroke="none";},"",SH),"strokeI"),it("Garis tepi 3 px gelap",()=>bulk(o=>{o.strokeWidth=3;o.stroke="#20243a";},"",SH),"strokeI"),it("Sudut persegi bulat 28",()=>bulk(o=>{o.rx=28;},"",o=>o.type==="rect"),"rect")]},
 {h:"Transparansi & ukuran",items:[it("Transparansi semua 50%",()=>bulk(o=>{o.opacity=50;}),"eye"),it("Transparansi semua 100%",()=>bulk(o=>{o.opacity=100;}),"eye"),it("Skala semua 90% dari pusat halaman",()=>scAll(.9),"transform"),it("Skala semua 110% dari pusat halaman",()=>scAll(1.1),"transform")]},
 {h:"Kunci & gambar",items:[it("Kunci semua objek",()=>bulk(o=>{o.locked=true;},"Semua objek dikunci"),"lock"),it("Sembunyikan semua gambar",()=>bulk(o=>{o.hidden=true;},"Gambar disembunyikan",o=>o.type==="image"),"eye")]}];

BT.push(["fxp","filter","Filter+"],["pola","pattern","Pola"],["organ","blob","Organik"],["txk","textfx","Teks Kreatif"],["paltr","swatches","Palet Tren"],["mass","stack","Massal"]);
hubAdd("warna","fxp","paltr");hubAdd("pustaka","pola","organ");hubAdd("teks","txk");hubAdd("atur","mass");
})();
