/* V47: menu Presisi - geser/putar tepat, cermin salin, jarak sama, margin halaman */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,sels,pick,T,it}=M,uid=()=>crypto.randomUUID(),r0=Math.round;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const hh=o=>o.h||0,W=()=>S.page.width,H=()=>S.page.height;
const need=()=>{const a=sels();if(!a.length)T("Pilih objek dulu");return a;};
const nudge=(dx,dy)=>{const a=need();if(!a.length)return;Hi.snapshot();a.forEach(o=>{o.x=r0(o.x+dx);o.y=r0(o.y+dy);});C.render();};
const spin=d=>{const a=need();if(!a.length)return;Hi.snapshot();a.forEach(o=>{o.rotation=(((o.rotation||0)+d)%360+360)%360;});C.render();T("Rotasi "+(d>0?"+":"")+d+"°");};
const reset=()=>{const a=need();if(!a.length)return;Hi.snapshot();a.forEach(o=>{o.rotation=0;});C.render();T("Rotasi direset");};
const box=a=>({x0:Math.min(...a.map(o=>o.x)),x1:Math.max(...a.map(o=>o.x+o.w)),y0:Math.min(...a.map(o=>o.y)),y1:Math.max(...a.map(o=>o.y+hh(o)))});
/* cermin salin terhadap tengah halaman */
function mirror(mx,my){const a=need();if(!a.length)return;Hi.snapshot();const out=[];
 const mk=(fx,fy)=>a.forEach(o=>{const c=JSON.parse(JSON.stringify(o));c.id=uid();delete c.groupId;
  if(fx){c.x=r0(W()-o.x-o.w);c.flipH=!o.flipH;c.rotation=((360-(o.rotation||0))%360);}
  if(fy){c.y=r0(H()-o.y-hh(o));c.flipV=!o.flipV;c.rotation=((360-(c.rotation||0))%360);}
  out.push(c);});
 if(mx)mk(true,false);if(my)mk(false,true);if(mx&&my)mk(true,true);
 S.objects.push(...out);pick(out);T(out.length+" salinan cermin dibuat");}
/* jarak sama antar objek (urut menurut posisi) */
function gap(ax,g){const a=sels();if(a.length<2)return T("Pilih 2 objek atau lebih");Hi.snapshot();
 const k=ax==="h"?"x":"y",sz=ax==="h"?"w":"h",s=[...a].sort((p,q)=>p[k]-q[k]);let pos=s[0][k];
 s.forEach(o=>{o[k]=r0(pos);pos+=(o[sz]||0)+g;});C.render();T("Jarak "+g+" px antar objek");}
/* rapatkan ke tepi halaman dengan margin */
function edge(side,m){const a=need();if(!a.length)return;Hi.snapshot();const b=box(a);let dx=0,dy=0;
 if(side==="l")dx=m-b.x0;if(side==="r")dx=W()-m-b.x1;if(side==="t")dy=m-b.y0;if(side==="b")dy=H()-m-b.y1;
 a.forEach(o=>{o.x=r0(o.x+dx);o.y=r0(o.y+dy);});C.render();}
/* posisi tepat: pusatkan ke koordinat px */
function setPos(){const a=need();if(!a.length)return;const v=prompt("Posisi kiri-atas X,Y (px kanvas):","0,0");if(v==null)return;
 const p=v.split(/[ ,;]+/).map(Number);if(p.length<2||p.some(n=>!isFinite(n)))return T("Format: X,Y");
 Hi.snapshot();const b=box(a);a.forEach(o=>{o.x=r0(o.x-b.x0+p[0]);o.y=r0(o.y-b.y0+p[1]);});C.render();T("Dipindah ke "+p[0]+", "+p[1]);}
const N=[1,10,50];
MENUS.presisi=()=>[
 {h:"Geser tepat",items:N.flatMap(n=>[it("Kiri "+n+" px",()=>nudge(-n,0),"arrange"),it("Kanan "+n+" px",()=>nudge(n,0),"arrange"),it("Atas "+n+" px",()=>nudge(0,-n),"arrange"),it("Bawah "+n+" px",()=>nudge(0,n),"arrange")]).concat([it("Ke koordinat X,Y…",setPos,"arrange")])},
 {h:"Putar tepat",items:[it("−1°",()=>spin(-1),"transform"),it("+1°",()=>spin(1),"transform"),it("−15°",()=>spin(-15),"transform"),it("+15°",()=>spin(15),"transform"),it("−90°",()=>spin(-90),"transform"),it("+90°",()=>spin(90),"transform"),it("Reset rotasi",reset,"transform")]},
 {h:"Cermin salin (sumbu tengah halaman)",items:[it("Salin cermin kiri-kanan",()=>mirror(1,0),"copy"),it("Salin cermin atas-bawah",()=>mirror(0,1),"copy"),it("Salin ke 4 kuadran",()=>mirror(1,1),"copy")]},
 {h:"Jarak sama antar objek",items:[0,8,16,32].flatMap(g=>[it("Mendatar "+g+" px",()=>gap("h",g),"multi"),it("Menurun "+g+" px",()=>gap("v",g),"multi")])},
 {h:"Rapat ke tepi (margin 24 px)",items:[it("Kiri",()=>edge("l",24),"rect"),it("Kanan",()=>edge("r",24),"rect"),it("Atas",()=>edge("t",24),"rect"),it("Bawah",()=>edge("b",24),"rect")]}];
BT.push(["presisi","crosshair","Presisi"]);
hubAdd("atur","presisi");
})();
