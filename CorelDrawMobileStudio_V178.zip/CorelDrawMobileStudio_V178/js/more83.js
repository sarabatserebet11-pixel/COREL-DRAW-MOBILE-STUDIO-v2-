/* V95: dua grup menu baru.
   "Pola Lembar" (ikon tilesheet): Mozaik (pecah objek jadi ubin berwarna), Lembar Salin (isi halaman dengan salinan, seperti lembar label), Pantulan (cermin lantai/samping dengan opacity).
   "Anotasi" (ikon annotate): Dimensi (garis ukuran px/mm/cm), Kartu Palet (kartu warna dari desain + kode hex), Penanda (lencana nomor urut).
   Semua aksi bisa di-undo; hasil berupa objek biasa (grup) yang tetap bisa diedit. */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,tc,cell,sels,T}=M;
if(!M.HUBS)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),uid=()=>crypto.randomUUID();
const r1=v=>Math.round(v*10)/10,dpi=()=>S.dpi94||150,W=()=>S.page.width,H=()=>S.page.height;
const done=m=>{C.render();if(m)T(m);};
const unitsOf=a=>{const seen=new Set(),out=[];a.forEach(o=>{if(seen.has(o.id))return;const m=o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o];m.forEach(p=>seen.add(p.id));out.push(m);});return out;};
const bb=a=>{let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;a.forEach(o=>{x0=Math.min(x0,o.x);y0=Math.min(y0,o.y);x1=Math.max(x1,o.x+(o.w||0));y1=Math.max(y1,o.y+(o.h||0));});return{x:x0,y:y0,w:x1-x0,h:y1-y0};};
const clone=o=>JSON.parse(JSON.stringify(o));
const rect=(x,y,w,h,fill,x2)=>({id:uid(),type:"rect",name:"Kotak",x:Math.round(x),y:Math.round(y),w:Math.max(1,Math.round(w)),h:Math.max(1,Math.round(h)),rx:0,fill,stroke:"none",strokeWidth:0,opacity:100,rotation:0,...x2});
const text=(t,x,y,fs,fill,x2)=>({id:uid(),type:"text",name:"Teks",text:t,x:Math.round(x),y:Math.round(y),w:Math.round(t.length*fs*.6),h:Math.round(fs*1.2),fontSize:Math.round(fs),fill,opacity:100,rotation:0,...x2});
const line=(x,y,w,h,col,sw,x2)=>({id:uid(),type:"line",name:"Garis",x:Math.round(x),y:Math.round(y),w:Math.round(w),h:Math.round(h),stroke:col,strokeWidth:sw,fill:"none",opacity:100,rotation:0,...x2});
/* ---- warna ---- */
const parse=c=>{const m=/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(c||"").trim());if(!m)return null;let h=m[1];if(h.length===3)h=h.split("").map(x=>x+x).join("");return[0,2,4].map(i=>parseInt(h.substr(i,2),16));};
const toHex=r=>"#"+r.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0")).join("");
const mix=(a,b,t)=>toHex(a.map((v,i)=>v+(b[i]-v)*t));
const toHsl=([r,g,b])=>{r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;}return[h,s*100,l*100];};
const fromHsl=(h,s,l)=>{h=((h%360)+360)%360;s/=100;l/=100;const k=n=>(n+h/30)%12,a=s*Math.min(l,1-l),f=n=>l-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)));return toHex([f(0)*255,f(8)*255,f(4)*255]);};
const rnd=(a,b)=>a+Math.random()*(b-a);
const grup=(arr,nama)=>{const g=uid();arr.forEach(o=>{o.groupId=g;o.groupName=nama;});return arr;};

/* ================= POLA LEMBAR ================= */
const MOZ=[["Ombre mendatar","ombre"],["Ombre diagonal","diag"],["Papan catur","catur"],["Acak","acak"],["Acak warna","hue"]];
function mozaik(){const a=sels();if(!a.length)return T("Pilih objek dulu");const b=bb(a);if(!(b.w>4&&b.h>4))return T("Objek terlalu kecil");
 const n=S.mozN95||8,gap=S.mozGap95??2,st=S.mozSt95||"ombre",cw=b.w/n,rows=Math.max(1,Math.min(40,Math.round(b.h/cw))),ch=b.h/rows;
 if(n*rows>600)return T("Terlalu banyak ubin ("+n*rows+"). Kurangi kolom.");
 const base=parse(a[0].fill)||[109,93,252],light=parse(mix(base,[255,255,255],.82)),dark=parse(mix(base,[0,0,0],.3)),hsl=toHsl(base),el=a.length===1&&a[0].type==="ellipse";
 Hi.snapshot();const T0=[];
 for(let r=0;r<rows;r++)for(let c=0;c<n;c++){const cx=b.x+(c+.5)*cw,cy=b.y+(r+.5)*ch;
  if(el){const dx=(cx-(b.x+b.w/2))/(b.w/2),dy=(cy-(b.y+b.h/2))/(b.h/2);if(dx*dx+dy*dy>1)continue;}
  let col;const tx=n>1?c/(n-1):0,ty=rows>1?r/(rows-1):0;
  if(st==="ombre")col=mix(dark,light,tx);else if(st==="diag")col=mix(dark,light,(tx+ty)/2);else if(st==="catur")col=(c+r)%2?toHex(base):toHex(light);
  else if(st==="acak")col=mix(dark,light,Math.random());else col=fromHsl(hsl[0]+rnd(-45,45),Math.max(40,hsl[1]),rnd(35,72));
  T0.push(rect(b.x+c*cw+gap/2,b.y+r*ch+gap/2,cw-gap,ch-gap,col,{name:"Ubin "+(r+1)+"-"+(c+1)}));}
 if(!T0.length)return T("Tidak ada ubin yang terbentuk");
 grup(T0,"Mozaik");const ids=new Set(a.map(o=>o.id));
 if(S.mozDel95!==false){const i=Math.min(...a.map(o=>S.objects.indexOf(o)));S.objects=S.objects.filter(o=>!ids.has(o.id));S.objects.splice(Math.min(i,S.objects.length),0,...T0);}else S.objects.push(...T0);
 S.selectedIds=T0.map(o=>o.id);S.selected=T0[0].id;done("Mozaik "+n+"×"+rows+" ("+T0.length+" ubin)");}
MENUS.mozaik95=()=>[
 {h:"Gaya warna",items:MOZ.map(m=>tc(m[0],()=>{S.mozSt95=m[1];},{keep:1,on:(S.mozSt95||"ombre")===m[1]}))},
 {h:"Kolom ubin",items:[4,6,8,12,16].map(v=>tc(v+"",()=>{S.mozN95=v;},{keep:1,on:(S.mozN95||8)===v}))},
 {h:"Celah antar ubin (px)",items:[0,2,4,8].map(v=>tc(v+"",()=>{S.mozGap95=v;},{keep:1,on:(S.mozGap95??2)===v}))},
 {h:"Terapkan",items:[it("Pecah pilihan jadi mozaik",mozaik,"mosaic"),it(S.mozDel95===false?"Objek asal: DIPERTAHANKAN":"Objek asal: DIGANTI",()=>{S.mozDel95=S.mozDel95===false;},"settings",{keep:1})]}];

function salin(cols){const a=sels();if(!a.length)return T("Pilih objek dulu (atau satu grup)");const us=unitsOf(a),all=[].concat(...us),b=bb(all),m=S.lembarM95??10,g=S.lembarG95??10;
 if(!(b.w>0&&b.h>0))return T("Objek tidak punya ukuran");
 const maxC=Math.max(1,Math.floor((W()-2*m+g)/(b.w+g))),nc=cols?Math.min(cols,maxC):maxC,nr=Math.max(1,Math.floor((H()-2*m+g)/(b.h+g)));
 if(nc*nr<2)return T("Objek terlalu besar untuk digandakan di halaman ini");if(nc*nr>400)return T("Terlalu banyak salinan ("+nc*nr+")");
 Hi.snapshot();const gw=nc*b.w+(nc-1)*g,gh=nr*b.h+(nr-1)*g,x0=(W()-gw)/2,y0=(H()-gh)/2;const add=[];let k=0;
 for(let r=0;r<nr;r++)for(let c=0;c<nc;c++){const dx=Math.round(x0+c*(b.w+g)-b.x),dy=Math.round(y0+r*(b.h+g)-b.y);
  if(!k){all.forEach(o=>{o.x+=dx;o.y+=dy;});}
  else{const gm={};all.forEach(o=>{const c2=clone(o);c2.id=uid();c2.x+=dx;c2.y+=dy;if(c2.groupId)c2.groupId=gm[c2.groupId]||(gm[c2.groupId]=uid());c2.name=(o.name||o.type)+" salinan "+(k+1);add.push(c2);});}
  k++;}
 S.objects.push(...add);done("Lembar "+nc+" × "+nr+" = "+k+" salinan");}
MENUS.lembar95=()=>[
 {h:"Margin halaman (px)",items:[0,10,20,40].map(v=>tc(v+"",()=>{S.lembarM95=v;},{keep:1,on:(S.lembarM95??10)===v}))},
 {h:"Jarak antar salinan (px)",items:[0,10,20,40].map(v=>tc(v+"",()=>{S.lembarG95=v;},{keep:1,on:(S.lembarG95??10)===v}))},
 {h:"Isi halaman",items:[it("Penuhi halaman",()=>salin(0),"labelsheet"),it("Maksimum 2 kolom",()=>salin(2),"labelsheet"),it("Maksimum 3 kolom",()=>salin(3),"labelsheet"),it("Maksimum 4 kolom",()=>salin(4),"labelsheet")]}];

function pantul(arah){const a=sels();if(!a.length)return T("Pilih objek dulu");const us=unitsOf(a),gap=S.pantulG95??6,op=(S.pantulO95??35)/100;Hi.snapshot();let n=0;
 us.forEach(u=>{const b=bb(u),gm={};u.forEach(o=>{const c=clone(o);c.id=uid();c.pantul95=o.id;c.locked=false;c.name=(o.name||o.type)+" pantulan";c.opacity=Math.max(2,Math.round((o.opacity??100)*op));
  if(c.groupId)c.groupId=gm[c.groupId]||(gm[c.groupId]=uid());
  if(arah==="bawah"){const L=b.y+b.h+gap/2;c.y=Math.round(2*L-(o.y+(o.h||0)));c.flipV=!o.flipV;c.rotation=-(o.rotation||0);}
  else{const L=b.x+b.w+gap/2;c.x=Math.round(2*L-(o.x+(o.w||0)));c.flipH=!o.flipH;c.rotation=-(o.rotation||0);}
  S.objects.splice(S.objects.indexOf(o)+1,0,c);n++;});});
 done("Pantulan dibuat ("+n+" objek)");}
function hapusPantul(){const ids=new Set(sels().map(o=>o.id)),all=!ids.size,t=S.objects.filter(o=>o.pantul95&&(all||ids.has(o.pantul95)||ids.has(o.id)));if(!t.length)return T("Tidak ada pantulan");Hi.snapshot();const rm=new Set(t.map(o=>o.id));S.objects=S.objects.filter(o=>!rm.has(o.id));S.selected=null;S.selectedIds=[];done(t.length+" pantulan dihapus");}
MENUS.pantul95=()=>[
 {h:"Opacity pantulan (%)",items:[20,35,50].map(v=>tc(v+"",()=>{S.pantulO95=v;},{keep:1,on:(S.pantulO95??35)===v}))},
 {h:"Celah dari objek (px)",items:[0,6,16].map(v=>tc(v+"",()=>{S.pantulG95=v;},{keep:1,on:(S.pantulG95??6)===v}))},
 {h:"Buat pantulan",items:[it("Pantulan di bawah (lantai)",()=>pantul("bawah"),"reflect"),it("Pantulan di kanan (samping)",()=>pantul("kanan"),"reflect"),it("Hapus pantulan (pilihan, atau semua)",hapusPantul,"trash")]}];

/* ================= ANOTASI ================= */
const SAT=[["px","px"],["mm","mm"],["cm","cm"]];
const lab=px=>{const u=S.satuan95||"mm";return u==="px"?Math.round(px)+" px":u==="cm"?r1(px*2.54/dpi())+" cm":r1(px*25.4/dpi())+" mm";};
function dimensi(mode){const a=sels();if(!a.length)return T("Pilih objek dulu");const b=bb(a),off=S.dimOff95||32,fs=Math.max(12,Math.min(40,Math.round(Math.min(W(),H())*.022))),sw=Math.max(1,Math.round(fs/12)),col="#e11d48",ex={dim95:true};Hi.snapshot();const out=[];
 if(mode!=="v"){const y=b.y+b.h+off,t=lab(b.w),tw=t.length*fs*.6;out.push(grup([line(b.x,y,b.w,0,col,sw,{...ex,name:"Dimensi lebar"}),line(b.x,y-8,0,16,col,sw,ex),line(b.x+b.w,y-8,0,16,col,sw,ex),text(t,b.x+b.w/2-tw/2,y+10,fs,col,{...ex,bold:true})],"Dimensi lebar"));}
 if(mode!=="h"){const x=b.x-off,t=lab(b.h),tw=t.length*fs*.6;out.push(grup([line(x,b.y,0,b.h,col,sw,{...ex,name:"Dimensi tinggi"}),line(x-8,b.y,16,0,col,sw,ex),line(x-8,b.y+b.h,16,0,col,sw,ex),text(t,x-10-tw,b.y+b.h/2-fs/2,fs,col,{...ex,bold:true})],"Dimensi tinggi"));}
 S.objects.push(...[].concat(...out));done("Dimensi ditambahkan ("+(S.satuan95||"mm")+")");}
function hapusTandaX(k,nama){const t=S.objects.filter(o=>o[k]);if(!t.length)return T("Tidak ada "+nama);Hi.snapshot();S.objects=S.objects.filter(o=>!o[k]);S.selected=null;S.selectedIds=[];done(t.length+" objek "+nama+" dihapus");}
MENUS.dimensi95=()=>[
 {h:"Satuan (kanvas pakai "+dpi()+" dpi)",items:SAT.map(x=>tc(x[0],()=>{S.satuan95=x[1];},{keep:1,on:(S.satuan95||"mm")===x[1]}))},
 {h:"Jarak garis dari objek (px)",items:[16,32,64].map(v=>tc(v+"",()=>{S.dimOff95=v;},{keep:1,on:(S.dimOff95||32)===v}))},
 {h:"Tambah dimensi",items:[it("Lebar (di bawah objek)",()=>dimensi("h"),"dimline"),it("Tinggi (di kiri objek)",()=>dimensi("v"),"dimline"),it("Lebar + tinggi",()=>dimensi("both"),"dimline"),it("Hapus semua dimensi",()=>hapusTandaX("dim95","dimensi"),"trash")]}];

function warnaDesain(a){const cnt=new Map(),add=c=>{const p=parse(c);if(!p)return;const h=toHex(p);cnt.set(h,(cnt.get(h)||0)+1);};
 a.forEach(o=>{if(o.hidden||o.cm94||o.pal95||o.pen95||o.dim95)return;if(o.type!=="image"&&o.type!=="line"&&!(o.type==="path"&&o.fill==="none"))add(o.fill);if(o.strokeWidth)add(o.stroke);if(Array.isArray(o.grad)){add(o.grad[0]);add(o.grad[1]);}});
 return[...cnt.entries()].sort((p,q)=>q[1]-p[1]).map(e=>e[0]).slice(0,12);}
function kartuPalet(dari){const src=dari==="pilih"?sels():S.objects,cols=warnaDesain(src);if(!cols.length)return T(dari==="pilih"?"Pilihan tidak punya warna":"Tidak ada warna di desain");
 Hi.snapshot();S.objects=S.objects.filter(o=>!o.pal95);const cs=64,gp=14,pad=20,fs=14,vert=S.palSt95==="v",perRow=vert?1:Math.max(1,Math.min(cols.length,Math.floor((W()-80-2*pad+gp)/(cs+gp)))),rows=Math.ceil(cols.length/perRow),
 cw=pad*2+perRow*cs+(perRow-1)*gp,ch=pad*2+rows*(cs+fs+10)+(rows-1)*gp-0,x0=Math.max(0,Math.round((W()-cw)/2)),y0=Math.max(0,Math.round(H()-ch-40)),ex={pal95:true},o=[rect(x0,y0,cw,ch,"#ffffff",{...ex,name:"Kartu palet",rx:16,stroke:"#d7dbe8",strokeWidth:1})];
 cols.forEach((c,i)=>{const r=Math.floor(i/perRow),k=i%perRow,x=x0+pad+k*(cs+gp),y=y0+pad+r*(cs+fs+10+gp),t=c.toUpperCase();
  o.push(rect(x,y,cs,cs,c,{...ex,name:"Warna "+t,rx:12,stroke:"#d7dbe8",strokeWidth:1}));o.push(text(t,x+cs/2-t.length*fs*.3,y+cs+6,fs,"#20243a",{...ex,name:"Kode "+t}));});
 grup(o,"Kartu palet");S.objects.push(...o);done("Kartu palet: "+cols.length+" warna");}
MENUS.palet95=()=>[
 {h:"Susunan",items:[tc("Mendatar",()=>{S.palSt95="h";},{keep:1,on:S.palSt95!=="v"}),tc("Menurun",()=>{S.palSt95="v";},{keep:1,on:S.palSt95==="v"})]},
 {h:"Buat kartu (maks 12 warna)",items:[it("Dari semua objek desain",()=>kartuPalet("semua"),"swatchcard"),it("Dari objek terpilih",()=>kartuPalet("pilih"),"swatchcard"),it("Hapus kartu palet",()=>hapusTandaX("pal95","kartu palet"),"trash")]}];

const PEN=[["Magenta","#e11d6a"],["Biru","#2563eb"],["Hijau","#16a34a"],["Kuning","#d99a00"]];
function penanda(){const a=(S.selectedIds&&S.selectedIds.length?S.selectedIds:(S.selected?[S.selected]:[])).map(id=>S.objects.find(o=>o.id===id)).filter(Boolean);if(!a.length)return T("Pilih objek dulu (urutan pilih = urutan nomor)");
 const us=unitsOf(a),d=Math.max(28,Math.round(Math.min(W(),H())*.035)),fs=Math.round(d*.55),col=PEN[S.penWarna95||0][1],n0=S.nomorMulai95||1;Hi.snapshot();const out=[];
 us.forEach((u,i)=>{const b=bb(u),cx=Math.max(d/2,b.x),cy=Math.max(d/2,b.y),t=String(n0+i),ex={pen95:true};
  out.push(...grup([rect(cx-d/2,cy-d/2,d,d,col,{...ex,type:"ellipse",name:"Lencana "+t,stroke:"#ffffff",strokeWidth:3}),text(t,cx-t.length*fs*.3,cy-fs*.55,fs,"#ffffff",{...ex,bold:true,name:"Nomor "+t})],"Penanda "+t));});
 S.objects.push(...out);done(us.length+" penanda dipasang (mulai "+n0+")");}
MENUS.nomor95=()=>[
 {h:"Warna lencana",items:PEN.map((p,i)=>tc(p[0],()=>{S.penWarna95=i;},{keep:1,on:(S.penWarna95||0)===i}))},
 {h:"Pasang",items:[it("Pasang penanda 1, 2, 3… pada pilihan",penanda,"flagpin"),it("Mulai nomor dari… (sekarang "+(S.nomorMulai95||1)+")",()=>{const q=prompt("Nomor awal:",String(S.nomorMulai95||1));if(q===null)return;const v=parseInt(q,10);if(isFinite(v)&&v>=0&&v<1000)S.nomorMulai95=v;else T("Angka tidak valid");},"hash"),it("Hapus semua penanda",()=>hapusTandaX("pen95","penanda"),"trash")]}];

/* ================= tombol & grup ================= */
BT.push(["mozaik95","mosaic","Mozaik"],["lembar95","labelsheet","Lembar Salin"],["pantul95","reflect","Pantulan"],["dimensi95","dimline","Dimensi"],["palet95","swatchcard","Kartu Palet"],["nomor95","flagpin","Penanda"]);
const defHub=(id,icon,nama,keys)=>{const i=M.HUBS.findIndex(h=>h[0]==="ritme");M.HUBS.splice(i<0?M.HUBS.length:i+1,0,[id,icon,nama,keys]);
 MENUS["hub_"+id]=()=>[{h:nama,items:keys.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($(`[data-menu="hub_${id}"]`),k),0));})}];};
defHub("anotasi95","annotate","Anotasi",["dimensi95","palet95","nomor95"]);
defHub("polalembar95","tilesheet","Pola Lembar",["mozaik95","lembar95","pantul95"]);
CDMS.PolaLembar={mozaik,salin,pantul,dimensi,kartuPalet,penanda};
})();
