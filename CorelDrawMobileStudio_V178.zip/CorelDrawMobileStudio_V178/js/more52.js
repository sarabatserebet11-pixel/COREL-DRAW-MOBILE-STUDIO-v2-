/* V63: menu Edukasi (papan tulis, soal pilihan ganda, flashcard, daftar hadir, jadwal piket, kartu rumus) dan Acara (agenda, pembicara, RSVP, denah meja, daftar acara, sertifikat mini) */
(()=>{
const M=CDMS.Menus,{MENUS,BT,it}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,STAR,AC,INK,MUTE,LINE}=K;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const WHT="#ffffff",GRN="#16a34a",CARD="#00000018";
const card=(w,h,name,a,bg=WHT)=>({w,h,a:[R(0,0,w,h,bg,{rx:28,stroke:CARD,strokeWidth:3,name}),...a]});
/* ---------- Edukasi ---------- */
Object.assign(COMP,{
 "Papan tulis":()=>({w:640,h:420,a:[R(0,0,640,420,"#8b5a2b",{rx:16,name:"Papan tulis"}),R(18,18,604,384,"#1f4d3a",{rx:8}),X("Belajar Hari Ini",320,100,52,WHT,{bold:1}),R(160,134,320,4,"#ffffff80",{rx:2}),X("1. Tulis poin pertama",70,206,32,"#e6f4ea",{left:1}),X("2. Tulis poin kedua",70,264,32,"#e6f4ea",{left:1}),X("3. Tulis poin ketiga",70,322,32,"#e6f4ea",{left:1}),R(470,372,60,10,"#f5f5f5",{rx:5})]}),
 "Soal pilihan ganda":()=>card(600,520,"Soal pilihan ganda",[X("Soal 1",36,52,26,AC,{left:1,bold:1}),X("Ibu kota Indonesia adalah …",36,112,32,INK,{left:1,bold:1}),...["A. Bandung","B. Jakarta","C. Surabaya","D. Medan"].flatMap((t,i)=>{const y=160+i*80;return [R(36,y,528,64,i===1?"#dcfce7":"#f1f3fa",{rx:20,stroke:i===1?GRN:"none",strokeWidth:i===1?3:0}),X(t,64,y+32,26,INK,{left:1,bold:i===1})];})]),
 "Flashcard":()=>({w:560,h:360,a:[R(14,14,546,346,"#d9dcf5",{rx:36}),R(0,0,546,346,AC,{rx:36,name:"Flashcard"}),X("ISTILAH",273,60,22,"#d9d4ff",{bold:1}),X("Fotosintesis",273,160,60,WHT,{bold:1}),R(193,208,160,4,"#ffffff80",{rx:2}),X("Ketuk untuk melihat arti",273,276,24,"#e6e2ff")]}),
 "Daftar hadir":()=>card(560,590,"Daftar hadir",[X("Daftar Hadir",32,54,34,INK,{left:1,bold:1}),R(32,84,100,5,AC,{rx:3}),...[1,2,3,4,5].flatMap(i=>{const y=110+i*78;return [X(String(i),52,y,24,MUTE,{bold:1}),R(88,y+22,320,3,LINE),R(440,y-24,48,48,"none",{rx:10,stroke:LINE,strokeWidth:3}),i<3?X("✓",464,y,32,GRN,{bold:1}):null].filter(Boolean);}),X("Nama",88,128,20,MUTE,{left:1}),X("Hadir",464,128,20,MUTE,{bold:1})]),
 "Jadwal piket":()=>card(640,420,"Jadwal piket",[X("Jadwal Piket Kelas",32,52,32,INK,{left:1,bold:1}),...["Sen","Sel","Rab","Kam","Jum"].flatMap((d,i)=>{const x=32+i*120;return [R(x,92,108,44,AC,{rx:14}),X(d,x+54,114,22,WHT,{bold:1}),R(x,148,108,240,i%2?"#f6f7fc":"#eef0fa",{rx:14}),X("Nama 1",x+54,200,20,INK),X("Nama 2",x+54,250,20,INK),X("Nama 3",x+54,300,20,INK)];})]),
 "Kartu rumus":()=>card(500,360,"Kartu rumus",[R(0,0,500,76,"#2f80ed",{rx:28}),R(0,40,500,36,"#2f80ed"),X("RUMUS",250,38,26,WHT,{bold:1}),X("Luas Lingkaran",250,130,30,MUTE,{bold:1}),X("L = π × r²",250,210,72,INK,{bold:1}),R(150,258,200,4,"#2f80ed",{rx:2}),X("r = jari-jari",250,306,26,MUTE)])
});
MENUS.edukasi=()=>[
 {h:"Kelas",items:["Papan tulis","Daftar hadir","Jadwal piket"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Belajar",items:["Soal pilihan ganda","Flashcard","Kartu rumus"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["edukasi","edu","Edukasi"]);
hubAdd("pustaka","edukasi");
/* ---------- Acara ---------- */
Object.assign(COMP,{
 "Agenda acara":()=>card(600,520,"Agenda acara",[X("Agenda",32,54,36,INK,{left:1,bold:1}),R(32,84,90,5,AC,{rx:3}),R(63,120,4,330,LINE),...[["08.00","Registrasi"],["09.00","Pembukaan"],["10.30","Sesi utama"],["13.00","Diskusi panel"]].flatMap((r,i)=>{const y=130+i*100;return [E(50,y-4,30,30,i===0?AC:WHT,{stroke:AC,strokeWidth:4}),X(r[0],104,y+4,22,AC,{left:1,bold:1}),X(r[1],104,y+40,28,INK,{left:1,bold:1})];})]),
 "Kartu pembicara":()=>card(420,500,"Kartu pembicara",[E(120,36,180,180,"#ece9ff"),E(170,70,80,80,AC),P(140,150,140,60,"M0 100Q0 10 50 10Q100 10 100 100Z",AC),X("Nama Pembicara",210,264,32,INK,{bold:1}),X("Jabatan · Perusahaan",210,310,22,MUTE),R(160,340,100,5,AC,{rx:3}),X("Topik: Judul sesi",210,394,24,INK),R(90,430,240,44,"#ece9ff",{rx:22}),X("10.30 · Ruang A",210,452,20,AC,{bold:1})]),
 "Undangan RSVP":()=>card(520,400,"Undangan RSVP",[X("KAMU DIUNDANG",260,60,22,AC,{bold:1}),X("Nama Acara",260,130,56,INK,{bold:1}),X("Sabtu, 14 Desember · 19.00",260,200,26,MUTE),R(210,236,100,4,AC,{rx:2}),R(60,284,190,64,AC,{rx:32}),X("Hadir",155,316,26,WHT,{bold:1}),R(270,284,190,64,"none",{rx:32,stroke:LINE,strokeWidth:4}),X("Tidak",365,316,26,MUTE,{bold:1})]),
 "Denah meja":()=>({w:560,h:500,a:[R(0,0,560,500,"#f6f7fc",{rx:28,name:"Denah meja"}),...[[110,50],[330,50],[110,230],[330,230]].flatMap((c,i)=>[E(c[0]+30,c[1]-6,90,90,AC),X("M"+(i+1),c[0]+75,c[1]+39,28,WHT,{bold:1}),...[0,1,2,3,4,5].map(k=>{const a=k*Math.PI/3;return E(Math.round(c[0]+75+Math.cos(a)*68-14),Math.round(c[1]+39+Math.sin(a)*68-14),28,28,"#d5daea");})]),R(180,440,200,36,INK,{rx:18}),X("PANGGUNG",280,458,18,WHT,{bold:1})]}),
 "Daftar acara":()=>card(560,460,"Daftar acara",[X("Acara Minggu Ini",32,54,32,INK,{left:1,bold:1}),...[["12","OKT","Workshop Desain","Online · 19.00"],["15","OKT","Meetup Kreator","Bandung · 16.00"],["20","OKT","Pameran Karya","Jakarta · 10.00"]].flatMap((r,i)=>{const y=96+i*112;return [R(32,y,90,90,i===0?AC:"#ece9ff",{rx:22}),X(r[0],77,y+38,38,i===0?WHT:AC,{bold:1}),X(r[1],77,y+70,18,i===0?"#e6e2ff":MUTE,{bold:1}),X(r[2],146,y+32,26,INK,{left:1,bold:1}),X(r[3],146,y+66,20,MUTE,{left:1})];})]),
 "Gelang masuk":()=>({w:620,h:150,a:[R(0,0,620,150,"#ffc857",{rx:20,name:"Gelang masuk"}),R(0,0,150,150,INK,{rx:20}),R(120,0,30,150,INK),X("VIP",75,75,48,"#ffc857",{bold:1}),X("AKSES PENUH",385,56,36,INK,{bold:1}),X("Nama Acara · 14 Des",385,104,24,"#7a5a10",{bold:1}),...[0,1,2,3,4].map(i=>R(180+i*8,128,4,16,INK))]})
});
MENUS.acara=()=>[
 {h:"Program",items:["Agenda acara","Daftar acara","Kartu pembicara"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Tamu",items:["Undangan RSVP","Denah meja","Gelang masuk"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["acara","ticket","Acara"]);
hubAdd("pustaka","acara");
})();
