/* V88: grup menu baru "Koleksi" - simpan pilihan/grup sebagai item koleksi yang bisa dipakai ulang di proyek lain (disimpan lokal di perangkat),
   sisip dengan skala, ganti pilihan dengan item, ganti nama, duplikat, hapus, cari, ekspor/impor .json + tab Koleksi di panel Penata + tombol cepat */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,P=CDMS.Penata,{MENUS,BT,it,sels,pick,T,cell}=M;
if(!M.HUBS||!P)return;
const addTab=(k,l,html,h)=>{const nh={};Object.keys(h).forEach(x=>{nh["x88_"+x]=h[x];});P.addTab(k,l,html.replace(/data-h="([^"]+)"/g,'data-h="x88_$1"'),nh);};
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),uid=()=>crypto.randomUUID(),KEY="cdms-koleksi-v88";
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const num=(id,d)=>{const e=$("#"+id),v=e?parseFloat(e.value):NaN;return isFinite(v)?v:d;};
const b=(k,l,i)=>`<button data-h="${k}">${i?ic(i):""}<span>${l}</span></button>`;
const bbox=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y)),x2=Math.max(...a.map(o=>o.x+(o.w||0))),y2=Math.max(...a.map(o=>o.y+(o.h||0)));return{x,y,x2,y2,w:x2-x,h:y2-y};};
function expand(a){const g=new Set(a.filter(o=>o.groupId).map(o=>o.groupId)),s=new Set(a);S.objects.forEach(o=>{if(o.groupId&&g.has(o.groupId))s.add(o);});return[...s];}
/* ---- penyimpanan ---- */
let memori=null;
function muat(){if(memori)return memori;try{const j=JSON.parse(localStorage.getItem(KEY)||"[]");memori=Array.isArray(j)?j:[];}catch(e){memori=[];}return memori;}
function simpanDb(){try{localStorage.setItem(KEY,JSON.stringify(muat()));return true;}catch(e){T("Penyimpanan penuh: hapus item koleksi atau ekspor dulu");return false;}}
const klon=o=>JSON.parse(JSON.stringify(o));
const bersih=o=>{const c=klon(o);["id","locked","hidden","isoWas"].forEach(k=>delete c[k]);return c;};
function buatItem(objs,nama){const r=bbox(objs),gids=[...new Set(objs.map(o=>o.groupId).filter(Boolean))];
 const arr=objs.map(o=>{const c=bersih(o);c.x=Math.round(o.x-r.x);c.y=Math.round(o.y-r.y);if(c.groupId)c.groupId="g"+gids.indexOf(c.groupId);return c;});
 return{id:uid(),name:nama,w:Math.round(r.w),h:Math.round(r.h),t:Date.now(),objs:arr};}
function namaBaru(d){const n=String($("#p88name")&&$("#p88name").value||"").trim();return n||d;}
/* ---- aksi ---- */
function simpan(){const a=expand(sels());if(!a.length)return T("Pilih objek atau grup dulu");const nm=a.find(o=>o.groupName)?a.find(o=>o.groupName).groupName:null;
 const it0=buatItem(a,namaBaru(nm||"Item "+(muat().length+1)));muat().unshift(it0);if(!simpanDb()){muat().shift();return;}draw();T("Disimpan ke koleksi: “"+it0.name+"” ("+a.length+" objek)");}
function simpanSemuaGrup(){const m=new Map();S.objects.forEach(o=>{if(o.groupId){if(!m.has(o.groupId))m.set(o.groupId,[]);m.get(o.groupId).push(o);}});if(!m.size)return T("Belum ada grup di desain");
 let i=0;const baru=[...m.values()].map(g=>buatItem(g,(g.find(o=>o.groupName)||{}).groupName||"Grup "+(++i)));const db=muat();db.unshift(...baru);if(!simpanDb()){db.splice(0,baru.length);return;}draw();T(baru.length+" grup disimpan ke koleksi");}
function sisipObjs(item,k,cx,cy){const gmap={},out=[];item.objs.forEach(o=>{const c=klon(o);c.id=uid();if(c.groupId){gmap[c.groupId]=gmap[c.groupId]||uid();c.groupId=gmap[c.groupId];}
  c.x=Math.round(c.x*k);c.y=Math.round(c.y*k);if(c.w)c.w=Math.max(1,Math.round(c.w*k));if(c.h)c.h=Math.max(1,Math.round(c.h*k));if(c.fontSize)c.fontSize=Math.max(1,Math.round(c.fontSize*k));if(c.rx)c.rx=Math.round(c.rx*k);if(c.strokeWidth)c.strokeWidth=Math.round(c.strokeWidth*k*10)/10;out.push(c);});
 const r=bbox(out),dx=Math.round(cx-r.w/2-r.x),dy=Math.round(cy-r.h/2-r.y);out.forEach(o=>{o.x+=dx;o.y+=dy;});
 if(item.objs.length>=2&&!out.some(o=>o.groupId)){const g=uid();out.forEach(o=>{o.groupId=g;o.groupName=item.name;});}
 return out;}
function sisip(id,ganti){const item=muat().find(x=>x.id===id);if(!item)return;const k=Math.max(1,num("p88k",100))/100;let cx=S.page.width/2,cy=S.page.height/2,lama=[];
 if(ganti){lama=expand(sels());if(!lama.length)return T("Pilih objek yang mau diganti dulu");const r=bbox(lama);cx=(r.x+r.x2)/2;cy=(r.y+r.y2)/2;}
 Hi.snapshot();const out=sisipObjs(item,k,cx,cy);if(ganti)S.objects=S.objects.filter(o=>!lama.includes(o));S.objects.push(...out);pick(out);draw();T((ganti?"Pilihan diganti dengan “":"Disisipkan “")+item.name+"”");}
function ubah(id,fn,msg){const db=muat(),i=db.findIndex(x=>x.id===id);if(i<0)return;fn(db,i);if(simpanDb()){draw();if(msg)T(msg);}}
function ganti(id){const nm=String($("#p88name")&&$("#p88name").value||"").trim();if(!nm)return T("Isi nama di kolom Nama item dulu");ubah(id,(d,i)=>{d[i].name=nm;},"Nama diubah");}
function dupItem(id){ubah(id,(d,i)=>{const c=klon(d[i]);c.id=uid();c.name+=" salinan";c.t=Date.now();d.splice(i,0,c);},"Item diduplikat");}
function hapusItem(id){ubah(id,(d,i)=>{d.splice(i,1);},"Item dihapus dari koleksi");}
function ekspor(){const db=muat();if(!db.length)return T("Koleksi masih kosong");CDMS.Export.download(new Blob([JSON.stringify({cdmsKoleksi:1,items:db})],{type:"application/json"}),"koleksi_cdms.json");T(db.length+" item diekspor");}
function impor(){const f=document.createElement("input");f.type="file";f.accept=".json,application/json";f.onchange=()=>{const file=f.files&&f.files[0];if(!file)return;if(file.size>8*1048576)return T("Berkas terlalu besar (maks 8 MB)");
  const r=new FileReader();r.onload=()=>{try{const j=JSON.parse(r.result);if(!j||!Array.isArray(j.items))throw 0;const ok=j.items.filter(x=>x&&typeof x.name==="string"&&Array.isArray(x.objs)&&x.objs.every(o=>o&&typeof o==="object"&&isFinite(o.x)&&isFinite(o.y)));
   if(!ok.length)throw 0;const baru=ok.map(x=>({id:uid(),name:x.name.slice(0,60),w:+x.w||0,h:+x.h||0,t:Date.now(),objs:x.objs}));muat().unshift(...baru);if(!simpanDb()){muat().splice(0,baru.length);return;}draw();T(baru.length+" item diimpor");}catch(e){T("Berkas bukan koleksi CDMS yang valid");}};r.readAsText(file);};f.click();}
function kosongkan(){const n=muat().length;if(!n)return T("Koleksi sudah kosong");if(!confirm("Hapus semua "+n+" item koleksi dari perangkat ini?"))return;memori=[];simpanDb();draw();T("Koleksi dikosongkan");}
/* ---- daftar ---- */
function thumb(it0){const W=Math.max(1,it0.w),Hh=Math.max(1,it0.h),k=Math.min(56/W,40/Hh);
 const r=it0.objs.slice(0,40).map(o=>{const f=/^#[0-9a-f]{3,8}$/i.test(o.fill||"")?o.fill:(Array.isArray(o.grad)&&/^#/.test(o.grad[0])?o.grad[0]:"#8892b0");const x=o.x*k,y=o.y*k,w=Math.max(2,(o.w||4)*k),h=Math.max(2,(o.h||4)*k);
  return o.type==="ellipse"?`<ellipse cx="${x+w/2}" cy="${y+h/2}" rx="${w/2}" ry="${h/2}" fill="${f}"/>`:`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="1.5" fill="${f}"/>`;}).join("");
 return`<svg viewBox="0 0 ${Math.ceil(W*k)||1} ${Math.ceil(Hh*k)||1}" width="${Math.ceil(W*k)}" height="${Math.ceil(Hh*k)}">${r}</svg>`;}
function draw(){const box=$("#p88list");if(!box)return;const q=String(($("#p88q")||{}).value||"").toLowerCase(),db=muat().filter(x=>!q||x.name.toLowerCase().includes(q));
 box.innerHTML=db.length?db.map(x=>`<div class="p88row"><div class="p88th">${thumb(x)}</div><div class="p88nm"><b>${esc(x.name)}</b><small>${x.objs.length} objek · ${x.w}×${x.h}</small></div><div class="p88bt"><button data-p88="ins" data-i="${x.id}" title="Sisipkan di tengah halaman">${ic("plus")}</button><button data-p88="rep" data-i="${x.id}" title="Ganti pilihan dengan item ini">${ic("redo")}</button><button data-p88="ren" data-i="${x.id}" title="Ganti nama (isi kolom Nama item)">${ic("text")}</button><button data-p88="dup" data-i="${x.id}" title="Duplikat">${ic("copy")}</button><button data-p88="del" data-i="${x.id}" title="Hapus">${ic("trash")}</button></div></div>`).join(""):`<div class="kosong">${muat().length?"Tidak ada item yang cocok.":"Koleksi kosong. Pilih objek atau grup lalu ketuk Simpan pilihan."}</div>`;
 const inf=$("#p88info");if(inf)inf.textContent=muat().length+" item";}
document.addEventListener("click",e=>{const x=e.target.closest&&e.target.closest("[data-p88]");if(x){const k=x.dataset.p88,id=x.dataset.i;({ins:()=>sisip(id),rep:()=>sisip(id,true),ren:()=>ganti(id),dup:()=>dupItem(id),del:()=>hapusItem(id)})[k]();return;}
 if(e.target.closest&&e.target.closest(".p69 [data-t=kol]"))setTimeout(draw,0);});
document.addEventListener("input",e=>{if(e.target&&e.target.id==="p88q")draw();});
const H={sm:simpan,sg:simpanSemuaGrup,ex:ekspor,im:impor,ko:kosongkan,sr:draw};
addTab("kol","Koleksi",`<div class="p69h">Koleksi saya <span id="p88info" class="muted" style="font-weight:400"></span></div>
 <div class="p69row"><label>Nama item<input id="p88name" type="text" maxlength="60" placeholder="mis. Kartu harga"></label><label>Cari<input id="p88q" type="search" placeholder="cari nama"></label></div>
 <div class="p69btns">${b("sm","Simpan pilihan","save")}${b("sg","Simpan semua grup","group")}</div>
 <div id="p88list" class="p88list" style="margin-top:10px"></div>
 <p class="muted" style="margin:-2px 0 8px">+ sisip di tengah halaman · ↻ ganti pilihan dengan item · T ganti nama (isi Nama item dulu) · salin · hapus.</p>
 <div class="p69row"><label>Skala sisip (%)<input id="p88k" type="number" value="100" min="1"></label></div>
 <div class="p69btns c3">${b("ex","Ekspor","export")}${b("im","Impor","import")}${b("ko","Kosongkan","trash")}</div>
 <p class="muted" style="margin:8px 0 0">Koleksi tersimpan di browser perangkat ini dan tidak ikut berkas proyek; ekspor .json untuk memindahkannya.</p>`,H);
/* ---- tombol cepat, menu, hub ---- */
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q88="simpan" title="Simpan pilihan ke koleksi">${ic("save")}</button><button data-q88="buka" title="Buka koleksi">${ic("stack")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q88]");if(!x)return;if(x.dataset.q88==="simpan")simpan();else{P.openTab("kol");draw();}});}
const buka=()=>{P.openTab("kol");draw();};
MENUS.kol1=()=>[{h:"Simpan",items:[it("Simpan pilihan ke koleksi",simpan,"save"),it("Simpan semua grup ke koleksi",simpanSemuaGrup,"group")]},{h:"Pakai",items:[it("Buka koleksi",buka,"stack"),...muat().slice(0,8).map(x=>it("Sisip: "+x.name,()=>sisip(x.id),"plus"))]}];
MENUS.kol2=()=>[{h:"Berkas koleksi",items:[it("Ekspor koleksi (.json)",ekspor,"export"),it("Impor koleksi (.json)",impor,"import"),it("Kosongkan koleksi",kosongkan,"trash")]}];
BT.push(["kol1","save","Simpan & pakai"],["kol2","export","Ekspor / impor"]);
const KOL=["kol1","kol2"],ai=M.HUBS.findIndex(h=>h[0]==="isolasi");
M.HUBS.splice(ai<0?M.HUBS.length:ai+1,0,["koleksi","stack","Koleksi",KOL]);
MENUS.hub_koleksi=()=>[{h:"Koleksi",items:KOL.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($('[data-menu="hub_koleksi"]'),k),0));})}];
const ot=P.openTab;P.openTab=function(){const r=ot.apply(this,arguments);setTimeout(()=>{draw();},0);return r;};
})();
