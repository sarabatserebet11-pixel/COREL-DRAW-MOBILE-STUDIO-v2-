/* V42: menu Harmoni - harmoni warna, swatch halaman, cek kontras, langkah rotasi */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,sels,pick,T,it,tc}=M,uid=()=>crypto.randomUUID();
const HEX=/^#([0-9a-f]{3}|[0-9a-f]{6})$/i;
const rgb=h=>{h=h.slice(1);if(h.length===3)h=[...h].map(c=>c+c).join("");return[0,2,4].map(i=>parseInt(h.substr(i,2),16));};
const toHsl=([r,g,b])=>{r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2,d=mx-mn;let h=0,s=0;if(d){s=d/(1-Math.abs(2*l-1));h=mx===r?((g-b)/d)%6:mx===g?(b-r)/d+2:(r-g)/d+4;h=(h*60+360)%360;}return[h,s,l];};
const hex=(h,s,l)=>{h=((h%360)+360)%360;s=Math.min(1,Math.max(0,s));l=Math.min(1,Math.max(0,l));const k=n=>(n+h/30)%12,a=s*Math.min(l,1-l),f=n=>l-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)));return"#"+[f(0),f(8),f(4)].map(v=>Math.round(v*255).toString(16).padStart(2,"0")).join("");};
const base=()=>{const o=sels().find(o=>HEX.test(o.fill||""));return o?o.fill:null;};
const scheme=k=>{const b=base();if(!b)return null;const[h,s,l]=toHsl(rgb(b));
 const d={komplementer:[0,180],analog:[-30,0,30],triadik:[0,120,240],tetradik:[0,90,180,270],"split-komplementer":[0,150,210]}[k];
 return d?d.map(x=>hex(h+x,s,l)):[0,1,2,3,4].map(i=>hex(h,s,.18+i*.17));};
const apply=k=>{const a=sels();if(!a.length||!scheme(k))return T("Pilih objek berwarna isi hex dulu");const p=scheme(k);Hi.snapshot();a.forEach((o,i)=>{if(o.type!=="image"&&o.type!=="line"){o.fill=p[i%p.length];delete o.grad;}});C.render();T("Harmoni "+k+" diterapkan");};
const swatch=k=>{const p=scheme(k);if(!p)return T("Pilih objek berwarna isi hex dulu");Hi.snapshot();const z=Math.round(S.page.width/(p.length*2+1)),y=S.page.height-z-30,ids=[];
 p.forEach((c,i)=>{const o={id:uid(),type:"rect",name:"Swatch "+c,x:z*(i*2+1)/1,y,w:z,h:z,fill:c,stroke:"none",strokeWidth:0,opacity:100,rotation:0};S.objects.push(o);ids.push(o);});pick(ids);T("Swatch "+k+" ditambahkan");};
const lum=([r,g,b])=>{const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4);};return .2126*f(r)+.7152*f(g)+.0722*f(b);};
function contrast(){const t=sels().find(o=>o.type==="text"&&HEX.test(o.fill||""));const bg=S.page.background;if(!t||!HEX.test(bg||""))return T("Pilih teks berwarna hex dengan latar halaman solid");
 const a=lum(rgb(t.fill)),b=lum(rgb(bg)),r=(Math.max(a,b)+.05)/(Math.min(a,b)+.05),ok=r>=4.5?"Lulus AA":r>=3?"Hanya teks besar (AA)":"Gagal";
 N.openModal("Cek kontras teks",`<div class="st-pane"><p style="padding:18px;border-radius:12px;background:${bg};color:${t.fill};font-size:22px;font-weight:700">Contoh teks</p><p>Rasio <b>${r.toFixed(2)}:1</b> — ${ok}</p><small>Dibandingkan dengan warna latar halaman.</small></div>`);}
const step=d=>{const a=sels();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();a.forEach(o=>{o.rotation=d===0?0:((Math.round(((o.rotation||0)+d)/15)*15+540)%360)-180;});C.render();};
const NM=["komplementer","analog","triadik","tetradik","split-komplementer","monokrom"];
MENUS.harmoni=()=>[
 {h:"Terapkan harmoni (dari warna isi objek pertama)",items:NM.map(k=>it(k[0].toUpperCase()+k.slice(1),()=>apply(k),"color"))},
 {h:"Tambah swatch ke halaman",items:NM.map(k=>tc(k,()=>swatch(k)))},
 {h:"Aksesibilitas",items:[it("Cek kontras teks vs latar",contrast,"eye")]},
 {h:"Putar bertahap",items:[tc("−15°",()=>step(-15)),tc("+15°",()=>step(15)),tc("Reset 0°",()=>step(0))]}];
BT.push(["harmoni","harmony","Harmoni"]);M.HUBS.find(h=>h[0]==="warna")[3].push("harmoni");
})();
