/* V45: Bentuk+ (12 bentuk baru), Huruf+ (ukuran/rata), Bagikan (salin/bagikan PNG), Fokus (zoom ke objek), Aksen (warna UI + toolbar ringkas) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,sels,pick,T,it,tc,cell,edit}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),r0=Math.round;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const burst=(n,a,b)=>Array.from({length:n*2},(_,i)=>{const t=i/(n*2)*Math.PI*2-Math.PI/2,r=i%2?b:a;return(i?"L":"M")+r0(50+Math.cos(t)*r)+" "+r0(50+Math.sin(t)*r);}).join("")+"Z";
const SH=[["Petir","M58 4L20 54H44L38 96L80 40H54Z"],["Bulan sabit","M62 6A44 44 0 1 0 94 66A36 36 0 0 1 62 6Z"],["Tambah","M38 6H62V38H94V62H62V94H38V62H6V38H38Z"],["Centang","M6 54L22 38L40 56L78 14L94 30L40 88Z"],["Silang","M20 6L50 36L80 6L94 20L64 50L94 80L80 94L50 64L20 94L6 80L36 50L6 20Z"],["Chevron","M10 6H48L90 50L48 94H10L52 50Z"],["Segi lima","M50 4L96 38L78 94H22L4 38Z"],["Perisai","M50 4L90 18V50C90 74 70 90 50 96C30 90 10 74 10 50V18Z"],["Daun","M10 90C10 40 40 10 92 8C94 60 64 90 10 90Z"],["Ledakan 12","burst12"],["Pita","M2 28H98L84 50L98 72H2L16 50Z"],["Oval bicara","M50 8C26 8 8 22 8 40S26 72 40 72L28 94L58 72C78 70 92 56 92 40C92 22 74 8 50 8Z"]];
const COL=["#ff6b6b","#ffc857","#00d6c9","#7b6cff","#4f83ff","#ff7ac8"];let ci=0;
function addShape(n,d){Hi.snapshot();const W=S.page.width,H=S.page.height,z=r0(Math.min(W,H)*.25),o={id:uid(),type:"path",name:n,x:r0((W-z)/2),y:r0((H-z)/2),w:z,h:z,vw:100,vh:100,d:d==="burst12"?burst(12,48,34):d,fill:COL[ci++%COL.length],stroke:"none",strokeWidth:0,opacity:100,rotation:0};S.objects.push(o);pick([o]);}
MENUS.bentuk2=()=>[{h:"Bentuk tambahan",items:SH.map((s,i)=>cell(`<svg class="s" viewBox="0 0 100 100"><path d="${s[1]==="burst12"?burst(12,48,34):s[1]}" fill="${COL[i%6]}"/></svg><span>${s[0]}</span>`,()=>addShape(s[0],s[1])))}];

const tx=(fn,msg)=>edit(fn,msg||"",o=>o.type==="text"&&!o.locked);
MENUS.huruf2=()=>[{h:"Ukuran huruf",items:[12,16,24,36,48,72,96,128].map(v=>tc(v+"",()=>tx(o=>{o.fontSize=v;})))},
 {h:"Ubah ukuran",items:[it("Perbesar 10%",()=>tx(o=>{o.fontSize=Math.max(8,r0((o.fontSize||24)*1.1));}),"text"),it("Perkecil 10%",()=>tx(o=>{o.fontSize=Math.max(8,r0((o.fontSize||24)*.9));}),"text")]},
 {h:"Rata teks",items:[["Kiri","left"],["Tengah","center"],["Kanan","right"]].map(x=>tc(x[0],()=>tx(o=>{o.align=x[1];})))}];

const nm=()=>String(S.projectName||"desain").replace(/[^\w-]+/g,"_").slice(0,40)||"desain";
const png=()=>M.raster(M.pageSvg({objects:S.objects,page:S.page},false),S.page.width,S.page.height,Math.min(2,S.expScale||2),"image/png");
const copyPng=()=>M.busy("Menyiapkan gambar…",async()=>{if(!navigator.clipboard||!window.ClipboardItem)return T("Peramban ini tidak mendukung salin gambar");const b=await png();await navigator.clipboard.write([new ClipboardItem({"image/png":b})]);T("Gambar disalin ke clipboard");});
const share=()=>M.busy("Menyiapkan gambar…",async()=>{const b=await png(),f=new File([b],nm()+".png",{type:"image/png"});if(navigator.canShare&&navigator.canShare({files:[f]})){try{await navigator.share({files:[f],title:nm()});}catch(e){if(e&&e.name!=="AbortError")throw e;}}else{CDMS.Export.download(b,nm()+".png");T("Bagikan tidak didukung, gambar diunduh");}});
MENUS.bagi=()=>[{h:"Bagikan hasil desain",items:[it("Bagikan PNG (WhatsApp, dll.)",share,"export"),it("Salin PNG ke clipboard",copyPng,"copy")]}];

function focus(){const a=sels();if(!a.length)return T("Pilih objek dulu");const vp=$("#canvasViewport"),x0=Math.min(...a.map(o=>o.x)),x1=Math.max(...a.map(o=>o.x+o.w)),y0=Math.min(...a.map(o=>o.y)),y1=Math.max(...a.map(o=>o.y+(o.h||0))),base=Math.min(680,vp.clientWidth-30);
 C.setZoom(r0(Math.min(vp.clientWidth*.8/Math.max(40,x1-x0),vp.clientHeight*.8/Math.max(40,y1-y0))*S.page.width*100/base));
 requestAnimationFrame(()=>{const s=C.svg.getBoundingClientRect(),v=vp.getBoundingClientRect(),cx=s.left+(x0+x1)/2/S.page.width*s.width,cy=s.top+(y0+y1)/2/S.page.height*s.height;vp.scrollLeft+=cx-(v.left+vp.clientWidth/2);vp.scrollTop+=cy-(v.top+vp.clientHeight/2);});}
const center=()=>{const vp=$("#canvasViewport"),s=C.svg.getBoundingClientRect(),v=vp.getBoundingClientRect();vp.scrollLeft+=s.left+s.width/2-(v.left+vp.clientWidth/2);vp.scrollTop+=s.top+s.height/2-(v.top+vp.clientHeight/2);};
MENUS.fokus2=()=>[{h:"Navigasi kanvas",items:[it("Zoom ke objek terpilih",focus,"select"),it("Pusatkan halaman di layar",center,"grid"),it("Zoom 150%",()=>{C.setZoom(150);setTimeout(center,30);},"plus")]}];

const AK=[["Ungu","#7b6cff"],["Cyan","#00d6c9"],["Biru","#4f83ff"],["Pink","#ff7ac8"],["Oranye","#ff9f43"],["Hijau","#2ecc71"],["Merah","#ff5c5c"]],LS=(k,v)=>{try{if(v===undefined)return localStorage.getItem(k);v===null?localStorage.removeItem(k):localStorage.setItem(k,v);}catch(e){}};
const setAk=c=>{if(c)document.body.style.setProperty("--accent",c);else document.body.style.removeProperty("--accent");LS("cdms_accent",c);};
const compact=on=>{document.body.classList.toggle("v45-compact",on);LS("cdms_compact",on?"1":"0");};
MENUS.aksen=()=>[{h:"Warna aksen aplikasi",items:[...AK.map(a=>cell(`<i style="background:${a[1]}"></i><span>${a[0]}</span>`,()=>setAk(a[1]))),tc("Bawaan tema",()=>setAk(null))]},
 {h:"Toolbar",items:[it("Mode ringkas (tanpa label): "+(document.body.classList.contains("v45-compact")?"AKTIF":"MATI"),()=>compact(!document.body.classList.contains("v45-compact")),"settings",{keep:1})]}];
{const a=LS("cdms_accent");if(a&&/^#[0-9a-f]{6}$/i.test(a))setAk(a);if(LS("cdms_compact")==="1")document.body.classList.add("v45-compact");}

BT.push(["bentuk2","shapes","Bentuk+"],["huruf2","text","Huruf+"],["bagi","share","Bagikan"],["fokus2","target","Fokus"],["aksen","bolt","Aksen"]);
hubAdd("buat","bentuk2");hubAdd("teks","huruf2");hubAdd("berkas","bagi");hubAdd("kanvas","fokus2","aksen");
})();
