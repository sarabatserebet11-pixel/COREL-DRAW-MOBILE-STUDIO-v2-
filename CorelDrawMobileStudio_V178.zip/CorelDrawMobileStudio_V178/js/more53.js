/* V64: ukuran teks akurat (lebar diukur, bukan perkiraan) + menu Pusat Teks: ukur ulang kotak teks, pusatkan/rata teks di dalam objek di bawahnya */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,tc,sels,T}=M;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const cv=document.createElement("canvas").getContext("2d");
function ukur(o){const fs=o.fontSize||32;let st=(o.italic?"italic ":"")+(o.bold?"700 ":"400 ")+fs+"px "+(o.fontFamily||"Arial, sans-serif");
 try{cv.font=st;}catch(e){}
 const L=String(o.text||"").split("\n"),ls=+o.letterSpacing||0;
 return Math.max(20,Math.round(Math.max(...L.map(l=>cv.measureText(l).width+ls*Math.max(0,l.length-1)))));}
function targets(){const a=sels().filter(o=>o.type==="text");return a.length?a:S.objects.filter(o=>o.type==="text");}
function ukurUlang(){const a=targets();if(!a.length)return T("Belum ada teks");Hi.snapshot();let n=0;
 a.forEach(o=>{const w=ukur(o);if(Math.abs(w-o.w)>1){const cx=o.x+o.w/2;o.w=w;o.x=Math.round(cx-w/2);n++;}});C.render();T(n?n+" kotak teks diukur ulang (tetap di tengah)":"Ukuran sudah pas");}
/* objek non-teks paling atas di bawah teks yang menampung titik tengahnya */
function wadah(t){const i=S.objects.indexOf(t),cx=t.x+t.w/2,cy=t.y+t.h/2;
 for(let k=i-1;k>=0;k--){const b=S.objects[k];if(b.type==="text"||b.hidden||!(b.w>0&&b.h>0))continue;if(cx>=b.x&&cx<=b.x+b.w&&cy>=b.y&&cy<=b.y+b.h)return b;}return null;}
function posisi(mode){const a=sels().filter(o=>o.type==="text");if(!a.length)return T("Pilih teks dulu");Hi.snapshot();let n=0;const PAD=24;
 a.forEach(t=>{const b=wadah(t);if(!b)return;
  if(mode==="tengah"||mode==="h")t.x=Math.round(b.x+(b.w-t.w)/2);
  if(mode==="tengah"||mode==="v")t.y=Math.round(b.y+(b.h-t.h)/2);
  if(mode==="kiri")t.x=Math.round(b.x+PAD);
  if(mode==="kanan")t.x=Math.round(b.x+b.w-t.w-PAD);
  if(mode==="atas")t.y=Math.round(b.y+PAD);
  if(mode==="bawah")t.y=Math.round(b.y+b.h-t.h-PAD);
  n++;});
 C.render();T(n?n+" teks diposisikan di dalam objek":"Tidak ada objek di bawah teks");}
MENUS.pusatteks=()=>[
 {h:"Ukuran",items:[tc("Ukur ulang kotak teks (semua/terpilih)",ukurUlang)]},
 {h:"Pusatkan di objek di bawahnya",items:[tc("Tengah (X + Y)",()=>posisi("tengah")),tc("Tengah mendatar",()=>posisi("h")),tc("Tengah menurun",()=>posisi("v"))]},
 {h:"Rata dalam objek (jarak 24 px)",items:[tc("Kiri",()=>posisi("kiri")),tc("Kanan",()=>posisi("kanan")),tc("Atas",()=>posisi("atas")),tc("Bawah",()=>posisi("bawah"))]}];
BT.push(["pusatteks","textcenter","Pusat Teks"]);
hubAdd("teks","pusatteks");
CDMS.PusatTeks={ukur};
})();
