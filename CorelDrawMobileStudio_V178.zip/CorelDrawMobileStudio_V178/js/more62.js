/* V73: tab baru Posisi (9 titik di halaman, geser per langkah, set X/Y/Lebar/Tinggi persis dengan kunci rasio) dan Garis (tebal, putus-putus kustom, warna, hapus) di panel Penata + 4 tombol tepi halaman di bar aksi cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T}=M;
if(!P)return;
const $=s=>document.querySelector(s),{num}=P,ic=n=>CDMS.Icons.svg(n);
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const done=m=>{C.render();if(m)T(m);};
function members(){const a=M.sels().filter(o=>!o.locked),out=[];a.forEach(o=>{(o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]).forEach(p=>{if(!out.includes(p))out.push(p);});});return out;}
const bb=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y)),x2=Math.max(...a.map(o=>o.x+(o.w||0))),y2=Math.max(...a.map(o=>o.y+(o.h||0)));return {x,y,x2,y2,w:x2-x,h:y2-y};};
const mv=(a,dx,dy)=>a.forEach(o=>{o.x=Math.round(o.x+dx);o.y=Math.round(o.y+dy);});
const need=()=>{const a=members();if(!a.length){T("Pilih objek dulu");return null;}return a;};
/* ---- Posisi ---- */
function titik(c,r){const a=need();if(!a)return;const m=Math.max(0,num("p73m",40)),g=bb(a);Hi.snapshot();
 const tx=c===0?m:c===1?(S.page.width-g.w)/2:S.page.width-g.w-m,ty=r===0?m:r===1?(S.page.height-g.h)/2:S.page.height-g.h-m;mv(a,tx-g.x,ty-g.y);done();}
function geser(dx,dy){const a=need();if(!a)return;const st=Math.max(1,num("p73st",10));Hi.snapshot();mv(a,dx*st,dy*st);done();}
function ambil(){const a=members();if(!a.length)return T("Pilih objek dulu");const g=bb(a);[["p73x",g.x],["p73y",g.y],["p73w",g.w],["p73h",g.h]].forEach(([i,v])=>{$("#"+i).value=Math.round(v);});T("Nilai diambil dari pilihan");}
function terapkan(){const a=need();if(!a)return;const g=bb(a),X=num("p73x",g.x),Y=num("p73y",g.y);let W=Math.max(1,num("p73w",g.w)),Hh=Math.max(1,num("p73h",g.h));
 if($("#p73lk").checked){const r=g.h/Math.max(1,g.w);if(Math.abs(W-g.w)>=Math.abs(Hh-g.h)&&Math.abs(W-g.w)>.5)Hh=W*r;else if(Math.abs(Hh-g.h)>.5)W=Hh/r;}
 Hi.snapshot();const fx=W/Math.max(1,g.w),fy=Hh/Math.max(1,g.h),fs=Math.sqrt(fx*fy);
 a.forEach(o=>{o.x=g.x+(o.x-g.x)*fx;o.y=g.y+(o.y-g.y)*fy;o.w=Math.max(1,Math.round((o.w||0)*fx));if(o.h)o.h=Math.max(1,Math.round(o.h*fy));if(o.fontSize&&fs!==1)o.fontSize=Math.max(6,Math.round(o.fontSize*fs));});
 const n=bb(a);mv(a,X-n.x,Y-n.y);done("Posisi/ukuran diterapkan");ambil();}
/* ---- Garis ---- */
const gar=(fn,msg)=>{const a=M.sels().filter(o=>!o.locked&&o.type!=="text"&&o.type!=="image");if(!a.length)return T("Pilih bentuk/garis dulu");Hi.snapshot();a.forEach(fn);done(msg);};
const H={ambil,terapkan,
 gTipis:()=>gar(o=>{o.strokeWidth=Math.max(0,(o.strokeWidth||0)-1);},"Garis ditipiskan"),gTebal:()=>gar(o=>{o.strokeWidth=Math.min(60,(o.strokeWidth||0)+1);if(!o.stroke||o.stroke==="none")o.stroke="#20243a";},"Garis ditebalkan"),
 gSet:()=>gar(o=>{o.strokeWidth=Math.max(0,Math.min(60,num("p73sw",4)));if(o.strokeWidth&&(!o.stroke||o.stroke==="none"))o.stroke="#20243a";},"Tebal garis diatur"),
 gWarna:()=>gar(o=>{o.stroke=$("#p73sc").value;if(!o.strokeWidth)o.strokeWidth=3;},"Warna garis diterapkan"),
 gDash:()=>gar(o=>{const d=($("#p73dash").value||"").trim().replace(/[^0-9. ]/g,"").replace(/\s+/g," ");if(d)o.dash=d;else delete o.dash;if(d&&!o.strokeWidth)o.strokeWidth=3;},"Pola putus-putus diterapkan"),
 gSolid:()=>gar(o=>{delete o.dash;},"Garis dibuat solid"),gOff:()=>gar(o=>{o.strokeWidth=0;},"Garis dihapus")};
const grid9=[0,1,2].map(r=>[0,1,2].map(c=>`<button data-h="t${r}${c}" title="${["Atas","Tengah","Bawah"][r]} ${["kiri","tengah","kanan"][c]}"><span>${["↖","↑","↗","←","●","→","↙","↓","↘"][r*3+c]}</span></button>`).join("")).join("");
[0,1,2].forEach(r=>[0,1,2].forEach(c=>{H["t"+r+c]=()=>titik(c,r);}));
Object.assign(H,{nL:()=>geser(-1,0),nR:()=>geser(1,0),nU:()=>geser(0,-1),nD:()=>geser(0,1)});
P.addTab("posisi","Posisi",`<div class="p69row">${fld("p73m","Margin halaman",40,'min="0"')}${fld("p73st","Langkah geser",10,'min="1"')}</div>
 <div class="p69btns c3" style="grid-template-columns:repeat(3,1fr)">${grid9}</div>
 <div class="p69btns c4" style="margin-top:6px">${b("nL","◀")}${b("nU","▲")}${b("nD","▼")}${b("nR","▶")}</div>
 <div class="p69h">Nilai persis (seluruh pilihan)</div><div class="p69row">${fld("p73x","X",0)}${fld("p73y","Y",0)}${fld("p73w","Lebar",100,'min="1"')}${fld("p73h","Tinggi",100,'min="1"')}</div>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 8px"><input id="p73lk" type="checkbox" checked> Kunci rasio</label>
 <div class="p69btns">${b("ambil","Ambil dari pilihan")}${b("terapkan","Terapkan")}</div>`,H);
P.addTab("garis","Garis",`<div class="p69row">${fld("p73sw","Tebal (px)",4,'min="0" max="60"')}<label>Warna<input id="p73sc" type="color" value="#20243a"></label><label>Pola putus (angka)<input id="p73dash" type="text" value="4 3"></label></div>
 <div class="p69btns c3">${b("gSet","Atur tebal")}${b("gTipis","Tipis −1")}${b("gTebal","Tebal +1")}</div>
 <div class="p69btns" style="margin-top:6px">${b("gWarna","Terapkan warna")}${b("gDash","Terapkan putus-putus")}${b("gSolid","Solid")}${b("gOff","Hapus garis")}</div>
 <p class="muted" style="margin-top:8px">Pola: panjang garis dan celah dalam kelipatan tebal, contoh <b>6 2</b> atau <b>5 2 1 2</b>.</p>`,H);
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q3="0" title="Ke tepi kiri">${ic("al")}</button><button data-q3="1" title="Ke tepi kanan">${ic("ar")}</button><button data-q3="2" title="Ke tepi atas">${ic("au")}</button><button data-q3="3" title="Ke tepi bawah">${ic("ad")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q3]");if(!x)return;const k=+x.dataset.q3,a=need();if(!a)return;const m=Math.max(0,num("p73m",40)),g=bb(a);Hi.snapshot();
  if(k===0)mv(a,m-g.x,0);else if(k===1)mv(a,S.page.width-m-g.x2,0);else if(k===2)mv(a,0,m-g.y);else mv(a,0,S.page.height-m-g.y2);done();});}
MENUS.penata73=()=>[{h:"Tab Penata",items:[it("Posisi (9 titik, nilai persis)",()=>P.openTab("posisi"),"arrange"),it("Garis (tebal, warna, putus-putus)",()=>P.openTab("garis"),"line")]}];
BT.push(["penata73","panel","Penata 4"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata73");
})();
