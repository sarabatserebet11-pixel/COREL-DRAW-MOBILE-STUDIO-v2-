/* V118: info posisi & Alt-seret.
   1) Bilah status kini menampilkan geometri seleksi (X, Y, lebar × tinggi, rotasi) dan posisi kursor di halaman (desktop).
   2) Alt (Option di Mac) + seret objek = menggandakan sambil menggeser: salinan tetap di tempat asal, objek asli ikut terseret.
      Objek berkelompok digandakan bersama anggota kelompoknya. Tiap langkah bisa di-undo. Hanya dengan alat Pilih. */
(()=>{
const S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,M=CDMS.Menus,$=(s,r=document)=>r.querySelector(s);
let raf=0,cur=null,skip=false;
/* satu Undo membatalkan gandaan sekaligus geserannya: snapshot pertama dari seretan yang menyusul dilewati */
if(Hi&&Hi.snapshot){const sn=Hi.snapshot;Hi.snapshot=function(){if(skip){skip=false;return;}return sn.apply(this,arguments);};}

/* ---------- info status ---------- */
function pasangInfo(){const st=$(".status-strip"),sel=$("#selectionStatus");if(!st||!sel||$("#cdSel"))return;
 const a=document.createElement("span"),b=document.createElement("span");a.id="cdSel";a.className="cd-info";b.id="cdCur";b.className="cd-info cd-cur";
 sel.insertAdjacentElement("afterend",a);a.insertAdjacentElement("afterend",b);}
const bulat=n=>Math.round(n);
function teksSel(){const ids=S.selectedIds&&S.selectedIds.length?S.selectedIds:(S.selected?[S.selected]:[]);
 const a=S.objects.filter(o=>ids.includes(o.id));if(!a.length)return"";
 if(a.length===1){const o=a[0];return"X "+bulat(o.x)+" · Y "+bulat(o.y)+" · "+bulat(o.w||0)+" × "+bulat(o.h||0)+(o.rotation?" · "+bulat(o.rotation)+"°":"");}
 const b=M&&M.box?M.box(a):null;if(!b)return"";return"Kotak seleksi: X "+bulat(b.x0)+" · Y "+bulat(b.y0)+" · "+bulat(b.x1-b.x0)+" × "+bulat(b.y1-b.y0);}
function tulis(){raf=0;pasangInfo();const a=$("#cdSel"),b=$("#cdCur");if(a)a.textContent=teksSel();
 if(b)b.textContent=cur?"Kursor "+bulat(cur.x)+", "+bulat(cur.y):"";}
const jadwal=()=>{if(!raf)raf=requestAnimationFrame(tulis);};
if(C){const r=C.render;C.render=function(){const x=r.apply(this,arguments);jadwal();return x;};}

/* ---------- Alt + seret = duplikat ---------- */
function klon(e){if(!e.altKey||e.button!==0||S.tool!=="select")return;
 const g=e.target.closest&&e.target.closest("#designCanvas [data-id]");if(!g)return;
 const o=S.objects.find(t=>t.id===g.dataset.id);if(!o||o.locked||e.shiftKey)return;
 const set=o.groupId?S.objects.filter(t=>t.groupId===o.groupId&&!t.locked):[o];
 Hi.snapshot();skip=true;const gm={};
 set.forEach(t=>{const c={...t,id:crypto.randomUUID()};if(c.groupId)c.groupId=gm[c.groupId]||(gm[c.groupId]=crypto.randomUUID());
  S.objects.splice(S.objects.indexOf(t),0,c);});}

function pasang(){const v=$("#canvasViewport");if(!v||v.dataset.v118)return;v.dataset.v118="1";
 v.addEventListener("pointerdown",klon,true);
 const lepas=()=>{skip=false;};window.addEventListener("pointerup",lepas,true);window.addEventListener("pointercancel",lepas,true);
 v.addEventListener("pointermove",e=>{if(e.pointerType==="touch"||!C.point)return;const p=C.point(e);if(p&&isFinite(p.x)){cur=p;jadwal();}});
 v.addEventListener("pointerleave",()=>{cur=null;jadwal();});}
pasang();setTimeout(()=>{pasang();pasangInfo();jadwal();},400);
CDMS.Info={update:jadwal};
})();
