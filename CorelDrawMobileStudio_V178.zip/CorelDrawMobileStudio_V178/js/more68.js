/* V79: tab baru Konektor (panah/garis penghubung antar objek: lurus, siku, lengkung; kepala akhir atau dua arah; putus-putus; rantai berurutan) dan Label (tombol, lencana, pita, label harga, bintang rating) di panel Penata + tombol cepat */
(()=>{
const P=CDMS.Penata,M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,T,pick}=M;
if(!P)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),{num}=P;
const b=(k,l)=>`<button data-h="${k}"><span>${l}</span></button>`;
const fld=(id,l,v,x="")=>`<label>${l}<input id="${id}" type="number" value="${v}" ${x}></label>`;
const uid=()=>crypto.randomUUID();
const val=(id,d)=>{const e=$("#"+id);return e&&e.value?e.value:d;};
const chk=(id,d)=>{const e=$("#"+id);return e?e.checked:d;};
const base=(t,x,y,w,h,f)=>({id:uid(),type:t,name:t[0].toUpperCase()+t.slice(1),x:Math.round(x),y:Math.round(y),w:Math.max(1,Math.round(w)),h:Math.max(1,Math.round(h)),fill:f,stroke:"#20243a",strokeWidth:0,opacity:100,rotation:0});
const bbox=a=>{const x=Math.min(...a.map(o=>o.x)),y=Math.min(...a.map(o=>o.y));return{x,y,w:Math.max(...a.map(o=>o.x+(o.w||0)))-x,h:Math.max(...a.map(o=>o.y+(o.h||0)))-y};};
/* unit = objek tunggal atau satu grup, urut sesuai pilihan */
function units(){const seen=new Map();M.sels().forEach(o=>{const k=o.groupId||o.id;if(!seen.has(k))seen.set(k,o.groupId?S.objects.filter(p=>p.groupId===o.groupId):[o]);});return [...seen.values()].map(m=>{const r=bbox(m);r.cx=r.x+r.w/2;r.cy=r.y+r.h/2;return r;});}
/* ---- Konektor ---- */
let gaya="lurus";
function tepi(r,tx,ty,gap){const dx=tx-r.cx,dy=ty-r.cy,L=Math.hypot(dx,dy);if(L<.001)return{x:r.cx,y:r.cy};
 const t=Math.min(dx?r.w/2/Math.abs(dx):Infinity,dy?r.h/2/Math.abs(dy):Infinity);return{x:r.cx+dx*t+dx/L*gap,y:r.cy+dy*t+dy/L*gap};}
function kepala(tip,ang,L){const s=.42;return [tip,{x:tip.x-L*Math.cos(ang-s),y:tip.y-L*Math.sin(ang-s)},{x:tip.x-L*Math.cos(ang+s),y:tip.y-L*Math.sin(ang+s)}];}
function hubung(A,B){const tw=Math.max(1,num("p79w",6)),gap=Math.max(0,num("p79g",8)),col=val("p79c","#20243a"),mode=val("p79k","akhir"),putus=chk("p79d",false),L=Math.max(12,tw*4);
 let pts,ctrl=null,dx=B.cx-A.cx,dy=B.cy-A.cy;
 if(gaya==="siku"){if(Math.abs(dx)>=Math.abs(dy)){const sg=dx>=0?1:-1,s={x:(sg>0?A.x+A.w:A.x)+sg*gap,y:A.cy},e={x:(sg>0?B.x:B.x+B.w)-sg*gap,y:B.cy},mx=(s.x+e.x)/2;pts=[s,{x:mx,y:s.y},{x:mx,y:e.y},e];}
  else{const sg=dy>=0?1:-1,s={x:A.cx,y:(sg>0?A.y+A.h:A.y)+sg*gap},e={x:B.cx,y:(sg>0?B.y:B.y+B.h)-sg*gap},my=(s.y+e.y)/2;pts=[s,{x:s.x,y:my},{x:e.x,y:my},e];}}
 else{const s=tepi(A,B.cx,B.cy,gap),e=tepi(B,A.cx,A.cy,gap);pts=[s,e];
  if(gaya==="lengkung"){const mx=(s.x+e.x)/2,my=(s.y+e.y)/2,ln=Math.hypot(e.x-s.x,e.y-s.y)||1;ctrl={x:mx-(e.y-s.y)/ln*ln*.25,y:my+(e.x-s.x)/ln*ln*.25};}}
 const n=pts.length,e=pts[n-1],s=pts[0],pe=ctrl||pts[n-2],ps=ctrl||pts[1];
 const heads=[];if(mode!=="tanpa")heads.push(kepala(e,Math.atan2(e.y-pe.y,e.x-pe.x),L));if(mode==="dua")heads.push(kepala(s,Math.atan2(s.y-ps.y,s.x-ps.x),L));
 const all=[...pts,...(ctrl?[ctrl]:[]),...heads.flat()],pad=tw+2,x0=Math.min(...all.map(p=>p.x))-pad,y0=Math.min(...all.map(p=>p.y))-pad,w=Math.max(2,Math.max(...all.map(p=>p.x))-x0+pad),h=Math.max(2,Math.max(...all.map(p=>p.y))-y0+pad);
 const f=p=>Math.round((p.x-x0)*10)/10+" "+Math.round((p.y-y0)*10)/10;
 const d=ctrl?"M"+f(s)+"Q"+f(ctrl)+" "+f(e):"M"+pts.map(f).join("L");
 const mk=(dd,fill,nm)=>{const o=base("path",x0,y0,w,h,fill);o.d=dd;o.vw=w;o.vh=h;o.name=nm;o.stroke=col;return o;};
 const ln=mk(d,"none","Garis penghubung");ln.strokeWidth=tw;if(putus)ln.dash=Math.round(tw*2)+" "+Math.round(tw*1.5);
 const out=[ln];if(heads.length){const hd=mk(heads.map(h3=>"M"+h3.map(f).join("L")+"Z").join(""),col,"Kepala panah");hd.strokeWidth=1;out.push(hd);}
 return out;}
function konek(rantai){const u=units();if(u.length<2)return T("Pilih 2 objek atau lebih (urutan ketukan = arah panah)");
 const pairs=rantai?u.slice(1).map((r,i)=>[u[i],r]):[[u[0],u[1]]];const made=[];
 pairs.forEach((p,i)=>{hubung(p[0],p[1]).forEach(o=>made.push(o));});
 /* satu grup per konektor: garis + kepala */
 for(let i=0;i<made.length;){const g=uid();made[i].groupId=g;if(made[i+1]&&made[i+1].name==="Kepala panah"){made[i+1].groupId=g;i+=2;}else i++;}
 Hi.snapshot();S.objects.push(...made);pick(made);T(pairs.length+" konektor dibuat");}
/* ---- Label ---- */
const fs0=()=>Math.max(10,num("p79fs",40));
function ukur(o){const est=Math.round((o.text||"").length*o.fontSize*(o.bold?.6:.56)+8);try{if(CDMS.PusatTeks){const m=CDMS.PusatTeks.ukur(o);if(m>0)return m;}}catch(e){}return est;}
function txt(s,cx,cy,fs,col){const o=base("text",0,0,10,Math.round(fs*1.3),col);o.text=s;o.fontSize=fs;o.bold=true;const w=ukur(o);o.w=Math.round(w);o.x=Math.round(cx-w/2);o.y=Math.round(cy-fs*.6);o.name="Teks label";return o;}
function pusat(){const m=M.sels();if(chk("p79at",false)&&m.length){const r=bbox(m);return{x:r.x+r.w/2,y:r.y+r.h/2};}return{x:S.page.width/2,y:S.page.height/2};}
function taruh(a,nm){const g=uid();a.forEach((o,i)=>{o.groupId=g;if(!o.name||o.name==="Rect"||o.name==="Ellipse"||o.name==="Path")o.name=nm+" "+(i+1);});Hi.snapshot();S.objects.push(...a);pick(a);T(nm+" disisipkan");}
const warna=()=>[val("p79bg","#6d5dfc"),val("p79tc","#ffffff")];
function bentuk(kind){const fs=fs0(),[bg,tc]=warna(),s=(val("p79t","Baru")||"Baru").trim()||"Baru",c=pusat(),t=txt(s,0,0,fs,tc),tw=t.w;let a=[];
 if(kind==="tbl"){const w=tw+fs*2,h=fs*2.2,r=base("rect",-w/2,-h/2,w,h,bg);r.rx=Math.round(h/2);r.name="Tombol";a=[r,t];}
 else if(kind==="bdg"){const d=Math.max(tw+fs*1.2,fs*3),e=base("ellipse",-d/2,-d/2,d,d,bg),i=base("ellipse",-d/2+8,-d/2+8,d-16,d-16,"none");i.stroke=tc;i.strokeWidth=3;e.name="Lencana";i.name="Cincin";a=[e,i,t];}
 else if(kind==="pta"){const w=tw+fs*3.2,h=fs*2.2,o=base("path",-w/2,-h/2,w,h,bg);o.d="M0 0H100L90 50L100 100H0L10 50Z";o.vw=100;o.vh=100;o.name="Pita";a=[o,t];}
 else{const w=tw+fs*3,h=fs*2.2,o=base("path",-w/2,-h/2,w,h,bg);o.d="M0 0H78L100 50L78 100H0Z";o.vw=100;o.vh=100;o.name="Label harga";const hl=base("ellipse",w*.8-w/2-fs*.28,-fs*.28,fs*.56,fs*.56,"#ffffff");hl.name="Lubang";t.x=Math.round(-w/2+fs*.9);}
 a.forEach(o=>{o.x=Math.round(o.x+c.x);o.y=Math.round(o.y+c.y);});
 taruh(a,{tbl:"Tombol",bdg:"Lencana",pta:"Pita",hrg:"Label harga"}[kind]);}
function rating(){const n=Math.max(0,Math.min(5,Math.round(num("p79rt",4)))),sz=Math.max(12,Math.round(fs0()*1.1)),gap=Math.round(sz*.2),tot=5*sz+4*gap,c=pusat(),a=[];
 for(let i=0;i<5;i++){const o=base("star",c.x-tot/2+i*(sz+gap),c.y-sz/2,sz,sz,i<n?"#ffc857":"#d9dcea");o.name="Bintang "+(i+1);a.push(o);}
 taruh(a,"Rating "+n+"/5");}
const H={gl:()=>{gaya="lurus";sUI();},gs:()=>{gaya="siku";sUI();},gk:()=>{gaya="lengkung";sUI();},kn:()=>konek(false),kr:()=>konek(true),
 tbl:()=>bentuk("tbl"),bdg:()=>bentuk("bdg"),pta:()=>bentuk("pta"),hrg:()=>bentuk("hrg"),rat:rating};
function sUI(){document.querySelectorAll(".p69 [data-sg]").forEach(x=>x.classList.toggle("on",x.dataset.sg===gaya));}
P.addTab("konektor","Konektor",`<p class="muted">Pilih 2 objek atau lebih (urutan ketukan menentukan arah), lalu buat panah penghubung.</p>
 <div class="p69btns c3" style="margin-top:8px">${[["gl","lurus","Lurus"],["gs","siku","Siku"],["gk","lengkung","Lengkung"]].map(x=>`<button data-h="${x[0]}" data-sg="${x[1]}"><span>${x[2]}</span></button>`).join("")}</div>
 <div class="p69row" style="margin-top:10px">${fld("p79w","Tebal",6,'min="1"')}${fld("p79g","Jarak objek",8,'min="0"')}<label>Warna<input id="p79c" type="color" value="#20243a"></label>
 <label>Kepala<select id="p79k"><option value="akhir">Di ujung</option><option value="dua">Dua arah</option><option value="tanpa">Tanpa kepala</option></select></label></div>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 8px"><input id="p79d" type="checkbox"> Garis putus-putus</label>
 <div class="p69btns">${b("kn","Hubungkan 2 objek")}${b("kr","Rantai berurutan")}</div>`,H);
P.addTab("label","Label",`<div class="p69row"><label style="grid-column:1/-1">Teks label<input id="p79t" type="text" value="Baru"></label>${fld("p79fs","Ukuran huruf",40,'min="10"')}<label>Warna latar<input id="p79bg" type="color" value="#6d5dfc"></label><label>Warna teks<input id="p79tc" type="color" value="#ffffff"></label>${fld("p79rt","Rating (0–5)",4,'min="0" max="5"')}</div>
 <label class="p69rg" style="flex-direction:row;align-items:center;gap:8px;margin:0 0 8px"><input id="p79at" type="checkbox"> Letakkan di tengah objek terpilih</label>
 <div class="p69btns c3">${b("tbl","Tombol")}${b("bdg","Lencana")}${b("pta","Pita")}${b("hrg","Label harga")}${b("rat","Bintang rating")}</div>
 <p class="muted" style="margin-top:8px">Setiap label berupa satu grup yang bisa dipecah, diwarnai ulang, dan diedit teksnya.</p>`,H);
document.addEventListener("click",e=>{if(e.target.closest&&e.target.closest(".p69 [data-t=konektor]"))sUI();});
const qb=$(".qbar");
if(qb){qb.insertAdjacentHTML("beforeend",`<span class="qsep"></span><button data-q9="hub" title="Hubungkan dengan panah">${ic("line")}</button><button data-q9="label" title="Label & lencana">${ic("sticker")}</button><button data-q9="rating" title="Bintang rating">${ic("star")}</button>`);
 qb.addEventListener("click",e=>{const x=e.target.closest("[data-q9]");if(!x)return;const k=x.dataset.q9;
  if(k==="hub"){if(units().length<2){P.openTab("konektor");sUI();return T("Pilih 2 objek atau lebih dulu");}konek(false);}
  else if(k==="label")P.openTab("label");else rating();});}
MENUS.penata79=()=>[{h:"Tab Penata",items:[it("Konektor (panah antar objek)",()=>{P.openTab("konektor");sUI();},"line"),it("Label (tombol, lencana, pita, rating)",()=>P.openTab("label"),"sticker")]},{h:"Cepat",items:[it("Hubungkan 2 objek dengan panah",()=>konek(false),"line"),it("Rantai panah berurutan",()=>konek(true),"line"),it("Sisip bintang rating",rating,"star")]}];
BT.push(["penata79","panel","Penata 10"]);M.HUBS.find(h=>h[0]==="atur")[3].push("penata79");
})();
