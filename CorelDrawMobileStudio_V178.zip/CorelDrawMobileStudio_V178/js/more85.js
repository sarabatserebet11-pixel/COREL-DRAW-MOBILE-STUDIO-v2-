/* V97: dua grup menu baru.
   "Lanskap" (ikon landscape): Pegunungan (lapisan gunung + langit + matahari), Gelombang Lapis (pita gelombang bertingkat), Malam (langit bintang + bulan sabit).
   "Aksen Teks" (ikon accent): Pita Sudut (pita diagonal di sudut halaman), Daftar Titik (daftar nama ..... nilai dengan garis pengisi), Garis Hias (gelombang, zigzag, ganda, titik, kuas).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,tc,cell,sels,T}=M;
if(!M.HUBS)return;
const $=s=>document.querySelector(s),ic=n=>CDMS.Icons.svg(n),uid=()=>crypto.randomUUID();
const W=()=>S.page.width,H=()=>S.page.height,rnd=(a,b)=>a+Math.random()*(b-a),R=Math.round;
const done=m=>{C.render();if(m)T(m);};
const bb=a=>{let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;a.forEach(o=>{x0=Math.min(x0,o.x);y0=Math.min(y0,o.y);x1=Math.max(x1,o.x+(o.w||0));y1=Math.max(y1,o.y+(o.h||0));});return{x:x0,y:y0,w:x1-x0,h:y1-y0};};
const parse=c=>{const m=/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(c||"").trim());if(!m)return null;let h=m[1];if(h.length===3)h=h.split("").map(x=>x+x).join("");return[0,2,4].map(i=>parseInt(h.substr(i,2),16));};
const toHex=r=>"#"+r.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0")).join("");
const mix=(a,b,t)=>toHex(parse(a).map((v,i)=>v+(parse(b)[i]-v)*t));
const ramp=(arr,t)=>{const p=t*(arr.length-1),i=Math.min(arr.length-2,Math.floor(p));return mix(arr[i],arr[i+1],p-i);};
const grup=(arr,nama)=>{const g=uid();arr.forEach(o=>{o.groupId=g;o.groupName=nama;});return arr;};
const shape=(type,x,y,w,h,fill,x2)=>({id:uid(),type,name:type==="ellipse"?"Lingkaran":type==="star"?"Bintang":"Kotak",x:R(x),y:R(y),w:Math.max(1,R(w)),h:Math.max(1,R(h)),rx:0,fill,stroke:"none",strokeWidth:0,opacity:100,rotation:0,...x2});
const text=(t,x,y,fs,fill,x2)=>({id:uid(),type:"text",name:"Teks",text:t,x:R(x),y:R(y),w:R(t.length*fs*.6),h:R(fs*1.2),fontSize:R(fs),fill,opacity:100,rotation:0,...x2});
const line=(x,y,w,h,col,sw,x2)=>({id:uid(),type:"line",name:"Garis",x:R(x),y:R(y),w:R(w),h:R(h),stroke:col,strokeWidth:sw,fill:"none",opacity:100,rotation:0,...x2});
const path=(x,y,w,h,vw,vh,d,fill,stroke,sw,x2)=>({id:uid(),type:"path",name:"Bentuk",x:R(x),y:R(y),w:R(w),h:R(h),vw,vh,d,fill,stroke,strokeWidth:sw,opacity:100,rotation:0,...x2});
const gelap=()=>{const c=parse(S.page.background||"#ffffff");return c?(c[0]*.3+c[1]*.59+c[2]*.11)<110:false;};
const finish=(arr,msg,ganti)=>{if(ganti){const i=S.objects.findIndex(o=>o.lanskap97);}S.objects.push(...arr);S.selectedIds=arr.map(o=>o.id);S.selected=arr[0].id;done(msg);};
const pil=(k,d)=>S[k]||d;

/* ================= LANSKAP ================= */
const PAL={senja:{n:"Senja",sky:["#3b1d6e","#ff9a62"],c:["#c06c9b","#8f4a8f","#5b2f6e","#33194a"],sun:"#ffe29a"},
 biru:{n:"Biru",sky:["#bfe3ff","#eaf6ff"],c:["#8fb8e8","#5f8fd0","#3b66ad","#23427d"],sun:"#ffffff"},
 hijau:{n:"Hijau",sky:["#d8f3dc","#f1fbe9"],c:["#95d5a8","#52b788","#2d8a5f","#1b5a3d"],sun:"#fff3b0"},
 mono:{n:"Mono",sky:["#e9ecf5","#ffffff"],c:["#c3c9dc","#99a1bd","#6b7494","#3d4466"],sun:"#ffffff"},
 laut:{n:"Laut",sky:["#dff4ff","#f5fbff"],c:["#a5e1ff","#5bb8f0","#2b8ad1","#14589c"],sun:"#ffffff"}};
const pk=()=>PAL[S.lanPal97&&PAL[S.lanPal97]?S.lanPal97:"senja"];
function gunung(){const P=pk(),n=S.gunungN97||3,w=W(),h=H(),out=[];Hi.snapshot();
 if(S.langit97!==false){out.push(shape("rect",0,0,w,h,P.sky[0],{name:"Langit",grad:[P.sky[0],P.sky[1],"v"]}));
  if(S.matahari97!==false){const r=Math.min(w,h)*.08;out.push(shape("ellipse",w*rnd(.55,.8)-r,h*rnd(.16,.28)-r,r*2,r*2,P.sun,{name:"Matahari",opacity:92}));}}
 for(let i=0;i<n;i++){const t=n>1?i/(n-1):0,col=ramp(P.c,t),top=h*(.34+.16*i),steps=6+i*2;let d=`M0 ${h} L0 ${R(top+rnd(0,h*.05))}`;
  for(let k=1;k<=steps;k++){const x=w*k/steps,peak=k%2===1,y=top+(peak?-rnd(.02,.12)*h*(1-.12*i):rnd(0,.07)*h);d+=` L${R(x)} ${R(y)}`;}
  d+=` L${w} ${h}Z`;out.push(path(0,0,w,h,w,h,d,col,"none",0,{name:"Gunung "+(i+1)}));}
 finish(grup(out,"Pegunungan"),"Pegunungan "+n+" lapis ("+P.n+")");}
MENUS.gunung97=()=>[
 {h:"Palet",items:["senja","biru","hijau","mono"].map(k=>tc(PAL[k].n,()=>{S.lanPal97=k;},{keep:1,on:(S.lanPal97||"senja")===k}))},
 {h:"Jumlah lapisan",items:[2,3,4].map(v=>tc(v+"",()=>{S.gunungN97=v;},{keep:1,on:(S.gunungN97||3)===v}))},
 {h:"Pilihan",items:[tc(S.langit97===false?"Langit: OFF":"Langit: ON",()=>{S.langit97=S.langit97===false;},{keep:1}),tc(S.matahari97===false?"Matahari: OFF":"Matahari: ON",()=>{S.matahari97=S.matahari97===false;},{keep:1})]},
 {h:"Buat",items:[it("Buat pegunungan (mengisi halaman)",gunung,"mountain")]}];

function gelombang(){const P=pk(),n=S.gelN97||4,w=W(),h=H(),out=[];Hi.snapshot();const pts=Math.max(24,Math.round(w/24));
 for(let i=0;i<n;i++){const t=n>1?i/(n-1):0,col=ramp(P.c,t),base=h*(.46+.4*i/n),A=h*(.03+.012*(n-i)),f=1.1+.5*i,ph=rnd(0,6.28);let d=`M0 ${h} L0 ${R(base+A*Math.sin(ph))}`;
  for(let k=1;k<=pts;k++){const x=w*k/pts;d+=` L${R(x)} ${R(base+A*Math.sin(2*Math.PI*f*k/pts+ph))}`;}
  d+=` L${w} ${h}Z`;out.push(path(0,0,w,h,w,h,d,col,"none",0,{name:"Gelombang "+(i+1),opacity:90}));}
 finish(grup(out,"Gelombang lapis"),"Gelombang "+n+" lapis ("+P.n+")");}
MENUS.gelombang97=()=>[
 {h:"Palet",items:["laut","senja","hijau","mono"].map(k=>tc(PAL[k].n,()=>{S.lanPal97=k;},{keep:1,on:(S.lanPal97||"senja")===k}))},
 {h:"Jumlah pita",items:[3,4,5].map(v=>tc(v+"",()=>{S.gelN97=v;},{keep:1,on:(S.gelN97||4)===v}))},
 {h:"Buat",items:[it("Buat gelombang lapis di bagian bawah",gelombang,"waves")]}];

function malam(){const N=S.bintangN97||80,w=W(),h=H(),out=[];Hi.snapshot();
 out.push(shape("rect",0,0,w,h,"#0b1030",{name:"Langit malam",grad:["#0b1030","#3b3a8f","v"]}));
 for(let i=0;i<N;i++){const big=Math.random()<.12,sz=big?rnd(14,26):rnd(2,7),x=rnd(0,w),y=rnd(0,h*.85);
  out.push(shape(big?"star":"ellipse",x,y,sz,sz,big?"#ffe9a8":"#ffffff",{name:"Bintang "+(i+1),opacity:R(rnd(40,100))}));}
 const ms=Math.min(w,h)*.16;out.push(path(w*.72,h*.1,ms,ms,100,100,"M62 6A46 46 0 1 0 62 94A36 36 0 1 1 62 6Z","#fff3c4","none",0,{name:"Bulan"}));
 finish(grup(out,"Malam"),"Langit malam · "+N+" bintang");}
MENUS.malam97=()=>[
 {h:"Jumlah bintang",items:[40,80,140].map(v=>tc(v+"",()=>{S.bintangN97=v;},{keep:1,on:(S.bintangN97||80)===v}))},
 {h:"Buat",items:[it("Buat langit malam (mengisi halaman)",malam,"moon")]}];

/* ================= AKSEN TEKS ================= */
const PITA=[["Merah","#e11d48"],["Biru","#2563eb"],["Hijau","#16a34a"],["Hitam","#111827"]];
const SUD=[["Kiri atas","tl"],["Kanan atas","tr"],["Kiri bawah","bl"],["Kanan bawah","br"]];
function pita(){const q=prompt("Teks pita (maks 14 huruf):","BARU");if(q===null)return;const t=String(q).trim().slice(0,14);if(!t)return T("Teks kosong");Hi.snapshot();
 const w=W(),h=H(),L=Math.min(w,h)*.5,rh=L*.17,a=L*.3,sd=pil("pitaSud97","tr"),col=PITA[S.pitaWarna97||0][1],
 cx=sd[1]==="l"?a:w-a,cy=sd[0]==="t"?a:h-a,rot=(sd==="tl"||sd==="br")?-45:45,fs=Math.round(rh*.55),
 o=[shape("rect",cx-L/2,cy-rh/2,L,rh,col,{name:"Pita",rotation:rot,stroke:"#ffffff",strokeWidth:2}),text(t,cx-t.length*fs*.3,cy-fs*.6,fs,"#ffffff",{name:"Teks pita",bold:true,rotation:rot})];
 finish(grup(o,"Pita sudut"),"Pita \""+t+"\" dipasang");}
MENUS.pita97=()=>[
 {h:"Sudut",items:SUD.map(x=>tc(x[0],()=>{S.pitaSud97=x[1];},{keep:1,on:pil("pitaSud97","tr")===x[1]}))},
 {h:"Warna",items:PITA.map((x,i)=>tc(x[0],()=>{S.pitaWarna97=i;},{keep:1,on:(S.pitaWarna97||0)===i}))},
 {h:"Pasang",items:[it("Pasang pita sudut…",pita,"ribbon")]}];

const LDR=[["Titik","1 7"],["Putus","8 6"],["Garis",""]];
function daftar(){const q=prompt("Satu baris per item: Nama=nilai (pisahkan dengan koma/titik koma/baris baru; hindari koma di dalam nilai)","Nasi goreng=25.000, Mie ayam=18.000, Es teh=5.000, Kopi susu=15.000");if(q===null)return;
 const rows=String(q).split(/[,;\n]+/).map(s=>s.trim()).filter(Boolean).map(s=>{const i=s.indexOf("=");return i>0?[s.slice(0,i).trim(),s.slice(i+1).trim()]:null;});
 if(!rows.length||rows.some(r=>!r||!r[1])||rows.length>20)return T("Isi 1–20 baris berformat Nama=nilai");Hi.snapshot();
 const w=W(),h=H(),fs=Math.max(16,Math.min(40,R(h*.03))),gp=R(fs*2),x0=w*.15,x1=w*.85,y0=(h-rows.length*gp)/2,tc0=gelap()?"#f1f3ff":"#20243a",dash=LDR[S.ldrSt97||0][1],out=[];
 rows.forEach((r,i)=>{const y=y0+i*gp,nw=r[0].length*fs*.6,vw=r[1].length*fs*.6;out.push(text(r[0],x0,y,fs,tc0,{name:"Item "+r[0],bold:true}));
  out.push(text(r[1],x1-vw,y,fs,tc0,{name:"Nilai "+r[0]}));
  if(x1-vw-(x0+nw)>fs*2)out.push(line(x0+nw+fs*.5,y+fs*1.05,x1-vw-(x0+nw)-fs,0,gelap()?"#8a93aa":"#8a93aa",Math.max(2,R(fs*.12)),{name:"Pengisi",...(dash?{dash}:{})}));});
 finish(grup(out,"Daftar titik"),"Daftar "+rows.length+" baris");}
MENUS.daftar97=()=>[
 {h:"Garis pengisi",items:LDR.map((x,i)=>tc(x[0],()=>{S.ldrSt97=i;},{keep:1,on:(S.ldrSt97||0)===i}))},
 {h:"Buat",items:[it("Buat daftar nama ..... nilai…",daftar,"leader")]}];

const GH=[["Gelombang","wave"],["Zigzag","zig"],["Ganda","dbl"],["Titik","dot"],["Kuas","kuas"]];
function garisHias(){const a=sels(),b=a.length?bb(a):{x:W()*.3,y:H()*.55,w:W()*.4,h:0},sw=S.garisT97||5,st=S.garisSt97||"wave",w=Math.max(60,R(b.w)),x=b.x,y=b.y+b.h+Math.max(10,sw*2);Hi.snapshot();
 const src=a.find(o=>parse(o.type==="text"?o.fill:o.fill)||parse(o.stroke));const col=toHex(parse(src&&(src.type==="text"?src.fill:src.fill))||parse(src&&src.stroke)||[225,29,72]),out=[];
 if(st==="wave"||st==="zig"){const k=Math.max(4,R(w/(sw*5))),amp=sw*1.6,hh=amp*2+sw;let d="";for(let i=0;i<=k;i++){const px=w*i/k,py=st==="wave"?hh/2+amp*Math.sin(i*Math.PI):(i%2?hh-sw/2:sw/2);d+=(i?"L":"M")+R(px)+" "+R(py);}
  if(st==="wave"){d="";const N=Math.max(24,R(w/4));for(let i=0;i<=N;i++){d+=(i?"L":"M")+R(w*i/N)+" "+R(hh/2+amp*Math.sin(i/N*k*Math.PI))+" ";}}
  out.push(path(x,y,w,hh,w,hh,d,"none",col,sw,{name:"Garis "+st}));}
 else if(st==="dbl"){out.push(line(x,y,w,0,col,sw,{name:"Garis 1"}),line(x,y+sw*2.4,w,0,col,Math.max(1,R(sw*.5)),{name:"Garis 2"}));}
 else if(st==="dot"){const r=sw*.8,gp=r*3.4,n=Math.max(3,Math.floor(w/gp));for(let i=0;i<n;i++)out.push(shape("ellipse",x+(w-(n-1)*gp)/2+i*gp-r,y,r*2,r*2,col,{name:"Titik "+(i+1)}));}
 else{const hh=sw*3;out.push(path(x,y,w,hh,w,hh,`M0 ${hh/2} Q${w/2} ${-hh*.4} ${w} ${hh/2} Q${w/2} ${hh*1.4} 0 ${hh/2}Z`,col,"none",0,{name:"Goresan kuas"}));}
 finish(grup(out,"Garis hias"),"Garis hias: "+GH.find(g=>g[1]===st)[0]+(a.length?" di bawah pilihan":" di halaman"));}
MENUS.garis97=()=>[
 {h:"Gaya",items:GH.map(x=>tc(x[0],()=>{S.garisSt97=x[1];},{keep:1,on:(S.garisSt97||"wave")===x[1]}))},
 {h:"Tebal (px)",items:[3,5,8].map(v=>tc(v+"",()=>{S.garisT97=v;},{keep:1,on:(S.garisT97||5)===v}))},
 {h:"Pasang",items:[it("Pasang di bawah objek terpilih (warna ikut objek)",garisHias,"squiggle")]}];

/* ================= tombol & grup ================= */
BT.push(["gunung97","mountain","Pegunungan"],["gelombang97","waves","Gelombang Lapis"],["malam97","moon","Malam"],["pita97","ribbon","Pita Sudut"],["daftar97","leader","Daftar Titik"],["garis97","squiggle","Garis Hias"]);
const defHub=(id,icon,nama,keys)=>{const i=M.HUBS.findIndex(h=>h[0]==="ritme");M.HUBS.splice(i<0?M.HUBS.length:i+1,0,[id,icon,nama,keys]);
 MENUS["hub_"+id]=()=>[{h:nama,items:keys.map(k=>{const t=BT.find(x=>x[0]===k);return cell(`${ic(t[1])}<span>${t[2]}</span>`,()=>setTimeout(()=>M.openMenu($(`[data-menu="hub_${id}"]`),k),0));})}];};
defHub("aksenteks97","accent","Aksen Teks",["pita97","daftar97","garis97"]);
defHub("lanskap97","landscape","Lanskap",["gunung97","gelombang97","malam97"]);
CDMS.Lanskap={gunung,gelombang,malam,pita,daftar,garisHias};
CDMS.Util97={bb,parse,toHex,mix,ramp,grup,shape,text,line,path,gelap,finish,rnd,PAL,defHub,W,H};
})();
