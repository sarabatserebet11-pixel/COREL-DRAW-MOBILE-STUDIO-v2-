/* V51: menu Isi Contoh (teks placeholder siap pakai) dan Slot Pilihan (simpan/panggil seleksi) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,sels,pick,T,it}=M,uid=()=>crypto.randomUUID(),r0=Math.round;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const W=()=>S.page.width,H=()=>S.page.height;

/* ---- Isi Contoh ---- */
const LOREM=["Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.","Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.","Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."];
const BLN=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
const HARI=["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
const tgl=()=>{const d=new Date();return d.getDate()+" "+BLN[d.getMonth()]+" "+d.getFullYear();};
const hari=()=>{const d=new Date();return HARI[d.getDay()]+", "+tgl();};
const SAMPLES=[
 ["Judul besar","JUDUL UTAMA",Math.round(Math.min(W(),H())*.09),true],
 ["Sub judul","Sub judul singkat di sini",0.045,false],
 ["Paragraf lorem ipsum",LOREM.join(" "),0.028,false],
 ["Tanggal hari ini",null,0.04,false,hari],
 ["Harga Rp 99.000","Rp 99.000",0.08,true],
 ["Diskon 50%","DISKON 50%",0.09,true],
 ["Nomor telepon","0812-3456-7890",0.04,false],
 ["Akun @username","@username",0.04,false],
 ["Alamat situs","www.contoh.com",0.04,false],
 ["Tagar","#desainkeren #kreatif",0.04,false],
 ["Alamat","Jl. Contoh No. 123, Jakarta",0.035,false]];
function addText(txt,size,bold){Hi.snapshot();const m=Math.min(W(),H()),fs=size<1?r0(m*size):size,w=r0(W()*.8);
 const o={id:uid(),type:"text",name:"Contoh teks",text:txt,x:r0(W()*.1),y:r0(H()*.4),w,h:r0(fs*1.4),fontSize:fs,fill:"#20243a",bold,fontFamily:"Arial, sans-serif",stroke:"none",strokeWidth:0,opacity:100,rotation:0};
 S.objects.push(o);pick([o]);T("Teks contoh ditambahkan");}
function fillSel(txt){const a=sels().filter(o=>o.type==="text");if(!a.length)return T("Pilih teks dulu");Hi.snapshot();a.forEach(o=>{o.text=txt;});C.render();T(a.length+" teks diganti");}
MENUS.contoh=()=>[
 {h:"Tambah teks contoh",items:SAMPLES.map(s=>it(s[0],()=>addText(s[4]?s[4]():s[1],s[2],s[3]),"text"))},
 {h:"Isi teks terpilih",items:[it("Lorem ipsum pendek",()=>fillSel(LOREM[0].slice(0,60)),"text"),it("Lorem ipsum sedang",()=>fillSel(LOREM[0]),"text"),it("Lorem ipsum panjang",()=>fillSel(LOREM.join(" ")),"text"),it("Tanggal hari ini",()=>fillSel(tgl()),"text"),it("Nomor urut (1, 2, 3…)",()=>{const a=sels().filter(o=>o.type==="text");if(!a.length)return T("Pilih teks dulu");Hi.snapshot();a.forEach((o,i)=>{o.text=String(i+1);});C.render();T("Diberi nomor");},"text")]}];

/* ---- Slot pilihan ---- */
const SL=CDMS.SelSlots=CDMS.SelSlots||{};
const key=()=>String(S.pageIdx||0);
const slots=()=>(SL[key()]=SL[key()]||{});
function save(n){const a=sels();if(!a.length)return T("Pilih objek dulu");slots()[n]=a.map(o=>o.id);T("Slot "+n+": "+a.length+" objek tersimpan");}
function load(n,add){const ids=(slots()[n]||[]).filter(id=>S.objects.some(o=>o.id===id));if(!ids.length)return T("Slot "+n+" kosong");
 const cur=add?(S.selectedIds||[]):[];pick([...new Set([...cur,...ids])].map(id=>S.objects.find(o=>o.id===id)).filter(Boolean));T("Slot "+n+" dipanggil");}
const live=n=>(slots()[n]||[]).filter(id=>S.objects.some(o=>o.id===id)).length;
MENUS.slot=()=>[
 {h:"Simpan pilihan sekarang",items:[1,2,3,4].map(n=>it("Simpan ke slot "+n+" (isi: "+live(n)+")",()=>save(n),"multi"))},
 {h:"Panggil",items:[1,2,3,4].map(n=>it("Pilih slot "+n+" ("+live(n)+" objek)",()=>load(n,false),"select"))},
 {h:"Tambahkan ke pilihan",items:[1,2,3,4].map(n=>it("Tambah slot "+n,()=>load(n,true),"select"))},
 {h:"Kosongkan",items:[it("Kosongkan semua slot halaman ini",()=>{SL[key()]={};T("Slot dikosongkan");},"trash")]}];
BT.push(["contoh","lines","Isi Contoh"],["slot","slot","Slot"]);
hubAdd("buat","contoh");hubAdd("atur","slot");
})();
