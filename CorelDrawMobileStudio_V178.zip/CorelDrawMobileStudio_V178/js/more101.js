/* V113: panel kiri lebih lega. Bagian Elemen bisa dilipat (status diingat) agar daftar Lapisan punya ruang,
   dan baris lapisan yang disembunyikan/dikunci tampil redup. Tidak mengubah data atau fitur. */
(()=>{
const $=(s,r=document)=>r.querySelector(s);
const K="cdms-elem-closed";
function elemen(){const lp=$(".left-panel");if(!lp||lp.dataset.v113)return;const title=$(".panel-title",lp),list=$(".element-list",lp);if(!title||!list)return;lp.dataset.v113="1";
 const d=document.createElement("details");d.className="left-sec";let shut=false;try{shut=localStorage.getItem(K)==="1";}catch(e){}d.open=!shut;
 const s=document.createElement("summary");s.textContent="Elemen";
 const add=title.querySelector("button");
 lp.insertBefore(d,title);d.appendChild(s);d.appendChild(list);
 if(add){add.classList.add("left-sec-add");add.addEventListener("click",e=>e.preventDefault());s.appendChild(add);}
 title.remove();
 d.addEventListener("toggle",()=>{try{localStorage.setItem(K,d.open?"0":"1");}catch(e){}});}
function status(){const root=$("#layersList");if(!root||!CDMS.state)return;
 root.querySelectorAll("[data-layer]").forEach(r=>{const o=CDMS.state.objects.find(x=>x.id===r.dataset.layer);if(!o)return;r.classList.toggle("is-hidden",!!o.hidden);r.classList.toggle("is-locked",!!o.locked);});}
if(CDMS.Layers&&CDMS.Layers.render){const r=CDMS.Layers.render;CDMS.Layers.render=function(){const x=r.apply(this,arguments);status();return x;};}
elemen();
if(CDMS.Tools&&CDMS.Tools.init){const ti=CDMS.Tools.init;CDMS.Tools.init=function(){const x=ti.apply(this,arguments);elemen();status();return x;};}
})();
