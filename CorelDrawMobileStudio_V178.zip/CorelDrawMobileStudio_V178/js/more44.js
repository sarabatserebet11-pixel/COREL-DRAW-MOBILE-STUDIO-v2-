/* V55: menu Angka (format Rupiah, ribuan, persen, terbilang, romawi, singkat, hitung) dan Kartu Info (resep, tugas, cuaca, hitung mundur, musik, kontak, notifikasi, lokasi, target) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,it,tc,sels,pick,T}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,STAR,AC,INK,MUTE}=K;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
/* ---------- Angka ---------- */
const SAT=["","satu","dua","tiga","empat","lima","enam","tujuh","delapan","sembilan","sepuluh","sebelas"];
function tb(n){n=Math.floor(n);
 if(n<12)return SAT[n];
 if(n<20)return tb(n-10)+" belas";
 if(n<100)return tb(Math.floor(n/10))+" puluh"+(n%10?" "+tb(n%10):"");
 if(n<200)return "seratus"+(n>100?" "+tb(n-100):"");
 if(n<1000)return tb(Math.floor(n/100))+" ratus"+(n%100?" "+tb(n%100):"");
 if(n<2000)return "seribu"+(n>1000?" "+tb(n-1000):"");
 const U=[[1e12,"triliun"],[1e9,"miliar"],[1e6,"juta"],[1e3,"ribu"]];
 for(const [v,s] of U){if(n>=v)return tb(Math.floor(n/v))+" "+s+(n%v?" "+tb(n%v):"");}
 return "";}
const terbilang=n=>n===0?"nol":(n<0?"minus ":"")+tb(Math.abs(n));
const cap=s=>s.charAt(0).toUpperCase()+s.slice(1);
function parse(t){const m=String(t).match(/-?\d[\d.,]*/);if(!m)return null;let s=m[0];
 if(s.includes(","))s=s.replace(/\./g,"").replace(",",".");
 else if(/^-?\d{1,3}(\.\d{3})+$/.test(s))s=s.replace(/\./g,"");
 const v=parseFloat(s);return isFinite(v)?v:null;}
const ribu=(n,d=0)=>{const f=Math.abs(n).toFixed(d),[a,b]=f.split(".");return (n<0?"-":"")+a.replace(/\B(?=(\d{3})+(?!\d))/g,".")+(b?","+b:"");};
const ROM=[[1000,"M"],[900,"CM"],[500,"D"],[400,"CD"],[100,"C"],[90,"XC"],[50,"L"],[40,"XL"],[10,"X"],[9,"IX"],[5,"V"],[4,"IV"],[1,"I"]];
const romawi=n=>{n=Math.round(n);if(n<1||n>3999)return null;let r="";for(const [v,s] of ROM)while(n>=v){r+=s;n-=v;}return r;};
const singkat=n=>{const a=Math.abs(n),f=(x,u)=>(n<0?"-":"")+String(+(x).toFixed(1)).replace(".",",")+" "+u;
 return a>=1e12?f(a/1e12,"T"):a>=1e9?f(a/1e9,"M"):a>=1e6?f(a/1e6,"jt"):a>=1e3?f(a/1e3,"rb"):ribu(n);};
function numEdit(fn,msg){const a=sels().filter(o=>o.type==="text");if(!a.length)return T("Pilih teks dulu");
 const ok=a.filter(o=>parse(o.text)!==null);if(!ok.length)return T("Tidak ada angka di teks terpilih");
 Hi.snapshot();let n=0;ok.forEach(o=>{const v=parse(o.text),r=fn(v,o);if(r!=null&&r!==""){o.text=String(r);n++;}});C.render();T(n+" teks diubah"+(msg?" · "+msg:""));}
function total(kind){const a=sels().filter(o=>o.type==="text"&&parse(o.text)!==null);if(a.length<2)return T("Pilih 2+ teks berisi angka");
 const v=a.map(o=>parse(o.text)),sum=v.reduce((x,y)=>x+y,0),res=kind==="avg"?sum/v.length:kind==="max"?Math.max(...v):kind==="min"?Math.min(...v):sum;
 const lbl={sum:"Total",avg:"Rata-rata",max:"Terbesar",min:"Terkecil"}[kind],dec=res%1?2:0,txt=lbl+": "+ribu(res,dec);
 const x=Math.min(...a.map(o=>o.x)),y=Math.max(...a.map(o=>o.y+o.h))+24,fs=Math.max(...a.map(o=>o.fontSize||32));
 Hi.snapshot();const o={id:crypto.randomUUID(),type:"text",text:txt,x:Math.round(x),y:Math.round(y),w:Math.max(40,Math.round(txt.length*fs*.58)),h:Math.round(fs*1.4),fontSize:fs,fill:INK,bold:true,fontFamily:"Arial, sans-serif",opacity:100,rotation:0,stroke:"none",strokeWidth:0,name:lbl};
 S.objects.push(o);C.render();pick([o]);T(lbl+" = "+ribu(res,dec));}
const NUM={rp:v=>"Rp "+ribu(v,v%1?2:0),rb:v=>ribu(v,v%1?2:0),d2:v=>ribu(v,2),pct:v=>String(+v.toFixed(2)).replace(".",",")+"%",tb:v=>cap(terbilang(Math.round(v))),tbr:v=>cap(terbilang(Math.round(v)))+" rupiah",rom:v=>romawi(v),sg:v=>singkat(v),raw:v=>String(v)};
MENUS.angka=()=>[
 {h:"Format angka (teks terpilih)",items:[["Rupiah","rp"],["Ribuan","rb"],["2 desimal","d2"],["Persen","pct"],["Singkat (rb/jt/M)","sg"],["Hapus pemisah","raw"]].map(x=>tc(x[0],()=>numEdit(NUM[x[1]])))},
 {h:"Terbilang & romawi",items:[it("Terbilang",()=>numEdit(NUM.tb),"text"),it("Terbilang + rupiah",()=>numEdit(NUM.tbr),"text"),it("Angka romawi (1-3999)",()=>numEdit(NUM.rom),"text")]},
 {h:"Hitung angka",items:[["+1",v=>v+1],["−1",v=>v-1],["×2",v=>v*2],["÷2",v=>v/2],["+10%",v=>v*1.1],["−10%",v=>v*.9]].map(x=>tc(x[0],()=>numEdit((v,o)=>{const r=x[1](v),d=r%1?2:0;return /\d\.\d{3}/.test(o.text)?ribu(r,d):(d?String(+r.toFixed(2)).replace(".",","):String(r));})))},
 {h:"Gabungkan beberapa teks (pilih 2+)",items:[["Jumlah","sum"],["Rata-rata","avg"],["Terbesar","max"],["Terkecil","min"]].map(x=>tc(x[0],()=>total(x[1])))}];
BT.push(["angka","hash","Angka"]);
hubAdd("teks","angka");
/* ---------- Kartu Info ---------- */
const OKP="M10 52L40 82L92 20";
Object.assign(COMP,{
 "Kartu resep":()=>({w:420,h:520,a:[R(0,0,420,520,"#ffffff",{rx:28,stroke:"#00000018",strokeWidth:3,name:"Resep"}),R(20,20,380,200,"#ffe9c7",{rx:20}),X("Nasi Goreng Rumahan",28,262,34,INK,{left:1,bold:1}),X("30 menit · 2 porsi · Mudah",28,302,22,MUTE,{left:1}),R(28,330,364,2,"#e3e7f3"),X("Bahan",28,366,24,AC,{left:1,bold:1}),X("Nasi, telur, bawang, kecap",28,404,22,INK,{left:1}),X("Langkah",28,448,24,AC,{left:1,bold:1}),X("Tumis, masukkan nasi, aduk rata",28,486,22,INK,{left:1})]}),
 "Daftar tugas":()=>({w:420,h:360,a:[R(0,0,420,360,"#ffffff",{rx:28,stroke:"#00000018",strokeWidth:3,name:"Tugas"}),X("Tugas hari ini",28,52,32,INK,{left:1,bold:1}),...[0,1,2].flatMap(i=>[E(28,96+i*80,44,44,i===0?"#16a34a":"none",{stroke:i===0?"#16a34a":"#cfd6e6",strokeWidth:4}),...(i===0?[P(38,106,24,24,OKP,"none",{stroke:"#ffffff",strokeWidth:14})]:[]),X(["Kirim desain ke klien","Revisi logo","Rapat pukul 15.00"][i],92,118+i*80,26,i===0?MUTE:INK,{left:1})])]}),
 "Kartu cuaca":()=>({w:380,h:260,a:[R(0,0,380,260,"#3b82f6",{rx:28,name:"Cuaca"}),E(250,30,90,90,"#ffd166"),E(220,80,120,70,"#ffffff",{opacity:90}),X("Jakarta",28,52,28,"#dbeafe",{left:1,bold:1}),X("31°",28,150,96,"#ffffff",{left:1,bold:1}),X("Cerah berawan",28,222,24,"#dbeafe",{left:1})]}),
 "Hitung mundur":()=>({w:560,h:240,a:[R(0,0,560,240,"#11162a",{rx:28,name:"Hitung mundur"}),...[["12","HARI"],["08","JAM"],["45","MENIT"],["30","DETIK"]].flatMap((v,i)=>[R(24+i*132,40,116,130,"#1d2547",{rx:20}),X(v[0],82+i*132,100,60,"#ffffff",{bold:1}),X(v[1],82+i*132,148,18,"#9aa6d0",{bold:1})]),X("Menuju acara besar",280,208,24,"#9aa6d0")]}),
 "Pemutar musik":()=>({w:420,h:520,a:[R(0,0,420,520,"#1b1f3a",{rx:32,name:"Pemutar musik"}),R(40,40,340,340,AC,{rx:28}),E(150,150,120,120,"#ffffff",{opacity:25}),X("Judul Lagu",210,414,32,"#ffffff",{bold:1}),X("Nama Artis",210,448,22,"#9aa6d0"),R(40,474,340,6,"#3a4170",{rx:3}),R(40,474,170,6,"#ffffff",{rx:3}),E(198,466,22,22,"#ffffff")]}),
 "Kartu kontak":()=>({w:460,h:180,a:[R(0,0,460,180,"#ffffff",{rx:28,stroke:"#00000018",strokeWidth:3,name:"Kontak"}),E(24,36,108,108,"#ece9ff"),X("Nama Kontak",156,64,30,INK,{left:1,bold:1}),X("+62 812-3456-7890",156,104,24,MUTE,{left:1}),R(156,124,130,38,AC,{rx:19}),X("Hubungi",221,143,20,"#ffffff",{bold:1})]}),
 "Notifikasi":()=>({w:520,h:130,a:[R(0,0,520,130,"#ffffff",{rx:28,stroke:"#00000018",strokeWidth:3,name:"Notifikasi"}),R(24,29,72,72,AC,{rx:20}),X("Pesan baru",118,48,24,INK,{left:1,bold:1}),X("Desain Anda sudah disetujui.",118,84,22,MUTE,{left:1}),X("2 mnt",490,40,18,MUTE,{left:1,x:454})]}),
 "Kartu lokasi":()=>({w:440,h:300,a:[R(0,0,440,300,"#e8f1e4",{rx:28,name:"Lokasi"}),R(0,150,440,26,"#ffffff"),R(190,0,26,300,"#ffffff"),E(150,56,80,80,"#e5484d",{stroke:"#ffffff",strokeWidth:6}),E(178,84,24,24,"#ffffff"),R(24,208,392,68,"#ffffff",{rx:20}),X("Nama Tempat",44,232,26,INK,{left:1,bold:1}),X("Jl. Contoh No. 1 · 1,2 km",44,260,20,MUTE,{left:1})]}),
 "Target tabungan":()=>({w:460,h:240,a:[R(0,0,460,240,"#ffffff",{rx:28,stroke:"#00000018",strokeWidth:3,name:"Target"}),X("Target liburan",28,50,28,INK,{left:1,bold:1}),X("Rp 7.500.000",28,112,52,AC,{left:1,bold:1}),X("dari Rp 10.000.000",28,150,22,MUTE,{left:1}),R(28,176,404,24,"#e3e7f3",{rx:12}),R(28,176,303,24,AC,{rx:12}),X("75% tercapai",28,222,20,MUTE,{left:1})]})
});
MENUS.info2=()=>[
 {h:"Harian",items:["Kartu resep","Daftar tugas","Kartu cuaca","Hitung mundur"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Aplikasi",items:["Pemutar musik","Kartu kontak","Notifikasi","Kartu lokasi","Target tabungan"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["info2","info","Kartu Info"]);
hubAdd("pustaka","info2");
CDMS.Angka={terbilang,parse,ribu,romawi,singkat};
})();
