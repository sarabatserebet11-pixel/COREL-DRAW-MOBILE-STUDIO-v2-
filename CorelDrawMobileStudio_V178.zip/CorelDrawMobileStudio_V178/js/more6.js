/* V19: menu Format (salin gaya), Blend (blend, ekstrusi, kontur, ubin), Teks+ (alat teks), Versi (riwayat & versi) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,edit,sels,pick,T,it,tc}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;
const isHex=c=>/^#[0-9a-f]{6}$/i.test(String(c)),rgb=c=>[1,3,5].map(i=>parseInt(c.substr(i,2),16)),hx=a=>"#"+a.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0")).join("");
const lerpC=(a,b,t)=>{if(!isHex(a)||!isHex(b))return a;const A=rgb(a),B=rgb(b);return hx(A.map((v,i)=>v+(B[i]-v)*t));};
const shade=(c,f)=>isHex(c)?hx(rgb(c).map(v=>v*f)):c;
function ask(title,html,cb){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">Terapkan</button></div>`);$("#aOk").onclick=cb;}

/* ---- format painter ---- */
const KEYS=["fill","stroke","strokeWidth","opacity","fx","fxColor","fxAmount","pat","grad","dash","imgFx","mask","fontFamily","bold","italic","spacing","align","lh","textOutline","rx","skx","sky"],OPT=["fx","pat","grad","dash","imgFx","mask","textOutline","skx","sky","align","lh","spacing"];
let clip=null,geo=null;
function copyStyle(){const a=sels()[0];if(!a)return T("Pilih objek dulu");clip={};KEYS.forEach(k=>{if(a[k]!==undefined)clip[k]=a[k];});geo={w:a.w,h:a.h,x:a.x,y:a.y};T("Gaya disalin");}
const needClip=()=>{if(!clip){T("Salin gaya dulu");return true;}};
MENUS.fmt=()=>[
 {h:"Format painter",items:[it("Salin gaya objek terpilih",copyStyle,"copy"),it("Tempel gaya",()=>{if(needClip())return;edit(o=>{KEYS.forEach(k=>{if(k in clip&&!(o.type==="image"&&(k==="fill"||k==="stroke")))o[k]=clip[k];else if(OPT.includes(k))delete o[k];});},"Gaya ditempel");},"color"),it("Tempel ukuran",()=>{if(needClip())return;edit(o=>{o.w=geo.w;o.h=geo.h;},"Ukuran ditempel");},"plus"),it("Tempel posisi",()=>{if(needClip())return;edit(o=>{o.x=geo.x;o.y=geo.y;},"Posisi ditempel");},"arrange")]},
 {h:"Reset",items:[it("Reset gaya ke default",()=>edit(o=>{OPT.forEach(k=>delete o[k]);o.opacity=100;if(o.type!=="image"&&o.type!=="text"){o.stroke="#20243a";o.strokeWidth=2;}},"Gaya direset"),"undo")]}];

/* ---- blend, ekstrusi, kontur, ubin ---- */
function blend(n){const a=sels();if(a.length<2)return T("Pilih 2 objek (pakai tombol Multi)");const p=a[0],q=a[1];Hi.snapshot();const g=uid(),cp=[];
 for(let i=1;i<=n;i++){const t=i/(n+1),L=(u,v)=>u+(v-u)*t,c={...p,id:uid(),groupId:g,locked:false,name:"Blend "+i,x:Math.round(L(p.x,q.x)),y:Math.round(L(p.y,q.y)),w:Math.max(1,Math.round(L(p.w,q.w))),h:Math.round(L(p.h||0,q.h||0)),rotation:Math.round(L(p.rotation||0,q.rotation||0)),opacity:Math.round(L(p.opacity??100,q.opacity??100))};
  if(p.type!=="image"&&p.fill&&q.fill)c.fill=lerpC(p.fill,q.fill,t);if(c.fontSize&&q.fontSize)c.fontSize=Math.round(L(p.fontSize,q.fontSize));delete c.fxOf;cp.push(c);}
 S.objects.splice(Math.min(S.objects.indexOf(p),S.objects.indexOf(q))+1,0,...cp);C.render();T(n+" langkah blend dibuat");}
function extrude(depth,dir){const a=sels().filter(o=>o.type!=="image"&&o.type!=="line");if(!a.length)return T("Pilih bentuk atau teks dulu");Hi.snapshot();
 a.forEach(o=>{const g=o.groupId||(o.groupId=uid()),n=Math.max(2,Math.round(depth/2)),sy=dir==="ne"?-1:1,cp=[];
  for(let i=n;i>=1;i--){const c={...o,id:uid(),groupId:g,fxOf:o.id,locked:false,name:(o.name||o.type)+" ekstrusi",x:o.x+i*2,y:o.y+i*2*sy,fill:shade(o.fill,.55),opacity:100};delete c.fx;delete c.pat;delete c.grad;cp.push(c);}
  S.objects.splice(S.objects.indexOf(o),0,...cp);});C.render();}
function contour(n,out){const a=sels().filter(o=>["rect","ellipse","star","polygon","path"].includes(o.type));if(!a.length)return T("Pilih bentuk dulu");Hi.snapshot();
 a.forEach(o=>{const cx=o.x+o.w/2,cy=o.y+o.h/2,g=o.groupId||(o.groupId=uid()),step=out?.12:.16,cp=[];
  for(let i=1;i<=n;i++){const f=out?1+i*step:1-i*step;if(f<=.05)break;const c={...o,id:uid(),groupId:g,fxOf:o.id,locked:false,name:"Kontur "+i,w:Math.round(o.w*f),h:Math.round(o.h*f),x:Math.round(cx-o.w*f/2),y:Math.round(cy-o.h*f/2),fill:lerpC(o.fill,"#ffffff",i/(n+1)),opacity:out?Math.round(100-i*(70/(n+1))):100};delete c.fx;delete c.pat;delete c.grad;cp.push(c);}
  if(out)S.objects.splice(S.objects.indexOf(o),0,...cp.reverse());else S.objects.splice(S.objects.indexOf(o)+1,0,...cp);});C.render();}
function tile(mode,gk){const a=sels();if(!a.length)return T("Pilih objek dulu");const x0=Math.min(...a.map(o=>o.x)),y0=Math.min(...a.map(o=>o.y)),bw=Math.max(...a.map(o=>o.x+o.w))-x0,bh=Math.max(...a.map(o=>o.y+(o.h||0)))-y0,gap=Math.round(Math.min(bw,bh)*gk),cw=bw+gap,ch=bh+gap,cols=Math.ceil(W()/cw)+1,rows=Math.ceil(H()/ch)+1;
 if(cols*rows*a.length>240)return T("Terlalu banyak salinan. Perbesar jarak atau objek.");Hi.snapshot();const g=uid(),ids=new Set(a.map(o=>o.id)),out=[];
 for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){const dx=c*cw+(mode==="brick"&&r%2?cw/2:0)-x0,dy=r*ch-y0;a.forEach(o=>{const n={...o,id:uid(),groupId:g,x:Math.round(o.x+dx),y:Math.round(o.y+dy),name:"Ubin"};if(mode==="alt"&&(r+c)%2)n.rotation=(o.rotation||0)+180;out.push(n);});}
 S.objects=S.objects.filter(o=>!ids.has(o.id));S.objects.push(...out);S.selected=null;S.selectedIds=[];C.render();T(out.length+" ubin dibuat");}
MENUS.blend=()=>[
 {h:"Blend 2 objek (pilih 2 dgn Multi)",items:[3,5,8,12].map(n=>tc(n+" langkah",()=>blend(n)))},
 {h:"Ekstrusi 3D",items:[["12 px ↘",12,"se"],["24 px ↘",24,"se"],["12 px ↗",12,"ne"],["24 px ↗",24,"ne"]].map(x=>tc(x[0],()=>extrude(x[1],x[2])))},
 {h:"Kontur",items:[["Dalam 3",3,0],["Dalam 6",6,0],["Luar 3",3,1],["Luar 6",6,1]].map(x=>tc(x[0],()=>contour(x[1],x[2])))},
 {h:"Ubin memenuhi halaman",items:[it("Ubin lurus",()=>tile("grid",.2),"dup"),it("Ubin bata",()=>tile("brick",.2),"dup"),it("Ubin bolak-balik 180°",()=>tile("alt",.2),"dup"),it("Ubin rapat",()=>tile("grid",.05),"dup")]}];

/* ---- alat teks ---- */
const wrapT=(t,n)=>{const out=[];let l="";t.split(/\s+/).filter(Boolean).forEach(w=>{if(l&&(l+" "+w).length>n){out.push(l);l=w;}else l=(l+" "+w).trim();});if(l)out.push(l);return out.join("\n");};
const tx=(fn,msg)=>edit(o=>{o.text=fn(String(o.text||""));},msg,o=>o.type==="text"),one=t=>t.replace(/\s*\n\s*/g," ");
const LOREM="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
function findRep(){ask("Cari & ganti teks",'<label>Cari<input id="fF"></label><label>Ganti dengan<input id="fR"></label>',()=>{const f=$("#fF").value,r=$("#fR").value;if(!f)return T("Isi kata yang dicari");N.closeModal();const sel=sels().filter(o=>o.type==="text"),a=sel.length?sel:S.objects.filter(o=>o.type==="text");let n=0;Hi.snapshot();a.forEach(o=>{const parts=String(o.text||"").split(f);n+=parts.length-1;o.text=parts.join(r)||" ";});C.render();T(n+" penggantian di "+a.length+" teks");});}
function count(){const a=sels().filter(o=>o.type==="text");if(!a.length)return T("Pilih teks dulu");const t=a.map(o=>o.text||"").join(" ");T((t.trim().split(/\s+/).filter(Boolean).length)+" kata · "+t.replace(/\s/g,"").length+" huruf");}
MENUS.txu=()=>[
 {h:"Bungkus & rapikan",items:[it("Bungkus 16 kolom",()=>tx(t=>wrapT(one(t),16)),"text"),it("Bungkus 28 kolom",()=>tx(t=>wrapT(one(t),28)),"text"),it("Bungkus 40 kolom",()=>tx(t=>wrapT(one(t),40)),"text"),it("Gabung jadi satu baris",()=>tx(one),"text")]},
 {h:"Daftar",items:[it("Beri nomor tiap baris",()=>tx(t=>t.split("\n").map((l,i)=>(i+1)+". "+l.replace(/^\d+\.\s*/,"")).join("\n")),"layers"),it("Beri poin •",()=>tx(t=>t.split("\n").map(l=>"• "+l.replace(/^•\s*/,"")).join("\n")),"layers"),it("Hapus nomor / poin",()=>tx(t=>t.split("\n").map(l=>l.replace(/^(\d+\.|•)\s*/,"")).join("\n")),"trash"),it("Urutkan baris A–Z",()=>tx(t=>t.split("\n").sort((a,b)=>a.localeCompare(b,"id")).join("\n")),"arrange"),it("Balik urutan baris",()=>tx(t=>t.split("\n").reverse().join("\n")),"redo")]},
 {h:"Isi & info",items:[it("Cari & ganti…",findRep,"search"),it("Hitung kata & huruf",count,"text"),it("Isi contoh pendek",()=>tx(()=>wrapT(LOREM.slice(0,56),28)),"text"),it("Isi contoh panjang",()=>tx(()=>wrapT(LOREM,30)),"text")]}];

/* ---- versi & riwayat ---- */
const VK="cdms_versions",getV=()=>{try{return JSON.parse(localStorage.getItem(VK)||"[]");}catch(e){return[];}};
function saveV(){const l=getV();l.push({name:"Versi "+(l.length+1)+" · "+new Date().toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit"}),w:W(),h:H(),bg:S.page.background,o:JSON.stringify(S.objects)});try{localStorage.setItem(VK,JSON.stringify(l.slice(-8)));T("Versi tersimpan");}catch(e){T("Penyimpanan penuh (gambar besar?)");}}
function restoreV(i){const v=getV()[i];if(!v)return;Hi.snapshot();S.page.width=v.w;S.page.height=v.h;S.page.background=v.bg;S.objects=JSON.parse(v.o);S.selected=null;S.selectedIds=[];C.render();T(v.name+" dipulihkan");}
const rep=(f,n)=>{for(let i=0;i<n;i++)f();};
MENUS.ver=()=>{const l=getV();return[
 {h:"Riwayat sesi",items:[it("Urungkan 5 langkah",()=>rep(()=>Hi.undo(),5),"undo"),it("Urungkan 10 langkah",()=>rep(()=>Hi.undo(),10),"undo"),it("Ulangi 5 langkah",()=>rep(()=>Hi.redo(),5),"redo")]},
 {h:"Versi tersimpan (maks 8)",items:[it("Simpan versi sekarang",saveV,"save"),...l.map((v,i)=>it(v.name,()=>restoreV(i),"open"))]},
 {h:"Bersihkan",items:[it("Hapus semua versi",()=>{try{localStorage.removeItem(VK);}catch(e){}T("Semua versi dihapus");},"trash")]}];};

BT.push(["fmt","roller","Format"],["blend","blend","Campur"],["txu","textplus","Teks+"],["ver","history","Versi"]);
})();
