/* V53: menu Kartu Sosmed - testimoni, kupon, postingan, tombol play, profil, harga, promo, jadwal, daftar fitur */
(()=>{
const M=CDMS.Menus,{MENUS,BT,it}=M,K=CDMS.UIKit,{COMP,place,R,E,P,X,STAR,AC,INK,MUTE}=K;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const OK="M10 52L40 82L92 20";
Object.assign(COMP,{
 "Testimoni":()=>({w:520,h:300,a:[R(0,0,520,300,"#ffffff",{rx:28,stroke:"#00000018",strokeWidth:3,name:"Testimoni"}),...[0,1,2,3,4].map(i=>P(30+i*44,28,36,36,STAR,"#ffc857")),X("“Layanannya cepat dan hasilnya",30,108,28,INK,{left:1}),X("melebihi harapan saya.”",30,146,28,INK,{left:1}),E(30,200,64,64,"#ece9ff"),X("Nama Pelanggan",112,222,26,INK,{left:1,bold:1}),X("Pelanggan setia",112,252,22,MUTE,{left:1})]}),
 "Kupon diskon":()=>({w:560,h:220,a:[R(0,0,560,220,AC,{rx:28,name:"Kupon"}),R(390,16,4,188,"#ffffff",{opacity:60}),X("DISKON",34,60,26,"#e2dcff",{left:1,bold:1}),X("50%",34,128,84,"#ffffff",{left:1,bold:1}),X("Berlaku sampai habis",34,190,22,"#e2dcff",{left:1}),X("KODE",476,80,22,"#e2dcff",{bold:1}),X("HEMAT50",476,124,30,"#ffffff",{bold:1})]}),
 "Postingan sosmed":()=>({w:520,h:640,a:[R(0,0,520,640,"#ffffff",{rx:24,stroke:"#00000018",strokeWidth:3,name:"Postingan"}),E(20,16,64,64,"#ece9ff"),X("namaakun",100,36,26,INK,{left:1,bold:1}),X("Jakarta",100,64,20,MUTE,{left:1}),R(0,96,520,420,"#e8ecf8"),E(24,540,40,40,"none",{stroke:INK,strokeWidth:4}),E(80,540,40,40,"none",{stroke:INK,strokeWidth:4}),X("1.248 suka",24,610,24,INK,{left:1,bold:1})]}),
 "Tombol play video":()=>({w:200,h:200,a:[E(0,0,200,200,"#ff4f6d",{name:"Play",stroke:"#ffffff",strokeWidth:8}),P(66,56,80,88,"M0 0L100 50L0 100Z","#ffffff")]}),
 "Kartu profil":()=>({w:420,h:360,a:[R(0,0,420,360,"#ffffff",{rx:28,stroke:"#00000018",strokeWidth:3,name:"Profil"}),R(0,0,420,120,AC,{rx:28}),R(0,90,420,30,AC),E(145,60,130,130,"#ece9ff",{stroke:"#ffffff",strokeWidth:8}),X("Nama Lengkap",210,230,34,INK,{bold:1}),X("Desainer Grafis",210,270,24,MUTE),R(110,304,200,16,"#ece9ff",{rx:8})]}),
 "Kartu harga":()=>({w:380,h:520,a:[R(0,0,380,520,"#ffffff",{rx:28,stroke:AC,strokeWidth:4,name:"Harga"}),X("PRO",190,56,28,AC,{bold:1}),X("Rp 99rb",190,130,64,INK,{bold:1}),X("per bulan",190,176,24,MUTE),...[0,1,2].flatMap(i=>[P(34,234+i*64,32,32,OK,"none",{stroke:"#16a34a",strokeWidth:12}),X(["Semua fitur","Ekspor tanpa batas","Dukungan prioritas"][i],84,250+i*64,26,INK,{left:1})]),R(40,440,300,64,AC,{rx:32}),X("Pilih paket",190,472,26,"#ffffff",{bold:1})]}),
 "Banner promo":()=>({w:720,h:240,a:[R(0,0,720,240,"#ff6b6b",{rx:28,name:"Promo"}),E(560,-40,260,260,"#ffffff",{opacity:18}),X("FLASH SALE",36,70,28,"#ffe3e3",{left:1,bold:1}),X("Diskon hingga 70%",36,134,50,"#ffffff",{left:1,bold:1}),R(36,176,200,44,"#ffffff",{rx:22}),X("Belanja sekarang",136,198,20,"#ff6b6b",{bold:1})]}),
 "Kartu jadwal acara":()=>({w:520,h:200,a:[R(0,0,520,200,"#ffffff",{rx:28,stroke:"#00000018",strokeWidth:3,name:"Acara"}),R(24,24,120,152,AC,{rx:22}),X("OKT",84,62,26,"#e2dcff",{bold:1}),X("23",84,116,64,"#ffffff",{bold:1}),X("Nama Acara",172,66,32,INK,{left:1,bold:1}),X("19.00 WIB · Aula Utama",172,110,24,MUTE,{left:1}),X("Gratis · Daftar sekarang",172,148,22,AC,{left:1,bold:1})]}),
 "Daftar fitur (centang)":()=>({w:460,h:240,a:[0,1,2].flatMap(i=>[E(0,i*84,56,56,"#dcfce7"),P(14,i*84+14,28,28,OK,"none",{stroke:"#16a34a",strokeWidth:14}),X(["Cepat dan ringan","Bisa dipakai offline","Hasil ekspor tajam"][i],78,i*84+28,28,INK,{left:1})])})
});
MENUS.kartu=()=>[
 {h:"Sosial & ulasan",items:["Testimoni","Postingan sosmed","Kartu profil","Tombol play video"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Promosi & bisnis",items:["Kupon diskon","Banner promo","Kartu harga","Kartu jadwal acara","Daftar fitur (centang)"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["kartu","card","Kartu Sosmed"]);
hubAdd("pustaka","kartu");
})();
