/* V160: bentuk baru, seret sudut untuk ubah ukuran, garis tepi, transparansi. V148: transisi, maju otomatis, putar objek. V147: tabel, cadangan .json. V140: Mode PowerPoint — slide, tata letak, objek (teks/gambar/bentuk), tema, tampilan layar penuh, cetak */
(()=>{
 const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
 const dash=$('#dashboard'), editor=$('#editor'), view=$('#pptMode'), slide=$('#pptSlide'), wrapEl=$('#pptWrap'), stage=$('#pptStage'), strip=$('#pptStrip');
 if(!dash||!view||!slide)return;
 const STORE='cdms-ppt-deck', W=960, H=540, MAXS=60;
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const THEMES=[['A','#ffffff','#1f2430'],['A','#1f2430','#ffffff'],['A','#185abd','#ffffff'],['A','#217346','#ffffff'],['A','#c43e1c','#ffffff'],['A','#fff4d6','#4a3500'],['A','#f3e8ff','#3b1a66']];
 const LAY={
  title:()=>'<div class="ppt-ph ppt-t1" contenteditable="true" data-ph="Klik untuk judul"></div><div class="ppt-ph ppt-sub" contenteditable="true" data-ph="Klik untuk subjudul"></div>',
  content:()=>'<div class="ppt-ph ppt-t2" contenteditable="true" data-ph="Judul slide"></div><div class="ppt-ph ppt-body" contenteditable="true" data-ph="Tulis isi di sini"></div>',
  two:()=>'<div class="ppt-ph ppt-t2" contenteditable="true" data-ph="Judul slide"></div><div class="ppt-cols"><div class="ppt-ph ppt-body" contenteditable="true" data-ph="Kolom kiri"></div><div class="ppt-ph ppt-body" contenteditable="true" data-ph="Kolom kanan"></div></div>',
  blank:()=>''
 };
 const mk=(l,bg,fg)=>({bg:bg||'#ffffff',fg:fg||'#1f2430',html:(LAY[l]||LAY.content)()});
 let deck={title:'Presentasi1',num:false,trans:'fade',auto:0,slides:[mk('title')]}, cur=0, saveT=0, thT=0, sel=null, scale=1, savedRange=null;

 /* ---------- Penyimpanan ---------- */
 const clean=el=>{const c=el.cloneNode(true);c.querySelectorAll('.ppt-num,.ppt-rs').forEach(x=>x.remove());return c.innerHTML.replace(/ sel\b/g,'');};
 const okTrans=t=>['fade','slide','zoom','none'].includes(t)?t:'fade', okAuto=a=>[0,3,5,10].includes(+a)?+a:0;
 const numEl=n=>'<span class="ppt-num">'+n+'</span>';
 function grab(){if(deck.slides[cur])deck.slides[cur].html=clean(slide);}
 function save(){grab();try{localStorage.setItem(STORE,JSON.stringify(deck));$('#pptStatus').textContent='Tersimpan di perangkat';}catch(_){$('#pptStatus').textContent='Gagal menyimpan (penyimpanan penuh?)';}}
 function changed(){$('#pptStatus').textContent='Menyimpan…';clearTimeout(saveT);saveT=setTimeout(save,800);clearTimeout(thT);thT=setTimeout(renderStrip,500);}
 function toast(m){const s=$('#pptMsg');s.textContent=m;s.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>s.classList.remove('show'),2400);}
 function load(){try{const d=JSON.parse(localStorage.getItem(STORE)||'null');if(d&&Array.isArray(d.slides)&&d.slides.length){deck={title:String(d.title||'Presentasi1'),num:!!d.num,trans:okTrans(d.trans),auto:okAuto(d.auto),slides:d.slides.slice(0,MAXS).map(s=>({notes:String(s.notes||'').slice(0,2000),bg:/^#[0-9a-f]{6}$/i.test(s.bg)?s.bg:'#ffffff',fg:/^#[0-9a-f]{6}$/i.test(s.fg)?s.fg:'#1f2430',html:String(s.html||'')}))};}}catch(_){}}

 /* ---------- Tampilan ---------- */
 function style(el,s){el.style.background=s.bg;el.style.color=s.fg;}
 function show(i){
  grab();cur=Math.max(0,Math.min(deck.slides.length-1,i));const s=deck.slides[cur];
  slide.innerHTML=s.html;if(deck.num)slide.insertAdjacentHTML('beforeend',numEl(cur+1));style(slide,s);sel=null;$('#pptNotesText').value=s.notes||'';
  $('#pptBg').value=s.bg;$('#pptBgBar').style.background=s.bg;
  $('#pptCount').textContent='Slide '+(cur+1)+' dari '+deck.slides.length;
  renderStrip();fit();
 }
 function renderStrip(){
  strip.innerHTML='';deck.slides.forEach((s,i)=>{const d=document.createElement('div');d.className='ppt-th'+(i===cur?' on':'');d.dataset.i=i;const sl=document.createElement('div');sl.className='ppt-slide';sl.innerHTML=i===cur?clean(slide):s.html;style(sl,s);d.appendChild(sl);const b=document.createElement('b');b.textContent=i+1;d.appendChild(b);strip.appendChild(d);});
  const on=strip.querySelector('.on');if(on&&on.scrollIntoView)on.scrollIntoView({block:'nearest',inline:'nearest'});
 }
 strip.addEventListener('click',e=>{const t=e.target.closest('.ppt-th');if(t)show(+t.dataset.i);});
 function fit(){
  const r=stage.getBoundingClientRect(),cs=getComputedStyle(stage),pw=r.width-parseFloat(cs.paddingLeft)-parseFloat(cs.paddingRight),ph=r.height-parseFloat(cs.paddingTop)-parseFloat(cs.paddingBottom);
  scale=Math.max(.2,Math.min(pw/W,ph/H,2));wrapEl.style.width=W*scale+'px';wrapEl.style.height=H*scale+'px';slide.style.transform='scale('+scale+')';
 }
 window.addEventListener('resize',()=>{if(!view.classList.contains('hidden'))fit();});
 if(window.ResizeObserver)new ResizeObserver(()=>{if(!view.classList.contains('hidden'))fit();}).observe(stage);


 /* V143: urungkan / ulangi (struktur slide, objek, dan teks) */
 let undoSt=[],redoSt=[],textSnap=0;
 const snapStr=()=>{grab();return JSON.stringify({d:deck,c:cur});};
 function snap(){undoSt.push(snapStr());if(undoSt.length>40)undoSt.shift();redoSt=[];}
 function restoreSnap(str){const o=JSON.parse(str);deck=o.d;$('#pptTitle').value=deck.title;syncOpts();cur=-1;show(Math.min(o.c,deck.slides.length-1));changed();}
 function undo(){if(!undoSt.length){toast('Tidak ada yang bisa diurungkan.');return;}redoSt.push(snapStr());restoreSnap(undoSt.pop());}
 function redo(){if(!redoSt.length){toast('Tidak ada yang bisa diulang.');return;}undoSt.push(snapStr());restoreSnap(redoSt.pop());}
 slide.addEventListener('beforeinput',()=>{if(!textSnap){snap();}clearTimeout(textSnap);textSnap=setTimeout(()=>{textSnap=0;},1200);});
 /* ---------- Pita ---------- */
 $$('[data-ppt-tab]').forEach(b=>b.addEventListener('click',()=>{const t=b.dataset.pptTab;$$('[data-ppt-tab]').forEach(x=>x.classList.toggle('active',x===b));$$('[data-ppt-pane]').forEach(p=>p.classList.toggle('active',p.dataset.pptPane===t));}));
 $$('[data-ppt-cmd],[data-ppt-act]').forEach(b=>b.addEventListener('mousedown',e=>e.preventDefault()));
 document.addEventListener('selectionchange',()=>{const s=getSelection();if(s.rangeCount&&slide.contains(s.anchorNode))savedRange=s.getRangeAt(0).cloneRange();});
 function restore(){if(savedRange){const s=getSelection();s.removeAllRanges();s.addRange(savedRange);}}
 function exec(c,v){snap();restore();try{document.execCommand('styleWithCSS',false,c==='foreColor');}catch(_){ }document.execCommand(c,false,v==null?null:v);changed();}
 $$('[data-ppt-cmd]').forEach(b=>b.addEventListener('click',()=>{if(!savedRange){toast('Ketuk teks di slide dulu.');return;}exec(b.dataset.pptCmd);}));
 $('#pptColor').addEventListener('input',e=>{$('#pptColorBar').style.background=e.target.value;if(!savedRange){toast('Blok teks di slide dulu.');return;}exec('foreColor',e.target.value);});
 $('#pptSize').addEventListener('change',e=>{const px=e.target.value;e.target.value='';if(!px)return;if(!savedRange||getSelection().isCollapsed){toast('Blok teks dulu, lalu pilih ukuran.');return;}restore();document.execCommand('styleWithCSS',false,false);document.execCommand('fontSize',false,'7');
  slide.querySelectorAll('font[size="7"]').forEach(f=>{const sp=document.createElement('span');sp.style.fontSize=px+'px';while(f.firstChild)sp.appendChild(f.firstChild);f.replaceWith(sp);});changed();});
 slide.addEventListener('input',changed);
 slide.addEventListener('paste',e=>{e.preventDefault();const t=(e.clipboardData||window.clipboardData).getData('text/plain');document.execCommand('insertText',false,t);});

 /* ---------- Objek ---------- */
 const HANDLE='<span class="ppt-h" contenteditable="false">✥</span>';
 function place(html,w){snap();grab();const d=document.createElement('div');d.className='ppt-obj';d.style.left=(W/2-w/2)+'px';d.style.top='190px';d.style.width=w+'px';d.innerHTML=HANDLE+html;slide.appendChild(d);select(d);changed();return d;}
 function select(o){slide.querySelectorAll('.ppt-obj.sel').forEach(x=>x.classList.remove('sel'));slide.querySelectorAll('.ppt-rs').forEach(x=>x.remove());sel=o||null;if(o){o.classList.add('sel');if(!o.querySelector('.ppt-rs'))o.insertAdjacentHTML('beforeend','<span class="ppt-rs" contenteditable="false"></span>');if(o.dataset.shape){$('#pptFill').value=rgb2hex(o.style.background)||'#2f7fd1';}}}
 function rgb2hex(c){const m=/rgb\((\d+),\s*(\d+),\s*(\d+)\)/.exec(c);return m?'#'+[m[1],m[2],m[3]].map(x=>(+x).toString(16).padStart(2,'0')).join(''):(/^#[0-9a-f]{6}$/i.test(c)?c:'');}
 let drag=null;
 slide.addEventListener('pointerdown',e=>{
  const o=e.target.closest('.ppt-obj');
  if(o&&e.target.classList.contains('ppt-rs')){e.preventDefault();select(o);snap();const r=o.getBoundingClientRect(),isImg=!!o.querySelector('img');drag={rs:1,o,x:e.clientX,y:e.clientY,w:r.width/scale,h:r.height/scale,img:isImg};try{slide.setPointerCapture(e.pointerId);}catch(_){}return;}
  if(!o){if(sel)select(null);return;}
  select(o);
  const onHandle=e.target.closest('.ppt-h'),movable=onHandle||o.querySelector('img')===e.target||o.dataset.shape;
  if(!movable)return;
  e.preventDefault();snap();drag={o,x:e.clientX,y:e.clientY,l:parseFloat(o.style.left)||0,t:parseFloat(o.style.top)||0};try{slide.setPointerCapture(e.pointerId);}catch(_){}
 });
 slide.addEventListener('pointermove',e=>{if(!drag)return;if(drag.rs){const nw=Math.max(40,Math.min(W*1.5,drag.w+(e.clientX-drag.x)/scale));drag.o.style.width=Math.round(nw)+'px';if(!drag.img&&(drag.o.dataset.shape||drag.o.style.height)){drag.o.style.height=Math.max(6,Math.min(H*1.5,Math.round(drag.h+(e.clientY-drag.y)/scale)))+'px';}return;}const nl=Math.max(-100,Math.min(W-40,drag.l+(e.clientX-drag.x)/scale)),nt=Math.max(-20,Math.min(H-30,drag.t+(e.clientY-drag.y)/scale));drag.o.style.left=Math.round(nl)+'px';drag.o.style.top=Math.round(nt)+'px';});
 const endDrag=()=>{if(drag){drag=null;changed();}};
 slide.addEventListener('pointerup',endDrag);slide.addEventListener('pointercancel',endDrag);
 function need(){if(!sel){toast('Pilih objek dulu (ketuk gambar/bentuk/kotak teks).');return false;}return true;}

 /* V147: tabel + impor aman */
 function tblCtx(){let n=getSelection().anchorNode;n=n&&(n.nodeType===1?n:n.parentElement);let td=n&&n.closest?n.closest('td'):null;let o=td?td.closest('.ppt-obj'):(sel&&sel.querySelector('table')?sel:null);if(!o||!slide.contains(o)){toast('Pilih tabel dulu (ketuk sel atau tabelnya).');return null;}const tb=o.querySelector('tbody');if(!tb)return null;if(td&&!slide.contains(td))td=null;const tr=td?td.parentElement:tb.rows[tb.rows.length-1];return {tb,tr,td};}
 function safeHtml(h){const d=new DOMParser().parseFromString('<body>'+String(h||'')+'</body>','text/html').body;d.querySelectorAll('script,iframe,object,embed,link,style,meta,base,form,svg,math').forEach(x=>x.remove());d.querySelectorAll('*').forEach(x=>{[...x.attributes].forEach(a=>{const n=a.name.toLowerCase(),v=a.value;if(n.startsWith('on')||n==='srcdoc'||n==='formaction'||/^\s*(javascript|vbscript):/i.test(v)||(n==='href')||(n==='src'&&!/^data:image\/(png|jpe?g|gif|webp);/i.test(v)))x.removeAttribute(a.name);});});return d.innerHTML;}

 function rotate(d){if(!need())return;snap();const m=/rotate\((-?[\d.]+)deg\)/.exec(sel.style.transform||'');let a=((m?+m[1]:0)+d)%360;sel.style.transform=a?'rotate('+a+'deg)':'';changed();}

 /* V162: pengait impor PPTX/PDF (dipakai js/office-import.js) */
 (window.CDMS_OFFICE=window.CDMS_OFFICE||{}).ppt={apply(list,o){
  grab();snap();
  const s0=deck.slides[0],blank=deck.slides.length===1&&!/ppt-obj|<img|<table/.test(s0.html)&&!s0.html.replace(/<[^>]*>/g,'').trim();
  const rep=!!(o&&o.replace)||blank,room=rep?MAXS:MAXS-deck.slides.length;
  const add=list.slice(0,Math.max(0,room)).map(s=>({notes:String(s.notes||'').slice(0,2000),bg:/^#[0-9a-f]{6}$/i.test(s.bg)?s.bg:'#ffffff',fg:/^#[0-9a-f]{6}$/i.test(s.fg)?s.fg:'#1f2430',html:String(s.html||'')}));
  if(!add.length)return{added:0,saved:true};
  const first=rep?0:deck.slides.length;
  if(rep){deck.slides=add;if(o&&o.title){deck.title=String(o.title).slice(0,80);$('#pptTitle').value=deck.title;}}else deck.slides=deck.slides.concat(add);
  cur=-1;show(first);
  let ok=true;try{localStorage.setItem(STORE,JSON.stringify(deck));$('#pptStatus').textContent='Tersimpan di perangkat';}catch(_){ok=false;$('#pptStatus').textContent='Gagal menyimpan (penyimpanan penuh?)';}
  return{added:add.length,saved:ok};
 }};

 /* ---------- Aksi ---------- */
 const CLIP={tri:'polygon(50% 0,100% 100%,0 100%)',diamond:'polygon(50% 0,100% 50%,50% 100%,0 50%)',hex:'polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%)',star:'polygon(50% 0,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%)',arrowr:'polygon(0 25%,60% 25%,60% 0,100% 50%,60% 100%,60% 75%,0 75%)'};
 function shape(k){const o=place('',k==='arrowr'?280:200);o.dataset.shape=k;o.style.height=(k==='arrowr'?'160px':'200px');o.style.background='#2f7fd1';if(CLIP[k])o.style.clipPath=CLIP[k];if(k==='round')o.style.borderRadius='32px';select(o);changed();}
 const ACT={
  save(){save();toast('Tersimpan di perangkat.');},
  undo(){undo();},
  redo(){redo();},
  add(){snap();if(deck.slides.length>=MAXS){toast('Maksimum '+MAXS+' slide.');return;}grab();const c=deck.slides[cur];deck.slides.splice(cur+1,0,mk($('#pptLayout').value,c.bg,c.fg));show(cur+1);changed();},
  dup(){snap();if(deck.slides.length>=MAXS){toast('Maksimum '+MAXS+' slide.');return;}grab();const c=deck.slides[cur];deck.slides.splice(cur+1,0,{...c});show(cur+1);changed();},
  del(){snap();if(deck.slides.length<=1){deck.slides[0]=mk('title');show(0);changed();toast('Slide terakhir dikosongkan.');return;}if(!confirm('Hapus slide '+(cur+1)+'?'))return;deck.slides.splice(cur,1);cur=Math.min(cur,deck.slides.length-1);slide.innerHTML='';const keep=cur;cur=-1;show(keep);changed();},
  up(){snap();if(cur<1)return;grab();const s=deck.slides;[s[cur-1],s[cur]]=[s[cur],s[cur-1]];cur--;show(cur);changed();},
  down(){snap();if(cur>=deck.slides.length-1)return;grab();const s=deck.slides;[s[cur+1],s[cur]]=[s[cur],s[cur+1]];cur++;show(cur);changed();},
  textbox(){const o=place('<div class="ppt-ot" contenteditable="true">Teks baru</div>',360);const t=o.querySelector('.ppt-ot');t.focus();},
  image(){$('#pptImgInput').click();},
  rect(){const o=place('',240);o.dataset.shape='rect';o.style.height='140px';o.style.background='#2f7fd1';select(o);changed();},
  oval(){const o=place('',200);o.dataset.shape='oval';o.style.height='200px';o.style.borderRadius='50%';o.style.background='#e8a317';select(o);changed();},
  bigger(){snap();if(!need())return;sel.style.width=Math.min(W,(parseFloat(sel.style.width)||200)*1.15)+'px';if(sel.style.height)sel.style.height=Math.min(H,parseFloat(sel.style.height)*1.15)+'px';changed();},
  smaller(){snap();if(!need())return;sel.style.width=Math.max(40,(parseFloat(sel.style.width)||200)/1.15)+'px';if(sel.style.height)sel.style.height=Math.max(30,parseFloat(sel.style.height)/1.15)+'px';changed();},
  tri(){shape('tri');},star(){shape('star');},diamond(){shape('diamond');},hex(){shape('hex');},arrowr(){shape('arrowr');},round(){shape('round');},
  nostroke(){if(!need())return;snap();sel.style.border='';changed();},
  opac(){if(!need())return;snap();const L=[1,.75,.5,.25],c=parseFloat(sel.style.opacity||'1'),n=L[(L.findIndex(x=>Math.abs(x-c)<.02)+1)%L.length];sel.style.opacity=n===1?'':String(n);changed();toast('Transparansi: '+Math.round((1-n)*100)+'%');},
  line(){const o=place('',360);o.dataset.shape='line';o.style.height='6px';o.style.background='#1f2430';o.style.borderRadius='3px';o.style.top='260px';select(o);changed();},
  arrow(){const o=place('<div class="ppt-ot" contenteditable="false" style="font-size:64px;line-height:1;padding:0;text-align:center">➜</div>',120);o.style.top='230px';changed();},
  dupobj(){if(!need())return;snap();const c=sel.cloneNode(true);c.classList.remove('sel');c.style.left=(parseFloat(sel.style.left)||0)+30+'px';c.style.top=(parseFloat(sel.style.top)||0)+30+'px';slide.appendChild(c);select(c);changed();},
  front(){if(!need())return;snap();slide.appendChild(sel);changed();},
  back(){if(!need())return;snap();slide.insertBefore(sel,slide.firstChild);changed();},
  center(){if(!need())return;snap();const w=sel.getBoundingClientRect().width/scale;sel.style.left=Math.round((W-w)/2)+'px';changed();},
  table(){const rows=3,cols=3;let h='<table class="ppt-tbl"><tbody>';for(let r=0;r<rows;r++){h+='<tr>';for(let c=0;c<cols;c++)h+='<td contenteditable="true">'+(r===0?'Judul '+(c+1):'')+'</td>';h+='</tr>';}h+='</tbody></table>';const o=place(h,520);o.dataset.table='1';o.style.top='170px';changed();},
  'tr+'(){const t=tblCtx();if(!t)return;snap();const nr=t.tr.cloneNode(true);nr.querySelectorAll('td').forEach(x=>{x.textContent='';});t.tr.after(nr);changed();},
  'tc+'(){const t=tblCtx();if(!t)return;snap();const i=t.td?t.td.cellIndex:t.tb.rows[0].cells.length-1;[...t.tb.rows].forEach((r,k)=>{const c=document.createElement('td');c.contentEditable='true';c.textContent=k===0?'Judul':'';r.cells[Math.min(i,r.cells.length-1)].after(c);});changed();},
  'tr-'(){const t=tblCtx();if(!t)return;if(t.tb.rows.length<=1){toast('Tabel minimal 1 baris.');return;}snap();t.tr.remove();changed();},
  'tc-'(){const t=tblCtx();if(!t)return;if(t.tb.rows[0].cells.length<=1){toast('Tabel minimal 1 kolom.');return;}snap();const i=t.td?t.td.cellIndex:t.tb.rows[0].cells.length-1;[...t.tb.rows].forEach(r=>{if(r.cells[i])r.cells[i].remove();});changed();},
  middle(){if(!need())return;snap();const h=sel.getBoundingClientRect().height/scale;sel.style.top=Math.round((H-h)/2)+'px';changed();},
  exportjson(){grab();const b=new Blob([JSON.stringify({type:'cdms-ppt',v:1,deck},null,1)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=(String(deck.title||'presentasi').replace(/[^\w\- ]+/g,'').trim()||'presentasi')+'.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000);toast('File .json diunduh.');},
  importjson(){let f=$('#pptJsonInput');if(!f){f=document.createElement('input');f.type='file';f.id='pptJsonInput';f.accept='.json,application/json';f.hidden=true;document.body.appendChild(f);f.addEventListener('change',()=>{const file=f.files&&f.files[0];f.value='';if(!file)return;if(file.size>25e6){toast('File terlalu besar.');return;}const r=new FileReader();r.onload=()=>{try{const j=JSON.parse(r.result),d=j&&j.deck?j.deck:j;if(!d||!Array.isArray(d.slides)||!d.slides.length)throw 0;if(!confirm('Ganti presentasi sekarang dengan isi file?'))return;snap();deck={title:String(d.title||'Presentasi1').slice(0,80),num:!!d.num,trans:okTrans(d.trans),auto:okAuto(d.auto),slides:d.slides.slice(0,MAXS).map(s=>({notes:String(s.notes||'').slice(0,2000),bg:/^#[0-9a-f]{6}$/i.test(s.bg)?s.bg:'#ffffff',fg:/^#[0-9a-f]{6}$/i.test(s.fg)?s.fg:'#1f2430',html:safeHtml(s.html)}))};$('#pptTitle').value=deck.title;syncOpts();cur=-1;show(0);changed();toast('Presentasi dibuka.');}catch(_){toast('File tidak valid.');}};r.readAsText(file);});}f.click();},
  rotl(){rotate(-15);},rotr(){rotate(15);},rot0(){if(!need())return;snap();sel.style.transform='';changed();},
  delobj(){snap();if(!need())return;sel.remove();sel=null;changed();},
  themeall(){snap();grab();const c=deck.slides[cur];deck.slides.forEach(s=>{s.bg=c.bg;s.fg=c.fg;});show(cur);changed();toast('Tema diterapkan ke semua slide.');},
  num(){deck.num=!deck.num;const old=cur;cur=-1;show(old);changed();toast(deck.num?'Nomor slide ditampilkan.':'Nomor slide disembunyikan.');},
  notes(){const n=$('#pptNotes');n.classList.toggle('hidden');if(!n.classList.contains('hidden'))$('#pptNotesText').focus();fit();},
  present(){present(cur);},
  print(){printDeck();},
  sample(){if(!confirm('Ganti seluruh presentasi dengan contoh?'))return;snap();deck.slides=[
   {...mk('title','#185abd','#ffffff'),html:'<div class="ppt-ph ppt-t1" contenteditable="true" data-ph="Klik untuk judul">Presentasi Saya</div><div class="ppt-ph ppt-sub" contenteditable="true" data-ph="Klik untuk subjudul">Dibuat dengan CorelDraw Mobile Studio</div>'},
   {...mk('content'),html:'<div class="ppt-ph ppt-t2" contenteditable="true" data-ph="Judul slide">Poin Utama</div><div class="ppt-ph ppt-body" contenteditable="true" data-ph="Tulis isi di sini"><ul><li>Poin pertama</li><li>Poin kedua</li><li>Poin ketiga</li></ul></div>'},
   {...mk('two'),html:'<div class="ppt-ph ppt-t2" contenteditable="true" data-ph="Judul slide">Perbandingan</div><div class="ppt-cols"><div class="ppt-ph ppt-body" contenteditable="true" data-ph="Kolom kiri"><b>Sebelum</b><br>Proses manual</div><div class="ppt-ph ppt-body" contenteditable="true" data-ph="Kolom kanan"><b>Sesudah</b><br>Proses otomatis</div></div>'}];
   cur=-1;show(0);changed();}
 };
 $$('[data-ppt-act]').forEach(b=>b.addEventListener('click',()=>{const f=ACT[b.dataset.pptAct];if(f)f();}));
 $('#pptStroke').addEventListener('input',e=>{$('#pptStrokeBar').style.background=e.target.value;if(!sel||!sel.dataset.shape){toast('Pilih bentuk dulu.');return;}if(sel.style.clipPath){toast('Garis tepi tersedia untuk persegi, bulat, dan sudut bulat.');return;}sel.style.boxSizing='border-box';sel.style.border='4px solid '+e.target.value;changed();});
 $('#pptFill').addEventListener('input',e=>{$('#pptFillBar').style.background=e.target.value;if(sel&&sel.dataset.shape){sel.style.background=e.target.value;changed();}else toast('Pilih bentuk dulu.');});
 let bgSnap=0;$('#pptBg').addEventListener('change',()=>{bgSnap=0;});
 $('#pptBg').addEventListener('input',e=>{if(!bgSnap){snap();bgSnap=1;}const s=deck.slides[cur];s.bg=e.target.value;$('#pptBgBar').style.background=e.target.value;style(slide,s);changed();});
 $('#pptImgInput').addEventListener('change',e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(!/^image\//.test(f.type)||f.size>6*1024*1024){toast('Pilih gambar maksimum 6 MB.');return;}
  const fr=new FileReader();fr.onload=()=>{const img=new Image();img.onload=()=>{const k=Math.min(1,900/img.width),cv=document.createElement('canvas');cv.width=Math.round(img.width*k);cv.height=Math.round(img.height*k);cv.getContext('2d').drawImage(img,0,0,cv.width,cv.height);
   const w=Math.min(460,cv.width);place('<img alt="Gambar" src="'+cv.toDataURL(f.type==='image/png'?'image/png':'image/jpeg',.82)+'">',w);};img.onerror=()=>toast('Gambar tidak bisa dibuka.');img.src=fr.result;};fr.readAsDataURL(f);});
 const th=$('#pptThemes');THEMES.forEach(t=>{const b=document.createElement('button');b.className='ox-tool ppt-theme';b.textContent=t[0];b.style.background=t[1];b.style.color=t[2];b.setAttribute('aria-label','Tema '+t[1]);b.addEventListener('mousedown',e=>e.preventDefault());b.addEventListener('click',()=>{snap();const s=deck.slides[cur];s.bg=t[1];s.fg=t[2];style(slide,s);$('#pptBg').value=t[1];$('#pptBgBar').style.background=t[1];changed();});th.appendChild(b);});
 $('#pptNotesText').addEventListener('input',e=>{deck.slides[cur].notes=e.target.value;clearTimeout(saveT);saveT=setTimeout(save,800);});
 $('#pptTitle').addEventListener('input',e=>{deck.title=e.target.value.trim()||'Presentasi1';clearTimeout(saveT);saveT=setTimeout(save,600);});

 /* ---------- Tampilan layar penuh ---------- */

 let autoT=0,lastDir=1;
 function syncOpts(){const t=$('#pptTrans'),a=$('#pptAuto');if(t)t.value=deck.trans||'fade';if(a)a.value=String(deck.auto||0);}
 function transAnim(k){if(!showSlide.animate||deck.trans==='none')return;const sc0='scale('+k+')';let f;
  if(deck.trans==='slide')f=[{opacity:0,transform:'translateX('+(60*lastDir)+'px) '+sc0},{opacity:1,transform:sc0}];
  else if(deck.trans==='zoom')f=[{opacity:0,transform:'scale('+(k*.85)+')'},{opacity:1,transform:sc0}];
  else f=[{opacity:0},{opacity:1}];
  showSlide.animate(f,{duration:deck.trans==='fade'?260:340,easing:'ease-out'});}
 $('#pptTrans')?.addEventListener('change',e=>{snap();deck.trans=okTrans(e.target.value);changed();});
 $('#pptAuto')?.addEventListener('change',e=>{snap();deck.auto=okAuto(e.target.value);changed();toast(deck.auto?'Maju otomatis tiap '+deck.auto+' detik saat ▶ Tampilkan.':'Maju otomatis dimatikan.');});
 const show$=$('#pptShow'),showSlide=$('#pptShowSlide');let sc=0;
 function paintShow(){grab();const s=deck.slides[sc];showSlide.innerHTML=s.html+(deck.num?numEl(sc+1):'');showSlide.querySelectorAll('[contenteditable]').forEach(x=>x.removeAttribute('contenteditable'));style(showSlide,s);
  const k=Math.min(innerWidth/W,innerHeight/H);showSlide.style.transform='scale('+k+')';showSlide.style.left=(innerWidth-W*k)/2+'px';showSlide.style.top=(innerHeight-H*k)/2+'px';$('#pptShowNo').textContent=(sc+1)+' / '+deck.slides.length;transAnim(k);clearTimeout(autoT);if(deck.auto>0)autoT=setTimeout(()=>go(1),deck.auto*1000);}
 function present(i){sc=i;show$.classList.remove('hidden');paintShow();try{show$.requestFullscreen&&show$.requestFullscreen();}catch(_){}}
 function endShow(){clearTimeout(autoT);show$.classList.add('hidden');try{if(document.fullscreenElement)document.exitFullscreen();}catch(_){}}
 const go=d=>{lastDir=d<0?-1:1;const n=sc+d;if(n<0)return;if(n>=deck.slides.length){endShow();return;}sc=n;paintShow();};
 show$.addEventListener('click',e=>{if(e.target.id==='pptShowClose'){endShow();return;}go(e.clientX<innerWidth/3?-1:1);});
 document.addEventListener('keydown',e=>{if(show$.classList.contains('hidden')){if(!view.classList.contains('hidden')&&(e.ctrlKey||e.metaKey)&&!e.shiftKey&&(e.key==='z'||e.key==='Z')&&!e.target.closest('[contenteditable],textarea,input')){e.preventDefault();undo();}return;}if(e.key==='Escape')endShow();else if(e.key==='n'||e.key==='N'){const n=deck.slides[sc].notes;const no=$('#pptShowNo');no.textContent=n?n.slice(0,200):'Tidak ada catatan.';no.style.cssText='left:14px;font-size:16px;color:#fff';clearTimeout(endShow.t);endShow.t=setTimeout(()=>{no.style.cssText='';paintShow();},4000);}else if(['ArrowRight','ArrowDown',' ','PageDown','Enter'].includes(e.key)){e.preventDefault();go(1);}else if(['ArrowLeft','ArrowUp','PageUp'].includes(e.key)){e.preventDefault();go(-1);}});
 window.addEventListener('resize',()=>{if(!show$.classList.contains('hidden'))paintShow();});
 document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&!show$.classList.contains('hidden'))show$.classList.add('hidden');});
 let tx=0;show$.addEventListener('touchstart',e=>{tx=e.touches[0].clientX;},{passive:true});
 show$.addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-tx;if(Math.abs(dx)>60){e.preventDefault();go(dx<0?1:-1);}},{passive:false});

 /* ---------- Cetak / PDF ---------- */
 function printDeck(){
  grab();const pages=deck.slides.map((s,i)=>{const d=document.createElement('div');d.innerHTML=s.html;d.querySelectorAll('[contenteditable]').forEach(x=>x.removeAttribute('contenteditable'));d.querySelectorAll('.ppt-h,.ppt-rs').forEach(x=>x.remove());return '<div class="pg" style="background:'+s.bg+';color:'+s.fg+'"><div class="in">'+d.innerHTML+'</div>'+(deck.num?numEl(i+1):'')+'</div>';}).join('');
  const css='@page{size:960px 540px;margin:0}/*tbl*/*{box-sizing:border-box}body{margin:0}.pg{position:relative;width:960px;height:540px;overflow:hidden;page-break-after:always;font:28px/1.3 Calibri,Arial,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}.in{position:absolute;inset:0;padding:48px 64px}.ppt-ph{min-height:1em}.ppt-t1{font-size:64px;font-weight:700;text-align:center;margin-top:130px}.ppt-sub{font-size:32px;text-align:center;margin-top:14px}.ppt-t2{font-size:44px;font-weight:700;margin-bottom:22px}.ppt-body{font-size:30px}.ppt-body ul,.ppt-body ol{margin:6px 0;padding-left:34px}.ppt-cols{display:flex;gap:30px}.ppt-obj{position:absolute}.ppt-tbl{width:100%;border-collapse:collapse;table-layout:fixed;font-size:22px}.ppt-tbl td{border:1.5px solid currentColor;padding:6px 10px;vertical-align:top;word-break:break-word}.ppt-tbl tr:first-child td{background:rgba(47,127,209,.88);color:#fff;font-weight:700}.ppt-cols .ppt-body{flex:1}.ppt-num{position:absolute;right:24px;bottom:14px;font-size:20px;opacity:.6}.ppt-obj{position:absolute}.ppt-obj img{display:block;width:100%}.ppt-ot{padding:4px 8px;font-size:28px}';
  const f=document.createElement('iframe');f.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0';document.body.appendChild(f);const d=f.contentDocument;d.open();
  d.write('<!doctype html><html><head><meta charset="utf-8"><title>'+esc(deck.title)+'</title><style>'+css+'</style></head><body>'+pages+'</body></html>');d.close();
  setTimeout(()=>{try{f.contentWindow.focus();f.contentWindow.print();}catch(_){toast('Cetak tidak tersedia di perangkat ini.');}setTimeout(()=>f.remove(),4000);},400);
 }

 /* ---------- Buka / tutup ---------- */
 function open(){dash.classList.add('hidden');editor&&editor.classList.add('hidden');$('#excelMode')?.classList.add('hidden');$('#wordMode')?.classList.add('hidden');view.classList.remove('hidden');document.body.classList.add('office-open');$('#pptTitle').value=deck.title;syncOpts();cur=-1;show(0);}
 function home(){save();view.classList.add('hidden');document.body.classList.remove('office-open');dash.classList.remove('hidden');}
 document.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(!b)return;switch(b.dataset.action){case'pptMode':open();break;case'pptHome':home();break;case'home':if(!view.classList.contains('hidden'))home();break;}});
 load();
})();
