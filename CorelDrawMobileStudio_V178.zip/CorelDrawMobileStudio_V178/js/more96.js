/* V108: dua grup menu baru (helper bersama dari CDMS.Util97, tanpa kode duplikat).
   "Dokumen" (ikon doc108): Sertifikat, Kop Surat, Faktur (tabel + total), Struk (nota sempit).
   "Statistik & Media" (ikon media108): Statistik (kotak KPI), Pemutar (kartu musik), Obrolan (gelembung chat), Peringkat (papan peringkat).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U||!U.kv||!U.pill||!U.wrap||!U.poly||!U.seg||!U.kontras||!U.kartu)return;
const{ramp,grup,shape,text,line,finish,defHub,W,H,ask,tx,clamp,mkPal,kartu,seg,kontras,mix,poly,wrap,kv,ju,rt,t1,mx}=U,R=Math.round;
const PL=mkPal("pal108","senja"),pal=PL.pal,palMenu=PL.menu,pc=(P,t)=>ramp(P.c.slice(1),t);
/* angka dari "500000", "1.250.000", "Rp 50.000"; NaN bila bukan angka */
const num=v=>{const s=String(v).replace(/^rp\.?\s*/i,"").replace(/\./g,"").replace(",",".");return /^\d+(\.\d+)?$/.test(s)?parseFloat(s):NaN;};
const rp=v=>"Rp "+String(R(v)).replace(/\B(?=(\d{3})+(?!\d))/g,".");
const BUAT=(l,f,ic)=>()=>[palMenu(),{h:"Buat",items:[it(l,f,ic)]}];

/* ================= DOKUMEN ================= */
function sertifikat(){const q=ask("Sertifikat (Nama | Alasan | Tanggal):",S.srD108||"Budi Santoso | Juara 1 Lomba Desain | 20 November 2026");if(q===null)return;const p=q.split("|").map(v=>v.trim());if(p.length<2||!p[0]||!p[1])return T("Format: Nama | Alasan | Tanggal (tanggal boleh kosong)");S.srD108=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),cw=w*.94,ch=Math.min(h*.9,cw*.7),x=(w-cw)/2,y=(h-ch)/2,cx=w/2,gold="#b8860b",nm=p[0].slice(0,30),rs=p[1].slice(0,60),tg=(p[2]||"").slice(0,24),
  fT=R(clamp(cw*.07,10,60)),fN=R(clamp(Math.min(cw*.06,cw*.8/(nm.length*.6)),10,56)),fR=R(clamp(cw*.03,8,26)),m=cw*.02,
  out=[shape("rect",x,y,cw,ch,"#fffdf5",{name:"Kertas",rx:R(cw*.01),stroke:gold,strokeWidth:6}),shape("rect",x+m,y+m,cw-2*m,ch-2*m,"none",{name:"Bingkai dalam",stroke:pc(P,0),strokeWidth:3})];
 out.push(tx("SERTIFIKAT",cx,y+ch*.1,fT,pc(P,0),{name:"Judul",bold:true}),tx("diberikan kepada",cx,y+ch*.1+fT*1.5,fR,"#6b7280",{name:"Pengantar"}),tx(nm,cx,y+ch*.36,fN,"#1f2937",{name:"Nama",bold:true}),
  seg(cx-Math.max(nm.length*fN*.3,cw*.15),y+ch*.36+fN*1.4,cx+Math.max(nm.length*fN*.3,cw*.15),y+ch*.36+fN*1.4,gold,3,"Garis nama"));
 wrap(rs,Math.max(8,Math.floor(cw*.8/(fR*.6)))).slice(0,3).forEach((s,i)=>out.push(tx(s,cx,y+ch*.52+i*fR*1.4,fR,"#374151",{name:"Alasan "+(i+1)})));
 out.push(seg(x+cw*.12,y+ch*.84,x+cw*.36,y+ch*.84,"#6b7280",2,"Garis tanda tangan"),tx("Penyelenggara",x+cw*.24,y+ch*.86,fR*.8,"#6b7280",{name:"Penyelenggara"}));
 if(tg)out.push(tx(tg,cx+cw*.02,y+ch*.8,fR,"#374151",{name:"Tanggal"}));
 const mr=ch*.09,mxp=x+cw*.82,myp=y+ch*.76;out.push(shape("ellipse",mxp-mr,myp-mr,mr*2,mr*2,gold,{name:"Medali",stroke:"#fde68a",strokeWidth:4}),shape("star",mxp-mr*.55,myp-mr*.55,mr*1.1,mr*1.1,"#fffdf5",{name:"Bintang medali"}));
 finish(grup(out,"Sertifikat"),"Sertifikat untuk "+nm);}
MENUS.srt108=BUAT("Buat sertifikat…",sertifikat,"cert108");

function kop(){const q=ask("Kop (Nama | Alamat | Kontak):",S.kpD108||"PT Maju Jaya | Jl. Merdeka No. 10, Jakarta | 0812-3456-7890");if(q===null)return;const p=q.split("|").map(v=>v.trim());if(!p[0])return T("Format: Nama | Alamat | Kontak");S.kpD108=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),mg=w*.06,ld=Math.min(w*.14,h*.1),y=h*.05,lx=mg+ld+w*.025,nm=p[0].slice(0,34),f1=R(clamp(Math.min(w*.04,(w-lx-mg)/(nm.length*.6)),9,44)),f2=R(clamp(w*.02,7,22)),col=pc(P,0),out=[];
 out.push(shape("ellipse",mg,y,ld,ld,col,{name:"Logo"}),tx(nm[0].toUpperCase(),mg+ld/2,y+ld/2-ld*.3,ld*.55,kontras(col),{name:"Inisial",bold:true}),text(nm,lx,y+ld*.06,f1,"#1f2937",{name:"Nama usaha",bold:true}));
 let yy=y+ld*.06+f1*1.4;[p[1],p[2]].filter(Boolean).forEach((s,i)=>{out.push(text(s.slice(0,70),lx,yy,f2,"#4b5563",{name:i?"Kontak":"Alamat"}));yy+=f2*1.4;});
 const ly=Math.max(y+ld,yy)+f2*.8;out.push(seg(mg,ly,w-mg,ly,col,Math.max(4,R(w*.006)),"Garis tebal"),seg(mg,ly+w*.012,w-mg,ly+w*.012,pc(P,.6),2,"Garis tipis"));
 finish(grup(out,"Kop surat"),"Kop surat "+nm+" dipasang di atas halaman");}
MENUS.kop108=BUAT("Pasang kop surat…",kop,"letter108");

function faktur(){const q=ask("Item (Nama:harga angka, 2-6 item):",S.fkD108||"Desain Logo:500000, Poster:250000, Revisi:100000");if(q===null)return;const d=kv(q,2,6,16,12);if(!d)return T("Format: Desain Logo:500000, Poster:250000 (2-6 item)");const v=d.map(a=>num(a[1]));if(v.some(isNaN))return T("Harga harus angka, mis. 250000 atau 250.000");S.fkD108=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=d.length,cw=Math.min(w*.9,h*.8),pd=cw*.06;let fs=R(clamp(cw*.04,8,24));fs=Math.min(fs,(h*.9-2*pd)/(3.4+(n+2)*2.4));
 const hh=fs*3.4,ch=hh+(n+2)*fs*2.4+pd,x=(w-cw)/2,y=(h-ch)/2,col=pc(P,0),tot=v.reduce((a,b)=>a+b,0),out=[kartu(x,y,cw,ch,cw*.03),shape("rect",x,y,cw,hh,col,{name:"Kepala",rx:R(cw*.03)}),text("FAKTUR",x+pd,y+hh/2-fs*.8,fs*1.6,kontras(col),{name:"Judul",bold:true})];
 const y0=y+hh+fs*.6;out.push(text("No",x+pd,y0,fs*.85,"#6b7280",{name:"Kepala No"}),text("Item",x+pd+fs*3,y0,fs*.85,"#6b7280",{name:"Kepala Item"}),rt("Harga",x+cw-pd,y0,fs*.85,"#6b7280",{name:"Kepala Harga"}));
 d.forEach((s,i)=>{const yy=y0+fs*2+i*fs*2.4;if(i%2===0)out.push(shape("rect",x+pd*.5,yy-fs*.5,cw-pd,fs*2.2,mix(col,"#ffffff",.9),{name:"Pita baris "+(i+1),rx:R(fs*.3)}));
  out.push(text(String(i+1),x+pd,yy,fs,"#6b7280",{name:"No "+(i+1)}),text(s[0],x+pd+fs*3,yy,fs,"#1f2937",{name:"Item "+(i+1)}),rt(rp(v[i]),x+cw-pd,yy,fs,"#1f2937",{name:"Harga "+(i+1)}));});
 const ty=y0+fs*2+n*fs*2.4+fs*.3;out.push(seg(x+pd,ty-fs*.4,x+cw-pd,ty-fs*.4,"#9ca3af",2,"Garis total"),text("TOTAL",x+pd,ty+fs*.3,fs*1.1,"#1f2937",{name:"Label total",bold:true}),rt(rp(tot),x+cw-pd,ty+fs*.3,fs*1.1,col,{name:"Total",bold:true}));
 finish(grup(out,"Faktur"),"Faktur "+n+" item, total "+rp(tot));}
MENUS.fkt108=BUAT("Buat faktur…",faktur,"invoice108");

function struk(){const q=ask("Struk (Toko | Item:harga angka, 2-8 item):",S.stD108||"Warung Sari | Nasi Goreng:25000, Es Teh:8000, Kerupuk:3000");if(q===null)return;const[t0,b]=ju(q),d=kv(b,2,8,14,10);if(!d)return T("Format: Toko | Nasi:25000, Es Teh:8000 (2-8 item)");const v=d.map(a=>num(a[1]));if(v.some(isNaN))return T("Harga harus angka, mis. 25000 atau 25.000");S.stD108=q;Hi.snapshot();
 const w=W(),h=H(),n=d.length,cw=Math.min(w*.62,h*.5),pd=cw*.08;let fs=R(clamp(cw*.055,8,22));fs=Math.min(fs,(h*.92-2*pd)/((n+7)*1.5));
 const ch=pd*2+(n+7)*fs*1.5,x=(w-cw)/2,y=(h-ch)/2,cx=w/2,dash=text("-".repeat(Math.floor((cw-2*pd)/(fs*.6))),0,0,fs,"#9ca3af").text,tot=v.reduce((a,b)=>a+b,0),out=[shape("rect",x,y,cw,ch,"#ffffff",{name:"Kertas struk",stroke:"#e5e7eb",strokeWidth:2})];
 let yy=y+pd;out.push(tx(t0||"TOKO",cx,yy,fs*1.3,"#111827",{name:"Nama toko",bold:true}));yy+=fs*2;out.push(tx("STRUK PEMBELIAN",cx,yy,fs*.8,"#6b7280",{name:"Judul"}));yy+=fs*1.5;out.push(text(dash,x+pd,yy,fs,"#9ca3af",{name:"Garis putus atas"}));yy+=fs*1.5;
 d.forEach((s,i)=>{out.push(text(s[0],x+pd,yy,fs,"#1f2937",{name:"Item "+(i+1)}),rt(rp(v[i]),x+cw-pd,yy,fs,"#1f2937",{name:"Harga "+(i+1)}));yy+=fs*1.5;});
 out.push(text(dash,x+pd,yy,fs,"#9ca3af",{name:"Garis putus bawah"}));yy+=fs*1.5;out.push(text("TOTAL",x+pd,yy,fs*1.1,"#111827",{name:"Label total",bold:true}),rt(rp(tot),x+cw-pd,yy,fs*1.1,"#111827",{name:"Total",bold:true}));yy+=fs*2.2;out.push(tx("Terima kasih!",cx,yy,fs,"#6b7280",{name:"Penutup"}));
 finish(grup(out,"Struk"),"Struk "+n+" item, total "+rp(tot));}
MENUS.stk108=()=>[{h:"Buat",items:[it("Buat struk belanja…",struk,"receipt108")]}];

/* ================= STATISTIK & MEDIA ================= */
function statistik(){const q=ask("Statistik (Label:nilai, 2-4 item; desimal pakai titik):",S.sbD108||"Pengguna:12.5k, Unduhan:48k, Rating:4.8");if(q===null)return;const d=kv(q,2,4,14,8);if(!d)return T("Format: Pengguna:12.5k, Unduhan:48k (2-4 item)");S.sbD108=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=d.length,cols=n===4?2:n,rows=n===4?2:1,g=w*.025,tw=Math.min((w*.92-(cols-1)*g)/cols,(h*.9-(rows-1)*g)/rows/.7),th=tw*.7,x0=(w-(cols*tw+(cols-1)*g))/2,y0=(h-(rows*th+(rows-1)*g))/2,out=[];
 d.forEach((s,i)=>{const x=x0+(i%cols)*(tw+g),y=y0+Math.floor(i/cols)*(th+g),col=pc(P,t1(n,i)),fv=R(clamp(Math.min(tw*.8/(s[1].length*.6),th*.34),9,72)),fl=R(clamp(Math.min(tw*.8/(s[0].length*.6),th*.12),7,26));
  out.push(shape("rect",x,y,tw,th,"#ffffff",{name:"Kotak "+s[0],rx:R(tw*.06),stroke:"#e5e7eb",strokeWidth:2}),shape("rect",x,y,tw,th*.07,col,{name:"Garis atas "+(i+1),rx:R(tw*.03)}),tx(s[1],x+tw/2,y+th*.3,fv,col,{name:"Nilai "+(i+1),bold:true}),tx(s[0],x+tw/2,y+th*.68,fl,"#6b7280",{name:"Label "+(i+1)}));});
 finish(grup(out,"Statistik"),n+" kotak statistik");}
MENUS.sta108=BUAT("Buat kotak statistik…",statistik,"stat108");

function pemutar(){const q=ask("Pemutar (Judul | Artis | persen 0-100):",S.pmD108||"Senja di Kota | Nadia Rahma | 40");if(q===null)return;const p=q.split("|").map(v=>v.trim());if(!p[0])return T("Format: Judul | Artis | persen");S.pmD108=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),pr=clamp(parseFloat(p[2])||0,0,100),cw=Math.min(w*.92,h*.7*1.4),ch=cw*.6,x=(w-cw)/2,y=(h-ch)/2,pd=cw*.05,cs=ch*.42,tx0=x+pd*2+cs,ft=R(clamp(Math.min(cw*.05,(cw-cs-pd*3)/((p[0].length||1)*.6)),8,34)),fa=R(clamp(ft*.7,7,24)),c0=pc(P,0),c1=pc(P,1),
  out=[shape("rect",x,y,cw,ch,"#111827",{name:"Kartu pemutar",rx:R(cw*.04)}),shape("rect",x+pd,y+pd,cs,cs,c0,{name:"Sampul",rx:R(cs*.1)}),shape("ellipse",x+pd+cs*.15,y+pd+cs*.15,cs*.7,cs*.7,c1,{name:"Piringan"}),shape("ellipse",x+pd+cs*.42,y+pd+cs*.42,cs*.16,cs*.16,"#111827",{name:"Pusat piringan"})];
 out.push(text(p[0].slice(0,30),tx0,y+pd+cs*.2,ft,"#ffffff",{name:"Judul lagu",bold:true}));if(p[1])out.push(text(p[1].slice(0,30),tx0,y+pd+cs*.2+ft*1.5,fa,"#9ca3af",{name:"Artis"}));
 const tx1=x+pd,tw=cw-2*pd,ty=y+ch*.64,th=Math.max(4,ch*.025);out.push(shape("rect",tx1,ty,tw,th,"#374151",{name:"Jalur",rx:R(th/2)}));if(pr>0)out.push(shape("rect",tx1,ty,Math.max(th,tw*pr/100),th,c0,{name:"Progres",rx:R(th/2)}));
 const kr=th*1.5;out.push(shape("ellipse",tx1+tw*pr/100-kr,ty+th/2-kr,kr*2,kr*2,"#ffffff",{name:"Kenop"}));
 const cy=y+ch*.83,r=ch*.09,tz=r*.5,cx=x+cw/2;
 out.push(shape("ellipse",cx-r,cy-r,r*2,r*2,c0,{name:"Tombol putar"}),poly([[cx-tz*.5,cy-tz],[cx-tz*.5,cy+tz],[cx+tz,cy]],kontras(c0),"Ikon putar"));
 [-1,1].forEach((k,i)=>{const bx=cx+k*r*2.6;out.push(poly([[bx+k*tz*.9,cy-tz*.9],[bx+k*tz*.9,cy+tz*.9],[bx-k*tz*.3,cy]],"#ffffff",(i?"Lanjut":"Kembali")+" 1"),poly([[bx+k*tz*.1+k*tz*.9,cy-tz*.9],[bx+k*tz*.1+k*tz*.9,cy+tz*.9],[bx-k*tz*.3+k*tz*.9,cy]],"#ffffff",(i?"Lanjut":"Kembali")+" 2"));});
 finish(grup(out,"Pemutar musik"),"Pemutar musik \""+p[0]+"\" ("+R(pr)+"%)");}
MENUS.pmt108=BUAT("Buat kartu pemutar musik…",pemutar,"player108");

function obrolan(){const q=ask("Pesan (pisah dengan ;  awali > untuk pesan kanan; 2-5):",S.obD108||"Halo, desainnya sudah selesai? ; > Sudah, tinggal revisi kecil ; Oke, saya tunggu ya");if(q===null)return;const m=q.split(/[;\n]+/).map(s=>s.trim()).filter(Boolean).map(s=>s[0]===">"?[1,s.slice(1).trim().slice(0,60)]:[0,s.slice(0,60)]).filter(s=>s[1]);if(m.length<2||m.length>5)return T("Isi 2-5 pesan dipisah titik koma");S.obD108=q;Hi.snapshot();
 const P=pal(),w=W(),h=H(),cw=Math.min(w*.9,h*.55),pd=cw*.05;let fs=R(clamp(cw*.045,8,24));const lay=()=>{const mc=Math.max(8,Math.floor(cw*.62/(fs*.6)));return m.map(s=>{const L=wrap(s[1],mc),bw=Math.min(mx(L)*fs*.6+fs*1.6,cw*.72),bh=L.length*fs*1.35+fs*1.1;return{k:s[0],L,bw,bh};});};
 let B=lay(),tot=()=>B.reduce((a,b)=>a+b.bh+fs*.9,0)+2*pd;while(tot()>h*.92&&fs>7){fs--;B=lay();}
 const ch=tot(),x=(w-cw)/2,y=(h-ch)/2,out=[kartu(x,y,cw,ch,cw*.04)],col=pc(P,0);let yy=y+pd;
 B.forEach((b,i)=>{const bx=b.k?x+cw-pd-b.bw:x+pd,bc=b.k?col:"#e5e7eb",tc2=b.k?kontras(col):"#1f2937";out.push(shape("rect",bx,yy,b.bw,b.bh,bc,{name:"Gelembung "+(i+1),rx:R(fs*.9)}));
  b.L.forEach((s,j)=>out.push(text(s,bx+fs*.8,yy+fs*.55+j*fs*1.35,fs,tc2,{name:"Pesan "+(i+1)+"."+(j+1)})));yy+=b.bh+fs*.9;});
 finish(grup(out,"Obrolan"),m.length+" gelembung obrolan");}
MENUS.obr108=BUAT("Buat gelembung obrolan…",obrolan,"chat108");

function peringkat(){const q=ask("Peringkat (Nama:skor angka, 3-6 item):",S.pkD108||"Andi:980, Sari:850, Budi:720, Dewi:600");if(q===null)return;const d=kv(q,3,6,14,8);if(!d)return T("Format: Andi:980, Sari:850, Budi:720 (3-6 item)");const v=d.map(a=>({n:a[0],v:num(a[1]),s:a[1]}));if(v.some(a=>isNaN(a.v)))return T("Skor harus angka");S.pkD108=q;Hi.snapshot();
 v.sort((a,b)=>b.v-a.v);const P=pal(),w=W(),h=H(),n=v.length,cw=Math.min(w*.92,h*.85*1.3),pd=cw*.05;let fs=R(clamp(cw*.04,8,24));fs=Math.min(fs,(h*.92-2*pd)/(n*2.6));
 const rh=fs*2.6,ch=n*rh+pd*2,x=(w-cw)/2,y=(h-ch)/2,mxv=v[0].v||1,nw=mx(v.map(a=>a.n))*fs*.6+fs,vw=mx(v.map(a=>a.s))*fs*.6+fs,bx=x+pd+fs*3+nw,bl=Math.max(10,cw-2*pd-fs*3-nw-vw),RC=["#f59e0b","#9ca3af","#b45309"],out=[kartu(x,y,cw,ch,cw*.03)];
 v.forEach((a,i)=>{const cy=y+pd+i*rh+rh/2,rc=RC[i]||pc(P,.5),col=pc(P,t1(n,i)),r=fs*.95;
  out.push(shape("ellipse",x+pd,cy-r,r*2,r*2,rc,{name:"Peringkat "+(i+1)}),tx(String(i+1),x+pd+r,cy-fs*.6,fs,"#ffffff",{name:"Nomor "+(i+1),bold:true}),text(a.n,x+pd+fs*3,cy-fs*.6,fs,"#1f2937",{name:"Nama "+(i+1),bold:true}),
   shape("rect",bx,cy-fs*.35,bl,fs*.7,"#e5e7eb",{name:"Jalur "+(i+1),rx:R(fs*.35)}),shape("rect",bx,cy-fs*.35,Math.max(fs*.7,bl*a.v/mxv),fs*.7,col,{name:"Isi "+(i+1),rx:R(fs*.35)}),rt(a.s,x+cw-pd,cy-fs*.6,fs,"#374151",{name:"Skor "+(i+1),bold:true}));});
 finish(grup(out,"Peringkat"),"Papan peringkat "+n+" peserta");}
MENUS.prn108=BUAT("Buat papan peringkat…",peringkat,"rank108");

/* ================= tombol & grup ================= */
BT.push(["srt108","cert108","Sertifikat"],["kop108","letter108","Kop Surat"],["fkt108","invoice108","Faktur"],["stk108","receipt108","Struk"],["sta108","stat108","Statistik"],["pmt108","player108","Pemutar"],["obr108","chat108","Obrolan"],["prn108","rank108","Peringkat"]);
defHub("dokumen108","doc108","Dokumen",["srt108","kop108","fkt108","stk108"]);
defHub("media108","media108","Statistik & Media",["sta108","pmt108","obr108","prn108"]);
CDMS.Dokumen108={sertifikat,kop,faktur,struk,statistik,pemutar,obrolan,peringkat};
})();
