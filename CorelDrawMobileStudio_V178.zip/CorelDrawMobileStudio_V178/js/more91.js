/* V103: dua grup menu baru (helper bersama dari CDMS.Util97, tanpa kode duplikat).
   "Sosmed" (ikon social103): Sampul (judul + subjudul, gaya Bulat / Blok), Profil (kartu avatar + nama + tombol Ikuti), Tag (pil #tag yang turun baris otomatis).
   "Perangkat" (ikon device103): Ponsel (bingkai ponsel + teks layar), Jendela (jendela browser terang / gelap), Laptop (layar + alas).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U||!U.kontras||!U.mkPal)return;
const{ramp,grup,shape,text,line,finish,defHub,W,H,poly,ask,wrap,idx,tx,clamp,mkPal,kontras,daftar}=U,R=Math.round;
const PL=mkPal("pal103","laut"),pal=PL.pal,palMenu=PL.menu,pc=(P,t)=>ramp(P.c.slice(1),t);
const bagi=q=>{const[a,b]=String(q).split("|");return[(a||"").trim(),(b||"").trim()];};
const inisial=s=>(s.match(/[\p{L}\p{N}]/u)||["?"])[0].toUpperCase();

/* ================= SOSMED ================= */
const CG=[["Bulat","o"],["Blok","b"]];
function sampul(){const q=ask("Judul | Subjudul (judul maks 40 huruf):","Tips Desain Cepat | 5 langkah mudah");if(q===null)return;const[a,b]=bagi(q),t=a.slice(0,40),sb=b.slice(0,50);if(!t)return T("Judul kosong");Hi.snapshot();
 const P=pal(),w=W(),h=H(),st=S.cvG103||"o",bg=pc(P,.15),ac=pc(P,.85),fg=kontras(bg),m=Math.min(w,h),out=[shape("rect",0,0,w,h,bg,{name:"Latar"})];
 if(st==="o"){const d1=m*.4,d2=m*.28;out.push(shape("ellipse",w-d1-w*.06,h*.06,d1,d1,ac,{name:"Lingkaran 1",opacity:30}),shape("ellipse",w*.06,h-d2-h*.06,d2,d2,ac,{name:"Lingkaran 2",opacity:22}));}
 else out.push(shape("rect",0,h*.76,w,h*.24,ac,{name:"Blok"}),shape("rect",w*.1,h*.06,w*.04,h*.07,ac,{name:"Penanda"}));
 let fs=m*.09,Ls;for(let k=0;k<12;k++){Ls=wrap(t,Math.max(6,Math.floor(w*.78/(fs*.6))));if((Ls.length<=4&&Ls.length*fs*1.2<=h*.4)||fs<=10)break;fs*=.88;}
 fs=R(Math.max(10,fs));const tot=Ls.length*fs*1.2+(sb?fs*.9:0),y0=((st==="b"?h*.76:h)-tot)/2;
 out.push(shape("rect",w*.1,y0-fs*.7,w*.12,Math.max(4,fs*.14),ac,{name:"Garis aksen"}));
 Ls.forEach((s,i)=>out.push(text(s,w*.1,y0+i*fs*1.2,fs,fg,{name:"Judul "+(i+1),bold:true})));
 if(sb)out.push(text(sb,w*.1,y0+Ls.length*fs*1.2+fs*.3,R(Math.max(8,fs*.45)),fg,{name:"Subjudul",opacity:80}));
 finish(grup(out,"Sampul"),"Sampul gaya "+CG.find(x=>x[1]===st)[0].toLowerCase()+" dipasang");}
MENUS.cov103=()=>[palMenu(),{h:"Gaya",items:CG.map(x=>tc(x[0],()=>{S.cvG103=x[1];},{keep:1,on:(S.cvG103||"o")===x[1]}))},{h:"Buat",items:[it("Buat sampul (mengisi halaman)…",sampul,"cover103")]}];

function profil(){const q=ask("Nama | @akun (nama maks 20 huruf):","Rina Pratama | @rinadesain");if(q===null)return;const[a,b]=bagi(q),nm=a.slice(0,20),hd=b.slice(0,20);if(!nm)return T("Nama kosong");Hi.snapshot();
 const P=pal(),w=W(),h=H(),cw=Math.min(w*.8,h*.6),ch=cw*1.1,x=(w-cw)/2,y=(h-ch)/2,r=cw*.2,cx=w/2,ay=y+r*.4,col=pc(P,.3),ac=pc(P,.85),fn=R(clamp(Math.min(cw*.09,cw*.8/(Math.max(nm.length,6)*.6)),9,40)),fi=R(Math.max(24,r*1.1)),
  out=[shape("rect",x,y,cw,ch,"#ffffff",{name:"Kartu",rx:R(cw*.06),stroke:"#e5e7eb",strokeWidth:2}),
   shape("ellipse",cx-r-4,ay+r*.2-4,r*2+8,r*2+8,"#ffffff",{name:"Cincin",stroke:ac,strokeWidth:4}),
   shape("ellipse",cx-r,ay+r*.2,r*2,r*2,col,{name:"Avatar"}),tx(inisial(nm),cx,ay+r*1.2-fi*.6,fi,kontras(col),{name:"Inisial",bold:true}),
   tx(nm,cx,ay+r*2.6,fn,"#111827",{name:"Nama",bold:true})];
 if(hd)out.push(tx(hd,cx,ay+r*2.6+fn*1.4,R(fn*.75),"#6b7280",{name:"Akun"}));
 const bw=cw*.5,bh=fn*2,by=y+ch-bh-cw*.08,tb="Ikuti";out.push(shape("rect",cx-bw/2,by,bw,bh,ac,{name:"Tombol",rx:R(bh/2)}),tx(tb,cx,by+bh/2-fn*.55,fn,kontras(ac),{name:"Teks tombol",bold:true}));
 finish(grup(out,"Profil"),"Kartu profil dipasang");}
MENUS.prf103=()=>[palMenu(),{h:"Buat",items:[it("Buat kartu profil…",profil,"profile103")]}];

function tag(){const q=ask("Tag (pisahkan koma; 2-8, tanpa tanda #):","desain,kreatif,ilustrasi,vektor,belajar");if(q===null)return;const D=daftar(q.replace(/#/g,""),8);if(D.length<2)return T("Butuh minimal 2 tag");Hi.snapshot();
 const P=pal(),w=W(),h=H(),fs=clamp(Math.min(w,h)*.04,9,30),ph=fs*2,gap=fs*.5,maxW=w*.84,rows=[];let cur=[],cw=0;
 const pw=s=>(s.length+1)*fs*.6+fs*1.6;
 D.forEach((s,i)=>{const ww=pw(s);if(cur.length&&cw+gap+ww>maxW){rows.push({it:cur,w:cw});cur=[];cw=0;}cur.push([s,i,ww]);cw+=(cur.length>1?gap:0)+ww;});rows.push({it:cur,w:cw});
 const th=rows.length*ph+(rows.length-1)*gap,y0=(h-th)/2,out=[];
 rows.forEach((r,ri)=>{let x=(w-r.w)/2;r.it.forEach(([s,i,ww])=>{const col=pc(P,D.length>1?i/(D.length-1):0);
  out.push(shape("rect",x,y0+ri*(ph+gap),ww,ph,col,{name:"Pil "+(i+1),rx:R(ph/2)}),tx("#"+s,x+ww/2,y0+ri*(ph+gap)+ph/2-fs*.55,R(fs),kontras(col),{name:"Tag "+(i+1),bold:true}));x+=ww+gap;});});
 finish(grup(out,"Tag"),D.length+" tag dipasang");}
MENUS.tag103=()=>[palMenu(),{h:"Buat",items:[it("Buat pil #tag dari daftar…",tag,"tag103")]}];

/* ================= PERANGKAT ================= */
const gelapMenu=(key)=>({h:"Layar",items:[["Warna palet","p"],["Putih","w"],["Hitam","k"]].map(x=>tc(x[0],()=>{S[key]=x[1];},{keep:1,on:(S[key]||"p")===x[1]}))});
const layar=(key,P)=>{const v=S[key]||"p";return v==="w"?"#ffffff":v==="k"?"#0b1020":pc(P,.35);};
const isi=(s,cx,y0,wMax,fs0,fg,out)=>{if(!s)return;let fs=fs0,L;for(let k=0;k<8;k++){L=wrap(s,Math.max(6,Math.floor(wMax/(fs*.6))));if(L.length*fs*1.3<=fs0*8||fs<=8)break;fs*=.88;}
 fs=R(Math.max(8,fs));L.forEach((t,i)=>out.push(tx(t,cx,y0+i*fs*1.3,fs,fg,{name:"Teks layar "+(i+1),bold:true})));};

function ponsel(){const q=ask("Teks layar (boleh kosong, maks 40 huruf):","Aplikasi Baru");if(q===null)return;const t=q.slice(0,40);Hi.snapshot();
 const P=pal(),w=W(),h=H(),pw=Math.min(w*.7,h*.86*9/19),ph=pw*19/9,x=(w-pw)/2,y=(h-ph)/2,b=pw*.045,sc=layar("pnS103",P),fg=kontras(sc),out=[
  shape("rect",x,y,pw,ph,"#111827",{name:"Badan",rx:R(pw*.14)}),shape("rect",x+pw,y+ph*.2,Math.max(3,pw*.014),ph*.07,"#111827",{name:"Tombol daya"}),shape("rect",x-Math.max(3,pw*.014),y+ph*.16,Math.max(3,pw*.014),ph*.05,"#111827",{name:"Tombol volume"}),
  shape("rect",x+b,y+b,pw-2*b,ph-2*b,sc,{name:"Layar",rx:R(pw*.1)}),shape("rect",x+pw*.35,y+b*1.7,pw*.3,b*1.1,"#111827",{name:"Poni",rx:R(b*.55)}),
  shape("rect",x+pw*.36,y+ph-b*2.6,pw*.28,Math.max(3,b*.5),fg,{name:"Garis beranda",rx:R(b*.25),opacity:70})];
 isi(t,w/2,y+ph*.42,pw*.78,pw*.11,fg,out);
 finish(grup(out,"Ponsel"),"Bingkai ponsel dipasang");}
MENUS.phn103=()=>[palMenu(),gelapMenu("pnS103"),{h:"Buat",items:[it("Pasang bingkai ponsel di tengah…",ponsel,"phone103")]}];

function jendela(){const q=ask("Judul halaman | alamat (judul maks 30 huruf):","Beranda Saya | contoh.com");if(q===null)return;const[a,b]=bagi(q),t=a.slice(0,30),ad=b.slice(0,24);Hi.snapshot();
 const P=pal(),w=W(),h=H(),dk=(S.wnT103||"t")==="g",ww=w*.86,wh=Math.min(h*.7,ww*.65),x=(w-ww)/2,y=(h-wh)/2,bh=wh*.13,bg=dk?"#111827":"#ffffff",bar=dk?"#1f2937":"#e5e7eb",fg=dk?"#f9fafb":"#111827",gr=dk?"#374151":"#d1d5db",ac=pc(P,.6),r=bh*.14,fs=R(clamp(Math.min(ww*.06,wh*.1),9,40)),
  out=[shape("rect",x,y,ww,wh,bg,{name:"Jendela",rx:R(bh*.35),stroke:gr,strokeWidth:2}),shape("rect",x,y,ww,bh,bar,{name:"Bilah judul",rx:R(bh*.35)}),shape("rect",x,y+bh*.6,ww,bh*.4,bar,{name:"Bilah rapat"})];
 ["#ef4444","#f59e0b","#22c55e"].forEach((c,i)=>out.push(shape("ellipse",x+bh*.45+i*r*3,y+bh/2-r,r*2,r*2,c,{name:"Tombol "+(i+1)})));
 const aw=ww*.55,ax=x+ww*.3;out.push(shape("rect",ax,y+bh*.2,aw,bh*.6,bg,{name:"Kolom alamat",rx:R(bh*.3)}));
 if(ad)out.push(text(ad,ax+bh*.3,y+bh/2-R(bh*.28)*.6,R(bh*.28),dk?"#9ca3af":"#6b7280",{name:"Alamat"}));
 if(t)out.push(text(t,x+ww*.08,y+bh+wh*.1,fs,fg,{name:"Judul halaman",bold:true}));
 out.push(shape("rect",x+ww*.08,y+bh+wh*.1+fs*1.6,ww*.5,Math.max(5,wh*.025),ac,{name:"Garis aksen",rx:3}));
 for(let i=0;i<3;i++)out.push(shape("rect",x+ww*.08,y+bh+wh*.1+fs*2.6+i*wh*.07,ww*(.84-i*.14),Math.max(4,wh*.03),gr,{name:"Baris isi "+(i+1),rx:3}));
 finish(grup(out,"Jendela browser"),"Jendela browser dipasang");}
MENUS.win103=()=>[palMenu(),{h:"Tema",items:[["Terang","t"],["Gelap","g"]].map(x=>tc(x[0],()=>{S.wnT103=x[1];},{keep:1,on:(S.wnT103||"t")===x[1]}))},{h:"Buat",items:[it("Pasang jendela browser di tengah…",jendela,"window103")]}];

function laptop(){const q=ask("Teks layar (boleh kosong, maks 40 huruf):","Proyek Baru");if(q===null)return;const t=q.slice(0,40);Hi.snapshot();
 const P=pal(),w=W(),h=H(),lw=Math.min(w*.8,h*.6*1.6),lh=lw*.62,bw=lw*1.14,bh=lh*.07,x=(w-lw)/2,y=(h-lh-bh)/2,b=lw*.025,sc=layar("lpS103",P),fg=kontras(sc),
  out=[shape("rect",x,y,lw,lh,"#1f2937",{name:"Tutup",rx:R(lw*.025)}),shape("rect",x+b,y+b,lw-2*b,lh-2*b,sc,{name:"Layar",rx:R(lw*.012)}),shape("ellipse",w/2-b*.35,y+b*.35,b*.7,b*.7,"#374151",{name:"Kamera"}),
   poly([[w/2-bw/2,y+lh],[w/2+bw/2,y+lh],[w/2+bw/2-bw*.02,y+lh+bh],[w/2-bw/2+bw*.02,y+lh+bh]],"#9ca3af","Alas"),shape("rect",w/2-lw*.09,y+lh,lw*.18,bh*.45,"#6b7280",{name:"Takik",rx:R(bh*.2)})];
 isi(t,w/2,y+lh*.4,lw*.7,lw*.06,fg,out);
 finish(grup(out,"Laptop"),"Bingkai laptop dipasang");}
MENUS.lap103=()=>[palMenu(),gelapMenu("lpS103"),{h:"Buat",items:[it("Pasang bingkai laptop di tengah…",laptop,"laptop103")]}];

/* ================= tombol & grup ================= */
BT.push(["cov103","cover103","Sampul"],["prf103","profile103","Profil"],["tag103","tag103","Tag"],["phn103","phone103","Ponsel"],["win103","window103","Jendela"],["lap103","laptop103","Laptop"]);
defHub("sosmed103","social103","Sosmed",["cov103","prf103","tag103"]);
defHub("perangkat103","device103","Perangkat",["phn103","win103","lap103"]);
Object.assign(U,{bagi});
CDMS.Sosmed103={sampul,profil,tag,ponsel,jendela,laptop};
})();
