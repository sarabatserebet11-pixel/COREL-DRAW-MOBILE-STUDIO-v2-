/* V98: dua grup menu baru (memakai helper bersama CDMS.Util97 dari more85.js, tanpa kode duplikat).
   "Bingkai Hias" (ikon frame98): Bingkai (tunggal, ganda, sudut potong, sudut bulat, putus), Sudut Hias (siku, lengkung, kuncup), Lencana (segel bergerigi + teks + bintang).
   "Pola Latar" (ikon bgpat98): Garis Miring (strip 2 warna, 4 arah, dipotong rapi di tepi halaman), Halftone (titik berubah ukuran + warna), Segitiga (mozaik low-poly bergradasi).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U)return;
const{mix,ramp,grup,shape,text,path,finish,rnd,PAL,defHub,W,H}=U,R=Math.round;

/* poligon bebas -> objek path berkotak pas (koordinat lokal) */
const poly=(P,fill,name,x2)=>{const xs=P.map(p=>p[0]),ys=P.map(p=>p[1]),x0=Math.floor(Math.min(...xs)),y0=Math.floor(Math.min(...ys)),
 w=Math.max(1,Math.ceil(Math.max(...xs))-x0),h=Math.max(1,Math.ceil(Math.max(...ys))-y0),
 d=P.map((p,i)=>(i?"L":"M")+R((p[0]-x0)*10)/10+" "+R((p[1]-y0)*10)/10).join("")+"Z";
 return path(x0,y0,w,h,w,h,d,fill,"none",0,{name,...x2});};
/* potong poligon cembung ke persegi halaman (Sutherland–Hodgman) */
const clip=(P,w,h)=>{[p=>p[0],p=>w-p[0],p=>p[1],p=>h-p[1]].forEach(f=>{const Q=[];P.forEach((a,i)=>{const b=P[(i+1)%P.length],fa=f(a),fb=f(b);
 if(fa>=0)Q.push(a);if((fa>=0)!==(fb>=0)){const t=fa/(fa-fb);Q.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]);}});P=Q;});return P;};

/* ================= BINGKAI HIAS ================= */
const FRC=[["Emas","#d4a017"],["Hitam","#111827"],["Merah","#e11d48"],["Biru","#2563eb"],["Putih","#ffffff"]];
const FRS=[["Tunggal","tunggal"],["Ganda","ganda"],["Sudut potong","potong"],["Sudut bulat","bulat"],["Putus","putus"]];
const warnaBk=()=>FRC[S.bkC98||0][1];
const chips=(h,arr,key,def,fmt)=>({h,items:arr.map(v=>tc(fmt?fmt(v):v+"",()=>{S[key]=v;},{keep:1,on:(S[key]??def)===v}))});
const warnaMenu=()=>({h:"Warna",items:FRC.map((x,i)=>tc(x[0],()=>{S.bkC98=i;},{keep:1,on:(S.bkC98||0)===i}))});

function bingkai(){const w=W(),h=H(),m=S.bkM98||32,sw=S.bkT98||8,st=S.bkSt98||"tunggal",col=warnaBk(),bw=R(w-2*m),bh=R(h-2*m);
 if(bw<60||bh<60)return T("Halaman terlalu kecil untuk margin ini");Hi.snapshot();
 const fr=(x,y,ww,hh,t,x2)=>shape("rect",x,y,ww,hh,"none",{name:"Bingkai",stroke:col,strokeWidth:t,...x2}),out=[];
 if(st==="ganda"){const g=m+sw*2.4;out.push(fr(m,m,bw,bh,sw,{name:"Bingkai luar"}));if(w-2*g>20&&h-2*g>20)out.push(fr(g,g,w-2*g,h-2*g,Math.max(1,R(sw*.45)),{name:"Bingkai dalam"}));}
 else if(st==="potong"){const c=R(Math.min(bw,bh)*.07);out.push(path(m,m,bw,bh,bw,bh,`M${c} 0L${bw-c} 0L${bw} ${c}L${bw} ${bh-c}L${bw-c} ${bh}L${c} ${bh}L0 ${bh-c}L0 ${c}Z`,"none",col,sw,{name:"Bingkai potong"}));}
 else if(st==="bulat")out.push(fr(m,m,bw,bh,sw,{rx:R(Math.min(bw,bh)*.07)}));
 else if(st==="putus")out.push(fr(m,m,bw,bh,sw,{dash:"6 4"}));
 else out.push(fr(m,m,bw,bh,sw));
 finish(grup(out,"Bingkai"),"Bingkai "+FRS.find(x=>x[1]===st)[0].toLowerCase()+" dipasang");}
MENUS.bkt98=()=>[
 {h:"Gaya",items:FRS.map(x=>tc(x[0],()=>{S.bkSt98=x[1];},{keep:1,on:(S.bkSt98||"tunggal")===x[1]}))},
 warnaMenu(),chips("Tebal (px)",[4,8,14],"bkT98",8),chips("Margin (px)",[16,32,56],"bkM98",32),
 {h:"Pasang",items:[it("Pasang bingkai di tepi halaman",bingkai,"border98")]}];

const SDS=[["Siku","siku"],["Lengkung","lengkung"],["Kuncup","kuncup"]];
function sudut(){const w=W(),h=H(),mn=Math.min(w,h),s=R(mn*(S.sdS98||.14)),mg=R(mn*.03),sw=Math.max(3,R(s*.05)),st=S.sdSt98||"siku",col=warnaBk(),g=s*.17,out=[];Hi.snapshot();
 [[0,0],[1,0],[0,1],[1,1]].forEach(([fx,fy],i)=>{const P=(x,y)=>`${R(fx?s-x:x)} ${R(fy?s-y:y)}`,x0=fx?w-mg-s:mg,y0=fy?h-mg-s:mg;let d;
  if(st==="lengkung")d=`M${P(0,s)}Q${P(0,0)} ${P(s,0)}M${P(g,s*.62)}Q${P(g,g)} ${P(s*.62,g)}`;
  else d=`M${P(0,s)}L${P(0,0)}L${P(s,0)}`+(st==="siku"?`M${P(g,s*.6)}L${P(g,g)}L${P(s*.6,g)}`:"");
  out.push(path(x0,y0,s,s,s,s,d,"none",col,sw,{name:"Sudut "+(i+1)}));
  if(st==="kuncup"){const r=s*.09;[[0,0],[s,0],[0,s]].forEach((q,j)=>{const cx=fx?s-q[0]:q[0],cy=fy?s-q[1]:q[1];out.push(shape("ellipse",x0+cx-r,y0+cy-r,r*2,r*2,col,{name:"Kuncup "+(i+1)+"."+(j+1)}));});}});
 finish(grup(out,"Sudut hias"),"Sudut hias "+SDS.find(x=>x[1]===st)[0].toLowerCase()+" dipasang");}
MENUS.sdt98=()=>[
 {h:"Gaya",items:SDS.map(x=>tc(x[0],()=>{S.sdSt98=x[1];},{keep:1,on:(S.sdSt98||"siku")===x[1]}))},
 {h:"Ukuran",items:[["Kecil",.1],["Sedang",.14],["Besar",.2]].map(x=>tc(x[0],()=>{S.sdS98=x[1];},{keep:1,on:(S.sdS98||.14)===x[1]}))},
 warnaMenu(),{h:"Pasang",items:[it("Pasang di 4 sudut halaman",sudut,"corner98")]}];

const LC=[["Merah","#e11d48","#ffffff"],["Biru","#2563eb","#ffffff"],["Hijau","#16a34a","#ffffff"],["Emas","#d4a017","#3b2a00"]];
const LD=[["Kecil",.25],["Sedang",.35],["Besar",.5]];
function lencana(){const q=prompt("Teks lencana (maks 12 huruf):","TERBAIK");if(q===null)return;const t=String(q).trim().slice(0,12);if(!t)return T("Teks kosong");Hi.snapshot();
 const w=W(),h=H(),D=R(Math.min(w,h)*LD[S.lnD98??1][1]),L=LC[S.lnC98||0],cx=w/2,cy=h/2,N=28,r1=D/2,r2=D/2*.93;let d="";
 for(let i=0;i<N*2;i++){const a=Math.PI*i/N-Math.PI/2,r=i%2?r2:r1;d+=(i?"L":"M")+R(D/2+r*Math.cos(a))+" "+R(D/2+r*Math.sin(a));}d+="Z";
 const fs=R(Math.max(6,Math.min(D*.17,D*.6/(t.length*.6)))),rr=D*.4,sg=D*.1,sm=D*.065,ys=cy+D*.22,
 out=[path(cx-D/2,cy-D/2,D,D,D,D,d,L[1],"none",0,{name:"Lencana"}),
  shape("ellipse",cx-rr,cy-rr,rr*2,rr*2,"none",{name:"Cincin",stroke:L[2],strokeWidth:Math.max(2,R(D*.012)),opacity:85}),
  shape("star",cx-sg/2,cy-D*.27,sg,sg,L[2],{name:"Bintang atas"}),
  text(t,cx-t.length*fs*.3,cy-fs*.55,fs,L[2],{name:"Teks lencana",bold:true}),
  ...[-2.2,0,2.2].map((k,i)=>shape("star",cx+sm*k-sm/2,ys,sm,sm,L[2],{name:"Bintang "+(i+1)}))];
 finish(grup(out,"Lencana"),"Lencana \""+t+"\" dipasang");}
MENUS.lcn98=()=>[
 {h:"Warna",items:LC.map((x,i)=>tc(x[0],()=>{S.lnC98=i;},{keep:1,on:(S.lnC98||0)===i}))},
 {h:"Ukuran",items:LD.map((x,i)=>tc(x[0],()=>{S.lnD98=i;},{keep:1,on:(S.lnD98??1)===i}))},
 {h:"Buat",items:[it("Buat lencana di tengah halaman…",lencana,"badge98")]}];

/* ================= POLA LATAR ================= */
const PK=["senja","biru","hijau","mono","laut"],P98=()=>PAL[PAL[S.polaPal98]?S.polaPal98:"senja"];
const paletMenu=()=>({h:"Palet",items:PK.map(k=>tc(PAL[k].n,()=>{S.polaPal98=k;},{keep:1,on:(S.polaPal98||"senja")===k}))});

const ARAH=[["Diagonal /",[.7071,.7071]],["Diagonal \\",[.7071,-.7071]],["Tegak",[1,0]],["Mendatar",[0,1]]];
function miring(){const P=P98(),w=W(),h=H(),[nx,ny]=ARAH[S.mirA98||0][1];Hi.snapshot();
 const pr=[[0,0],[w,0],[0,h],[w,h]].map(p=>p[0]*nx+p[1]*ny),c0=Math.min(...pr),c1=Math.max(...pr),sp=Math.max(S.mirS98||48,(c1-c0)/320),L=w+h,tx=-ny,ty=nx,
 q=k=>[nx*k,ny*k],out=[shape("rect",0,0,w,h,P.sky[1],{name:"Latar"})];
 for(let c=c0,i=1;c<c1;c+=sp*2,i++){const A=q(c),B=q(c+sp),pg=clip([[A[0]-tx*L,A[1]-ty*L],[A[0]+tx*L,A[1]+ty*L],[B[0]+tx*L,B[1]+ty*L],[B[0]-tx*L,B[1]-ty*L]],w,h);
  if(pg.length>=3)out.push(poly(pg,P.c[1],"Garis "+i));}
 finish(grup(out,"Garis miring"),"Garis "+ARAH[S.mirA98||0][0].toLowerCase()+" · "+(out.length-1)+" strip ("+P.n+")");}
MENUS.mrg98=()=>[paletMenu(),
 {h:"Arah",items:ARAH.map((x,i)=>tc(x[0],()=>{S.mirA98=i;},{keep:1,on:(S.mirA98||0)===i}))},
 chips("Lebar strip (px)",[24,48,96],"mirS98",48),
 {h:"Buat",items:[it("Buat latar garis (mengisi halaman)",miring,"stripes98")]}];

const HA=[["Kiri → kanan","lr"],["Atas → bawah","tb"],["Diagonal","dg"],["Dari tengah","rd"]];
function halftone(){const P=P98(),w=W(),h=H(),cell=Math.max(S.htC98||36,Math.sqrt(w*h/700)),nx=Math.ceil(w/cell),ny=Math.ceil(h/cell),md=Math.hypot(w/2,h/2),mode=S.htA98||"lr",out=[];Hi.snapshot();
 if(S.htBg98!==false)out.push(shape("rect",0,0,w,h,P.sky[1],{name:"Latar"}));
 for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){const cx=(i+.5)*cell,cy=(j+.5)*cell,
  t=Math.min(1,Math.max(0,mode==="lr"?cx/w:mode==="tb"?cy/h:mode==="dg"?(cx/w+cy/h)/2:Math.hypot(cx-w/2,cy-h/2)/md)),d=cell*(.1+.82*(1-t));
  if(d>=2)out.push(shape("ellipse",cx-d/2,cy-d/2,d,d,ramp(P.c,t),{name:"Titik"}));}
 finish(grup(out,"Halftone"),"Halftone · "+(out.length-(S.htBg98!==false?1:0))+" titik ("+P.n+")");}
MENUS.htn98=()=>[paletMenu(),
 {h:"Arah pudar",items:HA.map(x=>tc(x[0],()=>{S.htA98=x[1];},{keep:1,on:(S.htA98||"lr")===x[1]}))},
 chips("Ukuran petak (px)",[24,36,54],"htC98",36),
 {h:"Pilihan",items:[tc(S.htBg98===false?"Latar: OFF":"Latar: ON",()=>{S.htBg98=S.htBg98===false;},{keep:1})]},
 {h:"Buat",items:[it("Buat halftone (mengisi halaman)",halftone,"halftone98")]}];

function lowpoly(){const P=P98(),w=W(),h=H(),cell=Math.max(w/(S.lpN98||9),Math.sqrt(w*h/300)),nx=Math.ceil(w/cell),ny=Math.ceil(h/cell),pts=[],out=[];Hi.snapshot();
 for(let j=0;j<=ny;j++){pts[j]=[];for(let i=0;i<=nx;i++){let x=Math.min(w,i*cell),y=Math.min(h,j*cell);
  if(i>0&&i<nx)x+=rnd(-.32,.32)*cell;if(j>0&&j<ny)y+=rnd(-.32,.32)*cell;pts[j][i]=[Math.max(0,Math.min(w,x)),Math.max(0,Math.min(h,y))];}}
 const mk=(a,b,c)=>{const t=Math.min(1,Math.max(0,((a[0]+b[0]+c[0])/3/w+(a[1]+b[1]+c[1])/3/h)/2)),col=mix(ramp(P.c,t),Math.random()<.5?"#ffffff":"#000000",rnd(0,.14));
  out.push(poly([a,b,c],col,"Segitiga "+(out.length+1),{stroke:col,strokeWidth:1}));};
 for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){const a=pts[j][i],b=pts[j][i+1],c=pts[j+1][i],d=pts[j+1][i+1];
  if(Math.random()<.5){mk(a,b,c);mk(b,d,c);}else{mk(a,b,d);mk(a,d,c);}}
 finish(grup(out,"Mozaik segitiga"),"Segitiga · "+out.length+" petak ("+P.n+")");}
MENUS.lpl98=()=>[paletMenu(),
 chips("Kolom",[6,9,13],"lpN98",9),
 {h:"Buat",items:[it("Buat mozaik segitiga (acak baru tiap kali)",lowpoly,"lowpoly98")]}];

/* ================= tombol & grup ================= */
BT.push(["bkt98","border98","Bingkai"],["sdt98","corner98","Sudut Hias"],["lcn98","badge98","Lencana"],["mrg98","stripes98","Garis Miring"],["htn98","halftone98","Halftone"],["lpl98","lowpoly98","Segitiga"]);
defHub("polalatar98","bgpat98","Pola Latar",["mrg98","htn98","lpl98"]);
defHub("hiasbingkai98","frame98","Bingkai Hias",["bkt98","sdt98","lcn98"]);
Object.assign(U,{chips,poly,clip});
CDMS.Hias98={bingkai,sudut,lencana,miring,halftone,lowpoly};
})();
