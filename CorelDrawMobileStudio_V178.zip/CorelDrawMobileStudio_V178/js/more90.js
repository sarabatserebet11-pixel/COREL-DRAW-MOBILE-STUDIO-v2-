/* V102: dua grup menu baru (helper bersama dari CDMS.Util97, tanpa kode duplikat).
   "Diagram" (ikon diagram102): Alur (kotak + panah, mendatar / menurun), Piramida (2-5 tingkat), Venn (2-3 lingkaran bertumpuk).
   "Tipografi" (ikon type102): Judul (bayangan / garis bawah / sorot), Kutipan (kartu kutipan + penulis), Stempel (cap miring berbingkai ganda).
   Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo. */
(()=>{
const U=CDMS.Util97,M=CDMS.Menus,S=CDMS.state,Hi=CDMS.History,{MENUS,BT,it,tc,T}=M;
if(!M.HUBS||!U||!U.mkPal||!U.panel)return;
const{ramp,grup,shape,text,line,finish,defHub,W,H,chips,poly,ask,wrap,idx,tx,clamp,mkPal}=U,R=Math.round;
const PL=mkPal("pal102","senja"),pal=PL.pal,palMenu=PL.menu,pc=(P,t)=>ramp(P.c.slice(1),t);
/* teks gelap atau putih mengikuti terang warna latar (#rrggbb) */
const kontras=c=>{const m=/^#?([0-9a-f]{6})$/i.exec(c);if(!m)return"#ffffff";const v=parseInt(m[1],16);return .299*(v>>16)+.587*(v>>8&255)+.114*(v&255)>150?"#111827":"#ffffff";};
const daftar=(s,max)=>String(s).split(",").map(x=>x.trim().slice(0,14)).filter(Boolean).slice(0,max);
const panah=(x1,y1,x2,y2,sz,col,n)=>{const a=Math.atan2(y2-y1,x2-x1),bx=x2-sz*Math.cos(a),by=y2-sz*Math.sin(a),nx=-Math.sin(a)*sz*.6,ny=Math.cos(a)*sz*.6;
 return[line(x1,y1,bx-x1,by-y1,col,Math.max(2,R(sz*.28)),{name:"Garis "+n}),poly([[x2,y2],[bx+nx,by+ny],[bx-nx,by-ny]],col,"Ujung "+n)];};

/* ================= DIAGRAM ================= */
function alur(){const q=ask("Langkah (pisahkan koma; 2-5, tiap maks 14 huruf):","Mulai,Proses,Tes,Selesai");if(q===null)return;const D=daftar(q,5);if(D.length<2)return T("Butuh minimal 2 langkah");Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=D.length,hor=(S.alO102||"h")==="h",ml=Math.max(...D.map(s=>s.length)),out=[],ac="#6b7280";
 const bw=hor?w*.92/(n+(n-1)*.4):Math.min(w*.7,h*.2*ml*.5+w*.2),bh=hor?Math.min(h*.2,bw*.7):h*.88/(n+(n-1)*.5),gx=hor?bw*.4:0,gy=hor?0:bh*.5,
  tw=hor?n*bw+(n-1)*gx:bw,th=hor?bh:n*bh+(n-1)*gy,x0=(w-tw)/2,y0=(h-th)/2,fs=R(clamp(Math.min(bw/(ml*.6+1.2),bh*.4),7,40));
 D.forEach((s,i)=>{const x=x0+(hor?i*(bw+gx):0),y=y0+(hor?0:i*(bh+gy)),col=pc(P,n>1?i/(n-1):0),pill=i===0||i===n-1;
  out.push(shape("rect",x,y,bw,bh,col,{name:"Kotak "+(i+1),rx:R(pill?bh/2:bh*.15)}),tx(s,x+bw/2,y+bh/2-fs*.55,fs,kontras(col),{name:"Teks "+(i+1),bold:true}));
  if(i<n-1){const a=Math.min(hor?gx:gy,bh,bw)*.3;out.push(...(hor?panah(x+bw+gx*.12,y+bh/2,x+bw+gx*.88,y+bh/2,a,ac,i+1):panah(x+bw/2,y+bh+gy*.12,x+bw/2,y+bh+gy*.88,a,ac,i+1)));}});
 finish(grup(out,"Alur"),"Alur "+n+" langkah ("+(hor?"mendatar":"menurun")+")");}
MENUS.flw102=()=>[palMenu(),{h:"Arah",items:[["Mendatar","h"],["Menurun","v"]].map(x=>tc(x[0],()=>{S.alO102=x[1];},{keep:1,on:(S.alO102||"h")===x[1]}))},{h:"Buat",items:[it("Buat diagram alur dari daftar…",alur,"flow102")]}];

function piramida(){const q=ask("Tingkat dari atas ke bawah (pisahkan koma; 2-5):","Puncak,Tengah,Dasar");if(q===null)return;const D=daftar(q,5);if(D.length<2)return T("Butuh minimal 2 tingkat");Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=D.length,bw=Math.min(w*.84,h*.8*1.1),ph=Math.min(h*.78,bw*.9),cx=w/2,top=(h-ph)/2,gp=Math.max(3,ph*.012),hw=y=>bw/2*(y-top)/ph,out=[];
 D.forEach((s,i)=>{const y0=top+i*ph/n+(i?gp/2:0),y1=top+(i+1)*ph/n-(i<n-1?gp/2:0),col=pc(P,n>1?i/(n-1):0),ym=(y0+y1)/2,
  fs=R(clamp(Math.min(ph/n*.34,2*hw(ym)*.86/(s.length*.6+.6)),7,36));
  out.push(poly([[cx-hw(y0),y0],[cx+hw(y0),y0],[cx+hw(y1),y1],[cx-hw(y1),y1]],col,"Tingkat "+(i+1)),tx(s,cx,ym-fs*.55+(i?0:ph/n*.12),fs,kontras(col),{name:"Teks "+(i+1),bold:true}));});
 finish(grup(out,"Piramida"),"Piramida "+n+" tingkat");}
MENUS.pyr102=()=>[palMenu(),{h:"Buat",items:[it("Buat piramida dari daftar…",piramida,"pyramid102")]}];

function venn(){const q=ask("Nama lingkaran (pisahkan koma; 2-3):","Desain,Kode,Bisnis");if(q===null)return;const D=daftar(q,3);if(D.length<2)return T("Butuh minimal 2 nama");Hi.snapshot();
 const P=pal(),w=W(),h=H(),n=D.length,cx=w/2,cy=h/2,out=[],r=n===2?Math.min(w*.3,h*.3):Math.min(w,h)*.27,
  C=n===2?[[cx-r*.55,cy,-1,0],[cx+r*.55,cy,1,0]]:[[cx,cy-r*.55,0,-1],[cx-r*.6,cy+r*.4,-.87,.5],[cx+r*.6,cy+r*.4,.87,.5]],fs=R(clamp(r*.2,8,32));
 D.forEach((s,i)=>out.push(shape("ellipse",C[i][0]-r,C[i][1]-r,r*2,r*2,pc(P,n>1?i/(n-1):0),{name:"Lingkaran "+(i+1),opacity:62,stroke:"#ffffff",strokeWidth:3})));
 D.forEach((s,i)=>out.push(tx(s,C[i][0]+C[i][2]*r*.55,C[i][1]+C[i][3]*r*.55-fs*.55,fs,"#111827",{name:"Teks "+(i+1),bold:true})));
 finish(grup(out,"Venn"),"Diagram Venn "+n+" lingkaran");}
MENUS.ven102=()=>[palMenu(),{h:"Buat",items:[it("Buat diagram Venn dari nama…",venn,"venn102")]}];

/* ================= TIPOGRAFI ================= */
const JG=[["Bayangan","b"],["Garis bawah","g"],["Sorot","s"]],JW=[["Merah","#dc2626"],["Biru","#2563eb"],["Hijau","#16a34a"],["Emas","#d97706"]];
function judul(){const q=ask("Judul (maks 24 huruf):","JUDUL KEREN");if(q===null)return;const t=q.slice(0,24);if(!t)return T("Teks kosong");Hi.snapshot();
 const w=W(),h=H(),st=S.jgG102||"b",col=JW[S.jgW102||0][1],L=t.length,fs=Math.max(10,Math.min(Math.min(w,h)*.12,w*.9/(L*.6+(st==="s"?1.6:.4)))),tw=L*fs*.6,cx=w/2,y=h/2-fs*.55,out=[];
 if(st==="s"){out.push(shape("rect",cx-tw/2-fs*.4,y-fs*.2,tw+fs*.8,fs*1.5,col,{name:"Sorot",rx:R(fs*.15)}),tx(t,cx,y,fs,kontras(col),{name:"Judul",bold:true}));}
 else if(st==="g"){out.push(tx(t,cx,y,fs,"#111827",{name:"Judul",bold:true}),shape("rect",cx-tw/2,y+fs*1.2,tw,Math.max(4,fs*.14),col,{name:"Garis bawah",rx:R(fs*.07)}),shape("rect",cx-tw*.15,y+fs*1.5,tw*.3,Math.max(3,fs*.08),col,{name:"Garis pendek",opacity:60}));}
 else{const d=Math.max(2,fs*.06);out.push(tx(t,cx+d*1.5,y+d*1.5,fs,col,{name:"Bayangan",bold:true,opacity:45}),tx(t,cx,y,fs,"#111827",{name:"Judul",bold:true}));}
 finish(grup(out,"Judul"),"Judul gaya "+JG.find(x=>x[1]===st)[0].toLowerCase()+" dipasang");}
MENUS.jdl102=()=>[{h:"Gaya",items:JG.map(x=>tc(x[0],()=>{S.jgG102=x[1];},{keep:1,on:(S.jgG102||"b")===x[1]}))},idx("Warna aksen",JW,"jgW102",0),{h:"Buat",items:[it("Buat judul di tengah halaman…",judul,"title102")]}];

function kutipan(){const q=ask("Kutipan | Penulis (penulis boleh kosong, maks 100 huruf):","Mulai dari mana kamu berada. | Arthur Ashe");if(q===null)return;const[a,b]=q.split("|"),t=(a||"").trim().slice(0,100),pn=(b||"").trim().slice(0,24);if(!t)return T("Kutipan kosong");Hi.snapshot();
 const w=W(),h=H(),gl=(S.kpT102||"t")==="g",bg=gl?"#1f2937":"#ffffff",fg=gl?"#f9fafb":"#111827",ac=JW[S.kpW102||0][1],cw=w*.84;let fs=Math.min(w,h)*.05,Ls,need;
 for(let k=0;k<10;k++){const mc=Math.max(8,Math.floor(cw*.82/(fs*.6)));Ls=wrap(t,mc);need=Ls.length*fs*1.4+fs*(pn?5.2:3.8);if(need<=h*.84||fs<=8)break;fs*=.88;}
 fs=R(Math.max(7,fs));const ch=need,x=(w-cw)/2,y=(h-ch)/2,out=[shape("rect",x,y,cw,ch,bg,{name:"Kartu",rx:R(fs*.8),stroke:ac,strokeWidth:Math.max(2,R(fs*.12))}),text("\u201C",x+fs*.9,y+fs*.1,fs*3.2,ac,{name:"Tanda kutip",bold:true})];
 Ls.forEach((s,i)=>out.push(text(s,x+fs*1.1,y+fs*2.4+i*fs*1.4,fs,fg,{name:"Baris "+(i+1)})));
 if(pn)out.push(text("\u2014 "+pn,x+cw-fs*1.1-(pn.length+2)*fs*.55,y+ch-fs*1.9,R(fs*.85),ac,{name:"Penulis",bold:true}));
 finish(grup(out,"Kutipan"),"Kartu kutipan dipasang");}
MENUS.ktp102=()=>[{h:"Tema",items:[["Terang","t"],["Gelap","g"]].map(x=>tc(x[0],()=>{S.kpT102=x[1];},{keep:1,on:(S.kpT102||"t")===x[1]}))},idx("Warna aksen",JW,"kpW102",0),{h:"Buat",items:[it("Buat kartu kutipan…",kutipan,"quote102")]}];

const SW=[["Merah","#dc2626"],["Biru","#1d4ed8"],["Hijau","#15803d"]];
function stempel(){const q=ask("Teks stempel (maks 14 huruf):","LUNAS");if(q===null)return;const t=q.slice(0,14).toUpperCase();if(!t)return T("Teks kosong");Hi.snapshot();
 const w=W(),h=H(),col=SW[S.stC102||0][1],L=t.length,fs=Math.max(10,Math.min(Math.min(w,h)*.12,w*.8/(L*.6+1.6))),bw=L*fs*.6+fs*1.6,bh=fs*2,cx=w/2,cy=h/2,rot=-12,sw=Math.max(3,R(fs*.1));
 finish(grup([shape("rect",cx-bw/2,cy-bh/2,bw,bh,"none",{name:"Bingkai luar",rx:R(fs*.3),stroke:col,strokeWidth:sw,rotation:rot,opacity:88}),
  shape("rect",cx-bw/2+fs*.2,cy-bh/2+fs*.2,bw-fs*.4,bh-fs*.4,"none",{name:"Bingkai dalam",rx:R(fs*.15),stroke:col,strokeWidth:Math.max(1,R(sw*.45)),rotation:rot,opacity:88}),
  tx(t,cx,cy-fs*.55,fs,col,{name:"Teks stempel",bold:true,rotation:rot,opacity:88})],"Stempel"),"Stempel \""+t+"\" dipasang");}
MENUS.stm102=()=>[idx("Warna",SW,"stC102",0),{h:"Buat",items:[it("Pasang stempel di tengah…",stempel,"stamp102")]}];

/* ================= tombol & grup ================= */
BT.push(["flw102","flow102","Alur"],["pyr102","pyramid102","Piramida"],["ven102","venn102","Venn"],["jdl102","title102","Judul"],["ktp102","quote102","Kutipan"],["stm102","stamp102","Stempel"]);
defHub("diagram102","diagram102","Diagram",["flw102","pyr102","ven102"]);
defHub("tipo102","type102","Tipografi",["jdl102","ktp102","stm102"]);
Object.assign(U,{kontras,daftar});
CDMS.Diagram102={alur,piramida,venn,judul,kutipan,stempel};
})();
