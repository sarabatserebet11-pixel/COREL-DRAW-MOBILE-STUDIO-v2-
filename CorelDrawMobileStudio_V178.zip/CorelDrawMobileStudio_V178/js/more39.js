/* V50: menu Bertahap - gradasi warna, skala, rotasi, transparansi dan jarak bertahap antar objek terpilih */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,sels,T,it}=M,r0=Math.round;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const hex=h=>{const m=/^#?([0-9a-f]{6})$/i.exec(h);return m?[0,2,4].map(i=>parseInt(m[1].substr(i,2),16)):null;};
const mix=(a,b,t)=>"#"+a.map((v,i)=>r0(v+(b[i]-v)*t).toString(16).padStart(2,"0")).join("");
/* urutan: menurut urutan pilih (S.selectedIds), bukan urutan tumpukan */
const ordered=()=>{const a=sels();const ids=S.selectedIds||[];return a.sort((p,q)=>ids.indexOf(p.id)-ids.indexOf(q.id));};
const run=(min,fn,msg)=>{const a=ordered();if(a.length<min)return T("Pilih "+min+" objek atau lebih");Hi.snapshot();const n=a.length;a.forEach((o,i)=>fn(o,n>1?i/(n-1):0,i));C.render();T(msg+" ("+n+" objek)");};
const GR=[["Sunset","#ff9966","#ff2d75"],["Samudra","#00e5ff","#1a3cff"],["Neon","#00d6c9","#a855f7"],["Hutan","#d4fc79","#0b8a5a"],["Api","#fff200","#e8102a"],["Monokrom","#ffffff","#222222"]];
const colorRamp=g=>run(2,(o,t)=>{const c=mix(hex(g[1]),hex(g[2]),t);if(o.type==="line"||o.type==="text"||o.fill!=="none")o.fill=c;if(o.type==="line")o.stroke=c;if(o.grad)delete o.grad;},"Gradasi "+g[0]);
const sizeRamp=(a,b)=>run(2,(o,t)=>{const f=a+(b-a)*t,cx=o.x+o.w/2,cy=o.y+(o.h||0)/2;o.w=Math.max(1,r0(o.w*f));if(o.h!=null)o.h=Math.max(1,r0(o.h*f));if(o.fontSize)o.fontSize=Math.max(6,r0(o.fontSize*f));o.x=r0(cx-o.w/2);o.y=r0(cy-(o.h||0)/2);},"Skala "+r0(a*100)+"%→"+r0(b*100)+"%");
const rotRamp=(a,b)=>run(2,(o,t)=>{o.rotation=((r0(a+(b-a)*t)%360)+360)%360;},"Putar "+a+"°→"+b+"°");
const opRamp=(a,b)=>run(2,(o,t)=>{o.opacity=r0(a+(b-a)*t);},"Transparansi "+a+"%→"+b+"%");
const spaceRamp=ax=>{const a=ordered();if(a.length<3)return T("Pilih 3 objek atau lebih");Hi.snapshot();const k=ax==="h"?"x":"y",s=[...a].sort((p,q)=>p[k]-q[k]),f=s[0][k],l=s[s.length-1][k];s.forEach((o,i)=>{o[k]=r0(f+(l-f)*i/(s.length-1));});C.render();T("Posisi diratakan berurutan");};
MENUS.bertahap=()=>[
 {h:"Gradasi warna antar objek (urut pilih)",items:GR.map(g=>it(g[0],()=>colorRamp(g),"color"))},
 {h:"Skala bertahap",items:[it("Kecil → besar (50%→150%)",()=>sizeRamp(.5,1.5),"transform"),it("Besar → kecil (150%→50%)",()=>sizeRamp(1.5,.5),"transform"),it("Kecil → besar (30%→100%)",()=>sizeRamp(.3,1),"transform")]},
 {h:"Putar bertahap",items:[it("Kipas 0°→90°",()=>rotRamp(0,90),"transform"),it("Kipas 0°→180°",()=>rotRamp(0,180),"transform"),it("Lingkar penuh 0°→360°",()=>rotRamp(0,360),"transform"),it("Condong −30°→30°",()=>rotRamp(-30,30),"transform")]},
 {h:"Transparansi bertahap",items:[it("Pudar 100%→20%",()=>opRamp(100,20),"eye"),it("Muncul 20%→100%",()=>opRamp(20,100),"eye")]},
 {h:"Posisi",items:[it("Jarak merata mendatar (urut posisi)",()=>spaceRamp("h"),"multi"),it("Jarak merata menurun (urut posisi)",()=>spaceRamp("v"),"multi")]}];
BT.push(["bertahap","steps","Bertahap"]);
hubAdd("atur","bertahap");

/* ---- Periksa: perbaikan kontras teks otomatis ---- */
const lum=h=>{const c=hex(h);if(!c)return null;const v=c.map(x=>{x/=255;return x<=.03928?x/12.92:Math.pow((x+.055)/1.055,2.4);});return .2126*v[0]+.7152*v[1]+.0722*v[2];};
const cr=(a,b)=>{const x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
const op=MENUS.periksa;
MENUS.periksa=()=>{const bg=S.page.background||S.page.bg||"#ffffff";
 const low=S.objects.filter(o=>o.type==="text"&&hex(o.fill)&&hex(bg)&&cr(o.fill,bg)<3);
 const g=op();if(low.length)g.splice(Math.min(2,g.length),0,{h:"Perbaikan kontras",items:[it("Atur otomatis warna teks kontras rendah ("+low.length+")",()=>{Hi.snapshot();low.forEach(o=>{o.fill=cr("#000000",bg)>=cr("#ffffff",bg)?"#000000":"#ffffff";});C.render();T("Kontras teks diperbaiki");},"layers")]});
 return g;};
})();
