/* V43 (2/2): menu Templat (Buat), Generatif (Pustaka), Ekspor+ (Berkas, ZIP) */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,{MENUS,BT,sels,pick,T,it,tc,cell,rotBox}=M,$=s=>document.querySelector(s),uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const base=(t,o)=>({id:uid(),type:t,name:t,x:0,y:0,w:100,h:100,fill:"#6d5dfc",stroke:"none",strokeWidth:0,opacity:100,rotation:0,...o});
const r0=Math.round;
const R=(x,y,w,h,fill,ex)=>base("rect",{name:"Kotak",x:r0(x),y:r0(y),w:r0(w),h:r0(h),fill,...ex});
const E=(x,y,w,h,fill,ex)=>base("ellipse",{name:"Lingkaran",x:r0(x),y:r0(y),w:r0(w),h:r0(h),fill,...ex});
const X=(text,x,y,w,size,fill,ex)=>{const o=base("text",{name:"Teks",text,x:r0(x),y:r0(y),w:r0(w),h:r0(size*1.25*String(text).split("\n").length),fontSize:r0(size),fill,bold:true,fontFamily:"Arial, sans-serif",...ex});
 if(o.align==="center")o._cx=x+w/2;else if(o.align==="right")o._rx=x+w;return o;};
function ask(title,html,cb,label){N.openModal(title,`<div class="st-pane">${html}<button class="btn primary" id="aOk">${label||"Buat"}</button></div>`);$("#aOk").onclick=cb;}
/* render mengukur ulang lebar teks, jadi posisi tengah/kanan dihitung setelah render pertama */
const settle=a=>{let ch=false;a.forEach(o=>{if(o._cx!=null){o.x=r0(o._cx-(o.w||0)/2);ch=true;}else if(o._rx!=null){o.x=r0(o._rx-(o.w||0));ch=true;}delete o._cx;delete o._rx;});if(ch)C.render();};
const addAll=(arr,msg,bg)=>{Hi.snapshot();if(bg)S.page.background=bg;S.objects.push(...arr);pick(arr);settle(arr);if(msg)T(msg);};

/* ================= TEMPLAT: tata letak siap pakai, menyesuaikan ukuran halaman ================= */
const SERIF="Georgia, serif",IMP="Impact, 'Arial Black', sans-serif";
const TPL={
 quote:(w,h,u)=>({bg:"#14122b",o:[E(w*.5-u*.55,h*.5-u*.55,u*1.1,u*1.1,"#2a2468",{opacity:60,name:"Cahaya"}),
  X("“",w*.09,h*.1,u*.3,u*.42,"#7b6cff",{fontFamily:SERIF,name:"Tanda kutip"}),R(w*.1,h*.4,u*.14,u*.012,"#00d6c9",{name:"Garis aksen"}),
  X("Mulai dari mana kamu berada,\ngunakan apa yang kamu punya,\nlakukan apa yang kamu bisa.",w*.1,h*.44,w*.8,u*.062,"#ffffff",{name:"Kutipan",fontFamily:SERIF,bold:false}),
  X("— NAMA PENULIS",w*.1,h*.78,w*.8,u*.034,"#00d6c9",{name:"Penulis",spacing:3})]}),
 poster:(w,h,u)=>({bg:"#1b1340",o:[E(w-u*.55,-u*.25,u*.9,u*.9,"#7b6cff",{opacity:35,name:"Hiasan 1"}),E(-u*.25,h-u*.6,u*.8,u*.8,"#00d6c9",{opacity:25,name:"Hiasan 2"}),
  X("LIVE EVENT 2026",w*.08,h*.1,w*.84,u*.04,"#00d6c9",{name:"Label",spacing:6}),X("FESTIVAL\nMUSIK\nMALAM",w*.08,h*.17,w*.84,u*.13,"#ffffff",{name:"Judul",fontFamily:IMP,bold:false}),
  R(w*.08,h*.66,u*.5,u*.09,"#ffc857",{rx:r0(u*.045),name:"Tanggal pil"}),X("12 DES · 19.00",w*.08+u*.04,h*.66+u*.02,u*.45,u*.045,"#20243a",{name:"Tanggal"}),
  X("Lapangan Kota, Jl. Merdeka No. 1",w*.08,h*.78,w*.84,u*.038,"#d9d6ff",{name:"Lokasi",bold:false}),R(0,h-u*.1,w,u*.1,"#7b6cff",{name:"Bar bawah"}),X("DAFTAR SEKARANG  →",w*.08,h-u*.1+u*.026,w*.84,u*.044,"#ffffff",{name:"CTA"})]}),
 promo:(w,h,u)=>({bg:"#ffcf3f",o:[E(-u*.2,-u*.2,u*.6,u*.6,"#ff6b6b",{name:"Hiasan 1"}),E(w-u*.4,h-u*.45,u*.7,u*.7,"#20243a",{opacity:90,name:"Hiasan 2"}),
  X("DISKON\nAKHIR TAHUN",w*.08,h*.14,w*.84,u*.085,"#20243a",{name:"Judul",fontFamily:IMP,bold:false}),X("50%",w*.08,h*.34,w*.84,u*.4,"#ff3d5a",{name:"Angka",fontFamily:IMP,bold:false}),
  X("untuk semua produk pilihan",w*.08,h*.7,w*.84,u*.045,"#20243a",{name:"Keterangan",bold:false}),R(w*.08,h*.78,u*.5,u*.11,"#20243a",{rx:r0(u*.055),name:"Tombol"}),X("BELANJA",w*.08+u*.07,h*.78+u*.028,u*.4,u*.05,"#ffffff",{name:"Teks tombol",spacing:2})]}),
 thumb:(w,h,u)=>({bg:"#10131c",o:[R(0,0,w*.55,h,"#7b6cff",{name:"Panel"}),E(w*.62,h*.14,u*.62,u*.62,"#00d6c9",{name:"Foto (ganti dengan gambar)"}),
  X("CARA\nMUDAH",w*.05,h*.12,w*.5,Math.min(u*.2,w*.5/3.9),"#ffffff",{name:"Judul 1",fontFamily:IMP,bold:false}),R(w*.05,h*.6,w*.46,Math.min(u*.16,w*.44/5)*1.3,"#ffc857",{name:"Sorot",rx:12}),X("PEMULA!",w*.065,h*.6+Math.min(u*.16,w*.44/5)*.06,w*.44,Math.min(u*.16,w*.44/5),"#20243a",{name:"Judul 2",fontFamily:IMP,bold:false}),X("▶  TONTON",w*.05,h*.86,w*.4,u*.07,"#ffffff",{name:"Label"})]}),
 kartu:(w,h,u)=>({bg:"#ffffff",o:[R(0,0,w*.36,h,"#1b1340",{name:"Panel kiri"}),E(w*.06,h*.08,w*.12,w*.12,"#00d6c9",{name:"Logo"}),
  X("NAMA LENGKAP",w*.42,h*.2,w*.54,Math.min(u*.085,w*.54/8.8),"#1b1340",{name:"Nama"}),X("Jabatan / Profesi",w*.42,h*.34,w*.54,u*.05,"#7b6cff",{name:"Jabatan",bold:false}),R(w*.42,h*.5,w*.12,u*.008,"#00d6c9",{name:"Garis"}),
  X("☎  0812 3456 7890\n✉  nama@email.com\n⌂  Kota, Indonesia",w*.42,h*.58,w*.54,u*.048,"#4a5068",{name:"Kontak",bold:false,lh:1.5})]}),
 sertifikat:(w,h,u)=>({bg:"#fffaf0",o:[R(u*.03,u*.03,w-u*.06,h-u*.06,"none",{stroke:"#c79100",strokeWidth:8,name:"Bingkai luar"}),R(u*.055,u*.055,w-u*.11,h-u*.11,"none",{stroke:"#c79100",strokeWidth:2,name:"Bingkai dalam"}),
  X("SERTIFIKAT",w*.1,h*.15,w*.8,u*.1,"#1b1340",{name:"Judul",align:"center",fontFamily:SERIF,spacing:6}),X("diberikan kepada",w*.1,h*.34,w*.8,u*.04,"#6b6f85",{name:"Pengantar",align:"center",bold:false}),
  X("Nama Penerima",w*.1,h*.42,w*.8,u*.09,"#c79100",{name:"Nama",align:"center",fontFamily:SERIF,italic:true}),R(w*.25,h*.56,w*.5,u*.004,"#1b1340",{name:"Garis nama"}),
  X("atas partisipasi dan pencapaiannya\ndalam kegiatan yang telah diselenggarakan.",w*.1,h*.6,w*.8,u*.04,"#4a5068",{name:"Deskripsi",align:"center",bold:false}),
  R(w*.18,h*.84,w*.24,u*.004,"#1b1340",{name:"Garis TTD 1"}),X("Ketua",w*.18,h*.855,w*.24,u*.036,"#1b1340",{name:"TTD 1",align:"center",bold:false}),R(w*.58,h*.84,w*.24,u*.004,"#1b1340",{name:"Garis TTD 2"}),X("Sekretaris",w*.58,h*.855,w*.24,u*.036,"#1b1340",{name:"TTD 2",align:"center",bold:false})]}),
 menu:(w,h,u)=>{const rows=[["Kopi Susu","22K"],["Americano","20K"],["Matcha Latte","28K"],["Croissant","25K"]],o=[R(0,0,w,h*.2,"#3b2a20",{name:"Header"}),X("KOPI SENJA",w*.08,h*.05,w*.84,u*.08,"#f6e7d0",{name:"Judul",align:"center",fontFamily:SERIF,spacing:4})];
  rows.forEach((r,i)=>{const y=h*(.3+i*.15);o.push(X(r[0],w*.1,y,w*.6,u*.055,"#3b2a20",{name:"Menu "+(i+1)}),X(r[1],w*.6,y,w*.3,u*.055,"#c1783a",{name:"Harga "+(i+1),align:"right"}),R(w*.1,y+u*.075,w*.8,u*.003,"#d8c3a5",{name:"Garis "+(i+1)}));});
  o.push(X("Buka setiap hari · 08.00 – 22.00",w*.08,h*.92,w*.84,u*.034,"#8a6a52",{name:"Jam buka",align:"center",bold:false}));return{bg:"#f6e7d0",o};},
 undangan:(w,h,u)=>({bg:"#fdf2f4",o:[R(u*.06,u*.06,w-u*.12,h-u*.12,"#ffffff",{rx:r0(u*.04),stroke:"#e8b4bc",strokeWidth:3,name:"Kartu"}),E(w*.5-u*.1,h*.12,u*.2,u*.2,"#f7d6dc",{name:"Hiasan"}),
  X("Kami Mengundang Anda",w*.1,h*.36,w*.8,u*.045,"#b0687a",{name:"Pengantar",align:"center",bold:false,spacing:2}),X("Rani & Dimas",w*.1,h*.43,w*.8,u*.11,"#7a3b4d",{name:"Nama",align:"center",fontFamily:SERIF,italic:true}),
  R(w*.4,h*.62,w*.2,u*.004,"#e8b4bc",{name:"Garis"}),X("Sabtu, 20 Desember 2026\nPukul 10.00 WIB",w*.1,h*.66,w*.8,u*.05,"#5a4a50",{name:"Waktu",align:"center",bold:false,lh:1.5}),X("Gedung Serbaguna, Kota",w*.1,h*.82,w*.8,u*.04,"#b0687a",{name:"Tempat",align:"center",bold:false})]})
};
const TL=[["Kutipan inspiratif","quote"],["Poster acara","poster"],["Promo diskon","promo"],["Thumbnail YouTube","thumb"],["Kartu nama","kartu"],["Sertifikat","sertifikat"],["Menu kafe","menu"],["Undangan","undangan"]];
function applyTpl(k,label){const w=W(),h=H(),t=TPL[k](w,h,Math.min(w,h));addAll(t.o,label+" ditambahkan. Edit teks dengan ketuk dua kali.",t.bg);}
MENUS.templat=()=>[{h:"Tata letak siap pakai (menyesuaikan ukuran halaman, undo untuk batal)",items:TL.map(x=>it(x[0],()=>applyTpl(x[1],x[0]),"insert"))}];

/* ================= GENERATIF: spirograf, mawar, lissajous, mandala, konstelasi, halftone ================= */
const PAL=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4f83ff","#ff7ac8"];let pc=0;
const gcd=(a,b)=>b?gcd(b,a%b):a;
function curve(name,pts,color,o){const xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]),x0=Math.min(...xs),y0=Math.min(...ys),w=Math.max(1,Math.max(...xs)-x0),h=Math.max(1,Math.max(...ys)-y0),
  z=Math.min(W(),H())*.72,f=z/Math.max(w,h),f2=(o&&o.noScale)?1:f,pw=Math.max(1,w*f2),ph=Math.max(1,h*f2);
 const d=pts.map((p,i)=>(i?"L":"M")+((p[0]-x0)*f2).toFixed(1)+" "+((p[1]-y0)*f2).toFixed(1)).join("")+((o&&o.close)?"Z":"");
 const ob=base("path",{name,x:r0((W()-pw)/2),y:r0((H()-ph)/2),w:r0(pw),h:r0(ph),vw:r0(pw),vh:r0(ph),d,fill:"none",stroke:color||PAL[pc++%PAL.length],strokeWidth:3});
 addAll([ob],name+" dibuat");}
function spiro(Rr,r,d,color){Rr=Math.max(2,Math.round(Rr));r=Math.max(1,Math.round(r));if(r>=Rr)r=Rr-1||1;const g=gcd(Rr,r),T2=Math.PI*2*(r/g),n=Math.min(2400,Math.round(260*(r/g)+400)),pts=[];
 for(let i=0;i<=n;i++){const t=T2*i/n;pts.push([(Rr-r)*Math.cos(t)+d*Math.cos((Rr-r)/r*t),(Rr-r)*Math.sin(t)-d*Math.sin((Rr-r)/r*t)]);}curve("Spirograf "+Rr+"/"+r,pts,color);}
function rose(p,q,color){const k=p/q,span=Math.PI*2*q*(p%2&&q%2?1:2)/(q%2?1:1),n=1600,pts=[];for(let i=0;i<=n;i++){const t=span*i/n,r=Math.cos(k*t);pts.push([r*Math.cos(t),r*Math.sin(t)]);}curve("Mawar "+(q===1?p:p+"/"+q),pts,color);}
function lissa(a,b,color){const pts=[];for(let i=0;i<=1200;i++){const t=Math.PI*2*i/1200;pts.push([Math.sin(a*t+Math.PI/2),Math.sin(b*t)]);}curve("Lissajous "+a+":"+b,pts,color);}
function mandala(n){const a=sels().filter(o=>!o.locked&&!o.hidden);if(!a.length)return T("Pilih objek yang ditaruh di luar pusat halaman");Hi.snapshot();const cx=W()/2,cy=H()/2,out=[];
 for(let i=1;i<n;i++){const th=i*Math.PI*2/n,c=Math.cos(th),s=Math.sin(th),gm={};a.forEach(o=>{const cp={...o,id:uid()};if(cp.groupId)cp.groupId=gm[cp.groupId]||(gm[cp.groupId]=uid());const ox=o.x+o.w/2-cx,oy=o.y+(o.h||0)/2-cy,nx=cx+ox*c-oy*s,ny=cy+ox*s+oy*c;cp.x=r0(nx-o.w/2);cp.y=r0(ny-(o.h||0)/2);cp.rotation=((r0((o.rotation||0)+th*180/Math.PI)+540)%360)-180;out.push(cp);});}
 S.objects.push(...out);pick([...a,...out]);T("Mandala "+n+" bagian dibuat");}
function stars(){const n=26,u=Math.min(W(),H()),pts=[];for(let i=0;i<n;i++)pts.push([Math.random()*W()*.86+W()*.07,Math.random()*H()*.86+H()*.07]);
 const x0=Math.min(...pts.map(p=>p[0])),y0=Math.min(...pts.map(p=>p[1])),w=Math.max(...pts.map(p=>p[0]))-x0||1,h=Math.max(...pts.map(p=>p[1]))-y0||1;let d="";
 pts.forEach((p,i)=>{pts.map((q,j)=>[j,Math.hypot(p[0]-q[0],p[1]-q[1])]).filter(z=>z[0]>i).sort((m,k)=>m[1]-k[1]).slice(0,2).forEach(z=>{const q=pts[z[0]];if(z[1]<u*.34)d+=`M${(p[0]-x0).toFixed(1)} ${(p[1]-y0).toFixed(1)}L${(q[0]-x0).toFixed(1)} ${(q[1]-y0).toFixed(1)}`;});});
 const dots=pts.map(p=>{const r=2+Math.random()*4,cx=(p[0]-x0).toFixed(1),cy=(p[1]-y0).toFixed(1);return`M${(+cx-r).toFixed(1)} ${cy}a${r.toFixed(1)} ${r.toFixed(1)} 0 1 0 ${(2*r).toFixed(1)} 0a${r.toFixed(1)} ${r.toFixed(1)} 0 1 0 ${(-2*r).toFixed(1)} 0`;}).join("");
 const ln=base("path",{name:"Garis konstelasi",x:r0(x0),y:r0(y0),w:r0(w),h:r0(h),vw:r0(w),vh:r0(h),d:d||"M0 0",fill:"none",stroke:"#9d92ff",strokeWidth:1.5,opacity:70}),
  dt=base("path",{name:"Bintang konstelasi",x:r0(x0),y:r0(y0),w:r0(w),h:r0(h),vw:r0(w),vh:r0(h),d:dots,fill:"#ffffff"});addAll([ln,dt],"Konstelasi dibuat");}
function halftone(mode){const n=15,z=Math.min(W(),H())*.8,cell=z/n,max=cell*.46;let d="";
 for(let i=0;i<n;i++)for(let j=0;j<n;j++){const dx=(i-(n-1)/2)/((n-1)/2),dy=(j-(n-1)/2)/((n-1)/2),t=mode==="radial"?1-Math.min(1,Math.hypot(dx,dy)):(i+j)/(2*(n-1)),r=Math.max(.8,max*t),cx=(i+.5)*cell,cy=(j+.5)*cell;
  d+=`M${(cx-r).toFixed(1)} ${cy.toFixed(1)}a${r.toFixed(1)} ${r.toFixed(1)} 0 1 0 ${(2*r).toFixed(1)} 0a${r.toFixed(1)} ${r.toFixed(1)} 0 1 0 ${(-2*r).toFixed(1)} 0`;}
 const s=r0(z);addAll([base("path",{name:"Halftone "+(mode==="radial"?"radial":"diagonal"),x:r0((W()-s)/2),y:r0((H()-s)/2),w:s,h:s,vw:r0(z),vh:r0(z),d,fill:PAL[pc++%PAL.length]})],"Halftone dibuat");}
function spiroCustom(){ask("Spirograf kustom",`<div class="st-grid"><label>Lingkaran besar (R)<input id="gR" type="number" value="9" min="3" max="40"></label><label>Lingkaran kecil (r)<input id="gr" type="number" value="4" min="1" max="39"></label><label>Jarak pena (d)<input id="gd" type="number" value="6" min="1" max="60"></label><label>Warna<input id="gc" type="color" value="#6d5dfc"></label></div>`,()=>{const Rr=+$("#gR").value||9,r=+$("#gr").value||4,d=+$("#gd").value||6,c=$("#gc").value;N.closeModal();spiro(Rr,r,d,c);});}
MENUS.generatif=()=>[
 {h:"Spirograf",items:[it("Spirograf 5/3",()=>spiro(5,3,4),"pen"),it("Spirograf 7/2",()=>spiro(7,2,5),"pen"),it("Spirograf 8/3",()=>spiro(8,3,6),"pen"),it("Spirograf 11/4",()=>spiro(11,4,7),"pen"),it("Spirograf kustom…",spiroCustom,"settings")]},
 {h:"Kurva matematika",items:[tc("Mawar 5",()=>rose(5,1)),tc("Mawar 7",()=>rose(7,1)),tc("Mawar 3/2",()=>rose(3,2)),tc("Lissajous 3:2",()=>lissa(3,2)),tc("Lissajous 5:4",()=>lissa(5,4))]},
 {h:"Mandala dari objek terpilih (diputar mengelilingi pusat halaman)",items:[6,8,12,16].map(n=>tc(n+" bagian",()=>mandala(n)))},
 {h:"Pola acak",items:[it("Konstelasi bintang",stars,"star"),it("Halftone radial",()=>halftone("radial"),"shapes"),it("Halftone diagonal",()=>halftone("diag"),"shapes")]}];

/* ================= EKSPOR+: ZIP tanpa pustaka luar ================= */
const CT=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0;}return t;})();
const crc=u=>{let c=-1;for(let i=0;i<u.length;i++)c=CT[(c^u[i])&255]^(c>>>8);return(c^-1)>>>0;};
function zip(files){const enc=new TextEncoder(),parts=[],cen=[];let off=0;
 files.forEach(f=>{const nm=enc.encode(f.name),d=f.data,c=crc(d),lh=new DataView(new ArrayBuffer(30));
  lh.setUint32(0,0x04034b50,true);lh.setUint16(4,20,true);lh.setUint16(6,0x0800,true);lh.setUint16(12,0x21,true);lh.setUint32(14,c,true);lh.setUint32(18,d.length,true);lh.setUint32(22,d.length,true);lh.setUint16(26,nm.length,true);
  const ch=new DataView(new ArrayBuffer(46));ch.setUint32(0,0x02014b50,true);ch.setUint16(4,20,true);ch.setUint16(6,20,true);ch.setUint16(8,0x0800,true);ch.setUint16(14,0x21,true);ch.setUint32(16,c,true);ch.setUint32(20,d.length,true);ch.setUint32(24,d.length,true);ch.setUint16(28,nm.length,true);ch.setUint32(42,off,true);
  parts.push(lh,nm,d);cen.push(ch,nm);off+=30+nm.length+d.length;});
 const cs=cen.reduce((t,x)=>t+x.byteLength,0),end=new DataView(new ArrayBuffer(22));end.setUint32(0,0x06054b50,true);end.setUint16(8,files.length,true);end.setUint16(10,files.length,true);end.setUint32(12,cs,true);end.setUint32(16,off,true);
 return new Blob([...parts,...cen,end],{type:"application/zip"});}
const loadImg=svg=>new Promise((ok,no)=>{const u=URL.createObjectURL(new Blob([svg],{type:"image/svg+xml;charset=utf-8"})),im=new Image();im.onload=()=>{URL.revokeObjectURL(u);ok(im);};im.onerror=()=>{URL.revokeObjectURL(u);no(new Error("gagal merender"));};im.src=u;});
const blobOf=(cv,type,q)=>new Promise(ok=>cv.toBlob(ok,type,q));
const bytes=async b=>new Uint8Array(await b.arrayBuffer());
const nm=()=>String(S.projectName||"desain").replace(/[^\w-]+/g,"_").slice(0,40)||"desain";
const sc=()=>S.expScale||2;
const lim=(w,h,s)=>Math.min(s,Math.sqrt(36e6/Math.max(1,w*h)));
async function raster(svg,w,h,s,type,q,sq){const im=await loadImg(svg),f=lim(w,h,s),cv=document.createElement("canvas");
 if(sq){cv.width=cv.height=sq;const g=cv.getContext("2d"),k=Math.min(sq/w,sq/h);g.drawImage(im,(sq-w*k)/2,(sq-h*k)/2,w*k,h*k);}
 else{cv.width=Math.max(1,Math.round(w*f));cv.height=Math.max(1,Math.round(h*f));cv.getContext("2d").drawImage(im,0,0,cv.width,cv.height);}
 return blobOf(cv,type||"image/png",q);}
const pages=()=>{if(CDMS.Pages&&CDMS.Pages.sync)CDMS.Pages.sync();return S.pages&&S.pages.length&&S.pages[0]?S.pages:[{objects:S.objects,page:S.page}];};
const busy=async(msg,fn)=>{T(msg);try{await fn();}catch(e){T("Ekspor gagal: "+(e&&e.message||e));}};
const save=(b,name)=>{CDMS.Export.download(b,name);T("Diunduh: "+name+" ("+Math.max(1,Math.round(b.size/1024))+" KB)");};
function objSvg(o){const r=rotBox(o),p=8,x=r.x0-p,y=r.y0-p,w=Math.max(1,r.x1-r.x0+p*2),h=Math.max(1,r.y1-r.y0+p*2);return{svg:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${x} ${y} ${w} ${h}" width="${w}" height="${h}">${C.objMarkup(o)}</svg>`,w,h};}
const zObjects=()=>busy("Menyiapkan ZIP objek…",async()=>{const a=S.objects.filter(o=>!o.hidden).slice(0,80);if(!a.length)return T("Tidak ada objek");const f=[];
 for(let i=0;i<a.length;i++){const{svg,w,h}=objSvg(a[i]),b=await raster(svg,w,h,sc());f.push({name:String(i+1).padStart(2,"0")+"_"+String(a[i].name||a[i].type).replace(/[^\w-]+/g,"_").slice(0,24)+".png",data:await bytes(b)});}
 save(zip(f),nm()+"_objek.zip");});
const zPages=full=>busy("Menyiapkan ZIP halaman…",async()=>{const pg=pages(),f=[],p2=n=>String(n).padStart(2,"0");
 for(let i=0;i<pg.length;i++){const w=pg[i].page.width,h=pg[i].page.height,svg=M.pageSvg(pg[i],false);f.push({name:"halaman_"+p2(i+1)+".png",data:await bytes(await raster(svg,w,h,sc()))});
  if(full)f.push({name:"halaman_"+p2(i+1)+".svg",data:new TextEncoder().encode(svg)});}
 if(full)f.push({name:nm()+".cdms",data:new TextEncoder().encode(JSON.stringify({name:S.projectName,width:W(),height:H(),background:S.page.background,objects:S.objects,...(pg.length>1?{pages:pg,pageIdx:S.pageIdx}:{})},null,1))});
 save(zip(f),nm()+(full?"_paket_lengkap":"_halaman")+".zip");});
const zIcons=()=>busy("Membuat paket ikon…",async()=>{const svg=M.pageSvg(pages()[S.pageIdx||0]||pages()[0],false),w=W(),h=H(),f=[];
 for(const z of [16,32,48,64,128,180,192,256,512])f.push({name:"icon-"+z+".png",data:await bytes(await raster(svg,w,h,1,"image/png",1,z))});save(zip(f),nm()+"_ikon.zip");});
const webp=()=>busy("Menyiapkan WebP…",async()=>{const b=await raster(M.pageSvg({objects:S.objects,page:S.page},false),W(),H(),sc(),"image/webp",.92);if(!b||b.type!=="image/webp")return T("Peramban ini tidak mendukung WebP");save(b,nm()+".webp");});
const copySvg=async()=>{try{await navigator.clipboard.writeText(M.pageSvg({objects:S.objects,page:S.page},false));T("Kode SVG disalin");}catch(e){T("Salin gagal: izin clipboard ditolak");}};
function palette(fmt){const c={};S.objects.forEach(o=>{[o.fill,o.stroke].forEach(v=>{if(/^#[0-9a-f]{3,8}$/i.test(v||""))c[v.toLowerCase()]=(c[v.toLowerCase()]||0)+1;});});
 if(/^#/.test(S.page.background||""))c[S.page.background.toLowerCase()]=(c[S.page.background.toLowerCase()]||0)+1;const l=Object.entries(c).sort((a,b)=>b[1]-a[1]).map(x=>x[0]);if(!l.length)return T("Tidak ada warna hex di desain");
 const txt=fmt==="css"?":root{\n"+l.map((x,i)=>`  --warna-${i+1}: ${x};`).join("\n")+"\n}\n":JSON.stringify(l,null,2);save(new Blob([txt],{type:"text/plain"}),nm()+(fmt==="css"?"_warna.css":"_warna.json"));}
MENUS.ekspor2=()=>[
 {h:"Skala ekspor untuk menu ini",items:[1,2,3,4].map(n=>tc(n+"×",()=>{S.expScale=n;},{keep:1,on:sc()===n}))},
 {h:"Paket ZIP",items:[it("Tiap objek jadi PNG (ZIP)",zObjects,"export"),it("Semua halaman PNG (ZIP)",()=>zPages(false),"export"),it("Paket lengkap: PNG + SVG + proyek (ZIP)",()=>zPages(true),"save"),it("Paket ikon aplikasi 16–512 px (ZIP)",zIcons,"star")]},
 {h:"Format lain",items:[it("WebP (hemat ukuran)",webp,"export"),it("Salin kode SVG halaman",copySvg,"copy"),it("Palet warna desain (.css)",()=>palette("css"),"color"),it("Palet warna desain (.json)",()=>palette("json"),"color")]}];

BT.push(["templat","layout","Templat"],["generatif","dice","Generatif"],["ekspor2","export","Ekspor+"]);
hubAdd("buat","templat");hubAdd("pustaka","generatif");hubAdd("berkas","ekspor2");
M.zip=zip;M.raster=raster;M.busy=busy;
})();
