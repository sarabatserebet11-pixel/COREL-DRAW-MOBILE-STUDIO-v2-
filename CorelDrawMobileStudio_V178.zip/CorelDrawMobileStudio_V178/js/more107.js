/* V121: Titik kurva. Ketuk tepi garis atau bentuk apa pun untuk menambah titik, lalu seret titik itu untuk melengkungkannya.
   Bentuk dasar (garis, persegi, elips, bintang, poligon) otomatis diubah jadi path; titik baru berupa simpul halus,
   jadi tepi yang tadinya lurus langsung melengkung. Memakai editor simpul V36 (more23.js): simpul putih dan
   titik kontrol kuning tetap bisa diseret. Satu Undo membatalkan satu titik beserta lengkungannya. */
(()=>{
const S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,M=CDMS.Menus,N=CDMS.Nodes,NS="http://www.w3.org/2000/svg",{MENUS,T,it,sels}=M;
if(!N||!C||!MENUS||!MENUS.node)return;
const $=(s,r=document)=>r.querySelector(s);
const L=(p,q,t)=>[p[0]+(q[0]-p[0])*t,p[1]+(q[1]-p[1])*t];
const cur=()=>{const ne=S.nodeEdit;return ne?{ne,o:S.objects.find(x=>x.id===ne.id)}:{};};
const pxScale=()=>{const w=C.svg.getBoundingClientRect().width||S.page.width;return Math.max(.2,S.page.width/w);};

/* ---- tepi path: setiap segmen L/C, ditambah garis penutup implisit (Z) bila ujungnya tak berimpit ---- */
function edges(segs){const out=[];let cp=null,sp=null;
 segs.forEach((s,i)=>{
  if(s.c==="M"){cp=sp=s.p[0];}
  else if(s.c==="L"||s.c==="C"){out.push({i,a:cp,s});cp=N.anchor(segs,i);}
  else if(s.c==="Z"){if(cp&&sp&&(Math.abs(cp[0]-sp[0])>1e-6||Math.abs(cp[1]-sp[1])>1e-6))out.push({i,a:cp,s,closing:true,b:sp});cp=sp;}});
 return out;}
const bz=(a,b,c,d,t)=>{const u=1-t,w0=u*u*u,w1=3*u*u*t,w2=3*u*t*t,w3=t*t*t;return[w0*a[0]+w1*b[0]+w2*c[0]+w3*d[0],w0*a[1]+w1*b[1]+w2*c[1]+w3*d[1]];};
function near(p,q,r){const dx=r[0]-q[0],dy=r[1]-q[1],l=dx*dx+dy*dy,u=l?Math.max(0,Math.min(1,((p[0]-q[0])*dx+(p[1]-q[1])*dy)/l)):0,x=q[0]+dx*u,y=q[1]+dy*u;return{u,d:Math.hypot(p[0]-x,p[1]-y),x,y};}

/* cari titik di tepi yang paling dekat dengan (X,Y) (koordinat halaman) dalam jarak thr */
function hit(o,ne,X,Y,thr,k){const P=q=>N.toPage(o,q[0],q[1]),pt=[X,Y];let best=null;
 const take=(e,t,r,x,y)=>{if(r<=thr&&(!best||r<best.r))best={e,t,r,x,y};};
 edges(ne.segs).forEach(e=>{
  if(e.s.c==="C"){const a=P(e.a),c1=P(e.s.p[0]),c2=P(e.s.p[1]),b=P(e.s.p[2]),n=40;let pv=a;
   for(let j=1;j<=n;j++){const q=bz(a,c1,c2,b,j/n),h=near(pt,pv,q);take(e,(j-1+h.u)/n,h.d,h.x,h.y);pv=q;}}
  else{const a=P(e.a),b=P(e.closing?e.b:e.s.p[0]),h=near(pt,a,b);take(e,h.u,h.d,h.x,h.y);}});
 if(!best)return null;
 /* terlalu dekat dengan simpul yang sudah ada: biarkan editor simpul biasa yang menangani */
 const ends=[best.e.a,best.e.closing?best.e.b:N.anchor(ne.segs,best.e.i)].map(P);
 if(ends.some(q=>Math.hypot(q[0]-best.x,q[1]-best.y)<9*k))return null;
 return best;}

/* sisipkan simpul halus di posisi t pada tepi h.e; kembalikan indeks segmen yang berujung di simpul baru */
function insert(ne,h){const segs=ne.segs;let i=h.e.i;
 if(h.e.closing)segs.splice(i,0,{c:"L",p:[h.e.b.slice()]});
 const s=segs[i],a=h.e.a,t=Math.max(.02,Math.min(.98,h.t));
 if(s.c==="L"){const b=s.p[0],m=L(a,b,t),dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy)||1,ux=dx/len,uy=dy/len,l1=Math.hypot(m[0]-a[0],m[1]-a[1]),l2=Math.hypot(b[0]-m[0],b[1]-m[1]);
  segs.splice(i,1,{c:"C",p:[L(a,m,1/3),[m[0]-ux*l1/3,m[1]-uy*l1/3],m]},{c:"C",p:[[m[0]+ux*l2/3,m[1]+uy*l2/3],L(b,m,1/3),b]});}
 else{const[c1,c2,b]=s.p,p01=L(a,c1,t),p12=L(c1,c2,t),p23=L(c2,b,t),p012=L(p01,p12,t),p123=L(p12,p23,t),m=L(p012,p123,t);
  segs.splice(i,1,{c:"C",p:[p01,p012,m]},{c:"C",p:[p123,p23,b]});}
 return i;}

/* ---- geser simpul; di path tertutup, simpul awal dan akhir yang berimpit ikut bergerak bersama ---- */
function place(segs,i,q,dx,dy){const s=segs[i],mv=p=>{p[0]+=dx;p[1]+=dy;};
 if(s.c==="C"){mv(s.p[1]);s.p[2]=q.slice();}else s.p[0]=q.slice();
 const nx=segs[i+1];if(nx&&nx.c==="C")mv(nx.p[0]);}
function moveNode(d,ne,q){const segs=ne.segs,i=d.i,last=segs.length-2;
 if(d.tie===undefined){d.tie=false;
  if(segs[segs.length-1].c==="Z"&&segs.filter(s=>s.c==="M").length===1&&last>0&&(i===0||i===last)){
   const a=segs[0].p[0],b=N.anchor(segs,last);d.tie=Math.abs(a[0]-b[0])<1e-6&&Math.abs(a[1]-b[1])<1e-6;}}
 const old=N.anchor(segs,i),dx=q[0]-old[0],dy=q[1]-old[1];
 place(segs,i,q,dx,dy);
 if(d.tie)place(segs,i===0?last:0,q,dx,dy);}

/* ---- sorotan garis + pratinjau titik saat mode aktif ---- */
const dov=C.drawOverlay;
C.drawOverlay=function(){dov.call(this);const ne=S.nodeEdit;if(!ne||!ne.bend)return;const o=S.objects.find(x=>x.id===ne.id);if(!o||S.selected!==o.id)return;
 const ov=document.getElementById("overlayLayer");if(!ov)return;const g=N.G(o);
 ov.insertAdjacentHTML("afterbegin",`<path d="${N.build(ne.segs)}" transform="translate(${o.x-g.px*g.sx} ${o.y-g.py*g.sy}) scale(${g.sx} ${g.sy})" fill="none" stroke="#7b6cff" stroke-opacity=".28" stroke-width="14" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke" pointer-events="none"/>`);};
function ghost(cv,e){const{ne,o}=cur(),ov=document.getElementById("cdNodes");if(!ne||!ne.bend||!o||!ov)return;
 let g=document.getElementById("cdGhost");if(!g){g=document.createElementNS(NS,"circle");g.id="cdGhost";g.setAttribute("fill","#7b6cff");g.setAttribute("fill-opacity",".35");g.setAttribute("stroke","#7b6cff");g.setAttribute("pointer-events","none");ov.appendChild(g);}
 const p=cv.point(e),k=pxScale(),h=hit(o,ne,p.x,p.y,10*k,k);
 if(!h){g.setAttribute("display","none");return;}
 g.removeAttribute("display");g.setAttribute("cx",h.x);g.setAttribute("cy",h.y);g.setAttribute("r",6*k);g.setAttribute("stroke-width",2*k);}

/* ---- pointer: ketuk tepi = tambah titik + langsung seret ---- */
const pd=C.pointerDown,pm=C.pointerMove;
C.pointerDown=function(e){const{ne,o}=cur();
 if(ne&&ne.bend&&o&&e.button===0&&!(e.target.closest&&e.target.closest("[data-node],[data-ctl],[data-h]"))){
  const p=this.point(e),k=pxScale(),h=hit(o,ne,p.x,p.y,(e.pointerType==="mouse"?10:18)*k,k);
  if(h){Hi.snapshot();const i=insert(ne,h);ne.sel=i;o.d=N.build(ne.segs);
   const m=N.anchor(ne.segs,i),q=N.toLocal(o,p.x,p.y);
   S.drag={mode:"node",kind:"n",i,bend:true,dirty:true,off:[m[0]-q[0],m[1]-q[1]]};
   try{this.svg.setPointerCapture&&this.svg.setPointerCapture(e.pointerId);}catch(_){}this.render();return;}}
 pd.call(this,e);};
C.pointerMove=function(e){const d=S.drag;
 if(d&&d.mode==="node"&&d.kind==="n"){const{ne,o}=cur();if(!ne||!o)return;const p=this.point(e),q=N.toLocal(o,p.x,p.y);
  if(d.off){q[0]+=d.off[0];q[1]+=d.off[1];}
  moveNode(d,ne,q);o.d=N.build(ne.segs);d.dirty=true;this.render();return;}
 if(!d&&e.pointerType==="mouse")ghost(this,e);
 pm.call(this,e);};
/* sebelum pendengar lain: rapikan kotak objek setelah seretan titik kurva */
window.addEventListener("pointerup",()=>{const d=S.drag;if(d&&d.mode==="node"&&d.bend&&d.dirty){d.dirty=false;N.tidy();setTimeout(()=>C.render(),0);}},true);

/* ---- memulai / mengakhiri mode ---- */
function start(){const o=sels()[0];if(!o)return T("Pilih garis atau bentuk dulu");
 if(o.locked)return T("Objek terkunci. Buka kunci dulu");
 if(o.rotation||o.flipH||o.flipV)return T("Setel rotasi ke 0 dan batalkan balik dulu");
 if(["rect","ellipse","star","polygon","line"].includes(o.type)){S.selected=o.id;S.selectedIds=[o.id];N.toCurves();}
 else if(o.type!=="path")return T("Titik kurva untuk garis, bentuk, dan path (teks dan gambar belum bisa)");
 const segs=N.parse(o.d);if(!segs)return T("Path memakai busur (arc) dan belum didukung");
 N.norm(o);const tl=$('.tool[data-tool="select"]');if(S.tool!=="select"&&tl)tl.click();
 S.nodeEdit={id:o.id,segs,sel:null,bend:true};S.selected=o.id;S.selectedIds=[o.id];C.render();
 T("Ketuk garis untuk menambah titik, lalu seret untuk melengkungkan");}
function stop(){if(S.nodeEdit&&S.nodeEdit.bend){S.nodeEdit=null;C.render();}}

/* bilah petunjuk + tombol Selesai (berguna di HP) */
function bar(){let b=$("#cdBendBar");const on=S.nodeEdit&&S.nodeEdit.bend,host=$(".canvas-area");
 if(!on){if(b)b.remove();return;}
 if(!host)return;
 if(!b){b=document.createElement("div");b.id="cdBendBar";b.innerHTML='<span>Titik kurva: ketuk garis, lalu seret</span><button type="button" data-k="del">Hapus titik</button><button type="button" data-k="ok">Selesai</button>';
  b.addEventListener("pointerdown",e=>e.stopPropagation());
  b.addEventListener("click",e=>{const k=e.target.closest("button");if(!k)return;
   if(k.dataset.k==="ok")stop();
   else{N.del();}});
  host.appendChild(b);}}
const rr=C.render;C.render=function(){const x=rr.apply(this,arguments);bar();return x;};
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&S.nodeEdit&&S.nodeEdit.bend&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName||"")&&!document.querySelector(".ctx-menu,.modal"))stop();});

/* ---- menu ---- */
const base=MENUS.node;
MENUS.node=()=>[{h:"Titik kurva (baru)",items:[it("Tambah titik kurva di garis / bentuk",start,"pen"),it("Selesai titik kurva",stop,"eye")]},...base()];
CDMS.Bend={start,stop};
})();
