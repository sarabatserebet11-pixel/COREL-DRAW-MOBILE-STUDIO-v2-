/* V52: menu Komponen UI - tombol, chip, toggle, input, avatar, progres, rating, pencarian, kartu statistik, kartu produk, tab bar, lencana */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,pick,T,it}=M,uid=()=>crypto.randomUUID(),r0=Math.round;
const hubAdd=(n,...k)=>M.HUBS.find(h=>h[0]===n)[3].push(...k);
const W=()=>S.page.width,H=()=>S.page.height;
const AC="#6d5dfc",INK="#20243a",MUTE="#8a93ad",LINE="#cfd6e6";
const R=(x,y,w,h,fill,o)=>({type:"rect",x,y,w,h,fill,rx:0,...o});
const E=(x,y,w,h,fill,o)=>({type:"ellipse",x,y,w,h,fill,...o});
const P=(x,y,w,h,d,fill,o)=>({type:"path",x,y,w,h,vw:100,vh:100,d,fill,...o});
/* teks: cx,cy = titik tengah (default) atau kiri (left:true) */
/* V64: lebar teks diukur dengan canvas (bukan perkiraan 0,58 × panjang) agar teks benar-benar di tengah */
const _cv=document.createElement("canvas").getContext("2d");
const mw=(t,fs,b)=>{try{_cv.font=(b?"700 ":"400 ")+fs+"px Arial, sans-serif";return Math.max(...String(t).split("\n").map(l=>_cv.measureText(l).width));}catch(e){return String(t).length*fs*.58;}};
const X=(txt,cx,cy,fs,fill,o={})=>({type:"text",text:txt,x:cx,y:cy-fs*.7,w:Math.max(20,r0(mw(txt,fs,o.bold))),h:r0(fs*1.4),fontSize:fs,fill,bold:!!o.bold,fontFamily:"Arial, sans-serif",_cx:o.left?null:cx,_cy:cy,...o});
const STAR="M50 5L61 38H96L67 59L78 93L50 72L22 93L33 59L4 38H39Z";
const COMP={
 "Tombol utama":()=>({w:320,h:88,a:[R(0,0,320,88,AC,{rx:44,name:"Tombol"}),X("Mulai",160,44,32,"#ffffff",{bold:1})]}),
 "Tombol garis":()=>({w:320,h:88,a:[R(0,0,320,88,"none",{rx:44,stroke:AC,strokeWidth:4,name:"Tombol garis"}),X("Pelajari",160,44,32,AC,{bold:1})]}),
 "Chip / tag":()=>({w:200,h:60,a:[R(0,0,200,60,"#ece9ff",{rx:30,name:"Chip"}),X("Desain",100,30,26,AC,{bold:1})]}),
 "Toggle aktif":()=>({w:120,h:64,a:[R(0,0,120,64,AC,{rx:32,name:"Toggle"}),E(62,6,52,52,"#ffffff")]}),
 "Toggle mati":()=>({w:120,h:64,a:[R(0,0,120,64,"#d5daea",{rx:32,name:"Toggle"}),E(6,6,52,52,"#ffffff")]}),
 "Kolom isian":()=>({w:480,h:88,a:[R(0,0,480,88,"#ffffff",{rx:18,stroke:LINE,strokeWidth:3,name:"Isian"}),X("Ketik di sini…",28,44,28,MUTE,{left:1})]}),
 "Kolom pencarian":()=>({w:480,h:84,a:[R(0,0,480,84,"#f1f3fa",{rx:42,name:"Pencarian"}),E(28,26,26,26,"none",{stroke:MUTE,strokeWidth:4}),P(48,46,16,16,"M5 5L95 95","none",{stroke:MUTE,strokeWidth:20}),X("Cari…",84,42,28,MUTE,{left:1})]}),
 "Avatar":()=>({w:130,h:130,a:[E(0,0,130,130,"#ece9ff",{name:"Avatar"}),E(43,24,44,44,AC),P(25,72,80,50,"M0 100Q0 20 50 20Q100 20 100 100Z",AC)]}),
 "Bilah progres":()=>({w:480,h:56,a:[R(0,16,480,24,"#e3e7f3",{rx:12,name:"Progres"}),R(0,16,312,24,AC,{rx:12}),X("65%",480,28,22,INK,{left:1,x:488,bold:1})]}),
 "Rating bintang":()=>({w:360,h:64,a:[0,1,2,3,4].map(i=>P(i*72,0,64,64,STAR,i<4?"#ffc857":"#d5daea",{name:"Bintang "+(i+1)}))}),
 "Lencana notifikasi":()=>({w:56,h:56,a:[E(0,0,56,56,"#ff4f6d",{stroke:"#ffffff",strokeWidth:4,name:"Lencana"}),X("3",28,28,26,"#ffffff",{bold:1})]}),
 "Kartu statistik":()=>({w:360,h:200,a:[R(0,0,360,200,"#ffffff",{rx:28,stroke:"#00000018",strokeWidth:3,name:"Kartu statistik"}),X("Pengunjung",28,44,24,MUTE,{left:1}),X("12.480",28,108,56,INK,{left:1,bold:1}),R(28,142,120,36,"#dcfce7",{rx:18}),X("▲ 12%",88,160,22,"#15803d",{bold:1})]}),
 "Kartu produk":()=>({w:360,h:470,a:[R(0,0,360,470,"#ffffff",{rx:28,stroke:"#00000018",strokeWidth:3,name:"Kartu produk"}),R(20,20,320,260,"#e8ecf8",{rx:20}),X("Nama produk",24,320,32,INK,{left:1,bold:1}),X("Rp 99.000",24,370,28,AC,{left:1,bold:1}),R(24,402,312,50,AC,{rx:25}),X("Beli",180,427,24,"#ffffff",{bold:1})]}),
 "Tab bar bawah":()=>({w:520,h:100,a:[R(0,0,520,100,"#ffffff",{rx:50,stroke:"#00000018",strokeWidth:3,name:"Tab bar"}),...[0,1,2,3].map(i=>E(40+i*120,26,48,48,i===0?AC:"#d5daea",{name:"Tab "+(i+1)}))]})
};
function place(name){const c=COMP[name]();Hi.snapshot();const g=uid(),ox=r0((W()-c.w)/2),oy=r0((H()-c.h)/2),out=[];
 c.a.forEach(s=>{const o={id:uid(),groupId:g,opacity:100,rotation:0,stroke:"none",strokeWidth:0,name:name,...s,x:ox+r0(s.x),y:oy+r0(s.y),w:r0(s.w),h:r0(s.h)};if(s.x2!=null)delete o.x2;out.push(o);});
 S.objects.push(...out);C.render();
 out.filter(o=>o.type==="text").forEach(o=>{if(o._cx!=null)o.x=r0(ox+o._cx-(o.w||0)/2);o.y=r0(oy+o._cy-(o.h||0)/2);delete o._cx;delete o._cy;delete o.left;});
 C.render();pick(out);T(name+" ditambahkan");}
MENUS.komponen=()=>[
 {h:"Tombol & kontrol",items:["Tombol utama","Tombol garis","Chip / tag","Toggle aktif","Toggle mati"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Isian & navigasi",items:["Kolom isian","Kolom pencarian","Tab bar bawah"].map(n=>it(n,()=>place(n),"rect"))},
 {h:"Tampilan data",items:["Avatar","Bilah progres","Rating bintang","Lencana notifikasi","Kartu statistik","Kartu produk"].map(n=>it(n,()=>place(n),"rect"))}];
BT.push(["komponen","component","Komponen UI"]);
hubAdd("pustaka","komponen");
CDMS.UIKit={COMP,place,R,E,P,X,STAR,AC,INK,MUTE,LINE};
})();
