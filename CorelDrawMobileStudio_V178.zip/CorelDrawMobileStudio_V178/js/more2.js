/* V15: menu Kurva, Foto, Pilih, Kanvas + perataan & tinggi baris teks */
(()=>{
const M=CDMS.Menus,S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,{MENUS,BT,edit,sels,pick,T,it,tc,cell}=M,uid=()=>crypto.randomUUID(),W=()=>S.page.width,H=()=>S.page.height;

/* ---- renderer: masker foto, perataan teks, tinggi baris ---- */
const HEART="M50 88C10 58 6 34 22 20C34 10 46 16 50 28C54 16 66 10 78 20C94 34 90 58 50 88Z",HEX="M50 4L91 27V73L50 96L9 73V27Z";
const om=C.objMarkup;
C.objMarkup=function(o){let s=om.call(this,o);
 if(o.mask&&o.type==="image"){const w=o.w,h=o.h,id="cp-"+o.id,sc=`transform="scale(${w/100} ${h/100})"`,
  cp={circle:`<ellipse cx="${w/2}" cy="${h/2}" rx="${w/2}" ry="${h/2}"/>`,round:`<rect width="${w}" height="${h}" rx="${Math.min(w,h)*.18}"/>`,star:`<polygon points="${C.starPoints(w,h)}"/>`,heart:`<path ${sc} d="${HEART}"/>`,hex:`<path ${sc} d="${HEX}"/>`}[o.mask];
  if(cp)s=s.replace("<image ",`<image clip-path="url(#${id})" `).replace(">",`><clipPath id="${id}">${cp}</clipPath>`);}
 if(o.type==="text"&&(o.align||o.lh)){const k=(o.lh||1.2)/1.2,al=o.align;
  s=s.replace(/<tspan x="0" y="([\d.]+)"/g,(m,y)=>{const yy=+(y*k).toFixed(2);return al==="center"?`<tspan x="${o.w/2}" y="${yy}" text-anchor="middle"`:al==="right"?`<tspan x="${o.w}" y="${yy}" text-anchor="end"`:`<tspan x="0" y="${yy}"`;});}
 return s;};

/* ---- kurva & garis ---- */
const COL=["#6d5dfc","#00d6c9","#ff6b6b","#ffc857","#4f83ff","#ff7ac8"];let ci=0;
const CUR=[["Panah lurus","M4 50H90M70 30L92 50L70 70"],["Panah melengkung","M6 80C10 20 60 10 88 40M70 34L90 42L82 62"],["Gelombang","M2 50C14 20 26 20 38 50S62 80 74 50S92 25 98 50"],["Zigzag","M4 70L22 30L40 70L58 30L76 70L94 30"],["Spiral","M50 50a4 4 0 0 1 8 0a9 9 0 0 1 -18 0a14 14 0 0 1 28 0a19 19 0 0 1 -38 0a24 24 0 0 1 48 0a29 29 0 0 1 -58 0"],["Busur","M8 70A42 42 0 0 1 92 70"],["Kurung kurawal","M62 6C40 6 54 44 34 50C54 56 40 94 62 94"],["Kilat","M60 4L26 54H48L40 96L76 40H54Z"]];
function addCurve(n,d){Hi.snapshot();const z=Math.round(Math.min(W(),H())*.3),o={id:uid(),type:"path",name:n,x:Math.round((W()-z)/2),y:Math.round((H()-z)/2),w:z,h:z,vw:100,vh:100,d,fill:"none",stroke:COL[ci++%6],strokeWidth:8,opacity:100,rotation:0};S.objects.push(o);pick([o]);}

/* ---- foto ---- */
const img=o=>o.type==="image",FX=[["Retro","sepia(.4) hue-rotate(-20deg) saturate(1.4)"],["Dramatis","contrast(1.5) brightness(.85) saturate(1.2)"],["Pastel","brightness(1.15) saturate(.7) contrast(.9)"],["Matte","contrast(.85) brightness(1.1)"],["Noir","grayscale(1) contrast(1.5)"],["Hue +90°","hue-rotate(90deg)"]];

/* ---- pilih ---- */
const vis=()=>S.objects.filter(o=>!o.hidden&&!o.locked),one=()=>{const a=sels()[0];if(!a)T("Pilih satu objek dulu");return a;};
const outside=()=>S.objects.filter(o=>o.x+o.w<0||o.y+(o.h||0)<0||o.x>W()||o.y>H());
function rm(list){if(!list.length)return T("Tidak ada objek di luar kanvas");Hi.snapshot();const s=new Set(list.map(o=>o.id));S.objects=S.objects.filter(o=>!s.has(o.id));S.selected=null;S.selectedIds=[];C.render();T(list.length+" objek dihapus");}
function isolate(){const a=sels();if(!a.length)return T("Pilih objek dulu");Hi.snapshot();const s=new Set(a.map(o=>o.id));S.objects.forEach(o=>{if(!s.has(o.id))o.hidden=true;});C.render();}

/* ---- kanvas ---- */
function setCanvas(w,h){const ow=W(),oh=H();if(w===ow&&h===oh)return;Hi.snapshot();const s=Math.min(w/ow,h/oh),dx=(w-ow*s)/2,dy=(h-oh*s)/2;
 S.objects.forEach(o=>{o.x=Math.round(o.x*s+dx);o.y=Math.round(o.y*s+dy);o.w=Math.max(1,Math.round(o.w*s));o.h=Math.round((o.h||0)*s);if(o.fontSize)o.fontSize=Math.max(1,Math.round(o.fontSize*s));if(o.strokeWidth)o.strokeWidth=+(o.strokeWidth*s).toFixed(2);});
 S.page.width=w;S.page.height=h;C.render();T("Kanvas "+w+" × "+h);}
const bg=c=>{Hi.snapshot();S.page.background=c;C.render();};
const SZ=[["IG Post 4:5",1080,1350],["Story / WA",1080,1920],["YouTube",1280,720],["FB Cover",1640,624],["X Header",1500,500],["Kartu nama",1050,600],["A4",2480,3508],["Persegi",1080,1080]];
const BGC=["#ffffff","#f5f3ef","#10131c","#20243a","#6d5dfc","#00b8c9","#ff6b6b","#ffc857","#3ddc84","#ff7ac8","#4f83ff","#000000"];
const GRD=[["Cyber","#10131c,#00d6c9"],["Galaxy","#1a103d,#ff4f9a"],["Sunset","#ff9966,#6a3093"],["Clean","#f5f3ef,#b9d6d3"]];

/* ---- menu ---- */
MENUS.curve=()=>[{h:"Kurva & garis",items:CUR.map((c,i)=>cell(`<svg class="s" viewBox="0 0 100 100"><path d="${c[1]}" fill="none" stroke="${COL[i%6]}" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/></svg><span>${c[0]}</span>`,()=>addCurve(c[0],c[1])))}]; 
MENUS.photo=()=>[
 {h:"Masker bentuk",items:[["Bulat","circle"],["Rounded","round"],["Bintang","star"],["Hati","heart"],["Segi enam","hex"],["Tanpa masker",""]].map(x=>tc(x[0],()=>edit(o=>{if(x[1])o.mask=x[1];else delete o.mask;},"",img)))},
 {h:"Filter cepat",items:FX.map(f=>it(f[0],()=>edit(o=>{o.imgFx=f[1];}),"image"))},
 {h:"Efek foto",items:[it("Bayangan foto",()=>edit(o=>{o.fx="shadow";o.fxAmount=18;},"",img),"image"),it("Glow foto",()=>edit(o=>{o.fx="glow";o.fxAmount=14;o.fxColor="#00d6c9";},"",img),"image"),it("Transparan 60%",()=>edit(o=>{o.opacity=60;},"",img),"eye"),it("Hapus filter & efek",()=>edit(o=>{delete o.imgFx;delete o.fx;o.opacity=100;},"",img),"trash")]}];
MENUS.sel=()=>[
 {h:"Pilih berdasarkan",items:[it("Jenis sama",()=>{const a=one();if(a)pick(vis().filter(o=>o.type===a.type));},"select"),it("Warna isi sama",()=>{const a=one();if(a)pick(vis().filter(o=>o.fill===a.fill));},"color"),it("Balik pilihan",()=>{const s=new Set(sels().map(o=>o.id));pick(vis().filter(o=>!s.has(o.id)));},"multi"),it("Objek di luar kanvas",()=>{const l=outside();pick(l);T(l.length+" objek di luar kanvas");},"select")]},
 {h:"Rapikan",items:[it("Hapus objek di luar kanvas",()=>rm(outside()),"trash"),it("Sembunyikan yang lain (fokus)",isolate,"eyeoff"),it("Tampilkan semua",()=>{Hi.snapshot();S.objects.forEach(o=>{o.hidden=false;});C.render();},"eye"),it("Buka semua kunci",()=>{Hi.snapshot();S.objects.forEach(o=>{o.locked=false;});C.render();},"unlock")]}];
MENUS.canvas=()=>[
 {h:"Ukuran siap pakai",items:SZ.map(s=>cell(`<span>${s[0]}</span><small style="color:var(--muted);font-size:9px">${s[1]}×${s[2]}</small>`,()=>setCanvas(s[1],s[2])))},
 {h:"Orientasi",items:[it("Tukar tegak ↔ mendatar",()=>setCanvas(H(),W()),"redo")]},
 {h:"Warna latar",items:BGC.map(c=>cell(`<i style="background:${c};border:1px solid var(--line)"></i>`,()=>bg(c)))},
 {h:"Gradien latar",items:GRD.map(g=>tc(g[0],()=>bg("grad:"+g[1]+",d")))}];
const ot=MENUS.text;MENUS.text=()=>[...ot(),
 {h:"Perataan & baris",items:[["Rata kiri",""],["Rata tengah","center"],["Rata kanan","right"]].map(x=>tc(x[0],()=>edit(o=>{if(x[1])o.align=x[1];else delete o.align;},"",o=>o.type==="text"))).concat([["Rapat",1],["Normal",1.2],["Lega",1.6],["Luas",2]].map(x=>tc(x[0],()=>edit(o=>{o.lh=x[1];},"",o=>o.type==="text"))))}];
BT.push(["curve","curve","Kurva"],["photo","image","Foto"],["sel","select","Pilih"],["canvas","canvas","Kanvas"]);
})();
