/* Studio V8: satu tombol menggantikan Studio V4-V7 (Desain, Watermark, Efek, Kanvas, Alat) */
(()=>{
const NS="http://www.w3.org/2000/svg",$=s=>document.querySelector(s),S=CDMS.state,C=CDMS.Canvas,Hi=CDMS.History,N=CDMS.Navigation,E=CDMS.escape;
const uid=()=>crypto.randomUUID();
const sels=()=>(S.selectedIds&&S.selectedIds.length?S.selectedIds:(S.selected?[S.selected]:[])).map(id=>S.objects.find(o=>o.id===id)).filter(Boolean);
const pick=a=>{S.selectedIds=a.map(o=>o.id);S.selected=a[0]?a[0].id:null;C.render();};
const nm=()=>(S.projectName||"desain").replace(/[^\w-]+/g,"_");
const wrap=(t,n)=>{const out=[];let l="";t.split(/\s+/).filter(Boolean).forEach(w=>{if(l&&(l+" "+w).length>n){out.push(l);l=w;}else l=(l+" "+w).trim();});if(l)out.push(l);return out.join("\n");};

/* ----- efek (kompatibel dengan proyek V7 lama) ----- */
const filterFor=o=>{const t=o.fx||o.v7Effect,n=Number(o.fxAmount||o.v7EffectAmount)||12,c=o.fxColor||o.v7EffectColor||"#00d6c9";
 if(t==="shadow")return`drop-shadow(3px 5px ${Math.max(2,n/3)}px rgba(0,0,0,.45))`;if(t==="deep")return`drop-shadow(5px 7px ${Math.max(3,n/3)}px rgba(0,0,0,.65))`;
 if(t==="glow")return`drop-shadow(0 0 ${n}px ${c})`;if(t==="pink")return`drop-shadow(0 0 ${n}px #ff39bd)`;return"";};
const om=C.objMarkup;
C.objMarkup=function(o){const s=om.call(this,o),f=filterFor(o);return f?s.replace('style="cursor:',`style="filter:${f};cursor:`):s;};

/* ----- render: latar gradien + guide yang tersimpan benar ----- */
const rr=C.render;
C.render=function(){
 rr.call(this);
 const b=S.page.background||"",bg=$("#pageBackground");let d=this.svg.querySelector("#cdGrad");
 if(b.startsWith("grad:")){const[a,c,m]=b.slice(5).split(",");if(!d){d=document.createElementNS(NS,"defs");d.id="cdGrad";this.svg.insertBefore(d,this.svg.firstChild);}
  d.innerHTML=`<linearGradient id="cdPageGrad" x1="0" y1="0" x2="${m==="v"?0:1}" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${c}"/></linearGradient>`;bg.setAttribute("fill","url(#cdPageGrad)");}
 else if(d)d.remove();
 const old=this.svg.querySelector("#cdGuides");if(old)old.remove();
 if(S.guideOn){const W=S.page.width,H=S.page.height,m=(S.guideMargin||7)/100,g=document.createElementNS(NS,"g");g.id="cdGuides";g.setAttribute("pointer-events","none");
  g.innerHTML=`<rect x="${W*m}" y="${H*m}" width="${W*(1-2*m)}" height="${H*(1-2*m)}" fill="none" stroke="#ff4f9a" stroke-width="${Math.max(2,W*.002)}" stroke-dasharray="12 10"/><line x1="${W/2}" x2="${W/2}" y1="0" y2="${H}" stroke="#00aaff" stroke-width="${Math.max(1,W*.001)}" stroke-dasharray="8 12"/><line y1="${H/2}" y2="${H/2}" x1="0" x2="${W}" stroke="#00aaff" stroke-width="${Math.max(1,W*.001)}" stroke-dasharray="8 12"/>`;this.svg.appendChild(g);}
};

/* ----- ekspor (PNG/JPG/SVG, tanpa kotak seleksi & guide) ----- */
const clean=()=>{const sv=C.svg.cloneNode(true);["#overlayLayer","#cdGuides","#cdAid"].forEach(q=>{const e=sv.querySelector(q);if(e)e.remove();});sv.setAttribute("xmlns",NS);sv.setAttribute("width",S.page.width);sv.setAttribute("height",S.page.height);sv.removeAttribute("style");return sv;};
const raster=(type,scale,cb)=>{
 while(S.page.width*S.page.height*scale*scale>40e6&&scale>1)scale--;
 const url=URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(clean())],{type:"image/svg+xml;charset=utf-8"})),img=new Image();
 img.onload=()=>{try{const c=document.createElement("canvas");c.width=S.page.width*scale;c.height=S.page.height*scale;const x=c.getContext("2d");if(type==="image/jpeg"){x.fillStyle="#fff";x.fillRect(0,0,c.width,c.height);}x.drawImage(img,0,0,c.width,c.height);c.toBlob(b=>{URL.revokeObjectURL(url);cb(b);},type,.92);}catch(e){URL.revokeObjectURL(url);cb(null);}};
 img.onerror=()=>{URL.revokeObjectURL(url);cb(null);};img.src=url;};
CDMS.Export.svg=()=>CDMS.Export.download(new Blob([new XMLSerializer().serializeToString(clean())],{type:"image/svg+xml"}),nm()+".svg");
CDMS.Export.png=(sc,type)=>{type=type||"image/png";raster(type,sc||2,b=>b?CDMS.Export.download(b,nm()+(type==="image/png"?".png":".jpg")):CDMS.toast("Ekspor gagal. Coba skala lebih kecil atau SVG."));};
CDMS.Export.open=function(){
 N.openModal("Ekspor desain",`<div class="st-pane"><label>Skala<select id="exScale"><option value="1">1× (${S.page.width} × ${S.page.height})</option><option value="2" selected>2×</option><option value="3">3×</option></select></label><div class="st-grid"><button class="btn primary" id="exPng">PNG</button><button class="btn subtle" id="exJpg">JPG</button><button class="btn subtle" id="exSvg">SVG</button><button class="btn subtle" id="exBak">Cadangkan proyek</button></div></div>`);
 const sc=()=>Number($("#exScale").value)||2;
 $("#exPng").onclick=()=>CDMS.Export.png(sc());$("#exJpg").onclick=()=>CDMS.Export.png(sc(),"image/jpeg");$("#exSvg").onclick=()=>CDMS.Export.svg();
 $("#exBak").onclick=()=>CDMS.Storage.downloadJSON({name:S.projectName,width:S.page.width,height:S.page.height,background:S.page.background,objects:S.objects},nm()+".cdms");
};

/* ----- generator desain ----- */
const PAL={neon:{bg:"#10131c",fg:"#ffffff"},minimal:{bg:"#f5f3ef",fg:"#181818"},street:{bg:"#181018",fg:"#fff5dc"},sunset:{bg:"#24113b",fg:"#fff4d6"},royal:{bg:"#160b32",fg:"#f8edff"}};
function generate(){
 const W=S.page.width,H=S.page.height,st=$("#stStyle").value,kind=$("#stKind").value,a=$("#stAccent").value,{bg,fg}=PAL[st];
 const title=$("#stTitle").value.trim()||"JUDUL ANDA",sub=$("#stSub").value.trim(),fam=(st==="street"||kind==="promo")?"Impact, 'Arial Black', sans-serif":"Arial, sans-serif";
 Hi.snapshot();if($("#stClear").checked)S.objects=[];S.page.background=bg;
 const arr=[],add=o=>{const n={id:uid(),opacity:100,stroke:"none",strokeWidth:0,rotation:0,w:100,h:50,...o};arr.push(n);return n;};
 const txt=(name,t,x,y,size,fill,x2)=>add({type:"text",name,text:t,x,y,fontSize:size,fontFamily:fam,bold:true,fill,...x2});
 add({type:"rect",name:"Garis aksen",x:W*.07,y:H*.12,w:W*.86,h:H*.014,fill:a});
 if(kind==="promo"){add({type:"ellipse",name:"Disk",x:W*.63,y:H*.22,w:W*.28,h:W*.28,fill:a,opacity:28});txt("Label promo","SPECIAL OFFER",W*.08,H*.22,Math.max(20,W*.03),a);}
 else if(kind==="cover"){add({type:"rect",name:"Panel",x:W*.07,y:H*.2,w:W*.86,h:H*.55,fill:a,opacity:14});add({type:"star",name:"Bintang",x:W*.72,y:H*.23,w:W*.16,h:W*.16,fill:a});}
 else if(kind==="quote")txt("Tanda kutip","\u201C",W*.08,H*.14,W*.2,a);
 else{add({type:"ellipse",name:"Orb",x:W*.6,y:H*.2,w:Math.min(W,H)*.32,h:Math.min(W,H)*.32,fill:a,opacity:22});add({type:"star",name:"Bintang",x:W*.78,y:H*.17,w:W*.1,h:W*.1,fill:a,stroke:fg,strokeWidth:2});}
 const size=Math.round(Math.min(W*.105,H*.12)),tl=wrap(title,Math.max(6,Math.floor(W*.84/(size*.6)))),n=tl.split("\n").length;
 const main=txt("Judul utama",tl,W*.08,H*.34,size,fg,st==="neon"?{fx:"glow",fxColor:a,fxAmount:10}:{});
 if(sub){const ss=Math.round(Math.max(18,Math.min(W*.032,H*.04)));txt("Subjudul",wrap(sub,Math.max(10,Math.floor(W*.8/(ss*.6)))),W*.085,H*.34+size*1.2*n+size*.25,ss,a);}
 add({type:"rect",name:"Garis bawah",x:W*.08,y:H*.8,w:W*.34,h:H*.009,fill:a});
 txt("Footer","DESIGNED WITH MOBILE STUDIO",W*.08,H*.84,Math.max(14,W*.018),fg,{opacity:80});
 S.objects.push(...arr);S.projectName=title.slice(0,32);N.closeModal();pick([main]);
}
function quick(k){
 const W=S.page.width,H=S.page.height,a=$("#stAccent").value;Hi.snapshot();let o;
 if(k==="badge")o={type:"star",name:"Badge",x:W*.4,y:H*.4,w:W*.2,h:W*.2,fill:a,stroke:"#ffffff",strokeWidth:3};
 if(k==="label")o={type:"text",name:"Label",text:"LABEL ANDA",x:W*.1,y:H*.1,w:W*.5,h:70,fontSize:48,bold:true,fill:a};
 if(k==="frame")o={type:"rect",name:"Bingkai",x:W*.06,y:H*.06,w:W*.88,h:H*.88,fill:"none",stroke:a,strokeWidth:8};
 if(k==="divider")o={type:"line",name:"Garis",x:W*.1,y:H*.5,w:W*.8,h:0,fill:"none",stroke:a,strokeWidth:8};
 o.id=uid();o.opacity=100;o.rotation=0;S.objects.push(o);N.closeModal();pick([o]);
}

/* ----- watermark ----- */
function place(o,pos){const W=S.page.width,H=S.page.height,p=Math.min(W,H)*.035;
 o.x=Math.round(pos==="center"?(W-o.w)/2:pos.includes("l")?p:W-o.w-p);o.y=Math.round(pos==="center"?(H-o.h)/2:pos.includes("t")?p:H-o.h-p);}
function wmText(){
 const t=$("#wmText").value.trim();if(!t)return;Hi.snapshot();
 const o={id:uid(),type:"text",name:"Watermark teks",text:t,x:0,y:0,w:100,h:40,fontSize:num("#wmSize",28),fontFamily:"Arial, sans-serif",bold:true,fill:$("#wmColor").value,stroke:"none",strokeWidth:0,opacity:num("#wmOp",45),rotation:0};
 S.objects.push(o);S.selected=o.id;S.selectedIds=[o.id];C.render();place(o,$("#wmPos").value);N.closeModal();C.render();
}
function wmLogo(){
 const pos=$("#wmPos").value,pw=num("#wmLogoW",18),op=num("#wmLogoOp",55),inp=document.createElement("input");inp.type="file";inp.accept="image/*";
 inp.onchange=()=>{const f=inp.files[0];if(!f)return;if(f.size>8*1048576)return CDMS.toast("Ukuran logo maksimal 8 MB");const r=new FileReader();
  r.onload=()=>{const im=new Image();im.onload=()=>{const w=Math.round(S.page.width*pw/100),h=Math.round(w*im.height/im.width);Hi.snapshot();
   const o={id:uid(),type:"image",name:"Watermark logo",href:String(r.result),x:0,y:0,w,h,strokeWidth:0,opacity:op,rotation:0};place(o,pos);S.objects.push(o);N.closeModal();pick([o]);};im.src=String(r.result);};r.readAsDataURL(f);};
 inp.click();
}
function num(id,d){return Number($(id)&&$(id).value)||d;}

/* ----- efek, kanvas, alat ----- */
function fx(clear){const a=sels();if(!a.length)return CDMS.toast("Pilih objek dulu");Hi.snapshot();
 a.forEach(o=>{o.fx=clear?"none":$("#fxType").value;o.fxColor=$("#fxColor").value;o.fxAmount=num("#fxAmt",12);delete o.v7Effect;});N.closeModal();C.render();CDMS.toast(clear?"Efek dihapus":"Efek diterapkan");}
function resize(){
 const[w,h]=$("#cvSize").value.split(",").map(Number),ow=S.page.width,oh=S.page.height;if(w===ow&&h===oh)return;Hi.snapshot();
 const s=Math.min(w/ow,h/oh),dx=(w-ow*s)/2,dy=(h-oh*s)/2;
 S.objects.forEach(o=>{o.x=Math.round(o.x*s+dx);o.y=Math.round(o.y*s+dy);o.w=Math.max(1,Math.round(o.w*s));o.h=Math.round((o.h||0)*s);if(o.fontSize)o.fontSize=Math.max(1,Math.round(o.fontSize*s));if(o.strokeWidth)o.strokeWidth=+(o.strokeWidth*s).toFixed(2);});
 S.page.width=w;S.page.height=h;N.closeModal();C.render();CDMS.toast("Ukuran kanvas "+w+" × "+h);
}
const BK="cdms-v6-brandkit";
const brand=()=>{try{return JSON.parse(localStorage.getItem(BK)||"null");}catch(e){return null;}};
function swatches(){const el=$("#bSwatch");if(!el)return;const p=brand();
 el.innerHTML=p&&p.colors?p.colors.map(c=>`<button style="--c:${c}" data-c="${c}" title="${c}"></button>`).join(""):'<span class="st-note">Palet tersimpan muncul di sini. Ketuk warna untuk mewarnai objek terpilih.</span>';
 el.querySelectorAll("[data-c]").forEach(b=>b.onclick=()=>{const a=sels();if(!a.length)return CDMS.toast("Pilih objek dulu");Hi.snapshot();a.forEach(o=>{o.fill=b.dataset.c;});C.render();});}
function dup(){const a=sels();if(!a.length)return CDMS.toast("Pilih objek dulu");const n=Math.max(1,Math.min(20,num("#dN",3))),gx=Number($("#dX").value)||0,gy=Number($("#dY").value)||0;Hi.snapshot();
 const c=[];for(let i=1;i<=n;i++)a.forEach(o=>c.push({...o,id:uid(),name:(o.name||o.type)+" salinan "+i,x:o.x+gx*i,y:o.y+gy*i}));S.objects.push(...c);N.closeModal();pick(c);CDMS.toast(c.length+" salinan dibuat");}
function center(){const a=sels();if(!a.length)return CDMS.toast("Pilih objek dulu");Hi.snapshot();
 const x0=Math.min(...a.map(o=>o.x)),x1=Math.max(...a.map(o=>o.x+o.w)),y0=Math.min(...a.map(o=>o.y)),y1=Math.max(...a.map(o=>o.y+(o.h||0))),dx=S.page.width/2-(x0+x1)/2,dy=S.page.height/2-(y0+y1)/2;
 a.forEach(o=>{o.x=Math.round(o.x+dx);o.y=Math.round(o.y+dy);});C.render();CDMS.toast("Objek dipusatkan");}


function vstyle(outline){const a=sels();if(!a.length)return CDMS.toast("Pilih objek dulu");Hi.snapshot();const f=$("#vFill").value,k=$("#vStroke").value,w=num("#vW",4);
 if(outline){const t=a.filter(o=>o.type==="text");if(!t.length)return CDMS.toast("Pilih objek teks dulu");t.forEach(o=>{o.textOutline=true;o.stroke=k;o.strokeWidth=Math.max(2,w);});}
 else a.forEach(o=>{o.fill=f;o.stroke=k;o.strokeWidth=w;});
 C.render();CDMS.toast(outline?"Outline teks diterapkan":"Style diterapkan");}
function snapGrid(){const a=sels();if(!a.length)return CDMS.toast("Pilih objek dulu");Hi.snapshot();a.forEach(o=>{o.x=Math.round(o.x/20)*20;o.y=Math.round(o.y/20)*20;});C.render();CDMS.toast("Disejajarkan ke grid 20 px");}
function cropImg(){const a=sels().filter(o=>o.type==="image");if(!a.length)return CDMS.toast("Pilih gambar dulu");Hi.snapshot();
 a.forEach(o=>{const W=S.page.width,H=S.page.height,x=Math.max(0,o.x),y=Math.max(0,o.y),r=Math.min(W,o.x+o.w),b=Math.min(H,o.y+o.h);if(r>x&&b>y){o.x=x;o.y=y;o.w=r-x;o.h=b-y;}});C.render();CDMS.toast("Gambar dipotong ke area kanvas");}
function bezier(){Hi.snapshot();const w=Math.round(S.page.width*.6),h=Math.round(S.page.height*.3),o={id:uid(),type:"path",name:"Kurva Bezier",x:Math.round(S.page.width*.2),y:Math.round(S.page.height*.3),w,h,d:`M 0 ${h*.8} C ${w*.15} ${-h*.2}, ${w*.55} ${h*1.4}, ${w} ${h*.25}`,fill:"none",stroke:"#00d6c9",strokeWidth:8,opacity:100,rotation:0};S.objects.push(o);N.closeModal();pick([o]);}
const AB="cdms_autobackup",proj=()=>{if(CDMS.Pages)CDMS.Pages.sync();return{version:12,name:S.projectName,width:S.page.width,height:S.page.height,background:S.page.background,objects:S.objects,pages:S.pages&&S.pages.length>1?S.pages:undefined,pageIdx:S.pageIdx};};
function restoreLocal(){try{const r=localStorage.getItem(AB)||localStorage.getItem("cdms_v9_autobackup");if(!r)return CDMS.toast("Belum ada cadangan lokal");C.loadProject(JSON.parse(r));N.closeModal();CDMS.toast("Cadangan dipulihkan");}catch(e){CDMS.toast("Cadangan tidak bisa dibaca");}}
function textPng(){const t=$("#tpText").value.trim();if(!t)return CDMS.toast("Isi teks dulu");const sz=Math.max(12,Math.min(240,num("#tpSize",64))),lines=t.split("\n"),c=document.createElement("canvas"),x=c.getContext("2d");
 x.font=`700 ${sz}px Arial`;const pad=Math.ceil(sz*.45),lh=Math.ceil(sz*1.35),w=Math.max(1,...lines.map(l=>x.measureText(l||" ").width));c.width=Math.ceil(w+pad*2);c.height=lines.length*lh+pad*2;
 x.font=`700 ${sz}px Arial`;x.fillStyle=$("#tpColor").value;x.textBaseline="top";lines.forEach((l,i)=>x.fillText(l,pad,pad+i*lh));
 c.toBlob(b=>b?CDMS.Export.download(b,"teks.png"):CDMS.toast("PNG gagal dibuat"),"image/png");}
setInterval(()=>{const ed=$("#editor");if(!ed||ed.classList.contains("hidden"))return;try{localStorage.setItem(AB,JSON.stringify(proj()));}catch(e){}},12000);

/* ----- modal Studio ----- */
const opt=(a,sel)=>a.map(x=>`<option value="${x[0]}"${x[0]===sel?" selected":""}>${x[1]}</option>`).join("");
const POS=[["br","Kanan bawah"],["bl","Kiri bawah"],["tr","Kanan atas"],["tl","Kiri atas"],["center","Tengah"]];
function open(){
 N.showEditor();
 const T=[["design","Desain"],["wm","Watermark"],["fx","Style"],["cv","Kanvas"],["tool","Alat"],["file","Berkas"]];
 N.openModal("Studio",`<div class="st-tabs">${T.map((t,i)=>`<button class="st-tab${i?"":" active"}" data-t="${t[0]}">${t[1]}</button>`).join("")}</div>
<section class="st-pane" data-p="design"><p class="st-note">Buat susunan desain siap edit dari teks kamu (generator lokal, bukan AI). Teks panjang dibungkus otomatis.</p><label>Judul<input id="stTitle" maxlength="80" value="DREAM BIG"></label><label>Subjudul<input id="stSub" maxlength="100" value="CREATE YOUR OWN STORY"></label><div class="st-grid"><label>Gaya<select id="stStyle">${opt([["neon","Neon futuristik"],["minimal","Minimal elegan"],["street","Street poster"],["sunset","Sunset"],["royal","Royal purple"]])}</select></label><label>Layout<select id="stKind">${opt([["poster","Poster"],["promo","Promo / diskon"],["cover","Cover modern"],["quote","Quote card"]])}</select></label></div><label>Warna aksen<input id="stAccent" type="color" value="#00d6c9"></label><label class="chk"><input id="stClear" type="checkbox" checked> Ganti isi kanvas saat ini</label><button class="btn primary" id="stGen">Buat desain</button><div class="st-grid"><button class="btn subtle" data-q="badge">Badge</button><button class="btn subtle" data-q="label">Label</button><button class="btn subtle" data-q="frame">Bingkai</button><button class="btn subtle" data-q="divider">Garis aksen</button></div></section>
<section class="st-pane hidden" data-p="wm"><p class="st-note">Watermark ditambahkan sebagai objek, jadi tetap bisa dipindah dan diedit. Gunakan logo milik sendiri atau yang diizinkan.</p><label>Posisi<select id="wmPos">${opt(POS)}</select></label><label>Teks watermark<input id="wmText" maxlength="60" value="© YOUR BRAND"></label><div class="st-grid"><label>Warna<input id="wmColor" type="color" value="#ffffff"></label><label>Ukuran<input id="wmSize" type="range" min="12" max="90" value="28"></label></div><label>Transparansi<input id="wmOp" type="range" min="10" max="100" value="45"></label><button class="btn primary" id="wmAddText">Tambah watermark teks</button><hr><div class="st-grid"><label>Lebar logo (%)<input id="wmLogoW" type="range" min="8" max="50" value="18"></label><label>Transparansi logo<input id="wmLogoOp" type="range" min="10" max="100" value="55"></label></div><button class="btn primary" id="wmLogo">Pilih logo dari galeri</button></section>
<section class="st-pane hidden" data-p="fx"><div class="st-h">Warna & outline</div><div class="st-grid"><label>Isi<input id="vFill" type="color" value="#6d5dfc"></label><label>Outline<input id="vStroke" type="color" value="#00d6c9"></label></div><label>Ketebalan outline<input id="vW" type="range" min="0" max="32" value="4"></label><div class="st-grid"><button class="btn primary" id="vApply">Terapkan style</button><button class="btn subtle" id="vOutline">Outline teks</button></div><hr><div class="st-h">Efek bayangan & glow</div><p class="st-note">Diterapkan ke semua objek yang dipilih dan ikut tampil di ekspor.</p><label>Preset<select id="fxType">${opt([["shadow","Bayangan lembut"],["deep","Bayangan tegas"],["glow","Glow neon"],["pink","Glow magenta"]])}</select></label><div class="st-grid"><label>Warna glow<input id="fxColor" type="color" value="#00d6c9"></label><label>Intensitas<input id="fxAmt" type="range" min="1" max="30" value="12"></label></div><div class="st-grid"><button class="btn primary" id="fxGo">Terapkan</button><button class="btn subtle" id="fxNo">Hapus efek</button></div></section>
<section class="st-pane hidden" data-p="cv"><label>Ukuran kanvas<select id="cvSize">${opt([["1080,1080","Post 1080 × 1080"],["1080,1920","Story 1080 × 1920"],["1920,1080","Banner 1920 × 1080"],["1200,628","Link preview 1200 × 628"],["1200,1200","Logo 1200 × 1200"],["2480,3508","A4 2480 × 3508"]],S.page.width+","+S.page.height)}</select></label><p class="st-note">Isi desain diskalakan proporsional dan dipusatkan, tanpa gepeng.</p><button class="btn primary" id="cvGo">Terapkan ukuran</button><hr><div class="st-grid"><label>Warna latar<input id="cvBg" type="color" value="#ffffff"></label><button class="btn subtle" id="cvBgGo">Pakai warna</button></div><div class="st-grid"><label>Gradien A<input id="gA" type="color" value="#10131c"></label><label>Gradien B<input id="gB" type="color" value="#4527a0"></label></div><div class="st-grid"><label>Arah<select id="gM">${opt([["d","Diagonal"],["v","Vertikal"]])}</select></label><button class="btn subtle" id="gGo">Pakai gradien</button></div><div class="st-grid3">${[["#10131c","#00d6c9","Cyber"],["#1a103d","#ff4f9a","Galaxy"],["#ff9966","#6a3093","Sunset"],["#f5f3ef","#b9d6d3","Clean"]].map(p=>`<button class="btn subtle" data-g="${p[0]},${p[1]}">${p[2]}</button>`).join("")}</div><hr><div class="st-grid"><button class="btn subtle" id="cvGuide">Guide: ${S.guideOn?"matikan":"tampilkan"}</button><label>Margin aman <input id="cvMargin" type="range" min="3" max="15" value="${S.guideMargin||7}"></label></div><label>Nama proyek<input id="cvName" value="${E(S.projectName)}"></label><button class="btn subtle" id="cvRename">Ubah nama</button></section>
<section class="st-pane hidden" data-p="tool"><label>Nama brand<input id="bName" maxlength="40" value="My Brand"></label><div class="st-grid3">${[["#00d6c9"],["#6d5dfc"],["#ff6b6b"],["#ffc857"],["#20243a"],["#ffffff"]].map((c,i)=>`<input type="color" id="b${i+1}" value="${c[0]}">`).join("")}</div><div class="st-grid"><button class="btn primary" id="bSave">Simpan Brand Kit</button><button class="btn subtle" id="bLoad">Muat Brand Kit</button></div><div class="st-sw" id="bSwatch"></div><hr><div class="st-grid3"><label>Salinan<input id="dN" type="number" min="1" max="20" value="3"></label><label>Jarak X<input id="dX" type="number" value="30"></label><label>Jarak Y<input id="dY" type="number" value="30"></label></div><div class="st-grid"><button class="btn primary" id="dGo">Duplikat bertahap</button><button class="btn subtle" id="dCenter">Pusatkan objek</button></div><hr><div class="st-grid3"><button class="btn subtle" id="vSnap">Snap grid</button><button class="btn subtle" id="vCrop">Crop gambar</button><button class="btn subtle" id="vBez">Kurva</button></div></section>
<section class="st-pane hidden" data-p="file"><div class="st-h">Cadangan proyek</div><p class="st-note">Cadangan otomatis tersimpan di browser tiap ±12 detik. Unduh file .cdms untuk memindahkan proyek ke perangkat lain.</p><div class="st-grid"><button class="btn primary" id="fBak">Unduh cadangan</button><button class="btn subtle" id="fRes">Pulihkan lokal</button></div><hr><div class="st-h">Teks menjadi PNG</div><label>Teks<textarea id="tpText" rows="3" placeholder="Tulis judul atau kutipan..."></textarea></label><div class="st-grid"><label>Ukuran<input id="tpSize" type="number" min="12" max="240" value="64"></label><label>Warna<input id="tpColor" type="color" value="#20243a"></label></div><button class="btn primary" id="tpGo">Buat PNG transparan</button></section>`);
 document.querySelectorAll(".st-tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".st-tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll("[data-p]").forEach(p=>p.classList.toggle("hidden",p.dataset.p!==b.dataset.t));});
 $("#stGen").onclick=generate;document.querySelectorAll("[data-q]").forEach(b=>b.onclick=()=>quick(b.dataset.q));
 $("#wmAddText").onclick=wmText;$("#wmLogo").onclick=wmLogo;$("#fxGo").onclick=()=>fx(false);$("#fxNo").onclick=()=>fx(true);$("#cvGo").onclick=resize;
 $("#cvBgGo").onclick=()=>{Hi.snapshot();S.page.background=$("#cvBg").value;C.render();};
 const grad=()=>{Hi.snapshot();S.page.background=`grad:${$("#gA").value},${$("#gB").value},${$("#gM").value}`;C.render();};
 $("#gGo").onclick=grad;document.querySelectorAll("[data-g]").forEach(b=>b.onclick=()=>{const[a,c]=b.dataset.g.split(",");$("#gA").value=a;$("#gB").value=c;grad();});
 $("#cvGuide").onclick=()=>{S.guideOn=!S.guideOn;S.guideMargin=num("#cvMargin",7);C.render();$("#cvGuide").textContent="Guide: "+(S.guideOn?"matikan":"tampilkan");};
 $("#cvMargin").oninput=()=>{S.guideMargin=num("#cvMargin",7);if(S.guideOn)C.render();};
 $("#cvRename").onclick=()=>{S.projectName=$("#cvName").value.trim()||"Desain tanpa judul";C.render();CDMS.toast("Nama proyek diubah");};
 $("#bSave").onclick=()=>{try{localStorage.setItem(BK,JSON.stringify({name:$("#bName").value,colors:[1,2,3,4,5,6].map(i=>$("#b"+i).value)}));swatches();CDMS.toast("Brand Kit tersimpan");}catch(e){CDMS.toast("Penyimpanan tidak tersedia");}};
 $("#bLoad").onclick=()=>{const p=brand();if(!p)return CDMS.toast("Belum ada Brand Kit");$("#bName").value=p.name||"";(p.colors||[]).forEach((c,i)=>{if($("#b"+(i+1)))$("#b"+(i+1)).value=c;});swatches();};
 $("#dGo").onclick=dup;$("#dCenter").onclick=center;swatches();
 $("#vApply").onclick=()=>vstyle(false);$("#vOutline").onclick=()=>vstyle(true);$("#vSnap").onclick=snapGrid;$("#vCrop").onclick=cropImg;$("#vBez").onclick=bezier;
 $("#fBak").onclick=()=>CDMS.Storage.downloadJSON(proj(),nm()+".cdms");$("#fRes").onclick=restoreLocal;$("#tpGo").onclick=textPng;
}

/* ----- satu tombol Studio ----- */
const ab=$(".top-actions");
if(ab&&!$('[data-action="studio"]'))ab.insertAdjacentHTML("afterbegin",'<button class="btn studio-btn" data-action="studio" title="Studio kreatif"><span>Studio</span></button>');
const mb=$(".mobile-bottom-tools");
if(mb&&!mb.querySelector('[data-action="studio"]'))mb.insertAdjacentHTML("afterbegin",'<button data-action="studio"><span>Studio</span></button>');
document.addEventListener("click",e=>{if(e.target.closest('[data-action="studio"]'))open();});
})();
