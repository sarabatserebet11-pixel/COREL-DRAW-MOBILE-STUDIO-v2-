# CorelDraw Mobile Studio V152

Editor desain grafis responsif untuk HP dan desktop. Bukan produk resmi CorelDRAW.

## Fitur V5
- Prompt → Desain: menyusun poster tipografi lokal yang dapat diedit; bukan generator gambar AI berbasis cloud.
- Watermark teks: posisi, warna, ukuran, dan transparansi.
- Pilih logo dari galeri melalui alur impor gambar yang tersedia.
- Background gradien diagonal/vertikal dan warna solid.
- Preset Cyber, Galaxy, Sunset, dan Clean.
- Tetap membawa tool, layer, properti, undo/redo, penyimpanan, dan ekspor dari versi sebelumnya.

## Menjalankan
Ekstrak ZIP lalu buka `index.html` di folder hasil ekstrak melalui browser atau SPCK Editor. Fitur penyimpanan lokal bergantung pada dukungan browser/perangkat.

Catatan: fitur prompt menyusun objek vektor/teks secara lokal, tidak mengirim prompt ke layanan AI dan tidak menghasilkan foto AI.

## Upgrade V6
- Brand Kit lokal: simpan/muat palet warna dan terapkan ke objek terpilih.
- Smart Layout: buat poster editorial, promo, cover, dan quote card yang objeknya tetap bisa diedit.
- Kanvas & Guides: ukuran kanvas preset, margin aman, garis tengah, dan guide non-ekspor.
- Batch Tools: duplikasi bertahap hingga 20 kali dan pusatkan objek terpilih.
- Fitur baru berjalan lokal tanpa layanan AI eksternal.


## Fitur tambahan V7
- Panel Studio Pro V7 untuk efek bayangan dan glow pada objek terpilih.
- Preset ukuran kanvas untuk post persegi, Story/Reels, banner, link preview, dan A4 dengan skala objek.
- Watermark logo dari galeri (PNG/JPG/WebP/SVG, maksimum 8 MB) serta watermark teks.
- Ekspor PNG dengan skala 1x, 2x, atau 3x dan ekspor SVG.
- Tetap mempertahankan fitur dari versi sebelumnya.

## Catatan
Efek visual menggunakan filter SVG/CSS dan hasil ekspor bergantung pada dukungan browser. Ekspor PNG skala tinggi dapat memerlukan memori besar di perangkat seluler. Generator desain prompt tetap merupakan penyusun desain lokal, bukan generator gambar AI cloud.


## Upgrade V10
- V9 Studio Control Center untuk akses cepat watermark, impor logo, dan cadangan proyek.
- Watermark teks yang dapat diedit ditambahkan langsung ke kanvas.
- Auto-backup lokal otomatis setiap sekitar 12 detik saat editor terbuka.
- Ekspor cadangan proyek `.cdms` dan pulihkan dari cadangan lokal.
- Pintasan keyboard: `Ctrl+S` simpan/cadangkan, `Ctrl+D` duplikat, `Delete` hapus objek terpilih.
- Mempertahankan fitur V8 dan layout HP/desktop.

## Menjalankan V9
Ekstrak ZIP lalu buka `CorelDrawMobileStudio_V9/index.html` di browser atau SPCK Editor. Auto-backup menggunakan penyimpanan lokal browser; ekspor cadangan `.cdms` untuk memindahkan salinan ke perangkat lain.


## Upgrade V10
- Panel V10 Studio untuk pengaturan ukuran kanvas cepat (post, story, banner, logo, atau ukuran kustom).
- Kontrol latar kanvas dengan warna pilihan.
- Garis bantu tata letak yang bisa ditampilkan/disembunyikan.
- Generator teks ke PNG mandiri dengan ukuran dan warna teks yang dapat diatur.
- Branding dan menu V10 diperbarui.

Catatan: garis bantu adalah overlay editor dan tidak ditujukan untuk ikut dalam ekspor. Uji di browser/preview SPCK sebelum mengandalkan proyek untuk pekerjaan penting.


## Upgrade V11 — Advanced Vector Tools
- Panel **V11 Vector** untuk style objek terpilih, warna isi, warna outline, dan ketebalan outline.
- Outline teks, efek bayangan, rata tengah kanvas, snap posisi ke grid 20 px.
- Kurva Bezier contoh berbasis SVG path.
- Crop sederhana membatasi gambar terpilih ke area halaman (mengubah bingkai/ukuran objek, bukan mengedit piksel sumber).
- V11 dibangun di atas struktur V10 dan tetap memakai HTML/CSS/JavaScript.


## Pembaruan V12
- Tombol V9, V10, dan V11 digabung ke dalam satu tombol **Studio**: tab Desain, Watermark, Style (warna, outline, efek), Kanvas, Alat (Brand Kit, duplikat, snap grid, crop, kurva), dan Berkas (cadangan, teks ke PNG).
- Pintasan keyboard ganda dari V9 dihapus (sebelumnya Ctrl+D menduplikat dua kali dan Delete berjalan dua kali). Auto-backup tetap ada.
- Outline teks kini benar-benar tampil di kanvas dan ekspor.
- Tampilan baru bergaya profesional: topbar ringkas, toolbar berkelompok, panel dan properti seragam, modal bergaya sheet di HP.


## Pembaruan V13
- Tombol menu di toolbar yang berisi tombol-tombol turunan (muncul sebagai popover, di HP sebagai sheet dari bawah): **Bentuk** (16 bentuk vektor), **Susun** (urutan tumpukan, rata ke halaman, distribusi, balik), **Ubah** (putar 90°, skala, samakan ukuran, sudut persegi, kunci), **Warna** (gradien objek 8 preset + arah, 10 filter foto/efek), **Teks** (huruf besar/kecil, tebal/miring, spasi huruf, font cepat), **Edit** (pilih semua, salin/potong/tempel, ekspor objek terpilih PNG), **Tampilan** (zoom, grid, snap magnet, mode fokus, layar penuh, tema).
- Snap magnet: objek menempel ke tepi dan tengah halaman serta objek lain saat digeser.
- Pintasan baru: Ctrl+A, Ctrl+C, Ctrl+X, Ctrl+V, Ctrl+G, tombol panah (Shift = 10 px), Esc.

## Pembaruan V14
- Menu baru: **Gaya** (ketebalan garis, garis putus-putus/titik, pola isi garis/titik/kotak/papan), **Sisip** (tombol, kartu, lencana angka, rating bintang, label diskon, polaroid, pembatas ornamen), **Duplikat** (salin ke kanan/bawah, grid 2-4, melingkar 6-16, cermin H/V), **Proyek** (simpan, ekspor, Studio, impor gambar, desain baru).
- Menu Warna ditambah: acak warna, pelangi antar objek, tukar isi/garis, isi transparan, samakan warna, teks kontras otomatis. Menu Teks ditambah: teks 3D dan bayangan panjang.
- Klik/ketuk dua kali pada teks untuk mengedit isinya.

## Pembaruan V15
- Menu baru: **Kurva** (8 garis/kurva: panah, gelombang, zigzag, spiral, busur, kurung kurawal, kilat), **Foto** (masker bulat/rounded/bintang/hati/segi enam, 6 filter, bayangan/glow foto), **Pilih** (pilih jenis atau warna sama, balik pilihan, hapus objek di luar kanvas, mode fokus, tampilkan semua, buka semua kunci), **Kanvas** (8 ukuran siap pakai, tukar orientasi, 12 warna latar, 4 gradien latar).
- Menu Teks: rata kiri/tengah/kanan dan tinggi baris.

## Pembaruan V16
- Menu baru: **Grafik** (diagram batang, lingkaran, donat dari data yang kamu ketik, cincin progres, tabel), **Hiasan** (konfeti, bintang, gelembung, pola titik, garis diagonal di belakang desain, plus hapus semua hiasan), **Bantu** (panduan sepertiga, rasio emas, garis tengah, diagonal, grid 20/40/80; tidak ikut ekspor).
- Cubit dua jari di kanvas untuk zoom dan geser (HP).

## Pembaruan V17
- Menu baru: **Efek** (pantulan, glitch, halo, neon, miring/skew X-Y, hapus efek salinan), **Palet** (palet komplementer/triad/analog/tetradik/monokrom dari warna objek terpilih, lalu terapkan ke objek), **Emoji** (24 emoji, bisa diubah ukuran), **Ekspor** (PNG transparan, PNG HD 3×, JPG, salin ke clipboard, bagikan lewat aplikasi, pratinjau bersih).
- Toolbar di desktop kini membungkus ke baris kedua agar semua menu terlihat.

## Pembaruan V18
- **Cari fitur** (tombol Cari atau Ctrl+K): ketik nama fitur apa pun dari semua menu, lalu ketuk hasilnya untuk langsung menjalankannya.
- Menu baru: **Layer** (ganti nama, nama otomatis, balik/urutkan layer, pilih grup, kunci yang tidak dipilih, hapus objek tersembunyi), **Mockup** (ponsel, jendela browser, catatan tempel, pita promo, tiket, chat bubble), **Preset** teks (judul tebal, subjudul, caption, elegan serif, mono kode, neon), **Tata** (susun melingkar, grid rapi, tangga, acak posisi/rotasi/ukuran).

## Pembaruan V19
- Menu baru: **Format** (salin gaya, tempel gaya/ukuran/posisi, reset gaya), **Blend** (blend 2 objek 3-12 langkah, ekstrusi 3D, kontur dalam/luar, ubin memenuhi halaman: lurus, bata, bolak-balik), **Teks+** (bungkus kolom, nomor/poin, urutkan baris, cari & ganti, hitung kata, isi contoh), **Versi** (urungkan/ulangi banyak langkah, simpan dan pulihkan hingga 8 versi).

## Pembaruan V20
- **Toolbar dirapikan**: 31 tombol menu kini dikelompokkan menjadi 6 tombol grup (Buat, Atur, Warna, Teks, Kanvas, Berkas). Ketuk grup untuk melihat menu di dalamnya, lalu ketuk menu untuk membukanya. Mode lama (semua tombol) bisa dipilih lewat Berkas > Toolbar. Fitur apa pun tetap bisa dicari lewat Cari / Ctrl+K.
- Menu baru: **Anim** (putar, ayun, melayang, berkedip, kecepatan, pratinjau, ekspor SVG animasi) dan **Klip** (PowerClip: isi satu objek ke dalam bentuk objek lain; isi harus tanpa rotasi).

## Pembaruan V21
- Menu baru (masuk grup Buat dan Kanvas): **Pena** (warna dan ketebalan kuas, penghalus goresan, mode simetri menggambar: cermin H/V, 4 arah, radial 6/8/12, kaleidoskop 6/8), **Kolase** (5 layout slot foto, isi slot dengan foto yang otomatis dipotong pas, mode pas foto Isi/Muat/Regang), **Ukur** (ukuran objek dalam px dan cm, jarak antar objek, sudut, persentase luas, statistik halaman).

## Pembaruan V22
- Menu baru: **Konektor** (hubungkan 2 objek dengan garis lurus, siku, atau lengkung, dengan kepala panah opsional; grup Atur), **Filter** (filter SVG: sketsa tangan, riak air, posterisasi, duotone, emboss, blur gerak, grain film; plus 11 mode campur seperti multiply, screen, overlay; grup Warna), **Kode** (barcode EAN-13 dengan digit cek otomatis, penomoran 1 sampai N, sisip tanggal dan jam bahasa Indonesia; grup Buat).

## Pembaruan V23
- **Bar aksi cepat** muncul di dekat objek terpilih: duplikat, ke depan, ke belakang, balik, kunci, hapus.
- Menu baru: **Melengkung** (teks mengikuti busur atas/bawah, lingkaran penuh, atau gelombang; grup Teks), **Segel** (stempel LUNAS/DISETUJUI/DRAFT/ASLI/URGENT, bingkai halaman, watermark pola diagonal, garis tanda tangan; grup Buat), **Latar** (latar aurora dan bokeh 4 palet; grup Kanvas).

## Pembaruan V24
- Grup baru **Pustaka** (Ikon, 3D, Infografis, Emoji, Mockup, Grafik, Segel, Hiasan) supaya grup Buat tidak terlalu penuh.
- Menu baru: **Ikon** (16 ikon garis yang bisa diubah warna dan ketebalannya), **3D** (kubus, silinder, piramida, 3 kubus bertumpuk dengan pewarnaan sisi otomatis, 6 warna dasar), **Infografis** (timeline, langkah 1-2-3, daftar centang, statistik besar, progress bar).

## Pembaruan V25
- Panel layer: tombol ▲ ▼ untuk mengatur urutan, ketuk dua kali nama layer untuk mengganti nama.
- Dashboard: tombol **Lanjutkan sesi terakhir** (dari cadangan otomatis).
- Menu **Bantuan** (grup Berkas): pintasan keyboard (juga lewat tombol ?), gestur dan tips, cek kesehatan proyek.
- Menu Warna: gradien kustom (2 warna + arah), balik warna gradien, gradien dari warna objek.
- Nama grup toolbar diperjelas (Objek, Huruf) agar tidak sama dengan alat Atur dan Teks.

## Pembaruan V26
- Menu baru: **Rata** (rata ke objek acuan, jarak tetap antar objek mendatar/tegak, samakan lebar/tinggi; grup Objek) dan **Crop** (crop rasio 1:1, 4:5, 16:9, 9:16, 3:2 dari tengah, potong gambar jadi grid atau carousel, hapus crop, palet warna dari foto; grup Warna).
- Menu Bantuan: cek kontras teks (standar WCAG) dengan tombol perbaiki otomatis.
- Perbaikan: teks lingkaran tidak lagi menempel di awal dan akhir.

## Pembaruan V27
- **Gambar bentuk dengan menyeret**: pilih alat Persegi, Elips, Bintang, Poligon, atau Garis, lalu seret di kanvas untuk menentukan ukuran (Shift untuk proporsional). Ketuk saja tanpa seret untuk ukuran standar.
- Menu baru: **Zoom** (zoom cepat, zoom ke objek terpilih atau semua objek; grup Kanvas) dan **Poligon+** (poligon beraturan 3-12 sisi, bintang 5/6/8/12, roda gigi; grup Buat).
- Menu Filter: pikselasi, hanya kontur luar, hapus latar putih/hitam, sepia, negatif.
- Bar aksi cepat tersembunyi saat alat gambar aktif.

## Pembaruan V28
- **Perbaikan Klip (PowerClip)**: sebelumnya objek berklip menghilang karena cara pemotongan yang tidak valid; kini memakai mask sehingga berfungsi untuk bentuk, gambar, dan teks (misalnya foto di dalam huruf).
- Menu baru: **Huruf** (pisah teks per huruf atau per kata, lalu efek pelangi, melompat, tangga, gelombang; grup Huruf) dan **Bayangan** (preset lembut/tegas/jatuh jauh/ambient/ungu serta bayangan kustom: geser X/Y, blur, warna, transparansi; grup Warna).

## Pembaruan V29
- **Multi-halaman** (slide atau carousel): menu **Halaman** (grup Kanvas) untuk tambah halaman kosong, duplikat, hapus, geser kiri/kanan, daftar halaman dengan thumbnail, dan ekspor semua halaman sebagai PNG. Tombol ◀ ▶ dan indikator halaman muncul di bar bawah kanvas saat ada lebih dari satu halaman. Semua halaman ikut tersimpan (Simpan, cadangan otomatis, cadangan .cdms).
- **Boolean kurangi** (menu Klip): objek pertama dikurangi bentuk objek kedua sehingga muncul lubang.
- **Ujung garis** (menu Gaya): panah akhir, panah awal, panah ganda, titik akhir untuk objek Garis.

## Pembaruan V30
- Menu **Presentasi** (grup Berkas): mode slideshow layar penuh dari halaman ini atau dari awal, putar otomatis (1,5/3/5/8 detik), transisi pudar, geser, atau tanpa; kontrol keyboard ← → Spasi Esc dan tombol layar.
- **Ekspor video WebM** dari semua halaman (2 atau 4 detik per halaman, dengan transisi pudar), memakai perekaman bawaan browser.
- Menu Halaman: beri/hapus nomor halaman otomatis, terapkan latar halaman ini ke semua halaman, samakan ukuran semua halaman.

## Pembaruan V31
- Menu **Tema** (grup Warna): ubah warna seluruh desain sekaligus: geser hue (+30° sampai +240°), lebih hidup/pudar/terang/gelap, kontras tinggi, monokrom, ganti satu warna (persis atau mirip), pilihan berlaku di semua halaman, dan daftar warna yang dipakai (ketuk untuk memilih semua objek berwarna itu).
- Menu **Carousel** (grup Buat): buat carousel multi-halaman 1080 × 1350 dari judul dan daftar poin (cover, halaman tiap poin dengan nomor besar dan titik progres, halaman penutup) dalam 4 tema.

## Pembaruan V32
- Menu **Font** (grup Huruf): unggah font sendiri (.ttf .otf .woff .woff2, maks 1,5 MB), terapkan ke teks, tersimpan di browser dan ikut tampil di ekspor PNG, PDF, dan video.
- Menu **Cetak** (grup Berkas): ekspor **PDF** semua halaman atau halaman ini saja (kualitas standar atau 2×); ukuran halaman PDF mengikuti kanvas.
- Menu **Anotasi** (grup Pustaka): penanda angka berurutan, sorot seperti stabilo, kotak fokus + label, balon catatan dengan penunjuk panah, sensor hitam dan kotak-kotak.

## Pembaruan V33
- Menu **Impor** (grup Berkas): impor file SVG sebagai gambar utuh, atau sebagai vektor yang bisa diedit (path, persegi, lingkaran, elips, poligon, garis; warna dari atribut dan CSS ikut terbaca, teks dan gambar di dalam SVG diabaikan).
- Menu **Pudar** (grup Warna): pudar tepi ke bawah, atas, kiri, kanan, atau vinyet, dengan kekuatan lembut/sedang/kuat.
- Menu Cetak: **Ekspor HTML presentasi**, satu file yang bisa dibuka di browser mana pun dengan tombol dan keyboard untuk pindah halaman.

## Pembaruan V34
- Menu **QR** (grup Buat): generator QR Code vektor untuk tautan, teks, Wi-Fi, WhatsApp, email, dan kontak vCard; pilihan warna kode dan latar, serta 4 tingkat koreksi kesalahan (L/M/Q/H). Mendukung data hingga sekitar 270 karakter (versi 1-10), termasuk huruf non-Latin.
- Menu **Kalender** (grup Pustaka): kalender bulanan dengan nama bulan dan hari berbahasa Indonesia, awal minggu Senin, hari Minggu merah, dan penanda hari ini.

## Pembaruan V35
- **Garis bantu cerdas**: saat menggeser objek, garis putus-putus magenta muncul ketika tepi atau tengahnya sejajar dengan objek lain atau halaman (tidak ikut ekspor).
- Menu **Pipet** (grup Warna): pipet isi atau garis dari objek lain di kanvas, serta kunci rasio ukuran per objek.
- Menu **Optimasi** (grup Berkas): kompres gambar (perkecil resolusi atau ubah ke JPEG ringan), lihat ukuran data proyek, hapus objek tersembunyi dan di luar kanvas.

## Pembaruan V36
- Menu **Simpul** (grup Objek): **edit simpul** (node editing) ala CorelDRAW untuk objek path. Seret simpul putih dan titik kontrol kuning, tambah simpul di tengah segmen, hapus simpul, ubah segmen jadi lengkung atau lurus, serta tutup atau buka path.
- **Ubah bentuk jadi kurva**: persegi, elips, bintang, poligon, dan garis diubah menjadi path agar bisa diedit simpulnya.
- Path dari SVG impor atau tulisan tangan juga bisa diedit (perintah M L H V C S Q T Z; path dengan busur/arc belum didukung).

## Pembaruan V37
- Menu **Tekstur** (grup Warna): overlay tekstur di atas seluruh halaman (grain film, kertas kasar, kain linen, halftone titik, garis diagonal tipis), terkunci agar tidak menghalangi seleksi, dan bisa dihapus sekaligus.
- Menu **Sesuaikan** (grup Warna): penyesuaian foto atau objek dengan slider dan pratinjau langsung: kecerahan, kontras, saturasi, geser warna, blur.
- Menu Pena: gaya goresan solid, putus-putus, titik-titik, dan stabilo transparan.

## Pembaruan V38
- Menu **Kotak** (grup Huruf): kotak teks dengan bungkus otomatis berdasarkan lebar (30/50/70/90% halaman atau lebar saat ini); teks asli tidak berubah, jadi tetap bisa diedit dengan ketuk dua kali.
- Menu **Penggaris** (grup Kanvas): penggaris horizontal dan vertikal dalam px kanvas yang mengikuti zoom dan geser, plus kolom panduan 2/3/4/6/12 (tidak ikut ekspor).
- Menu **Simpanan** (grup Warna): simpan gaya objek dengan nama (warna, garis, efek, pola, font, bayangan, dll.) lalu terapkan ke objek lain, serta simpan palet warna pribadi; tersimpan di browser.

## Pembaruan V39
- Menu **Pemandu** (grup Kanvas): garis pemandu buatan sendiri (vertikal atau horizontal pada posisi px tertentu, tengah halaman, sepertiga, margin 6%) dengan snap saat objek digeser; tidak ikut ekspor.
- Menu **Filter**: bevel timbul, bayangan dalam, kilau tepi dalam.
- Menu **Diagram** (grup Pustaka): bentuk flowchart berlabel (proses, mulai/selesai, keputusan, data, dokumen, basis data) dan contoh alur 4 langkah lengkap dengan konektor panah.

## Pembaruan V40
- Tombol baru **Cari** (paling kiri di toolbar): cari fitur atau menu mana pun dengan kata kunci, sematkan menu favorit (☆), dan lihat menu yang terakhir dipakai. Tersimpan di browser.
- Menu **Filter+** (grup Warna): glitch RGB, pertajam, bloom, cat air, cair (liquid), hamburan piksel, bayangan VHS.
- Menu **Palet Tren** (grup Warna): 8 palet siap pakai (pastel, retro, hutan, samudra, senja, monokrom, kopi, neon) untuk objek terpilih atau semua objek, latar dari warna terang palet, dan swatch di halaman.
- Menu **Pola** (grup Pustaka): pola penuh halaman (sarang lebah, gelombang, chevron, plus, belah ketupat, sisik ikan, memphis) dengan warna, ukuran sel, dan transparansi.
- Menu **Organik** (grup Pustaka): blob acak, 3 blob bertumpuk, burst label, swoosh, pembatas gelombang atas atau bawah, dan sunburst.
- Menu **Teks Kreatif** (grup Huruf): outline kosong, isi + garis kontras, sorot stabilo, label pil, gema 3 lapis, garis bawah, huruf vertikal, tanda kutip.
- Menu **Massal** (grup Objek): ubah font semua teks, hapus atau atur garis tepi semua bentuk, sudut bulat, transparansi, skala semua objek, kunci semua, sembunyikan semua gambar.
- Menu **Lanjutan** (grup Objek): duplikat lanjutan (jumlah, geser, putar, skala per salinan), bungkus objek dengan kartu, pil, atau lingkaran, dan skala objek ke lebar, tinggi, cover, atau margin halaman.
- Menu **Tampil+** (grup Kanvas): mode kerangka, abu-abu, kontras tinggi, dan simulasi buta warna (protan, deutan, tritan). Hanya di layar, tidak ikut ekspor.
- Perbaikan: pemandu buatan sendiri tidak lagi terbawa ke desain atau proyek lain; pola dan sunburst dipotong rapi di tepi halaman, baik di layar maupun ekspor.

## Pembaruan V41
- Menu **Pintar** (grup Objek): susun mendatar/menurun, grid 2/3/4 kolom, sebar melingkar, acak posisi/rotasi/ukuran, pilih objek terbesar/terkecil, potong kanvas ke isi (margin 40 px), dan statistik desain (jumlah objek per jenis + warna dominan).
- Polesan tampilan: topbar kaca (blur), transisi halus, cincin fokus keyboard, target sentuh 44 px di layar sentuh, safe-area Android/iOS, dan dukungan *reduced motion*.
- Seluruh fitur V40 dipertahankan; uji otomatis menjalankan semua item menu tanpa error.

## Pembaruan V42
- Menu **Harmoni** (grup Warna): harmoni warna dari warna isi objek pertama (komplementer, analog, triadik, tetradik, split-komplementer, monokrom) untuk objek terpilih; swatch palet ditambahkan ke halaman; cek kontras teks vs latar (rasio WCAG); putar bertahap ±15° dan reset.
- Semua fitur V41 dipertahankan.

## Pembaruan V43
- **Seleksi kotak (marquee)**: dengan alat Pilih, seret di area kosong untuk memilih banyak objek sekaligus (objek terkunci/tersembunyi dilewati, grup ikut terpilih utuh, Shift atau tombol Multi menambah seleksi). Kotak tidak ikut ekspor.
- **Simpan otomatis + pemulihan**: draf disimpan otomatis ke browser beberapa detik setelah perubahan. Jika aplikasi tertutup sebelum disimpan, beranda menampilkan banner **Pulihkan** (mendukung proyek multi-halaman). Jika penyimpanan penuh, aplikasi memberi tahu dan tidak error.
- Menu **Templat** (grup Buat): 8 tata letak siap pakai yang menyesuaikan ukuran halaman: kutipan, poster acara, promo diskon, thumbnail YouTube, kartu nama, sertifikat, menu kafe, undangan. Semua teks bisa diedit; undo untuk membatalkan.
- Menu **Generatif** (grup Pustaka): spirograf (4 preset + kustom R/r/d dan warna), mawar (rose curve), Lissajous, **mandala** dari objek terpilih (6/8/12/16 bagian), konstelasi bintang, halftone radial/diagonal. Semuanya path vektor yang bisa diedit simpulnya.
- Menu **Ekspor+** (grup Berkas): paket **ZIP** tanpa pustaka luar (tiap objek jadi PNG, semua halaman PNG, paket lengkap PNG + SVG + proyek .cdms, paket ikon aplikasi 16-512 px), WebP, salin kode SVG, ekspor palet warna (.css/.json), skala 1-4x.
- Tombol **/** membuka pencarian fitur (Ctrl+K tetap membuka peluncur lama).
- **PWA**: service worker (jaringan dulu, cadangan offline; aktif jika dibuka lewat http/https), manifest dengan pintasan "Desain baru" (`?new=1`).
- **Perbaikan bug**: undo/redo tidak lagi menyisakan seleksi lama; saat penyimpanan browser penuh, berkas cadangan .cdms otomatis diunduh agar pekerjaan tidak hilang; bantuan keyboard/gestur diperbarui.
- **Desain**: menu popover bergerak halus dengan sheet bergagang di HP, grid 4 kolom di layar lebar, scrollbar tipis, tata letak 3 kolom lebih lapang di layar 1280/1700 px, mode HP landscape yang hemat tinggi, glow pada beranda. Mendukung *reduced motion*.
- Catatan teknis: lebar objek teks selalu diukur ulang oleh aplikasi saat render, jadi perataan tengah/kanan baru terlihat pada teks banyak baris; templat menghitung posisi tengah/kanan setelah render pertama. Semua fitur V42 dipertahankan; uji otomatis (Chromium headless) menekan 850 item menu di 85 menu tanpa error.

## Pembaruan V44
- **Perbaikan bug penting**: tombol grup **Pustaka** tidak punya menu (`hub_pustaka` tidak terdefinisi) sehingga Ikon, 3D, Infografis, Emoji, Mockup, Grafik, Segel, Dekorasi, Anotasi, Kalender, Diagram, dan Generatif tidak bisa dibuka dari toolbar. Kini grup tanpa daftar dibuatkan otomatis.
- Menu **Gaya+** (grup Warna): salin/tempel gaya (Ctrl+Shift+C / Ctrl+Shift+V), tukar isi dan garis, terang/gelap/jenuh, warna negatif, abu-abu, transparansi, tebal garis.
- Menu **Tata+** (grup Atur): grid otomatis 2-6 kolom, susunan melingkar, tumpuk/rapatkan, rata ke objek pertama, acak posisi.
- Menu **Ukuran+** (grup Atur): pas/penuhi halaman, lebar/tinggi halaman, skala 25-200%, samakan dengan objek pertama, jadikan persegi.
- Menu **Pilih+** (grup Atur): pilih berdasarkan warna/jenis/garis/ukuran sama, balik pilihan, buka kunci semua, tampilkan semua, hapus tersembunyi / di luar halaman / duplikat persis.
- Menu **Pola** (grup Buat): panel grid dan lingkaran (baris, kolom, jarak, jumlah, radius, ikut berputar) serta preset cepat.
- Menu **Bantu+** (grup Kanvas): Info dokumen dan palet (ketuk warna untuk memilih semua objek berwarna itu).
- Desain: kaca buram pada topbar, cincin fokus keyboard, tata letak panel Pola yang rapi.
- Semua fitur V43 dipertahankan. Uji otomatis (Chromium headless) menekan setiap item pada seluruh menu di layar HP dan PC.

## Pembaruan V45
- **Perbaikan regresi V44**: menu "Pola" V44 menimpa menu "Pola" lama (pola satu halaman penuh). Menu V44 kini bernama **Klon** (grup Buat); **Pola** lama kembali berfungsi di grup Pustaka.
- **Bentuk+** (Buat): 12 bentuk vektor baru (petir, bulan sabit, tambah, centang, silang, chevron, segi lima, perisai, daun, ledakan, pita, oval bicara).
- **Huruf+** (Teks): ukuran huruf preset, perbesar/perkecil 10%, rata kiri/tengah/kanan.
- **Bagikan** (Berkas): bagikan PNG lewat lembar bagikan Android/iOS (WhatsApp dll.) atau salin PNG ke clipboard; jika tidak didukung, gambar diunduh.
- **Fokus** (Kanvas): zoom ke objek terpilih, pusatkan halaman, zoom 150%.
- **Aksen** (Kanvas): 7 warna aksen aplikasi (tersimpan) dan mode toolbar ringkas tanpa label.
- Desain: kanvas berbayang, panel membulat, bayangan aksen pada tombol aktif.
- Semua fitur V44 dipertahankan.

## Pembaruan V46
- **Perbaikan bug**: notifikasi (toast) menutupi item paling bawah pada menu sehingga ketukan tidak sampai ke tombol. Toast kini tidak menangkap sentuhan.
- **Bingkai** (Buat): bingkai halaman (tipis, tebal, membulat, ganda), sudut siku di 4 pojok, garis pemisah, kartu putih di belakang objek terpilih, lencana nomor.
- **Layer+** (Atur): nama otomatis semua objek, urutkan lapisan dari atas ke bawah, balik urutan tumpukan, isolasi objek terpilih, kunci objek lain.
- **Aksen**: ikuti tema sistem (gelap/terang). **Bantu+**: pasang di layar utama (PWA).
- Area aman layar berlekuk pada bilah bawah dan menu; target sentuh menu lebih besar.
- Semua fitur V45 dipertahankan.

## Pembaruan V47
- Menu **Presisi** (grup Atur): geser objek tepat 1/10/50 px ke 4 arah atau ke koordinat X,Y; putar ±1°, ±15°, ±90° dan reset rotasi; **salin cermin** (kiri-kanan, atas-bawah, 4 kuadran) terhadap sumbu tengah halaman; jarak sama 0/8/16/32 px antar objek (mendatar/menurun); rapatkan ke tepi halaman dengan margin 24 px.
- Semua fitur V46 dipertahankan.

## Pembaruan V48
- Menu **Halaman+** (grup Atur): salin objek terpilih ke halaman berikutnya/sebelumnya/semua halaman, pindahkan ke halaman berikutnya/sebelumnya, gandakan halaman 1/3/5×, dan lompat ke halaman pertama/terakhir/berikutnya/sebelumnya.
- Semua fitur V47 dipertahankan.

## Pembaruan V49
- Menu **Periksa** (grup Kanvas): pemeriksa desain. Menampilkan jumlah masalah (objek di luar halaman, teks kecil, teks kontras rendah, teks kosong, objek tersembunyi, hampir transparan, ukuran terlalu kecil); ketuk baris untuk memilih objeknya, atau pakai tombol perbaikan sekali ketuk (bisa di-undo).
- Semua fitur V48 dipertahankan.

## Pembaruan V50
- Menu **Bertahap** (grup Atur): untuk 2+ objek terpilih (urut sesuai urutan dipilih): gradasi warna antar objek (6 preset), skala bertahap, putar bertahap (kipas, lingkar penuh), transparansi bertahap (pudar/muncul), dan jarak merata berurutan.
- **Periksa**: tombol baru untuk memperbaiki otomatis kontras teks rendah (hitam atau putih, mana yang lebih kontras dengan latar).
- Semua fitur V49 dipertahankan.

## Pembaruan V51
- Menu **Isi Contoh** (grup Buat): tambah teks placeholder siap pakai (judul, sub judul, paragraf lorem ipsum, tanggal hari ini, harga, diskon, telepon, @akun, situs, tagar, alamat) dan isi teks terpilih dengan lorem ipsum pendek/sedang/panjang, tanggal, atau nomor urut.
- Menu **Slot** (grup Atur): simpan seleksi ke 4 slot per halaman lalu panggil atau tambahkan kembali dengan satu ketukan (slot berlaku selama sesi dan tidak ikut proyek).
- Semua fitur V50 dipertahankan.

## Pembaruan V52
- Menu **Komponen UI** (grup Pustaka): 14 komponen antarmuka siap pakai, semuanya berupa objek vektor yang bisa diedit dan dikelompokkan: tombol utama/garis, chip, toggle aktif/mati, kolom isian, kolom pencarian, tab bar, avatar, bilah progres, rating bintang, lencana notifikasi, kartu statistik, dan kartu produk. Ditempatkan di tengah halaman.
- Semua fitur V51 dipertahankan.

## Pembaruan V53
- Menu **Kartu Sosmed** (grup Pustaka): 9 kartu siap pakai berupa objek vektor yang bisa diedit: testimoni, postingan sosmed, kartu profil, tombol play video, kupon diskon, banner promo, kartu harga, kartu jadwal acara, dan daftar fitur bercentang.
- Perbaikan: ikon kaca pembesar di Kolom pencarian (Komponen UI) lebih rapi.
- Semua fitur V52 dipertahankan.

## Pembaruan V54
- Menu **Dokumen** (grup Pustaka): 10 objek vektor siap edit dan dikelompokkan: voucher hadiah, label harga, papan skor, item menu restoran, name tag, kop surat, sampul buku, garis isian, kotak centang, dan kolom tanda tangan. Ditempatkan di tengah halaman.
- Menu **Sudut+** (grup Atur): radius persegi berdasarkan persen sisi terpendek (0-50%), tambah/kurangi radius 8/24 px, samakan dengan objek pertama, bentuk pil penuh, dan radius acak. Semua bisa di-undo.
- Service worker naik ke cache cdms-v54 dan memuat modul baru.
- Semua fitur V53 dipertahankan.

## Pembaruan V55
- Menu **Angka** (grup Teks), bekerja pada teks terpilih yang berisi angka (format Indonesia, titik ribuan dan koma desimal): ubah ke **Rupiah**, ribuan, 2 desimal, persen, singkat (rb/jt/M), atau hapus pemisah; **terbilang** (mis. "Satu juta dua ratus lima puluh ribu rupiah"); angka **romawi** (1-3999); hitung cepat +1, −1, ×2, ÷2, +10%, −10%; serta **gabungkan 2+ teks** menjadi jumlah, rata-rata, terbesar, atau terkecil sebagai teks baru di bawah objek. Semua bisa di-undo.
- Menu **Kartu Info** (grup Pustaka): 9 kartu vektor siap edit dan dikelompokkan: resep, daftar tugas, cuaca, hitung mundur, pemutar musik, kontak, notifikasi, lokasi, dan target tabungan.
- Service worker naik ke cache cdms-v55 dan memuat modul baru (`js/more44.js`).
- Semua fitur V54 dipertahankan. Uji otomatis (Chromium headless) di layar HP dan PC: tanpa error.

## Pembaruan V56
- Menu **Tanggal** (grup Teks), bekerja pada teks terpilih yang berisi tanggal (24/10/2026, 24-10-2026, 24.10.26, 2026-10-24, atau 24 Oktober 2026, boleh diawali nama hari): ubah format (hari + tanggal panjang, tanggal panjang/singkat, angka, ISO), ambil nama hari atau bulan + tahun, tampilkan **relatif** (besok, 3 hari lagi, 5 hari yang lalu), **geser** ±1/±7 hari, ±1 bulan, ±1 tahun (gaya penulisan asli dipertahankan, akhir bulan disesuaikan), **selisih** hari antara 2 teks tanggal, dan **Sisipkan tanggal…** lewat pemilih tanggal. Semua bisa di-undo.
- Menu **Infografis+** (grup Pustaka): 9 objek vektor siap edit dan dikelompokkan: batang mendatar, donut persen, angka besar, corong penjualan, piramida 3 level, sebelum/sesudah, pro dan kontra, matriks 2×2, dan roadmap 3 fase.
- Service worker naik ke cache cdms-v56 dan memuat modul baru (`js/more45.js`).
- Semua fitur V55 dipertahankan.

## Pembaruan V57
- Menu **Rapikan** (grup Teks), bekerja pada teks terpilih: bersihkan spasi ganda, baris kosong, dan tanda baca; **kapital awal kalimat**, satu kalimat per baris, gabung jadi satu baris; **daftar** bullet atau bernomor (satu item per baris) dan hapus penanda; urutkan baris A→Z / Z→A, balik urutan, hapus duplikat; **kutip pintar** (“ ”, ’, …, —) dan kembali ke kutip lurus. Ukuran kotak teks ikut disesuaikan. Semua bisa di-undo.
- Menu **Tabel** (grup Pustaka): **Tabel kustom…** (1-15 baris, 1-8 kolom, 5 gaya: zebra, bersih, garis, gelap, neon, dengan/tanpa baris judul), **Teks → tabel** (satu baris teks per baris tabel, kolom dipisah koma, titik koma, | atau tab), dan 5 tabel siap pakai: jadwal pelajaran, daftar harga, perbandingan fitur, anggaran bulanan, skor pertandingan. Tabel berupa objek vektor yang dikelompokkan dan bisa diedit sel demi sel setelah Ungroup.
- Service worker naik ke cache cdms-v57 dan memuat modul baru (`js/more46.js`).
- Semua fitur V56 dipertahankan.

## Pembaruan V58
- Menu **Logo** (grup Pustaka): buat logo atau monogram dari nama merek lewat **Buat logo…** (nama, gaya, warna). Inisial diambil otomatis dari nama. 8 gaya: lingkaran, kotak bulat, perisai, heksagon, cincin ganda, bintang, horizontal (dengan tagline), dan tumpuk. Semua berupa objek vektor yang dikelompokkan dan bisa diedit.
- Menu **Papan** (grup Pustaka): 6 objek vektor siap edit dan dikelompokkan: Gantt 4 tugas, Kanban 3 kolom, peta pikiran, SWOT, bagan organisasi, dan diagram Venn.
- Service worker naik ke cache cdms-v58 dan memuat modul baru (`js/more47.js`).
- Semua fitur V57 dipertahankan.

## Pembaruan V59
- Menu **Cari Teks** (grup Teks): **Cari & ganti…** di semua teks atau hanya teks terpilih (opsi huruf besar/kecil dan kata utuh, jumlah cocok tampil langsung), **Pilih yang cocok**, **Pilih semua teks**, **Statistik teks** (kata, karakter, kalimat, baris, waktu baca), dan **Hapus teks kosong**. Semua perubahan bisa di-undo.
- Menu **Sampul** (grup Pustaka): 5 objek vektor siap edit dan dikelompokkan: sampul podcast, sampul playlist, banner channel, banner LinkedIn, dan highlight story.
- Service worker naik ke cache cdms-v59 dan memuat modul baru (`js/more48.js`).
- Semua fitur V58 dipertahankan.

## Pembaruan V60
- Menu **Jajar** (grup Atur), bekerja pada 2+ objek terpilih (objek satu grup bergerak bersama): **Jajar kustom…** (mendatar/menurun, jarak -500 s.d. 500 px, rata awal/tengah), pintasan jajar rapat atau 24 px, **tumpuk di tengah**, dan **urutan tumpukan** (besar/kecil di belakang, kiri → kanan, atas → bawah). Semua bisa di-undo.
- Menu **Callout** (grup Pustaka): 9 objek vektor siap edit dan dikelompokkan: kotak Info, Sukses, Peringatan, Bahaya, balon obrolan kiri/kanan, catatan tempel, kutipan blok, dan pita judul.
- Service worker naik ke cache cdms-v60 dan memuat modul baru (`js/more49.js`).
- Semua fitur V59 dipertahankan.

## Pembaruan V61
- Menu **Gaya Huruf** (grup Teks), bekerja pada teks terpilih: **aLtErNaTiNg**, **judul cerdas** (kapital tiap kata kecuali di/ke/dan/yang…), spasi lebar T E K S dan rapatkan kembali, huruf terbalik, urutan kata terbalik, **slug-url**, **#hashtag** dari kata, hapus aksen (é → e), dan ulang 3 kali. Ukuran kotak teks ikut disesuaikan. Semua bisa di-undo.
- Menu **Ucapan** (grup Pustaka): 6 kartu ucapan vektor siap edit dan dikelompokkan: ulang tahun, terima kasih, Lebaran, tahun baru, 17 Agustus, dan Natal.
- Service worker naik ke cache cdms-v61 dan memuat modul baru (`js/more50.js`).
- Semua fitur V60 dipertahankan.

## Pembaruan V62
- Menu **Toko** (grup Pustaka): 8 objek vektor siap edit dan dikelompokkan untuk jualan online: Terlaris, Garansi, Pita diskon, Gratis ongkir, Bayar di tempat, Stok terbatas, Harga coret, dan Tombol beli.
- Menu **Kontak** (grup Pustaka): 5 objek vektor siap edit: footer kontak, jam buka, pin lokasi, ajakan hubungi, dan kartu tautan (link-in-bio).
- Service worker naik ke cache cdms-v62 dan memuat modul baru (`js/more51.js`).
- Semua fitur V61 dipertahankan.

## Pembaruan V63
- Menu **Edukasi** (grup Pustaka): 6 objek vektor siap edit dan dikelompokkan: papan tulis, daftar hadir, jadwal piket, soal pilihan ganda, flashcard, dan kartu rumus.
- Menu **Acara** (grup Pustaka): 6 objek vektor siap edit: agenda acara, daftar acara, kartu pembicara, undangan RSVP, denah meja, dan gelang masuk VIP.
- Service worker naik ke cache cdms-v63 dan memuat modul baru (`js/more52.js`).
- Semua fitur V62 dipertahankan.

## Pembaruan V64
- Perbaikan: lebar teks pada semua objek siap pakai (kartu, komponen, tabel, logo, dll.) kini **diukur** dengan canvas, bukan diperkirakan, sehingga teks yang ditengahkan benar-benar berada di tengah.
- Menu **Pusat Teks** (grup Teks): **Ukur ulang kotak teks** (semua teks atau yang dipilih, tetap berpusat di posisi lama), **Pusatkan di objek di bawahnya** (tengah X+Y, mendatar, atau menurun), dan **Rata dalam objek** (kiri, kanan, atas, bawah dengan jarak 24 px). Semua bisa di-undo.
- Service worker naik ke cache cdms-v64 dan memuat modul baru (`js/more53.js`).
- Semua fitur V63 dipertahankan.

## Pembaruan V65
- Menu **Kebiasaan** (grup Pustaka): 6 objek vektor siap edit dan dikelompokkan: pelacak kebiasaan mingguan, air minum, mood, tidur, jadwal olahraga, dan kartu nilai gizi.
- Menu **Perjalanan** (grup Pustaka): 6 objek vektor siap edit: boarding pass, rute perjalanan, pemesanan hotel, itinerari 3 hari, daftar bawaan, dan hitung mundur liburan.
- Service worker naik ke cache cdms-v65 dan memuat modul baru (`js/more54.js`).
- Semua fitur V64 dipertahankan.

## Pembaruan V66
- Menu **Isi Kartu** (grup Teks): ubah isi kartu siap pakai tanpa Ungroup. **Edit semua teks di grup…** menampilkan satu formulir berisi seluruh teks pada grup terpilih (urut atas ke bawah); lebar kotak teks otomatis diukur ulang dan teks yang tadinya di tengah tetap di tengah. Juga **Pilih teks dalam grup**, **Salin isi teks grup** lalu **Tempel isi ke grup lain** (berdasarkan urutan), dan **Ganti semua jadi “Teks”**. Semua bisa di-undo.
- Service worker naik ke cache cdms-v66 dan memuat modul baru (`js/more55.js`).
- Semua fitur V65 dipertahankan.

## Pembaruan V67
- Menu **Gabung Data** (grup Atur): ubah satu kartu/grup menjadi banyak kartu dari daftar data. Pilih kartu, buka **Buat banyak kartu dari data…**, tulis satu baris per kartu (kolom dipisah `|`, tab, `;` atau koma; baris pertama otomatis berisi teks kartu saat ini), atur jumlah kartu per baris dan jarak, lalu jadi: maksimal 60 kartu yang tersusun rapi dalam grid. Tiap kolom mengisi teks kartu berurutan dari atas ke bawah, lebar teks diukur ulang dan teks tengah tetap di tengah. Semua bisa di-undo (satu kali).
- Service worker naik ke cache cdms-v67 dan memuat modul baru (`js/more56.js`).
- Semua fitur V66 dipertahankan.

## Pembaruan V68
- **Bar aksi cepat** (yang muncul di dekat objek terpilih) diperluas dengan tombol baru: **Kelompokkan** (muncul saat 2+ objek dipilih), **Lepas kelompok**, **Tengahkan di halaman** (seluruh grup ikut), **Edit isi kartu** (formulir semua teks pada grup), dan **Warna isi** (pemilih warna langsung untuk objek terpilih, satu kali Undo membatalkan seluruh perubahan warna). Tombol yang tidak relevan otomatis disembunyikan, dan bar bisa digeser mendatar di layar sempit.
- Service worker naik ke cache cdms-v68 dan memuat modul baru (`js/more57.js`, `css/v68.css`).
- Semua fitur V67 dipertahankan.

## Pembaruan V69
- **Panel Penata** (panel melayang, tetap terbuka saat Anda bekerja di kanvas; bisa digeser lewat judulnya di desktop, jadi sheet bawah di HP). Buka lewat tombol baru di topbar, tombol di bar aksi cepat, atau menu **Penata** (grup Atur). Grup selalu diperlakukan sebagai satu unit, semua aksi bisa di-undo.
  - **Susun**: sebar mendatar/menurun dengan jarak tepat (px), rata ke objek yang dipilih pertama (kiri/tengah/kanan/atas/tengah V/bawah), susun grid (jumlah kolom), susun melingkar (radius).
  - **Ukuran**: samakan lebar/tinggi dengan objek pertama, skala 50/90/110/200% atau persen kustom, **Penuhi halaman** dengan margin, slider transparansi dan sudut persegi langsung.
  - **Latar**: tambah **latar** (di belakang) atau **bingkai garis** (di atas) di sekeliling objek/grup terpilih, dengan jarak tepi, sudut, tebal, dan warna.
  - **Warna**: gradasi warna bertahap antar objek menurut urutan pilih, warna acak dari palet, rotasi acak ±derajat.
  - **Pilih**: pilih sejenis, pilih warna sama, balik pilihan; aksi cepat putar 90° (grup berputar di pusatnya), sembunyikan, kunci.
- **Bar aksi cepat** mendapat 4 tombol baru: **Panel Penata**, **Putar 90°**, **Sembunyikan**, dan **Pilih sejenis**.
- Service worker naik ke cache cdms-v69 dan memuat modul baru (`js/more58.js`, `css/v69.css`).
- Semua fitur V68 dipertahankan.

## Pembaruan V70
- Panel Penata mendapat dua tab baru: **Efek** (bayangan dengan geser/blur/warna/opasitas, glow, hapus bayangan, beri/hapus garis tepi) dan **Teks** (atur ukuran huruf, A ±10%, tebal, miring, spasi huruf, BESAR/kecil/Judul, ukur ulang kotak teks). Berlaku untuk semua objek terpilih, bisa di-undo.
- Bar aksi cepat mendapat 3 tombol baru: **Bayangan hidup/mati**, **Salin ke kanan** (grup ikut disalin utuh), dan **panel Teks**.
- Menu baru **Penata+** (grup Atur) untuk membuka tab dan aksi cepat.
- Service worker naik ke cache cdms-v70 dan memuat `js/more59.js`.
- Semua fitur V69 dipertahankan.

## Pembaruan V71
- Panel Penata mendapat dua tab baru: **Layer** (tampilkan semua, buka semua kunci, isolasi pilihan, kunci yang lain, urut tumpukan menurut posisi, balik urutan, beri nama berurutan, hapus objek tersembunyi) dan **Kanvas** (preset 1:1, 4:5, Story, 16:9, A4, Link; ukuran kustom, tukar orientasi, warna latar, pangkas kanvas ke konten dengan margin, tambah ruang di keempat sisi). Semua bisa di-undo.
- Bar aksi cepat mendapat 4 tombol baru: **Tengah mendatar**, **Tengah menurun** (di halaman, grup ikut utuh), **Isolasi pilihan**, dan **Tampilkan semua**.
- Menu baru **Penata++** (grup Atur).
- Service worker naik ke cache cdms-v71 dan memuat `js/more60.js`.
- Semua fitur V70 dipertahankan.

## Pembaruan V72
- Panel Penata mendapat dua tab baru: **Ulang** (gandakan bertahap hingga 50 salinan dengan geser X/Y, putar, dan skala per salinan; **cermin** mendatar/menurun di seberang halaman) dan **Ekspor** (hanya objek/grup terpilih ke PNG, JPG, atau SVG dengan skala 0,25–6×, margin, warna latar JPG; **salin kode SVG** ke clipboard). Gandakan dan cermin bisa di-undo.
- Bar aksi cepat mendapat 4 tombol baru: **Balik menurun**, **Putar 90° kiri**, **Gandakan bertahap**, dan **Ekspor pilihan**.
- Menu baru **Penata 3** (grup Atur).
- Service worker naik ke cache cdms-v72 dan memuat `js/more61.js`.
- Semua fitur V71 dipertahankan.

## Pembaruan V73
- Panel Penata mendapat dua tab baru: **Posisi** (penempatan 9 titik di halaman dengan margin, geser per langkah dengan tombol panah, isi **X/Y/Lebar/Tinggi persis** untuk seluruh pilihan dengan opsi kunci rasio) dan **Garis** (atur tebal, tipis/tebal ±1, warna, pola putus-putus kustom, solid, hapus garis). Semua bisa di-undo.
- Bar aksi cepat mendapat 4 tombol baru: pindah ke **tepi kiri**, **kanan**, **atas**, dan **bawah** halaman (memakai margin dari tab Posisi, default 40 px).
- Menu baru **Penata 4** (grup Atur).
- Service worker naik ke cache cdms-v73 dan memuat `js/more62.js`.
- Semua fitur V72 dipertahankan.

## Pembaruan V74
- Panel Penata mendapat dua tab baru: **Gradien** (dua warna bebas, arah diagonal/vertikal/mendatar/radial, tukar warna, **gradien otomatis dari warna isi**, hapus gradien) dan **Filter** (kecerahan, kontras, saturasi, grayscale, sepia, hue, blur; slider tampil langsung pada semua objek terpilih, satu Undo membatalkan satu sesi geser).
- Bar aksi cepat mendapat 3 tombol baru: **Gradien**, **Filter**, dan **Hapus gradien, bayangan & filter** sekaligus.
- Menu baru **Penata 5** (grup Atur).
- Service worker naik ke cache cdms-v74 dan memuat `js/more63.js`.
- Semua fitur V73 dipertahankan.

## Pembaruan V75
- Panel Penata mendapat dua tab baru: **Gaya** (simpan gaya objek pertama sebagai preset bernama di perangkat, hingga 30; ketuk untuk menerapkan ke semua objek terpilih, hapus satu per satu atau semuanya, **terapkan gaya terakhir**; mencakup warna isi, garis, transparansi, sudut, bayangan, gradien, putus-putus, dan filter) dan **Info** (statistik desain: jumlah objek, grup, tersembunyi, terkunci, ukuran kanvas, rincian per jenis; **pilih menurut jenis** dan **cari menurut nama atau isi teks**).
- Bar aksi cepat mendapat 3 tombol baru: **Simpan gaya**, **Terapkan gaya terakhir**, dan **Info & pilih**.
- Menu baru **Penata 6** (grup Atur).
- Service worker naik ke cache cdms-v75 dan memuat `js/more64.js`.
- Semua fitur V74 dipertahankan.

## Pembaruan V76
- Panel Penata kini bisa **diciutkan** (tombol –) dan **mengingat tab terakhir** yang dibuka.
- Dua tab baru: **Menu** (daftar semua tab Penata dengan kotak cari) dan **Palet** (harmoni warna dari satu warna dasar: komplemen, analog, triadik, tetradik, monokrom; ketuk warna untuk mewarnai pilihan, **terapkan berurutan** per unit/grup, ambil warna dasar dari pilihan, salin kode warna, dan **teks kontras otomatis** yang memilih putih/hitam menurut warna objek di bawah teks).
- Bar aksi cepat mendapat 3 tombol baru: **Palet warna**, **Teks kontras otomatis**, dan **Semua tab**.
- Menu baru **Penata 7** (grup Atur).
- Service worker naik ke cache cdms-v76 dan memuat `js/more65.js`.
- Semua fitur V75 dipertahankan.

## Pembaruan V77
- Dua tab baru di panel Penata: **Pola** (titik, kotak, belah ketupat, garis mendatar/menurun dalam grid; ukuran, jarak, satu atau dua warna selang-seling ala papan catur; area halaman atau objek terpilih; diletakkan di belakang; hasilnya satu grup maks. 600 objek yang tetap bisa diedit) dan **Sisip** (judul, subjudul, paragraf contoh, **daftar bullet/nomor** dari teks satu butir per baris, garis pemisah; lebar teks diukur otomatis).
- Bar aksi cepat mendapat 3 tombol baru: **Pola**, **Sisip teks**, dan **Tebal/normal** untuk teks terpilih.
- Menu baru **Penata 8** (grup Atur).
- Service worker naik ke cache cdms-v77 dan memuat `js/more66.js`.
- Semua fitur V76 dipertahankan.

## Pembaruan V78
- Dua tab baru di panel Penata: **Bentuk** (12 bentuk siap pakai: segitiga, panah, hati, plus, awan, gelembung bicara, tetesan, perisai, sabit, petir, segi enam, jajar genjang; atur ukuran, warna isi/garis, tebal garis, dan letak di tengah halaman atau tengah objek terpilih; hasilnya kurva yang bisa diedit) dan **Bingkai** (bingkai halaman tunggal atau ganda dengan tebal, jarak tepi, sudut, dan warna; **bungkus objek terpilih** dengan pil/sudut bulat/kotak di belakangnya, satu untuk semua atau satu per objek/grup; **watermark teks berulang** miring dengan opasitas, jarak, dan sudut, satu grup maks. 80 teks).
- Bar aksi cepat mendapat 3 tombol baru: **Bentuk**, **Bingkai halaman**, dan **Bungkus dengan pil**.
- Menu baru **Penata 9** (grup Atur).
- Service worker naik ke cache cdms-v78 dan memuat `js/more67.js` serta `css/v78.css`.
- Semua fitur V77 dipertahankan.

## Pembaruan V79
- Dua tab baru di panel Penata: **Konektor** (panah/garis penghubung antar objek terpilih; gaya **lurus**, **siku**, atau **lengkung**; tebal, jarak dari objek, warna, putus-putus; kepala di ujung, dua arah, atau tanpa kepala; **rantai berurutan** untuk menghubungkan banyak objek sesuai urutan ketukan; setiap konektor berupa satu grup garis + kepala) dan **Label** (tombol pil, lencana bulat, pita, label harga, dan **bintang rating 0–5**; teks, ukuran huruf, warna latar/teks bisa diatur; diletakkan di tengah halaman atau tengah objek terpilih; setiap label satu grup yang bisa diedit).
- Bar aksi cepat mendapat 3 tombol baru: **Hubungkan dengan panah**, **Label & lencana**, dan **Bintang rating**.
- Menu baru **Penata 10** (grup Atur).
- Service worker naik ke cache cdms-v79 dan memuat `js/more68.js`.
- Semua fitur V78 dipertahankan.

## Pembaruan V80
- Dua tab baru di panel Penata: **Tabel** (tabel dari teks — satu baris per baris, kolom dipisah koma — atau tabel kosong dengan jumlah baris × kolom; lebar/tinggi sel, ukuran huruf, header, warna baris selang-seling dan garis; teks otomatis dikecilkan agar muat di sel dan seluruh tabel dikecilkan agar muat di halaman; satu grup maks. 400 sel) dan **Bagi** (8 tata letak: 2/3 kolom, 2/3 baris, grid 2×2/3×3, besar kiri + 2, besar atas + 2; margin, jarak antar sel, sudut; **buat bingkai kosong** di halaman atau di area objek terpilih, atau **tata objek terpilih ke sel** sebagai kolase — objek/grup diskalakan proporsional dan dipusatkan di tiap sel sesuai urutan ketukan).
- Bar aksi cepat mendapat 3 tombol baru: **Sisip tabel**, **Bagi halaman**, dan **Tata objek ke sel**.
- Menu baru **Penata 11** (grup Atur).
- Service worker naik ke cache cdms-v80 dan memuat `js/more69.js`.
- Semua fitur V79 dipertahankan.

## Pembaruan V81
- Dua tab baru di panel Penata: **Hias** (garis hias gelombang, zigzag, gelombang kotak, spiral, dan lengkung; atur lebar, amplitudo, jumlah periode, tebal, warna, putus-putus; diletakkan di tengah halaman atau tengah objek terpilih; hasilnya kurva yang tetap bisa diedit) dan **Acak** (geser acak, putar acak untuk objek tunggal, skala acak, opasitas acak, warna acak dari palet 8 warna atau variasi warna isi; berlaku per unit/grup; plus **tukar posisi acak** antar unit terpilih dan **acak urutan layer**; semua bisa di-undo).
- Bar aksi cepat mendapat 3 tombol baru: **Sisip gelombang**, **Garis hias**, dan **Acak pilihan**.
- Menu baru **Penata 12** (grup Atur).
- Service worker naik ke cache cdms-v81 dan memuat `js/more70.js`.
- Semua fitur V80 dipertahankan.

## Pembaruan V82
- Dua tab baru di panel Penata: **Ganti** (cari & ganti teks dengan opsi peka huruf besar/kecil, pada teks terpilih atau semua teks di desain; ubah huruf **BESAR / kecil / Judul / Kalimat**; tambah awalan dan akhiran; rapikan spasi ganda; **penomoran urut** atas ke bawah dengan templat seperti "Item {n}" dan angka awal bebas; lebar teks dihitung ulang otomatis) dan **Ukur** (garis dimensi bergaya gambar teknik untuk lebar, tinggi, atau keduanya dari objek/grup terpilih dengan label px, plus dimensi **jarak antar dua objek**; jarak, tebal, ukuran huruf, dan warna bisa diatur; setiap dimensi satu grup).
- Bar aksi cepat mendapat 3 tombol baru: **Cari & ganti teks**, **BESAR / kecil** (bolak-balik untuk teks terpilih), dan **Dimensi pilihan**.
- Menu baru **Penata 13** (grup Atur).
- Service worker naik ke cache cdms-v82 dan memuat `js/more71.js`.
- Semua fitur V81 dipertahankan.

## Pembaruan V83
- Dua tab baru di panel Penata: **Ikon** (12 ikon garis: centang, silang, plus, panah, lokasi, rumah, surat, jam, bel, kaca pembesar, tanda seru, tanda tanya; atur ukuran, tebal garis, warna ikon, dan **lingkaran latar** opsional dengan warna sendiri; diletakkan di tengah halaman atau tengah objek terpilih; hasilnya kurva yang tetap bisa diedit) dan **Mockup** (ponsel, tablet, laptop, jendela peramban, dan polaroid dengan teks keterangan; warna bodi dan layar bisa diatur; otomatis dikecilkan agar muat di halaman; setiap mockup satu grup).
- Bar aksi cepat mendapat 3 tombol baru: **Ikon garis**, **Mockup perangkat**, dan **Centang bulat** (centang putih di lingkaran hijau).
- Menu baru **Penata 14** (grup Atur).
- Service worker naik ke cache cdms-v83 dan memuat `js/more72.js`.
- Semua fitur V82 dipertahankan.

## Pembaruan V84
- Dua tab baru di panel Penata: **Spektrum** (daftar warna yang dipakai di desain beserta jumlah objeknya; ketuk warna untuk **memilih semua objek** berwarna itu; **ganti satu warna di seluruh desain** atau hanya di pilihan, termasuk warna gradien; **balikkan warna**, **abu-abu**, lebih terang/gelap, lebih pekat/pudar dengan kekuatan persen — berlaku pada pilihan, atau seluruh desain jika tidak ada pilihan) dan **Skala** (skala 50/75/125/150/200% atau persen khusus, bersama atau per objek/grup, titik tumpu tengah atau kiri atas; **ubah rasio** 1:1, 4:3, 3:2, 16:9, 9:16, 4:5 dengan mempertahankan lebar atau tinggi; **bulatkan** posisi atau ukuran ke kelipatan; **pas lebar** atau **pas tinggi** halaman dengan margin).
- Bar aksi cepat mendapat 3 tombol baru: **Warna di desain**, **Skala & rasio**, dan **Balikkan warna pilihan**.
- Menu baru **Penata 15** (grup Atur).
- Service worker naik ke cache cdms-v84 dan memuat `js/more73.js` serta `css/v84.css`.
- Semua fitur V83 dipertahankan.

## Pembaruan V85 (perapian ikon)
- **Satu sumber ikon**: seluruh ikon kini ada di `js/icons.js` (151 ikon, grid 24×24, garis 1.75 membulat, isian duotone `.d` dan titik detail `.a`). Tujuh blok `Object.assign(CDMS.Icons.P, …)` yang tersebar di `menus.js`, `more.js`, `more3.js`, `more5.js`, `more9.js`, `more58.js`, dan `more62.js` dihapus supaya tidak ada definisi ganda.
- **Ikon yang sebelumnya kosong diperbaiki**: `pages`, `curve`, `canvas`, dan `info` dulu dipanggil tetapi belum ada; ikon yang tidak dikenal sekarang jatuh ke ikon titik tiga, bukan kotak kosong.
- **Ikon menu dibedakan**: 147 tombol menu yang dulu hanya memakai 33 ikon berbeda (banyak yang berbagi ikon persegi, teks, atau layer) kini memakai 115 ikon berbeda, misalnya Mockup, Kurva, Kolase, Kode QR, Kalender, Pipet, Diagram, Tabel, Kartu, Dokumen, Toko, dan Acara.
- **Ikon baru untuk kontrol umum**: tutup (×), zoom −/＋, dan Sesuaikan memakai ikon SVG; tombol Menu di bilah bawah memakai ikon hamburger, bukan roda gigi yang sama dengan Pengaturan.
- **Ikon aplikasi baru**: tanda kurva Bézier (jangkar kotak dan titik kendali) di atas gradien ungu–cyan. `icon.svg` (favicon/any), `icon-maskable.svg` dan `icon-maskable-512.png` (aman untuk masker Android), `icon-192.png`, `icon-512.png`, dan `icon-180.png` (apple-touch-icon). `manifest.json` memisahkan ikon `any` dan `maskable`.
- **Logo di bilah atas** kini memakai id gradien unik sehingga latar gradiennya tampil (sebelumnya hanya garis putih karena gradien merujuk ke logo splash yang tersembunyi).
- **CSS**: aturan dasar `.ic` dipindah dari `upgrade2.css` ke `css/v85.css` (satu-satunya tempat); duplikat `.tool.active .ic .d` dihapus dari `upgrade2.css` dan `pro.css`.
- Service worker naik ke cache cdms-v85 dan memuat `css/v85.css` serta ikon PNG baru.
- Semua fitur V84 dipertahankan.



## Pembaruan V86 (grup menu Kelompok)
- **Grup menu baru "Kelompok"** di toolbar (di samping Atur), berisi empat tombol: **Kelola** (kelompokkan/gabung grup, lepas, keluarkan dari grup, duplikat, hapus, pilih anggota / semua grup / objek tanpa grup), **Status** (kunci, buka kunci, sembunyikan, tampilkan semua, beri nama, tengahkan, rapatkan layer, bersihkan grup beranggota satu), **Otomatis**, dan **Panel grup**.
- **Tab Grup** di panel Penata: daftar semua grup dengan nama dan jumlah objek; ketuk untuk memilih, **+** menambahkan objek terpilih ke grup itu, gembok dan mata untuk mengunci atau menyembunyikan satu grup. Nama grup disimpan di proyek.
- **Tab Otomatis**: buat banyak grup sekaligus menurut **jenis objek**, **warna isi**, **baris**, **kolom**, atau **objek yang saling bersentuhan** (dengan toleransi celah). Objek terkunci/tersembunyi dilewati; opsi hanya objek yang belum berkelompok.
- Bar aksi cepat mendapat 3 tombol: **Panel grup**, **Kelompokkan / gabung**, dan **Kunci / buka grup**.
- Pintasan baru **Ctrl+Shift+G** = lepas kelompok (Ctrl+G tetap mengelompokkan).
- Service worker naik ke cache cdms-v86 dan memuat `js/more74.js` serta `css/v86.css`.
- Semua fitur V85 dipertahankan.


## Pembaruan V87 (grup menu Isolasi)
- **Grup menu baru "Isolasi"** di toolbar (setelah Kelompok), tiga tombol: **Isolasi** (masuk/keluar, panel), **Selain** (kunci atau sembunyikan semua objek selain pilihan, buka semua kunci), dan **Anggota** (tata isi grup).
- **Mode isolasi**: pilih grup atau objek lalu masuk; objek lain dikunci dan diredupkan sementara, ada banner "Mode isolasi" dengan tombol Keluar. Keluar mengembalikan kunci dan opasitas semula; membuka proyek lain juga membersihkan sisa isolasi.
- **Tab Isolasi** dan **tab Anggota** di panel Penata. Anggota: rata kiri/tengah/kanan/atas/tengah/bawah di dalam grup, sebar rata atau jarak tepat (horizontal/vertikal), samakan lebar/tinggi (maks/min), susun grid di dalam grup, balik urutan layer anggota. Tanpa grup, berlaku pada 2 objek terpilih atau lebih.
- Bar aksi cepat: tombol **Isolasi** dan **Tata anggota**. Pintasan **Ctrl+Shift+I** = masuk/keluar isolasi.
- Service worker naik ke cache cdms-v87 dan memuat `js/more75.js` serta `css/v87.css`.
- Semua fitur V86 dipertahankan.


## Pembaruan V88 (grup menu Koleksi)
- **Grup menu baru "Koleksi"** di toolbar (setelah Isolasi): **Simpan & pakai** dan **Ekspor / impor**.
- **Koleksi item**: simpan objek atau grup terpilih sebagai item yang bisa dipakai ulang di proyek lain, atau simpan **semua grup** desain sekaligus. Nama grup menjadi nama item; nama bisa diisi sendiri.
- **Tab Koleksi** di panel Penata: daftar dengan pratinjau mini dan pencarian; **sisip** di tengah halaman dengan skala persen, **ganti pilihan** dengan item (diletakkan di tengah pilihan lama), ganti nama, duplikat, hapus. Item multi-objek disisipkan sebagai grup baru dengan id baru.
- **Ekspor / impor** koleksi sebagai `.json` (impor divalidasi, maks 8 MB) dan kosongkan koleksi.
- Koleksi disimpan di browser perangkat ini (tidak ikut berkas proyek); jika penyimpanan penuh, muncul peringatan.
- Bar aksi cepat: tombol **Simpan ke koleksi** dan **Buka koleksi**.
- Service worker naik ke cache cdms-v88 dan memuat `js/more76.js` serta `css/v88.css`.
- Semua fitur V87 dipertahankan.


## Pembaruan V89 (grup menu Varian)
- **Grup menu baru "Varian"** di toolbar (setelah Koleksi): **Tema warna** dan **Versi cepat**.
- **Tema warna**: 8 palet (Laut, Senja, Hutan, Mono, Pastel, Neon, Bumi, Kontras). Warna isi, garis, dan gradien pada pilihan (atau seluruh desain jika tidak ada pilihan) dipetakan ke palet menurut terang-gelapnya sehingga kontras terjaga; latar halaman ikut berubah bila seluruh desain. Opsi **acak penempatan** dan tombol **Tema acak**. Gambar tidak diubah; semua bisa di-undo.
- **Versi cepat**: simpan snapshot seluruh desain (objek dan halaman) dengan nama, pulihkan, ganti nama, hapus; maksimum 12 versi di browser perangkat ini. Memulihkan bisa di-undo.
- Tab **Tema** dan **Versi** di panel Penata; bar aksi cepat mendapat tombol Tema warna, Tema acak, dan Simpan versi.
- Service worker naik ke cache cdms-v89 dan memuat `js/more77.js` serta `css/v89.css`.
- Semua fitur V88 dipertahankan.

## Catatan teknis V86–V89
- Tab panel Penata berbagi satu objek handler (`data-h`). Mulai V86 handler tab baru diberi prefiks (`x86_`, `x87_`, `x88_`, `x89_`) supaya tidak menimpa tombol tab lama. (Sejak V90 hal ini sudah teratasi untuk semua tab: lihat catatan V90.)
- Tab Grup, Koleksi, Tema, dan Versi menggambar ulang daftarnya otomatis saat dibuka lewat `openTab`.


## Pembaruan V90 (grup menu Periksa + perbaikan tombol panel)
- **Perbaikan**: tombol panel Penata kini dicari menurut tab tempat tombol berada, sehingga nama handler yang sama di tab berbeda (`bg`, `tb`, `sr`, `s50`, `ph`, dst.) tidak lagi saling menimpa. Tab bawaan memakai salinan handler aslinya.
- **Grup menu baru "Periksa"** di toolbar (setelah Varian): **Periksa desain** dan **Daftar masalah**.
- **Pemeriksa desain** dengan skor 0–100: teks kosong, teks terlalu kecil (< 12 px), **kontras teks rendah** (rasio WCAG < 3:1 terhadap objek berwarna di belakang teks atau latar halaman), objek sepenuhnya di luar halaman, objek menjorok keluar, **duplikat persis**, objek hampir tak terlihat, dan objek tersembunyi. Tiap masalah punya tombol **Pilih** dan **Perbaiki**; **Perbaiki semua** menjalankan seluruh perbaikan sekaligus (objek tersembunyi dibiarkan). Semua bisa di-undo.
- Tab **Periksa** di panel Penata (otomatis memeriksa saat dibuka); bar aksi cepat mendapat tombol **Periksa desain** dan **Perbaiki semua masalah**.
- Service worker naik ke cache cdms-v90 dan memuat `js/more78.js` serta `css/v90.css`.
- Semua fitur V89 dipertahankan.


## Pembaruan V91 (grup menu Ekspor Lot)
- **Grup menu baru "Ekspor Lot"** di toolbar (setelah Periksa): **Ekspor ZIP** dan **Pengaturan lot**.
- **Ekspor banyak bagian sekaligus ke satu berkas ZIP**: semua grup, grup terpilih, tiap objek terpilih, atau tiap objek di desain. Format **PNG / JPG / SVG**, skala 0,25–6×, margin, latar transparan atau berwarna. Nama berkas diambil dari nama grup (dibersihkan dan dibuat unik); objek tersembunyi dilewati; maksimum 100 berkas per lot.
- ZIP dibuat langsung di browser (tanpa pustaka luar, tanpa kompresi, CRC32 valid) sehingga tetap berjalan offline.
- Tab **Lot** di panel Penata; bar aksi cepat mendapat tombol **Ekspor semua grup ke ZIP** dan **Pengaturan Ekspor Lot**.
- Service worker naik ke cache cdms-v91 dan memuat `js/more79.js`.
- Semua fitur V90 dipertahankan.


## Pembaruan V92 (grup menu Ritme)
- **Grup menu baru "Ritme"** di toolbar (setelah Ekspor Lot): **Jarak** dan **Sprite**.
- **Analisis jarak**: pilih 3 objek atau grup (grup dihitung satu unit); panel menampilkan jarak tiap pasangan berurutan dengan batang, menandai yang menyimpang dari median, serta min / rata-rata / median / maks dan status seragam. Arah otomatis, mendatar, atau menurun.
- **Seragamkan jarak**: ke rata-rata, median, terkecil, atau jarak tepat (px); opsi mempertahankan titik tengah barisan; **ratakan sumbu silang** (tengah). Semua bisa di-undo.
- **Lembar sprite**: susun grup (atau objek terpilih; tanpa pilihan, semua grup, atau tiap objek bila tidak ada grup) dalam satu gambar berpetak sama besar, PNG atau SVG, kolom otomatis atau tetap, margin petak, skala, latar transparan/berwarna, dengan **atlas JSON** (nama + x, y, w, h tiap petak) di dalam ZIP.
- Tab **Ritme** dan **Sprite** di panel Penata; bar aksi cepat mendapat tombol Analisis jarak, Seragamkan jarak, dan Lembar sprite.
- Service worker naik ke cache cdms-v92 dan memuat `js/more80.js` serta `css/v92.css`.
- Semua fitur V91 dipertahankan.

## Pembaruan V93 (tombol Penata digabung)
- 16 tombol Penata (Penata, Penata+, Penata++, Penata 3 sampai Penata 15) yang ikon dan fungsinya hampir sama digabung menjadi satu tombol "Penata" di grup Objek.
- Menu Penata kini berisi: Panel (buka/tutup), Tab Penata (semua tab dalam grid ikon), dan Cepat (semua aksi cepat tanpa duplikat).
- File baru `js/more81.js`; service worker naik ke cache cdms-v93.

## Pembaruan V94 (grup Siap Cetak & Gema Warna)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Siap Cetak** (ikon printer)
  - **Kertas** (ikon kertas): ukuran A2–A6, B5, Letter, Legal, kartu nama, KTP, foto 4R / 3×4, kartu pos, amplop DL atau ukuran sendiri (mm), pada 72/96/150/300 dpi, potret/lanskap, opsi isi desain ikut diskalakan.
  - **Tanda Potong** (ikon tanda sudut): pasang tanda potong + bleed 3/5 mm (opsi garis bleed magenta); kanvas diperluas dan isi dipindah ke tengah, **Hapus tanda potong** mengembalikan kanvas persis seperti semula.
  - **Ukuran Fisik** (ikon kaliper): ukuran objek/kanvas dalam mm · cm · inci, setel lebar/tinggi/lebar×tinggi dalam mm.
- **Gema Warna** (ikon gelombang)
  - **Gema** (ikon salinan bertingkat): 3/5/8 salinan di belakang objek, arah membesar, mengecil, atau bergeser, opacity memudar; membuat ulang menggantikan gema lama; hapus gema.
  - **Tempel Grid** (ikon grid): kelipatan 2–50 px; tempel posisi, posisi + ukuran, atau titik tengah ke grid (grup dipindah sebagai satu unit).
  - **Kocok Warna** (ikon acak): palet harmonis analog, komplementer, triad, pastel, gelap, neon untuk isi atau garis; putar warna isi antar objek.
- 8 ikon baru (printer, paper, cropmark, caliper, wavefx, echo, snapgrid, shuffle). File baru `js/more82.js`; service worker naik ke cache cdms-v94. Semua aksi bisa di-undo; fitur V93 dipertahankan.

## Pembaruan V95 (grup Pola Lembar & Anotasi)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Pola Lembar** (ikon empat ubin)
  - **Mozaik** (ikon ubin bergradasi): pecah objek jadi ubin 4–16 kolom dengan celah 0–8 px; gaya ombre mendatar, ombre diagonal, papan catur, acak, acak warna; lingkaran menghasilkan mozaik bulat; objek asal bisa diganti atau dipertahankan.
  - **Lembar Salin** (ikon lembar label): isi halaman dengan salinan objek/grup seperti lembar label, margin dan jarak diatur, atau batasi 2/3/4 kolom.
  - **Pantulan** (ikon bayangan cermin): pantulan di bawah (lantai) atau di kanan dengan opacity 20/35/50% dan celah; hapus pantulan.
- **Anotasi** (ikon balon catatan)
  - **Dimensi** (ikon garis ukuran): garis lebar/tinggi dengan label px, mm, atau cm (mengikuti dpi dari menu Kertas), jarak garis 16/32/64 px.
  - **Kartu Palet** (ikon kartu warna): kartu berisi hingga 12 warna dari desain atau pilihan lengkap dengan kode hex, susunan mendatar atau menurun.
  - **Penanda** (ikon bendera): lencana nomor urut sesuai urutan pilih, 4 warna, nomor awal bisa diatur.
- 8 ikon baru (tilesheet, mosaic, labelsheet, reflect, annotate, dimline, swatchcard, flagpin). File baru `js/more83.js`; service worker naik ke cache cdms-v95. Hasil berupa objek/grup biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V94 dipertahankan.

## Pembaruan V96 (grup Geometri Hias & Data Visual)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Geometri Hias** (ikon rosette)
  - **Cincin** (ikon lingkaran konsentris): 4/6/8/12 cincin, gaya isi bertingkat, garis, atau selang-seling; memakai warna isi objek terpilih dan berpusat di pilihan (tanpa pilihan: tengah halaman).
  - **Roset** (ikon kelopak): 6/8/12/16 kelopak melingkar dengan warna analog, pelangi, atau ombre, plus putik di tengah.
  - **Jaring** (ikon jaringan): 20/40/70 titik acak yang terhubung garis bila berdekatan, palet Neon, Biru, atau Mono.
- **Data Visual** (ikon meteran)
  - **Radar** (ikon radar): grafik laba-laba dari 3–10 angka 0–100 (boleh bernama: `Desain=80, Kode=60`) dengan cincin skala, sumbu, titik, dan label.
  - **Dial** (ikon piringan): meteran setengah lingkaran 25/50/75/90% atau nilai sendiri; warna merah/kuning/hijau menurut nilai.
  - **Bilah Skor** (ikon bilah): daftar bilah persentase `Nama=nilai` (1–12 baris), warna bergilir, teks menyesuaikan latar terang/gelap.
- 8 ikon baru (rosette, rings, petal, network, gaugechart, radar, dial, scorebars). File baru `js/more84.js`; service worker naik ke cache cdms-v96. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V95 dipertahankan.

## Pembaruan V97 (grup Lanskap & Aksen Teks)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Lanskap** (ikon lanskap)
  - **Pegunungan** (ikon gunung): 2/3/4 lapis gunung bergerigi acak, langit gradasi dan matahari (bisa dimatikan), palet Senja, Biru, Hijau, Mono.
  - **Gelombang Lapis** (ikon ombak): 3/4/5 pita gelombang bertingkat di bagian bawah, palet Laut, Senja, Hijau, Mono.
  - **Malam** (ikon bulan): langit malam gradasi, 40/80/140 bintang berbagai ukuran dan kecerahan, bulan sabit.
- **Aksen Teks** (ikon huruf A bergaris bawah)
  - **Pita Sudut** (ikon pita): pita diagonal berteks (mis. BARU) di salah satu dari 4 sudut halaman, 4 warna.
  - **Daftar Titik** (ikon daftar berpengisi): daftar `Nama=nilai` dengan garis pengisi titik, putus, atau penuh (cocok untuk menu dan daftar harga); teks menyesuaikan latar terang/gelap.
  - **Garis Hias** (ikon gelombang): garis gelombang, zigzag, ganda, titik, atau goresan kuas di bawah objek terpilih, warna mengikuti objek, tebal 3/5/8 px.
- 8 ikon baru (landscape, mountain, waves, moon, accent, ribbon, leader, squiggle). File baru `js/more85.js`; service worker naik ke cache cdms-v97. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V96 dipertahankan.

## Pembaruan V98 (grup Bingkai Hias & Pola Latar)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Bingkai Hias** (ikon bingkai)
  - **Bingkai** (ikon bingkai sudut potong): tunggal, ganda, sudut potong, sudut bulat, atau putus; warna Emas/Hitam/Merah/Biru/Putih, tebal 4/8/14 px, margin 16/32/56 px.
  - **Sudut Hias** (ikon sudut): ornamen di 4 sudut halaman, gaya siku (ganda), lengkung, atau kuncup (siku + bulatan); ukuran kecil/sedang/besar, warna sama dengan Bingkai.
  - **Lencana** (ikon medali): segel bergerigi dengan cincin, teks tebal (maks 12 huruf, ukuran huruf menyesuaikan), dan 4 bintang; 4 warna, 3 ukuran, di tengah halaman.
- **Pola Latar** (ikon garis miring berpetak)
  - **Garis Miring** (ikon strip): latar strip dua warna arah diagonal /, diagonal \\, tegak, atau mendatar; lebar strip 24/48/96 px; tiap strip dipotong tepat di tepi halaman (maks. ±160 strip).
  - **Halftone** (ikon titik mengecil): titik berubah ukuran dan warna dari kiri→kanan, atas→bawah, diagonal, atau dari tengah; petak 24/36/54 px (otomatis dilebarkan agar maks. ±700 titik); latar bisa dimatikan.
  - **Segitiga** (ikon low-poly): mozaik segitiga bergradasi dengan titik acak (hasil berbeda tiap dibuat), 6/9/13 kolom, maks. ±700 segitiga; tepi segitiga ditutup agar tanpa celah.
- Palet Pola Latar: Senja, Biru, Hijau, Mono, Laut (memakai palet Lanskap V97).
- 8 ikon baru (frame98, border98, corner98, badge98, bgpat98, stripes98, halftone98, lowpoly98). File baru `js/more86.js`; `js/more85.js` kini mengekspor helper bersama `CDMS.Util97` agar tidak ada kode duplikat; service worker naik ke cache cdms-v98. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V97 dipertahankan.

## Pembaruan V99 (grup Kartu & Infografis)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Kartu** (ikon kartu)
  - **Tiket** (ikon tiket): tiket berlubang di kiri-kanan dengan garis perforasi putus-putus, judul dan subjudul (`Judul=Subjudul`), stub bernomor acak; 4 warna.
  - **Kartu Nama** (ikon kartu bergaris aksen): nama, jabatan, dan sampai 3 baris kontak (telepon, email, dll.) dengan garis aksen; tema terang atau gelap, 4 warna aksen, rasio 1,75:1 di tengah halaman.
  - **Label Harga** (ikon tag): tag berujung runcing dengan lubang gantungan dan teks tebal (mis. DISKON 50%); 4 warna.
- **Infografis** (ikon info)
  - **Langkah** (ikon tiga lingkaran): 2–6 lingkaran bernomor dihubungkan garis dengan label, mendatar atau menurun, warna gradasi palet.
  - **Garis Waktu** (ikon sumbu bertitik): 2–8 peristiwa `Tahun=Keterangan`, bergantian atas/bawah (mendatar) atau kiri/kanan (menurun).
  - **Donat** (ikon donat): diagram donat dari `Nama=nilai` (2–8 data, angka positif; desimal pakai titik karena koma dipakai sebagai pemisah), persen terbesar di tengah, legenda berpersen, lubang tengah lebar/sedang/tipis.
- Palet Infografis: Laut, Senja, Hijau, Biru, Mono (memakai palet Lanskap V97).
- 8 ikon baru (card99, ticket99, namecard99, pricetag99, info99, steps99, timeline99, donut99). File baru `js/more87.js`; `js/more86.js` kini juga mengekspor `chips`, `poly`, `clip` ke `CDMS.Util97`; service worker naik ke cache cdms-v99. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V98 dipertahankan.

## Pembaruan V100 (grup Latar Seru & Catatan)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Latar Seru** (ikon bintang meledak)
  - **Sinar** (ikon matahari bersinar): sunburst sinar berselang-seling mengisi halaman, 12/20/32 sinar, warna Komik, Retro, Biru, Mono, pusat di tengah, atas, atau bawah; tiap sinar dipotong tepat di tepi halaman.
  - **Percik** (ikon cipratan): 1/3/5 cipratan cat acak berbentuk organik dengan tetesan di sekelilingnya, ukuran kecil/sedang/besar, warna mengikuti palet; hasil berbeda tiap kali dibuat.
  - **Konfeti** (ikon konfeti): 40/80/150 potongan acak (kertas miring, bulat, segitiga) dengan warna Pesta atau mengikuti palet.
- **Catatan** (ikon papan catatan)
  - **Kertas** (ikon lembar bergaris): kertas bergaris (dengan garis margin merah), kotak, atau titik; jarak 24/36/48 px (otomatis dilebarkan agar maks. ±200 garis / ±900 titik); warna kertas krem, kuning, biru muda.
  - **Balon** (ikon balon): balon bicara (dengan ekor), pikir (dengan gelembung), atau teriak (bergerigi); teks maks 60 huruf dibungkus otomatis dan ukuran huruf menyesuaikan halaman.
  - **Catatan Tempel** (ikon kertas sticky): kertas catatan di tengah dengan bayangan, lipatan sudut, selotip miring, dan teks terbungkus; 4 warna.
- Palet Percik dan Konfeti: Senja, Laut, Hijau, Biru, Mono (memakai palet Lanskap V97).
- 8 ikon baru (fun100, sunburst100, splat100, confetti100, note100, paper100, bubble100, sticky100). File baru `js/more88.js` memakai helper bersama `CDMS.Util97`; service worker naik ke cache cdms-v100. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V99 dipertahankan.

## Pembaruan V101 (grup Bagan & Pita & Tanda)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Bagan** (ikon grafik garis)
  - **Batang** (ikon batang): bagan batang dari data `Nama=nilai` (2–8 data, angka positif; desimal pakai titik karena koma dipakai sebagai pemisah), tegak atau mendatar, nilai di ujung batang, warna gradasi palet, di atas panel putih agar teks selalu terbaca.
  - **Progres** (ikon bilah): 1–6 bilah persen dari `Nama=0-100`, jalur abu-abu dengan isi berujung bulat dan persen di kanan.
  - **Tabel** (ikon tabel): tabel 3/4/6/8 baris × 2/3/4/5 kolom dengan header berwarna palet, baris selang-seling, dan garis sel; isi sel diedit lewat alat Teks.
- **Pita & Tanda** (ikon bintang)
  - **Pita** (ikon banner): banner bertuliskan teks tebal (maks 24 huruf, ukuran huruf menyesuaikan lebar halaman) dengan dua ekor berlekuk dan lipatan lebih gelap; warna Merah/Biru/Hijau/Emas.
  - **Bintang Nilai** (ikon bintang): 5 bintang, sebanyak 1–5 terisi emas dan sisanya abu-abu, dengan keterangan "n dari 5".
  - **Panah** (ikon panah): panah blok ke kanan, bawah, kiri, atas, atau ganda; warna Merah/Biru/Hijau/Hitam; ukuran kecil/sedang/besar, di tengah halaman.
- Palet Bagan: Laut, Senja, Hijau, Biru, Mono (memakai palet Lanskap V97).
- 8 ikon baru (chart101, bar101, progress101, table101, deco101, banner101, star101, arrow101). File baru `js/more89.js` memakai helper bersama `CDMS.Util97`; service worker naik ke cache cdms-v101. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V100 dipertahankan.

## Pembaruan V102 (grup Diagram & Tipografi)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Diagram** (ikon diagram)
  - **Alur** (ikon kotak berpanah): 2–5 langkah dari daftar `Langkah,Langkah` (tiap maks 14 huruf), mendatar atau menurun; kotak pertama dan terakhir berbentuk kapsul, warna gradasi palet, teks otomatis hitam/putih mengikuti terang warna, panah abu-abu di antara kotak.
  - **Piramida** (ikon piramida): 2–5 tingkat dari atas ke bawah dengan celah tipis antar tingkat; ukuran huruf menyesuaikan lebar tiap tingkat.
  - **Venn** (ikon dua lingkaran): 2–3 lingkaran transparan yang saling tumpuk, nama di bagian luar tiap lingkaran.
- **Tipografi** (ikon huruf T)
  - **Judul** (ikon judul bergaris bawah): judul maks 24 huruf bergaya Bayangan, Garis bawah, atau Sorot; 4 warna aksen (Merah/Biru/Hijau/Emas).
  - **Kutipan** (ikon tanda kutip): kartu kutipan dengan tanda kutip besar, teks dibungkus otomatis (maks 100 huruf), penulis opsional setelah tanda `|`; tema terang atau gelap, 4 warna aksen.
  - **Stempel** (ikon cap miring): teks huruf besar (maks 14 huruf) dalam bingkai ganda miring −12°, 3 warna (Merah/Biru/Hijau).
- Palet Diagram: Senja (bawaan), Laut, Hijau, Biru, Mono (memakai palet Lanskap V97).
- 8 ikon baru (diagram102, flow102, pyramid102, venn102, type102, title102, quote102, stamp102). File baru `js/more90.js`; `js/more88.js` kini mengekspor `ask`, `wrap`, `idx` dan `js/more89.js` mengekspor `data`, `fmt`, `panel`, `tx`, `clamp`, `mkPal` (pabrik palet) ke `CDMS.Util97`, dan `more89.js` memakai `ask`/`idx` bersama, sehingga tidak ada kode duplikat; service worker naik ke cache cdms-v102. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V101 dipertahankan.

## Pembaruan V103 (grup Sosmed & Perangkat)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Sosmed** (ikon dua orang)
  - **Sampul** (ikon sampul): sampul mengisi halaman dari `Judul | Subjudul` (judul maks 40 huruf, dibungkus otomatis maks 4 baris), gaya Bulat (dua lingkaran transparan) atau Blok (pita warna di bawah), garis aksen di atas judul; teks otomatis hitam/putih mengikuti terang warna latar.
  - **Profil** (ikon profil): kartu putih dengan avatar berinisial dan cincin warna, nama, akun `@...`, dan tombol "Ikuti"; format `Nama | @akun`.
  - **Tag** (ikon pagar): 2–8 pil `#tag` dari daftar yang dipisah koma; pil turun baris otomatis dan tiap baris diratakan di tengah.
- **Perangkat** (ikon ponsel + monitor)
  - **Ponsel** (ikon ponsel): bingkai ponsel (poni, tombol samping, garis beranda) dengan teks layar opsional; layar berwarna palet, putih, atau hitam.
  - **Jendela** (ikon jendela): jendela browser dengan tiga tombol berwarna, kolom alamat, judul halaman, garis aksen, dan baris isi abu-abu; format `Judul | alamat`, tema terang atau gelap.
  - **Laptop** (ikon laptop): layar dengan kamera, alas bertrapesium, dan takik, dengan teks layar opsional; warna layar sama seperti Ponsel.
- Palet Sosmed & Perangkat: Laut (bawaan), Senja, Hijau, Biru, Mono (memakai palet Lanskap V97).
- 8 ikon baru (social103, cover103, profile103, tag103, device103, phone103, window103, laptop103). File baru `js/more91.js`; `js/more90.js` kini juga mengekspor `kontras` dan `daftar` ke `CDMS.Util97`, dipakai bersama oleh `more91.js` sehingga tidak ada kode duplikat; service worker naik ke cache cdms-v103. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V102 dipertahankan.

## Pembaruan V104 (grup Perencana & Pengumuman)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Perencana** (ikon kalender)
  - **Kalender** (ikon kalender): kalender bulanan untuk bulan/tahun mana pun (format `10/2026`, bawaan bulan ini; tahun 1900–2200), awal pekan Senin atau Minggu, nama bulan Indonesia, hari libur pekan (Minggu) berwarna merah, dan tanggal hari ini disorot lingkaran bila bulannya sama.
  - **Centang** (ikon kotak centang): 2–8 item dipisah koma; awali `+` bila sudah selesai (kotak terisi, tanda centang, teks abu-abu dan dicoret).
  - **Jadwal** (ikon tabel jadwal): tabel pekan 5/6/7 hari × 4/6/8 jam (mulai 08:00) dengan header berwarna palet dan baris selang-seling; sel kosong siap diisi lewat alat Teks.
- **Pengumuman** (ikon pengeras suara)
  - **Diskon** (ikon bintang bergerigi): lencana 20 gerigi dengan cincin, label kecil dan nilai besar dari `Label | Nilai` (maks 10 huruf tiap bagian); 4 warna (Merah/Kuning/Biru/Hijau), teks otomatis hitam/putih.
  - **Undangan** (ikon amplop): kartu krem berbingkai ganda dengan label "UNDANGAN", hiasan belah ketupat, judul dibungkus otomatis (maks 40 huruf), tanggal, dan tempat; format `Judul | Tanggal | Tempat`, 4 warna (Emas/Merah/Hijau/Biru).
  - **Kupon** (ikon tiket): kupon bertakik dengan garis perforasi putus-putus, nilai besar, keterangan, dan kode di sisi kanan; format `Nilai | Kode | Keterangan`, 4 warna; takik mengikuti warna latar halaman.
- Palet Perencana: Biru (bawaan), Laut, Senja, Hijau, Mono (memakai palet Lanskap V97).
- 8 ikon baru (planner104, calendar104, check104, schedule104, notice104, sale104, invite104, coupon104). File baru `js/more92.js`; `js/more91.js` kini juga mengekspor `bagi` ke `CDMS.Util97`, dipakai bersama sehingga tidak ada kode duplikat; service worker naik ke cache cdms-v104. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V103 dipertahankan.

## Pembaruan V105 (grup Ilustrasi & Alat Desain)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Ilustrasi** (ikon palet cat)
  - **Wajah** (ikon wajah): wajah bulat dengan 5 ekspresi (Senyum, Tertawa, Sedih, Kaget, Kedip), 4 warna (Kuning/Oranye/Hijau/Biru), 3 ukuran; pipi merah muda untuk ekspresi senang.
  - **Robot** (ikon robot): maskot robot dari bentuk dasar (antena, kepala bermata dan gigi, badan berpanel lampu, lengan, kaki), 4 warna (Biru/Hijau/Merah/Abu), 3 ukuran.
  - **Cuaca** (ikon matahari + awan): Cerah (matahari bersinar), Berawan, Hujan, Salju, atau Malam (bulan berkawah + bintang berkilau); 3 ukuran; latar langit berwarna sesuai cuaca bisa dimatikan.
- **Alat Desain** (ikon pensil + penggaris)
  - **Penggaris** (ikon penggaris): penggaris di tepi halaman, mendatar atau menurun, tanda tiap 10/20/50 px (otomatis dilebarkan agar maks. ±160 tanda), angka tiap 5 tanda; warna Kuning/Kayu/Biru muda.
  - **Barcode** (ikon barcode): batang dekoratif dari teks (maks 16 huruf/angka; teks yang sama selalu menghasilkan batang yang sama) di atas kartu putih dengan teks di bawahnya; 3 warna. Hanya hiasan, bukan kode yang bisa dipindai.
  - **Swatch** (ikon deretan warna): 3/5/7 warna palet berderet, kotak atau bulat, dengan kode hex di bawahnya (mis. #1A2B3C) di atas kartu putih.
- Palet Ilustrasi & Alat Desain: Senja (bawaan), Laut, Hijau, Biru, Mono (memakai palet Lanskap V97).
- 8 ikon baru (art105, face105, robot105, weather105, tools105, ruler105, barcode105, swatch105). File baru `js/more93.js`; `js/more92.js` kini juga mengekspor `kartu` ke `CDMS.Util97`, dipakai bersama sehingga tidak ada kode duplikat; service worker naik ke cache cdms-v105. Garis sinar matahari memakai objek path karena objek garis hanya menggambar dari kiri-atas ke kanan-bawah. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V104 dipertahankan.

## Pembaruan V106 (grup Grafik Data & Pola)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Grafik Data** (ikon grafik batang)
  - **Batang** (ikon batang): diagram batang dari data `Label:nilai` dipisah koma (2-7 item, label maks 10 huruf), tegak atau mendatar, dengan garis kisi, sumbu, nilai di ujung batang, dan warna bertingkat sesuai palet.
  - **Pai** (ikon pai): diagram pai atau donat (2-8 item) dengan legenda berisi label dan persentase; donat menampilkan total di tengah. Nilai 0 dilewati; total harus lebih dari 0.
  - **Progres** (ikon bilah): 1-6 bilah persentase dari `Label:persen` (nilai di atas 100 dibatasi 100) dengan jalur abu-abu dan isi berwarna palet.
- **Pola** (ikon pola diagonal)
  - **Garis Pola** (ikon garis miring): pola di kartu 80% x 70% halaman: Diagonal /, Diagonal \, Tegak, Mendatar, atau Kotak-kotak; jarak 12/24/40 px (otomatis dilebarkan agar maks. ±160 garis), tebal 2/3/5 px, warna bergradasi palet.
  - **Titik Kisi** (ikon titik): kisi titik atau tanda plus, jarak 20/32/48 px (otomatis dilebarkan agar maks. ±320 titik), warna bergradasi per baris.
  - **Konfeti** (ikon konfeti): 30/60/100 keping persegi panjang miring, lingkaran, dan segitiga yang disebar acak di seluruh halaman (hasil berbeda setiap kali).
  - **Mandala** (ikon kelopak): kelopak melengkung 6/8/12 dalam 2/3/4 lapis (lapis berselang diputar setengah langkah), 3 ukuran, pusat kuning.
- Palet Grafik Data & Pola: Laut (bawaan), Senja, Hijau, Biru, Mono (memakai palet Lanskap V97). Data terakhir yang dimasukkan diingat sebagai isian bawaan kolom input berikutnya.
- 9 ikon baru (chart106, bar106, pie106, progress106, pattern106, stripes106, dots106, confetti106, mandala106). File baru `js/more94.js`; `js/more93.js` kini juga mengekspor `seg` (garis lurus bebas arah) ke `CDMS.Util97`, dipakai bersama sehingga tidak ada kode duplikat; service worker naik ke cache cdms-v106. Irisan pai dan kelopak mandala memakai objek path dalam satu kotak bersama. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V105 dipertahankan.


## Pembaruan V107 (grup Struktur & Acara & Niaga)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Struktur** (ikon bagan kotak)
  - **Peta Pikiran** (ikon simpul): `Pusat | Cabang, Cabang` (3-8 cabang, maks 12 huruf): topik di tengah berbentuk elips, cabang berbentuk pil di orbit melingkar dengan garis penghubung dan warna bertingkat palet.
  - **Hierarki** (ikon pohon): `Atasan | Bawahan, Bawahan` (2-5 bawahan): kotak atasan, garis siku penghubung, dan baris bawahan.
  - **Matriks** (ikon 4 kotak): `Judul | K1, K2, K3, K4` (tepat 4 kotak, mis. SWOT), tiap kotak berkepala berwarna dan badan terang yang siap diisi lewat alat Teks.
  - **Pro-Kontra** (ikon plus/minus): dua kolom, tiap kolom `Judul | poin, poin` (1-4 poin) dengan kepala berwarna dan titik poin.
- **Acara & Niaga** (ikon kalender)
  - **Papan Skor** (ikon papan): `Tim A | skor | skor | Tim B`, papan gelap dengan dua kotak skor dan titik dua.
  - **Hitung Mundur** (ikon jam): 2-4 angka `Hari | Jam | Menit | Detik` (otomatis 2 digit), kotak gelap dengan angka besar dan label.
  - **Harga** (ikon label harga): 2-3 paket `Nama:harga`, paket tengah (atau terakhir bila 2 paket) disorot dengan lencana POPULER; baris abu-abu siap diganti teks.
  - **Menu** (ikon daftar): `Judul | Nama:harga, ...` (3-8 item), kepala berwarna, garis titik antara nama dan harga.
- Palet semua alat baru: Biru (bawaan), Laut, Senja, Hijau, Mono. Data terakhir diingat sebagai isian bawaan berikutnya.
- 10 ikon baru (struct107, mind107, tree107, matrix107, proscon107, event107, score107, count107, price107, menu107). File baru `js/more95.js`; memakai helper bersama `CDMS.Util97` tanpa kode duplikat; service worker naik ke cache cdms-v107. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V106 dipertahankan.


## Pembaruan V108 (grup Dokumen & Statistik & Media)
Dua grup menu baru di toolbar (setelah Ritme), tiap tombol punya nama dan ikon sendiri.
- **Dokumen** (ikon kertas)
  - **Sertifikat** (ikon sertifikat): `Nama | Alasan | Tanggal` (tanggal boleh kosong): kertas krem berbingkai ganda, judul, nama bergaris bawah, alasan (otomatis dibungkus maks 3 baris), garis tanda tangan, dan medali emas.
  - **Kop Surat** (ikon kop): `Nama | Alamat | Kontak`: logo bulat berinisial, nama usaha, alamat, kontak, dan garis ganda; dipasang di atas halaman.
  - **Faktur** (ikon nota): `Nama:harga` (2-6 item, harga angka, boleh `250.000`): tabel No/Item/Harga dengan baris selang-seling dan total otomatis format `Rp 1.250.000`.
  - **Struk** (ikon struk): `Toko | Nama:harga` (2-8 item): nota sempit bergaris putus-putus dengan total dan ucapan terima kasih.
- **Statistik & Media** (ikon layar)
  - **Statistik** (ikon kotak KPI): `Label:nilai` (2-4 item; desimal pakai titik, mis. `12.5k`): kotak putih dengan garis atas berwarna dan nilai besar; 4 item disusun 2x2.
  - **Pemutar** (ikon pemutar): `Judul | Artis | persen`: kartu gelap berisi sampul piringan, judul, artis, bilah progres berkenop, dan tombol kembali/putar/lanjut.
  - **Obrolan** (ikon gelembung): pesan dipisah `;` (2-5), awali `>` untuk pesan di kanan; gelembung abu di kiri dan berwarna palet di kanan, teks dibungkus otomatis.
  - **Peringkat** (ikon podium): `Nama:skor` (3-6 item), otomatis diurutkan dari skor tertinggi; lingkaran peringkat emas/perak/perunggu, bilah proporsional, dan skor.
- Palet Dokumen & Media: Senja (bawaan), Laut, Hijau, Biru, Mono (Struk selalu hitam-putih tanpa palet).
- 10 ikon baru (doc108, cert108, letter108, invoice108, receipt108, media108, stat108, player108, chat108, rank108). File baru `js/more96.js`; `js/more95.js` kini juga mengekspor `pill, list, kv, ju, rt, t1, mx` ke `CDMS.Util97`, dipakai bersama sehingga tidak ada kode duplikat; service worker naik ke cache cdms-v108. Hasil berupa grup objek biasa yang tetap bisa diedit; semua aksi bisa di-undo; fitur V107 dipertahankan.


## Pembaruan V109 (tampilan gaya Office)
Tampilan dirombak agar sederhana seperti Word, Excel, dan PowerPoint. Semua alat dan menu lama tetap ada.
- Bilah judul biru (logo, nama aplikasi, Studio, urungkan/ulangi, Simpan, Ekspor) dan **tab pita**: **Beranda** (alat dasar, Objek, Kelompok, Warna, Huruf), **Sisip** (Buat, Pustaka, Ilustrasi, Pita & Tanda, Kartu, Bingkai, dll.), **Grafik** (Bagan, Grafik Data, Struktur, Diagram, Pola, Lanskap, dll.), **Dokumen** (Dokumen, Perencana, Pengumuman, Acara & Niaga, Sosmed, dll.), **Tampilan** (Grid, Kanvas, Isolasi, Cari, Periksa, Berkas), dan **Lainnya** (grup yang belum dipetakan). Tab terakhir diingat.
- Pita hanya satu baris yang bisa digeser; tombol datar dengan ikon biru dan sorotan biru muda untuk alat aktif.
- Tema terang menjadi bawaan (tema gelap tetap bisa dipilih lewat tombol tema); panel kiri/kanan putih, area kanvas abu-abu dengan halaman putih, bilah status biru.
- Layar awal disederhanakan: kartu "Mulai dengan dokumen kosong", ukuran halaman, dan proyek terbaru.
- File baru `js/more97.js` (tab pita) dan `css/v108.css` (tema Office, memetakan variabel warna lama sehingga menu dan modal ikut berubah); service worker naik ke cache cdms-v109.


## Pembaruan V110 (perapihan tampilan Office)
Hanya merapikan tampilan dan label; tidak ada fitur atau data yang diubah.
- **Pita**: pemisah tipis antar kelompok alat di tab Beranda, tepi memudar saat pita/tab bisa digeser, roda mouse menggeser pita ke samping, tab aktif selalu terlihat, dan tab bisa dipindah dengan panah kiri/kanan, Home, End.
- **Bilah aksi melayang** (di atas objek terpilih) kini dibatasi lebarnya (maks. 420 px), bisa digeser, dan tidak lagi melebar keluar dari area kanvas.
- **Panel kiri**: tombol Persegi/Lingkaran/Bintang/Teks/Stiker jadi baris ringkas; tombol Lapisan memakai label Indonesia (Grup, Pisah, Depan, Belakang); nama bawaan objek baru berbahasa Indonesia (Persegi, Elips, Teks, ...). Proyek lama tetap, namun tampil dengan nama Indonesia di daftar lapisan.
- **Panel kanan**: label isian huruf biasa (bukan huruf kapital), isian dan pemilih warna lebih rapat.
- Layar awal: kotak "Belum ada proyek" bergaris putus, kartu template lebih rata; modal bergaya Office.
- Fokus keyboard berwarna biru yang jelas; scrollbar tipis; animasi dimatikan jika perangkat meminta gerak minimal.
- `theme-color` dan `manifest.json` disamakan dengan bilah judul biru (#185abd).
- File baru `css/v109.css` dan `js/more98.js`; service worker naik ke cache cdms-v110.


## Pembaruan V111 (panel Properti)
- Panel Properti dikelompokkan menjadi bagian yang bisa dilipat: **Posisi & ukuran**, **Warna & garis**, **Teks** (hanya muncul saat objek teks dipilih), dan **Aksi** (Duplikat, Hapus, Balik). Status lipat diingat di perangkat.
- Semua isian dan tombol lama dipindahkan apa adanya sehingga fungsinya tidak berubah.
- File baru `js/more99.js`; gaya tambahan di `css/v109.css`; service worker naik ke cache cdms-v111.


## Pembaruan V112 (menu hub)
- Menu yang terbuka dari tombol pita bergaya Office: judul dengan garis, sel datar, sorotan biru saat disorot/dipilih, dan fokus keyboard yang jelas.
- Navigasi keyboard: menu terbuka langsung memfokuskan sel pertama (di perangkat dengan mouse); tombol panah, Home, dan End memindah fokus, Enter/Spasi memilih, Esc menutup. Panah tidak lagi menggeser objek di kanvas saat menu terbuka.
- Label bahasa Indonesia di menu Warna: Potong (sebelumnya Crop), Campur (Blend), Animasi (Anim).
- File baru `js/more100.js`; gaya tambahan di `css/v109.css`; service worker naik ke cache cdms-v112.


## Pembaruan V113 (panel kiri, lapisan, modal Studio)
- Bagian **Elemen** di panel kiri bisa dilipat (status diingat) sehingga daftar Lapisan punya ruang lebih.
- Baris lapisan yang disembunyikan tampil redup bergaris coret, dan yang dikunci tampil miring.
- Modal Studio: tab berubah jadi tab bergaris bawah ala Office, label isian di atas kolom dengan lebar seragam, isian dan tombol lebih rapat.
- File baru `js/more101.js`; gaya tambahan di `css/v109.css`; service worker naik ke cache cdms-v113.


## Pembaruan V114 (Asisten AI)
Tombol **AI** di bilah judul (di samping Studio) membuka Asisten AI dengan tiga tab:
- **Desain**: tulis permintaan (mis. "poster promo kopi"), pilih gaya, lalu AI menyusun objek (persegi, elips, bintang, poligon, garis, teks) yang langsung bisa diedit dan di-undo. Opsi "Ganti isi kanvas saat ini".
- **Variasi teks**: pilih satu objek teks di kanvas, lalu minta 3 variasi (bisa dengan instruksi seperti "lebih singkat" atau "bahasa Inggris"); klik salah satu untuk menerapkan.
- **Pengaturan**: pilih penyedia (OpenAI-compatible atau Anthropic), alamat API, model, dan kunci API; ada tombol Tes koneksi.

Catatan keamanan dan penggunaan:
- Kunci API TIDAK tertanam di kode. Kunci disimpan hanya di localStorage browser/perangkat ini dan dikirim langsung ke penyedia yang dipilih bersama prompt. Siapa pun yang memakai perangkat/browser itu bisa melihat kunci tersebut; untuk dipakai bersama orang lain, sebaiknya gunakan server perantara.
- Beberapa penyedia memblokir pemanggilan langsung dari browser (CORS); bila muncul pesan "Tidak bisa terhubung", pakai alamat API yang mengizinkan CORS atau server perantara.
- Keluaran model divalidasi: hanya jenis objek, warna heksadesimal, angka (dibatasi), dan font bawaan yang dipakai; teks dimasukkan sebagai teks biasa, bukan kode.
- File baru `js/more102.js`; gaya tambahan di `css/v109.css`; service worker naik ke cache cdms-v114.


## Pembaruan V115 (Navigator / peta mini)
Panel **Peta** kecil di sudut kanan-bawah kanvas membantu berpindah di halaman yang di-zoom.
- Menampilkan seluruh halaman beserta objeknya dan kotak biru area yang sedang terlihat; kotak ikut bergerak saat kanvas digeser, di-zoom, atau diedit.
- **Klik atau geser** di peta untuk memindahkan tampilan. Tombol **◎** memusatkan tampilan ke objek terpilih; tombol **×** menyembunyikan peta.
- Tombol **Peta** di samping Sesuaikan (bawah kanvas) menampilkan/menyembunyikan peta; pilihan diingat di perangkat. Di layar HP peta tampil lebih kecil.
- Hanya tampilan: tidak mengubah objek, riwayat undo, atau isi proyek, dan tidak ikut tercetak.
- File baru `js/more103.js`; gaya tambahan di `css/v109.css`; service worker naik ke cache cdms-v115.


## Pembaruan V116 (navigasi kanvas)
Cara berpindah dan zoom yang sebelumnya belum ada (teks "Cubit 2 jari" di Gestur & tips sebelumnya belum berfungsi, kini sudah).
- **HP**: cubit 2 jari untuk zoom (25-200%); geser dengan 2 jari untuk memindah tampilan.
- **Desktop**: **Ctrl/⌘ + roda mouse** untuk zoom (10% per ketukan; cubit di trackpad lebih halus); tahan **Spasi** lalu seret, atau seret dengan **tombol tengah mouse**, untuk menggeser kanvas. Tanpa Spasi, seret di area kosong tetap membuat seleksi seperti biasa.
- **Keyboard**: `+` / `=` zoom masuk, `-` zoom keluar, `0` kembali 100% (tidak aktif saat mengetik atau saat modal terbuka).
- Hanya mengubah zoom/scroll: objek, riwayat undo, dan data proyek tidak disentuh; peta mini V115 ikut mengikuti. Pintasan baru juga tercantum di Bantuan > Pintasan keyboard.
- File baru `js/more104.js`; gaya tambahan di `css/v109.css`; `js/more12.js` hanya menambah 3 baris pintasan; service worker naik ke cache cdms-v116.


## Pembaruan V117 (menu konteks)
Menu cepat yang muncul di dekat objek.
- **Desktop**: klik kanan pada objek atau area kosong kanvas. **HP**: tekan lama (sekitar setengah detik) tanpa menggeser jari. Tap singkat dan geser biasa tidak membuka menu.
- **Objek**: Salin, Potong, Tempel, Duplikat, Hapus; Ke depan, Ke belakang; Kelompokkan / Pisahkan kelompok; Kunci / Buka kunci; Sembunyikan; Balik horizontal/vertikal; **Pilih serupa** (jenis dan warna isi sama). Objek terkunci hanya menampilkan Buka kunci dan Tempel.
- **Area kosong**: Tempel, Pilih semua, Zoom 100%, Tampilkan/sembunyikan grid.
- Navigasi keyboard: panah atas/bawah, Home, End, Esc untuk menutup; menu juga tertutup saat klik di luar, kanvas digeser, atau jendela diubah ukurannya. Posisi menu dijaga tetap di dalam layar; tombol lebih besar di layar sentuh.
- Memakai ulang fungsi yang sudah ada (`copy`, `cut`, `paste` kini diekspor dari `js/menus.js` lewat `CDMS.Menus`; aksi lain lewat `CDMS.Navigation.action`), tanpa kode duplikat. Semua perubahan bisa di-undo.
- File baru `js/more105.js`; gaya tambahan di `css/v109.css`; `js/more12.js` menambah 1 baris pintasan; service worker naik ke cache cdms-v117.


## Pembaruan V118 (info posisi & Alt-seret)
- **Bilah status** kini menampilkan geometri seleksi: untuk satu objek `X · Y · lebar × tinggi` (plus rotasi bila ada), untuk beberapa objek ukuran kotak seleksinya. Di desktop ada juga **posisi kursor** di halaman (dalam px kanvas); di layar sempit info kursor disembunyikan dan info seleksi dipendekkan.
- **Alt + seret** (Option di Mac) pada objek = menggandakan sambil menggeser: salinan tetap di tempat asal, objek asli ikut terseret. Objek berkelompok digandakan bersama anggota kelompoknya (dengan ID kelompok baru); objek terkunci tidak digandakan; Shift+Alt tidak menggandakan. Hanya dengan alat Pilih, dan satu kali Undo membatalkan gandaan beserta gesernya.
- Pintasan baru tercantum di Bantuan > Pintasan keyboard.
- File baru `js/more106.js`; gaya tambahan di `css/v109.css`; `js/more12.js` menambah 1 baris pintasan; service worker naik ke cache cdms-v118.


## Pembaruan V119 (penyempurnaan tampilan)
Hanya gaya (CSS); perilaku, data proyek, dan fitur lama tidak berubah.
- **Mode gelap**: isian di jendela Studio/modal sebelumnya berlatar putih dengan teks terang sehingga nyaris tak terbaca; kini mengikuti tema (latar gelap, teks terang, placeholder redup). Kontrol bawaan browser (scrollbar, pilihan dropdown) ikut gelap.
- **Seleksi objek**: bingkai putus-putus, 4 handle ukuran, dan handle rotasi kini biru senada tema (sebelumnya cyan dan ungu).
- **Meja kerja bertitik** di sekitar halaman yang ikut bergeser saat kanvas digulir; grid yang diaktifkan tetap memakai gayanya sendiri.
- **Peta mini** mengikuti palet tema (terang/gelap).
- **Beranda**: ilustrasi halaman dengan objek terpilih di kartu sambutan (layar lebar saja); kartu template kini menampilkan pratinjau halaman sesuai rasio ukuran (persegi, story, banner, logo); tombol sambutan selebar penuh di HP.
- **Layar pembuka**: latar biru bergradasi halus, lintasan pemuatan lebih lembut, ikon logo berwarna biru.
- **Panel samping di HP** (Layer/Properti) kini punya bayangan sehingga terpisah jelas dari kanvas.
- Tanpa file JS baru; gaya tambahan di `css/v109.css`; service worker naik ke cache cdms-v119.


## Pembaruan V120 (ikon aplikasi)
- Ikon aplikasi (`icon.svg`, `icon-maskable.svg`, dan PNG 180/192/512 serta maskable 512) dibuat ulang dengan gradasi biru yang sama dengan bilah judul dan layar pembuka; sebelumnya ungu-teal.
- Bentuk ikon tidak berubah. Service worker naik ke cache cdms-v120.
- Bila ikon di layar utama HP belum berganti, hapus lalu pasang ulang pintasan/PWA (peramban menyimpan ikon lama).


## Pembaruan V121 (titik kurva)
- **Titik kurva**: tambah titik di garis atau bentuk apa pun untuk melengkungkannya. Buka menu **Simpul > Tambah titik kurva di garis / bentuk** (atau klik kanan / tekan lama objek > **Titik kurva (lengkungkan)**). Ketuk tepi garis atau bentuk, lalu **langsung seret**: titik baru muncul tepat di jari/kursor dan tepi di sekitarnya melengkung mengikutinya. Ketuk lagi untuk menambah titik lain.
- Berlaku untuk garis, persegi, elips, bintang, poligon, dan path; bentuk dasar otomatis diubah jadi path (isi dan warna tetap). Tepi penutup bentuk tertutup (mis. sisi kiri persegi) ikut bisa dilengkungkan.
- Selama mode aktif, garis disorot ungu muda dan, di desktop, ada titik pratinjau di bbawah kursor. Bilah **Selesai / Hapus titik** muncul di kanvas (Esc juga mengakhiri). Simpul putih dan titik kontrol kuning dari editor simpul tetap bisa diseret.
- Satu kali Undo membatalkan satu titik beserta lengkungannya.
- Perbaikan editor simpul: garis lurus mendatar/tegak (tinggi atau lebar 0) kini bisa diedit; kotak seleksi mengikuti kurva yang terlihat (bukan titik kontrol); di path tertutup, simpul awal dan akhir yang berimpit bergerak bersama.
- Batasan: objek harus tanpa rotasi/balik (setel dulu), dan teks/gambar belum didukung.
- File baru `js/more107.js`; `js/more23.js`, `js/more105.js`, `js/more12.js` diubah sedikit; gaya di `css/v109.css`; service worker naik ke cache cdms-v121.


## Pembaruan V122 (titik halus / sudut)
- **Titik kontrol berpasangan**: saat menyeret titik kontrol kuning pada simpul yang halus, titik kontrol di seberangnya ikut lurus (panjangnya tetap), jadi lengkungan tidak patah. Tahan **Alt** (Option) untuk memutus keselarasan sementara. Simpul sudut tetap bebas.
- **Klik dobel simpul putih** = ganti halus / sudut. Tersedia juga di menu **Simpul > Titik halus / sudut** (Titik terpilih jadi halus / jadi sudut).
- Simpul awal dan akhir yang berimpit di path tertutup diperlakukan sebagai satu simpul.
- File baru `js/more108.js`; service worker naik ke cache cdms-v122.


## Pembaruan V123 (tampilan mode Excel & Word)
- **Excel**: bilah judul hijau dengan nama buku kerja, pita bertab (Beranda, Sisipkan, Data), seleksi rentang (seret/Shift+klik) dengan sorotan header, edit sel langsung (klik dobel/F2/ketik), bilah rumus, statistik rentang (rata-rata, hitung, jumlah), zoom, dan banyak lembar (tab di bawah; ketuk lembar aktif untuk ganti nama, klik kanan untuk hapus).
- Format sel: tebal/miring/garis bawah, warna isi & huruf, rata kiri/tengah/kanan, format Angka/Rupiah/Persen. Rumus: SUM, AVERAGE, MIN, MAX, COUNT, IF, ROUND, ABS, SQRT, operator + - * / ^ %, galat #DIV/0! #NAME? #CYCLE!. Salin/tempel/potong, urutkan kolom, data contoh, ekspor CSV dan .XLS. Simpan otomatis.
- **Word**: bilah judul biru, pita bertab (Beranda, Sisipkan, Tampilan), halaman kertas dengan bayangan, gaya Normal/Judul 1-3/Kutipan, warna huruf & sorot, daftar, indentasi, tabel, gambar (diperkecil otomatis), tautan, garis, tanggal, halaman baru, margin, zoom, hitung kata/karakter/halaman, simpan otomatis, ekspor .DOC/.HTML dan cetak/PDF.
- Kartu mode di Beranda bergaya hijau (Excel) dan biru (Word).
- File baru `css/office.css`; `js/excel-mode.js` dan `js/word-mode.js` ditulis ulang; service worker naik ke cache cdms-v123.


## Pembaruan V124 (Excel & Word lanjutan)
- **Excel**: Urungkan/Ulangi (Ctrl+Z / Ctrl+Y, 60 langkah), ubah lebar kolom dengan menyeret tepi header (klik dobel = reset), sisip/hapus baris dan kolom (rumus ikut bergeser), Isi bawah/kanan (Ctrl+D / Ctrl+R, rumus menyesuaikan).
- **Word**: Cari & ganti (Ctrl+F; Berikutnya, Ganti, Ganti semua) dan jarak baris (1,0 / 1,15 / 1,5 / 2,0).
- Batasan: rumus di lembar lain tidak ikut bergeser saat sisip/hapus.
- Tanpa file baru; service worker naik ke cache cdms-v124.


## Pembaruan V125 (grafik & header/footer)
- **Excel**: Sisipkan > Batang / Garis / Pai dari rentang sel terpilih (baris pertama = judul seri, kolom pertama = label bila berupa teks). Unduh PNG atau SVG. Grafik tidak disimpan di lembar.
- **Word**: Sisipkan > Header & footer. Tulis `{n}` di footer untuk nomor halaman; nomor muncul pada cetak/PDF (butuh Chrome/Edge versi baru), sedangkan di layar tampil "1". Ikut terekspor ke .DOC/.HTML.
- File baru `js/excel-chart.js`; service worker naik ke cache cdms-v125.


## Pembaruan V126 (kemudahan di HP)
- **Excel**: tombol ⬚ **Mode rentang** di bilah rumus (ketuk sel lain untuk memperluas pilihan tanpa Shift/seret) dan tombol ✎ **Edit sel**. Ketuk sel terpilih sekali lagi untuk mengedit; menggulir tidak lagi memicu edit. Sel, header, dan tombol lebih besar; pegangan ubah lebar kolom lebih lebar; input 16px agar layar tidak otomatis zoom di iOS.
- **Pita bisa dilipat** (Excel & Word): ketuk tab yang sedang aktif untuk menyembunyikan/menampilkan pita dan memperluas area kerja.
- **Word**: saat mengetik di HP, pita otomatis melipat dan muncul **bilah format cepat** tepat di atas keyboard (urungkan, tebal, miring, garis bawah, daftar, rata kiri/tengah, dan **Aa** untuk membuka menu lengkap).
- Tanpa file baru; service worker naik ke cache cdms-v126.


## Pembaruan V127 (cubit zoom, format bersyarat, daftar isi)
- **Cubit dua jari** untuk memperbesar/memperkecil lembar Excel (60–160%) dan halaman Word (50–160%).
- **Excel – Format bersyarat**: Beranda > Aturan sel. Sorot sel di rentang terpilih bila lebih besar/kecil, ≥, ≤, sama dengan, atau teks mengandung nilai tertentu, dengan warna merah/kuning/hijau/biru. Bisa diurungkan; aturan tersimpan per lembar.
- **Word – Daftar isi**: Sisipkan > Daftar isi membuat daftar dari Judul 1–3 di posisi kursor (statis; sisipkan ulang bila judul berubah, tanpa nomor halaman).
- Tanpa file baru; service worker naik ke cache cdms-v127.


## Pembaruan V128 (rumus, cari & ganti, format teks)
- **Excel – rumus baru**: MEDIAN, PRODUCT, INT, MOD, POWER, ROUNDUP, ROUNDDOWN, COUNTIF, SUMIF (kriteria seperti ">5", "<>x", teks), AND, OR, NOT, LEN, UPPER, LOWER, TRIM, CONCAT, LEFT, RIGHT, TODAY, PI.
- **Excel – Data > Cari** (lompat ke hasil berikutnya) dan **Ganti semua** (di seluruh lembar, atau hanya rentang terpilih; rumus tidak diubah; bisa diurungkan).
- **Word**: tombol superskrip x² dan subskrip x₂; menu **Simbol** (©, °, ±, →, ✓, dll.) dan **Ubah huruf** (BESAR, kecil, Awal Kata Besar) di Sisipkan.
- Tanpa file baru; service worker naik ke cache cdms-v128.


## Pembaruan V129 (garis tepi & lanskap)
- **Excel**: tombol ▣ Garis tepi sel di Beranda (aktif/nonaktif pada sel terpilih; tersimpan, bisa diurungkan).
- **Word**: Tampilan > Potret/Lanskap mengubah orientasi halaman; ikut ke cetak/PDF.
- Tanpa file baru; service worker naik ke cache cdms-v129.


## Pembaruan V130 (alat tabel & duplikat)
- **Word**: Sisipkan > Alat tabel: tambah/hapus baris dan kolom di posisi kursor, hapus tabel.
- **Excel**: Data > Hapus duplikat mengosongkan baris yang isinya sama dalam rentang terpilih (baris pertama dipertahankan; bisa diurungkan). Pilih rentang dulu.
- Tanpa file baru; service worker naik ke cache cdms-v130.


## Pembaruan V131 (isi seri & daftar tugas)
- **Excel**: Data > Isi seri angka mengisi rentang terpilih dengan angka awal dan selisih pilihan Anda (satu sel dipilih = 10 sel ke bawah; bisa diurungkan).
- **Word**: Sisipkan > ☐ Daftar tugas menyisipkan baris berkotak; ☑ Centang mengganti kotak ☐/☑ pada baris kursor.
- Tanpa file baru; service worker naik ke cache cdms-v131.


## Pembaruan V132 (impor file)
- **Excel**: Data > Impor CSV memuat file .csv/.tsv/.txt (pemisah koma, titik koma, atau tab terdeteksi otomatis) mulai dari sel terpilih; maks. 2 MB, bisa diurungkan.
- **Word**: Sisipkan > Impor .TXT menyisipkan isi file teks di posisi kursor (paragraf dipisah baris kosong); maks. 1 MB.
- Tanpa file baru; service worker naik ke cache cdms-v132.


## Pembaruan V133 (ukuran huruf sel, bungkus teks, dua kolom)
- **Excel**: pilihan Ukuran huruf per sel dan tombol ↵ Bungkus teks di Beranda (tersimpan, bisa diurungkan).
- **Word**: Tampilan > 1/2 Kolom mengubah teks jadi dua kolom (ikut ke cetak/.DOC/.HTML).
- Tanpa file baru; service worker naik ke cache cdms-v133.


## Pembaruan V134 (VLOOKUP & inden)
- **Excel – rumus baru**: VLOOKUP(kunci, rentang, kolom, 0 untuk pas), COUNTA, COUNTBLANK. Galat #N/A bila tidak ditemukan, #REF! bila nomor kolom di luar rentang.
- **Word**: Tampilan > Inden baris 1 (aktif/nonaktif pada paragraf terpilih).
- Tanpa file baru; service worker naik ke cache cdms-v134.


## Pembaruan V135 (filter & kotak catatan)
- **Excel**: Data > Filter kolom menyembunyikan baris yang kolom sel aktifnya tidak mengandung teks yang dicari; Hapus filter menampilkannya lagi. Hanya tampilan (data tidak berubah), dan tidak disimpan.
- **Word**: Sisipkan > Kotak catatan (memakai teks terpilih bila ada); ikut ke ekspor.
- Tanpa file baru; service worker naik ke cache cdms-v135.


## Pembaruan V136 (cetak lembar)
- **Excel**: Data > Cetak / PDF mencetak area terisi pada lembar aktif lengkap dengan warna, format, garis tepi, dan format bersyarat. Pilih "Simpan sebagai PDF" di dialog cetak.
- **Word**: tahan/arahkan ke hitungan karakter untuk melihat perkiraan waktu baca (tooltip).
- Tanpa file baru; service worker naik ke cache cdms-v136.


## Pembaruan V137 (rumus jadi nilai & mode fokus)
- **Excel**: Data > Rumus → nilai mengganti rumus di pilihan dengan hasil hitungnya (rumus galat dilewati; bisa diurungkan).
- **Word**: Tampilan > Mode fokus menyembunyikan judul, pita, dan status agar layar penuh untuk menulis; keluar dengan tombol ✕ di pojok kanan atas.
- Tanpa file baru; service worker naik ke cache cdms-v137.


## Pembaruan V138 (catatan sel & kata terpilih)
- **Excel**: Beranda > 💬 Catatan menambah catatan pada sel aktif (tanda segitiga merah; teks muncul saat sel ditahan/diarahkan). Hapus Format juga menghapus catatan.
- **Word**: saat teks diblok, hitungan di bawah menampilkan jumlah kata terpilih.
- Tanpa file baru; service worker naik ke cache cdms-v138.


## Pembaruan V139 (templat Word & format angka)
- **Word**: Sisipkan > Templat: Surat resmi, Notulen rapat, CV, atau blok Tanda tangan, disisipkan di posisi kursor.
- **Excel**: format angka baru Bulat (1.000) dan Dolar ($).
- Tanpa file baru; service worker naik ke cache cdms-v139.


## Pembaruan V140 (Mode Microsoft PowerPoint)
- Kartu baru **Microsoft PowerPoint** di Beranda (oranye). Layar: pita bertab (Beranda, Sisipkan, Desain), daftar slide mini (di bawah pada HP), dan kanvas slide 16:9 yang otomatis menyesuaikan layar.
- **Beranda**: slide baru dengan tata letak (Judul + isi, Judul, Dua kolom, Kosong), duplikat, hapus, geser naik/turun (maks. 60 slide); tebal, miring, garis bawah, ukuran huruf, warna huruf, rata teks, daftar butir/nomor.
- **Sisipkan**: kotak teks, gambar (diperkecil otomatis), persegi, bulat; geser objek lewat pegangan ✥ (atau langsung pada gambar/bentuk), Perbesar/Perkecil, warna isi bentuk, hapus objek.
- **Desain**: 7 tema warna, warna latar bebas, terapkan ke semua slide, Cetak / PDF (satu slide per halaman), dan slide Contoh.
- **▶ Tampilkan**: layar penuh; ketuk kanan/kiri, geser, atau tombol panah/spasi untuk pindah; Esc atau ✕ untuk keluar.
- Simpan otomatis di perangkat. File baru `css/ppt-mode.css` dan `js/ppt-mode.js`; service worker naik ke cache cdms-v140.


## Pembaruan V141 (PowerPoint: nomor slide, catatan, transisi)
- **Desain > № Nomor slide**: tampilkan/sembunyikan nomor di pojok kanan bawah (layar, tampilan penuh, dan cetak/PDF).
- **Desain > 📝 Catatan**: kotak catatan pembicara per slide (tersimpan; tidak tampil di slide). Saat ▶ Tampilkan, tekan N untuk melihat catatan.
- Transisi memudar (fade) antar slide saat tampilan layar penuh.
- Tanpa file baru; service worker naik ke cache cdms-v141.


## Pembaruan V143 (perbaikan integrasi & urungkan PowerPoint)
- **Perbaikan**: baris `<link>` dan `<script>` Panel Aplikasi di `index.html` berisi teks "\n" harfiah — dirapikan; `css/app-panel.css` dan `js/app-panel.js` kini terdaftar di service worker (bisa dipakai offline). Panel Aplikasi Lain diuji dapat dibuka.
- **PowerPoint**: tombol ↶ Urungkan dan ↷ Ulangi (Ctrl+Z di luar kotak teks), 40 langkah, mencakup tambah/hapus/duplikat/geser slide, objek, tema, format, dan pengetikan teks.
- Tanpa file baru; service worker naik ke cache cdms-v143.


## Pembaruan V144 (PowerPoint: lebih banyak alat objek)
- **Sisipkan**: bentuk ― Garis dan ➜ Panah.
- **Objek terpilih**: Duplikat, Ke depan, Ke belakang, Tengahkan (horizontal), selain Perbesar/Perkecil/Hapus. Semua bisa diurungkan.
- Tanpa file baru; service worker naik ke cache cdms-v144.


## Pembaruan V145 (Tambah Aplikasi di Panel Aplikasi Lain berfungsi)
- **＋ Tambah Aplikasi** kini membuka dialog sungguhan (bukan lagi kotak prompt), dengan 3 tab:
  - **Katalog**: 27 aplikasi populer (WhatsApp, YouTube, Instagram, Spotify, Canva, Roblox, dll.), bisa pilih banyak sekaligus, ada pencarian; yang sudah ditambahkan ditandai.
  - **Manual**: nama, package Android, URL, URL ikon, dan cara buka (otomatis / jendela mengambang / tab baru) dengan validasi.
  - **Cadangan**: Ekspor/Impor daftar aplikasi sebagai JSON.
- **Membuka aplikasi**: di Android (Chrome/WebView biasa) aplikasi dengan package dibuka lewat intent, dan jika belum terpasang diarahkan ke URL/Play Store. Di PC/browser lain dibuka lewat URL. Jika bridge `AndroidAppPanel` ada, jalur native tetap dipakai (freeform → normal).
- **Jendela mengambang** (web): halaman tampil di jendela yang bisa digeser dan diubah ukuran. Situs yang melarang iframe akan kosong; tombol ↗ membuka di tab baru.
- **Tekan lama / klik kanan** pada ikon: menu Buka, Jendela mengambang, Pin, Edit, slider lebar jendela 40–80%, Hapus (menggantikan prompt).
- Mengganti `js/app-panel.js` dan `css/app-panel.css`; service worker naik ke cache cdms-v145.


## Pembaruan V146 (Panel Aplikasi: urutan & banyak jendela)
- **Urutkan** daftar: A–Z, Terakhir dibuka, atau Paling sering (pilihan tersimpan; item yang di-pin tetap di atas). Setiap aplikasi yang dibuka dicatat waktu dan jumlah bukanya.
- **Banyak jendela mengambang**: hingga 3 jendela sekaligus (yang tertua ditutup otomatis), ketuk jendela untuk membawanya ke depan, tombol – untuk mengecilkan ke bilah judul, ⟳ untuk muat ulang. Membuka aplikasi yang sama lagi hanya menampilkannya ke depan.
- Mengubah `index.html`, `js/app-panel.js`, `css/app-panel.css`; service worker naik ke cache cdms-v146.


## Pembaruan V147 (PowerPoint: tabel & cadangan .json)
- **Sisipkan > ⊞ Tabel**: tabel 3×3 (baris pertama berupa judul berwarna) yang selelnya bisa diketik; geser lewat pegangan ✥. Grup **Tabel**: + Baris / + Kolom (setelah sel aktif), − Baris / − Kolom (hapus baris/kolom sel aktif; minimal 1). Ikut tampil di ▶ Tampilkan, Cetak/PDF, dan bisa diurungkan.
- **Objek terpilih > Tengah V**: menengahkan objek secara vertikal (melengkapi Tengahkan horizontal).
- **Ekspor > ⬇ Simpan .json / ⬆ Buka .json**: cadangan seluruh presentasi ke file dan memuatnya kembali. File yang dibuka disaring (skrip, iframe, atribut on*, dan gambar non-data dibuang).
- Tanpa file baru; service worker naik ke cache cdms-v147.


## Pembaruan V148 (PowerPoint: transisi, maju otomatis, putar objek)
- **Desain > Tampilan**: pilih transisi antar slide (Pudar, Geser, Zoom, Tanpa) dan **Maju otomatis** (manual, 3, 5, atau 10 detik) saat ▶ Tampilkan. Pada maju otomatis, tampilan berhenti setelah slide terakhir. Pilihan tersimpan bersama presentasi, ikut ke file .json, dan bisa diurungkan.
- **Objek terpilih**: ↺ Putar / ↻ Putar (15° per ketukan) dan Lurus untuk mengembalikan. Rotasi ikut ke tampilan layar penuh dan Cetak/PDF.
- Tanpa file baru; service worker naik ke cache cdms-v148.


## Pembaruan V149 (Excel: lebih banyak rumus)
- **Pemisah titik koma**: argumen boleh dipisah `;` (gaya Indonesia) maupun `,` — mis. `=SUM(A1;A2;A3)`.
- **IFERROR**: `=IFERROR(1/0;"galat")` mengganti galat apa pun dengan nilai pengganti.
- **Teks**: MID, FIND, SEARCH, SUBSTITUTE, REPT, PROPER, VALUE, EXACT, CONCATENATE.
- **Pencarian**: INDEX (satu kolom/baris atau baris+kolom), MATCH (tepat dengan 0, atau urut naik), AVERAGEIF.
- **Angka**: SIGN, EXP, LN, LOG10, SIN, COS, TAN, RADIANS, DEGREES, CEILING, FLOOR, FACT, SUMSQ, LARGE, SMALL, VAR, STDEV, RAND, RANDBETWEEN.
- **Lain-lain**: ISNUMBER, ISTEXT, NOW.
- Catatan: ISNUMBER pada sel kosong menghasilkan benar (sel kosong dibaca 0). Rumus lama tetap bekerja.
- Tanpa file baru; service worker naik ke cache cdms-v149.


## Pembaruan V150 (jendela mengambang sungguhan di Android)
- Folder **`android/`**: proyek Android Studio (WebView + bridge `AndroidAppPanel`). Langkah build ada di `android/README.md`.
- **Izin dari HP**: tombol *⚠ Izinkan "Tampil di atas aplikasi lain"* di Panel Aplikasi Lain membuka Pengaturan; status berubah menjadi *Jendela mengambang aktif* (ketuk untuk tutup semua).
- Item **URL** kini dibuka sebagai **jendela overlay native** (geser, ubah ukuran, kecilkan, maks. 3) di atas semua aplikasi.
- Aplikasi **terpasang** dibuka lewat freeform; jika perangkat belum mengaktifkannya, ditawarkan membuka Opsi Pengembang.
- Di browser/SPCK perilaku tetap seperti V149 (jendela iframe di dalam halaman). Service worker cache cdms-v150.


## Pembaruan V151 (APK: simpan file & cetak)
- Di APK (`android/`), tombol ekspor/unduh kini benar-benar menyimpan file ke folder **Download**, dan **Cetak/PDF** Word/Excel/PowerPoint membuka dialog cetak Android (bisa *Simpan sebagai PDF*). Dikerjakan oleh `js/native-save.js` (aktif hanya jika bridge Android ada, jadi versi web tidak berubah) dan metode baru `saveFile` / `printHtml` di `AppPanelBridge.java`.
- Service worker cache cdms-v151.


## Pembaruan V152 (fitur Kembali)
- **Tombol/gestur Kembali** (browser, SPCK, dan APK) kini menutup satu lapisan teratas secara berurutan: menu item → dialog Tambah/Edit → pemilih aplikasi → Panel Aplikasi Lain → jendela modal → layar penuh PowerPoint → mode Word/Excel/PowerPoint (kembali ke beranda, data disimpan) → editor desain (kembali ke beranda).
- Di beranda, kembali pertama menampilkan "Tekan kembali sekali lagi untuk keluar"; kembali kedua dalam 2 detik keluar (di APK menutup aplikasi lewat `exitApp()`).
- Panah **←** baru di kiri judul Panel Aplikasi Lain.
- Berkas baru `js/back-nav.js`. Di APK, `MainActivity.onBackPressed()` meneruskan ke riwayat WebView.
- Service worker cache cdms-v152.


## Pembaruan V153 (Panel Aplikasi Lain benar-benar mengambang)
- **Panel mengambang**: tirai gelap/blur dihapus; panel kini jendela yang bisa **digeser** (tarik bilah judul), **dikecilkan** (–) dan ditutup (×), posisinya diingat. Editor di belakangnya tetap bisa disentuh.
- **Tidak masuk ke tautan**: mengetuk aplikasi yang punya URL kini membuka **jendela mengambang** di atas layar (APK: overlay native di atas semua aplikasi; browser: jendela di dalam halaman), tidak lagi berpindah halaman/tab. Item tidak lagi menutup panel saat dibuka.
- Cara buka **Otomatis** = mengambang. Pilihan baru **Aplikasi Android (package)** untuk membuka aplikasi terpasang dengan meninggalkan halaman; **Tab baru** tetap tersedia. Item hanya-package tanpa URL tetap lewat intent.
- APK: tanpa izin overlay, jendela tidak membuka browser/halaman; aplikasi meminta izin. `MainActivity` tidak lagi memuat atau membuka bingkai pihak ketiga ke browser.
- Tombol Kembali menutup jendela mengambang paling atas lebih dulu.
- Catatan: di browser, banyak situs (WhatsApp, YouTube, Instagram, dll.) melarang tampil di iframe sehingga jendelanya kosong; ketuk ↗ untuk tab baru. Di APK dengan izin overlay, jendela memakai WebView sendiri sehingga tidak terkena larangan itu.
- Service worker cache cdms-v153.


## Pembaruan V154 (semua aplikasi bisa mengambang)
- **Aplikasi terpasang tanpa URL** (dipilih dari daftar HP) yang ada di katalog otomatis memakai URL katalognya, sehingga di APK tetap mengambang lewat overlay jika freeform tidak tersedia.
- **Browser PC**: situs yang melarang iframe (WhatsApp, YouTube, Instagram, Google, dll.) kini dibuka sebagai **jendela pop-up berukuran** mengambang, bukan jendela kosong.
- **Browser HP**: situs semacam itu menampilkan jendela mengambang berisi penjelasan dan tombol *Buka di tab baru*; jendela mengambang penuh untuk semua aplikasi memerlukan APK (overlay).
- Batas Android: aplikasi terpasang tanpa URL hanya bisa mengambang lewat freeform bawaan sistem; Google/WhatsApp dapat menolak login di WebView.
- Service worker cache cdms-v154.


## Pembaruan V155 (login Google di jendela mengambang APK)
- `FloatingWebService`: WebView jendela mengambang memakai **user agent Chrome seluler** (penanda `wv` dibuang), header `X-Requested-With` dimatikan (androidx.webkit naik ke 1.10.0), cookie termasuk pihak ketiga disimpan, dan popup `window.open` (login) dimuat di jendela yang sama. Skema selain http/https tetap diblokir.
- Login tersimpan antar sesi jendela. Tetap tanpa JavascriptInterface.
- Catatan: Google sewaktu-waktu dapat tetap menolak login di WebView (pesan "browser tidak aman") atau meminta verifikasi tambahan; ini kebijakan sisi Google dan tidak bisa dijamin dari kode. Jika terjadi, login sekali di Chrome lalu pakai Google Foto/Drive lewat aplikasinya.
- Service worker cache cdms-v155.


## Pembaruan V156 (login Google pasti bisa: Chrome asli sebagai lembar)
- Google sering menolak login di WebView apa pun cara penyamarannya. Jalur yang andal: **Chrome asli** dibuka sebagai **lembar setengah layar** (Partial Custom Tab, tinggi bisa diseret) di atas aplikasi. Login Google/WhatsApp dll. diterima dan dibagi dengan Chrome HP.
- Item situs Google (google, gmail, youtube, drive, dll.) otomatis memakai lembar Chrome di APK. Cara buka baru **Chrome asli** bisa dipilih untuk item lain; **Jendela mengambang** tetap memaksa WebView.
- Tombol **G** baru di bilah judul setiap jendela mengambang: melanjutkan halaman saat ini di lembar Chrome (dipakai bila WebView ditolak).
- File baru `ChromeSheet.java`; dependensi `androidx.browser:browser:1.8.0`. Lembar setengah layar butuh Chrome 107+; versi lebih lama membuka layar penuh. Belum dikompilasi/diuji di perangkat.
- Service worker cache cdms-v156.


## Pembaruan V157
- Perbaikan popup login di jendela mengambang: URL popup juga ditangkap lewat `onPageStarted` (sebagian versi WebView tidak memanggil `shouldOverrideUrlLoading` untuk jendela baru), lalu dimuat di jendela yang sama. Service worker cache cdms-v157.


## Pembaruan V158 (Word: gambar, tabel, catatan kaki, tanda air)
- **Gambar**: ketuk gambar untuk memunculkan bilah kecil: lebar 25/50/75/100%, rata kiri/tengah/kanan, hapus (tombol Delete juga bisa).
- **Tabel** (Sisipkan > Tabel): **Gaya tabel** (garis penuh, selang-seling, hanya garis mendatar, tanpa garis), **Warna sel** untuk sel/rentang terpilih, dan **Hapus warna sel**. Ikut ke .DOC/.HTML/cetak.
- **Catatan kaki** (Sisipkan > Referensi): angka superskrip di kursor dan isi catatan di blok bawah dokumen.
- **Tanda air** teks diagonal (mis. DRAF) tampil di layar dan di cetak/PDF; kosongkan untuk menghapus.
- **Ekspor .TXT** (Tampilan).
- Mengubah `index.html`, `css/office.css`, `js/word-mode.js`; service worker cache cdms-v158.


## Pembaruan V159 (Excel: rumus, bekukan panel, daftar pilihan)
- **Rumus baru**: SUMIFS, COUNTIFS, AVERAGEIFS, MAXIFS, MINIFS (banyak kriteria, mis. `=SUMIFS(C1:C9;A1:A9;">5";B1:B9;"Ya")`), XLOOKUP(kunci; cari; hasil; [jika tidak ada]), IFS, CHOOSE, SUMPRODUCT, RANK, TEXTJOIN, ROWS, COLUMNS.
- **Data > Bekukan panel**: ❄ Baris 1, ❄ Kolom A, Lepas. Baris/kolom tetap terlihat saat menggulir; tersimpan per lembar.
- **Data > Validasi data (▾ Daftar pilihan)**: pilih rentang, ketik daftar pilihan dipisah koma. Sel bertanda ▾; ketuk dua kali / Enter untuk memilih dari daftar, dan ketikan di luar daftar ditolak. Kosongkan daftar untuk menghapus. Tersimpan per lembar (tidak ikut urungkan).
- Mengubah `index.html`, `css/office.css`, `js/excel-mode.js`; service worker cache cdms-v159.


## Pembaruan V160 (PowerPoint: bentuk, ubah ukuran, garis tepi)
- **Bentuk baru** (Sisipkan): ▲ Segitiga, ★ Bintang, ◆ Berlian, ⬢ Segi enam, ⇨ Blok panah, ▢ Sudut bulat. Warna isi lewat pemilih warna yang sudah ada.
- **Ubah ukuran dengan menyeret**: objek terpilih punya titik bulat di pojok kanan-bawah; seret untuk melebarkan (gambar mempertahankan rasio, bentuk bisa diubah lebar dan tingginya). Bisa diurungkan; tidak ikut tersimpan/cetak/tampilan layar penuh.
- **Garis tepi** (warna + Tanpa garis) untuk persegi, bulat, dan sudut bulat; **Transparansi** menggilir 0/25/50/75% untuk objek terpilih.
- Mengubah `index.html`, `css/ppt-mode.css`, `js/ppt-mode.js`; service worker cache cdms-v160.


## Pembaruan V161
- Jendela mengambang (browser) kini muncul **di bawah** Panel Aplikasi Lain bila panel terbuka dan ruangnya cukup, sehingga ikon aplikasi lain tetap bisa diketuk. Jika ruang kurang, posisi bawaan dipakai (jendela bisa digeser).
- Diuji di Chrome tanpa kepala (emulasi HP): tanpa galat JS saat memuat; panel terbuka, bisa digeser dan dikecilkan; item URL membuka jendela mengambang tanpa meninggalkan halaman; Tombol Kembali menutup jendela; Excel: bekukan baris dan daftar pilihan; PowerPoint: bentuk bintang, titik ubah ukuran, transparansi. Service worker cache cdms-v161.


## Pembaruan V162 (impor PPT / PDF di Excel, Word, dan PowerPoint)
- Tombol **Impor PPT/PDF** di ketiga mode: Excel (tab Data), Word (tab Sisipkan), PowerPoint (tab Sisipkan > Impor). Pilih file `.pptx` atau `.pdf`; dialog menawarkan cara impor, rentang halaman/slide (mis. `1-3,5`), dan penempatan (tambah / ganti).
- **PowerPoint**: `.pptx` → slide dengan posisi, teks berformat (tebal/miring/warna/ukuran), butir, gambar, tabel, bentuk, latar, dan catatan pembicara. PDF → slide **gambar halaman** (tampilan persis, maks 30 halaman) atau slide **teks** yang bisa diedit.
- **Word**: `.pptx` → dokumen (judul per slide, butir, tabel, gambar, catatan). PDF → teks (judul, paragraf, daftar, tabel terdeteksi) atau gambar halaman (maks 20).
- **Excel**: `.pptx` → lembar "Slide PPT" (No, Judul, Isi, Catatan) + tabel slide jadi lembar sendiri. PDF → tabel dari teks halaman (kolom dideteksi dari posisi), satu lembar per halaman.
- Pustaka dibundel offline di `lib/` (JSZip, PDF.js legacy) dan hanya dimuat saat dipakai. File tidak dikirim ke mana pun.
- Batas: `.ppt` biner lama tidak didukung (simpan ulang sebagai .pptx atau ekspor PDF); grafik/SmartArt/video dilewati; PDF hasil pindai tidak punya teks (pakai cara gambar halaman); Excel maks 60×26 sel × 8 lembar; penyimpanan perangkat (~5 MB) membatasi jumlah gambar.
- Android: `MainActivity` kini punya **pemilih file** (`onShowFileChooser`) — sebelumnya `<input type=file>` tidak membuka apa pun di APK — dan menyajikan `.mjs` sebagai JavaScript (untuk PDF.js). Belum dikompilasi/diuji di perangkat.
- Mengubah `index.html`, `js/office-import.js` (baru), `js/excel-mode.js`, `js/word-mode.js`, `js/ppt-mode.js`, `android/.../MainActivity.java`; service worker cache cdms-v162.


## Pembaruan V163 (impor juga .docx dan .xlsx)
- Tombol di ketiga mode kini bernama **Impor file** dan menerima `.pptx`, `.pdf`, `.docx`, `.xlsx` (jenis dikenali dari isi file).
- **.docx**: Word = dokumen (judul, daftar, tebal/miring/garis bawah, tabel, gambar); Excel = paragraf per baris + tiap tabel jadi lembar; PowerPoint = slide teks, judul 1/2 jadi pemisah slide.
- **.xlsx**: Excel = lembar dan nilai sel (rumus diimpor sebagai nilai hasil, tanggal dikenali); Word = tabel per lembar; PowerPoint = slide tabel (maks 8 kolom, 11 baris per slide).
- Service worker cache cdms-v163.


## Pembaruan V164 (aplikasi web benar-benar mengambang)
- **Penyebab tidak mengambang di APK**: (1) item yang punya package + URL memakai *freeform* Android lebih dulu — di banyak HP ukuran jendela diabaikan sehingga aplikasi terbuka layar penuh; (2) situs Google/YouTube/Gmail otomatis dibuka di lembar Chrome (setengah layar, bukan jendela yang bisa digeser).
- **Perbaikan**: item yang punya URL (sendiri atau dari katalog) kini selalu dibuka sebagai **jendela web mengambang (overlay)** yang bisa digeser, diubah ukuran, dikecilkan, di atas semua aplikasi. Lembar Chrome hanya bila cara buka *Chrome asli* dipilih, atau lewat tombol **G** di bilah judul jendela.
- **Izin**: bila izin "Tampil di atas aplikasi lain" belum aktif, item yang diketuk diingat; setelah izin diberikan dan Anda kembali ke aplikasi, jendela **terbuka otomatis**.
- `FloatingWebService`: WebView memakai konteks bertema (menu/dialog di Service lebih stabil) dan jendela memakai `FLAG_LAYOUT_NO_LIMITS`.
- **Browser biasa/PWA** tetap tidak bisa menampilkan situs yang melarang iframe (WhatsApp, YouTube, Google, dll.) atau mengambang di atas aplikasi lain — batas browser. Untuk itu pasang APK (folder `android/`).
- Mengubah `js/app-panel.js`, `android/.../FloatingWebService.java`; service worker cache cdms-v164. Belum dikompilasi/diuji di perangkat.


## Pembaruan V165 (diagnosis jendela mengambang di APK)
- Jika jendela mengambang tidak muncul padahal izin aktif, aplikasi kini menampilkan **alasannya** (toast) — sebelumnya galat di `FloatingWebService` ditelan diam-diam. Pesan memuat galat sebenarnya (notifikasi layanan, `addView`, dll.).
- `FloatingWebService`: ikon notifikasi memakai ikon aplikasi dan tombol *Tutup semua* punya ikon (sebelumnya `null`, rawan galat di Android baru); kegagalan notifikasi tidak lagi mematikan layanan.
- Bridge baru: `floatStatus()`, `floatCount()`.
- **Perbaikan build**: `android/app/build.gradle` kini menyalin `lib/**` (JSZip, PDF.js) ke APK; sebelumnya impor file di APK tidak punya pustakanya.
- HP Xiaomi/Oppo/Vivo/Realme sering butuh izin tambahan "Tampilkan jendela pop-up" / "Tampil di layar kunci" di Pengaturan > Aplikasi > izin lainnya.
- Service worker cache cdms-v165. Belum dikompilasi/diuji di perangkat.


## Pembaruan V166
- Jendela mengambang (APK): tombol **◐** di bilah judul mengatur transparansi 100% → 80% → 60% → 40% agar konten di belakang tetap terlihat.
- Jika jendela gagal muncul, halaman otomatis dibuka di **lembar Chrome** sebagai cadangan, plus toast alasannya.
- `FloatingWebService`: bila notifikasi utama gagal, dicoba notifikasi polos agar sistem tidak menutup aplikasi karena `startForeground` terlambat.
- Service worker cache cdms-v166. Belum dikompilasi/diuji di perangkat.


## Pembaruan V167 (lebih banyak fitur jendela mengambang)
- Bilah judul jendela mengambang (APK) mendapat **‹** (halaman sebelumnya) dan **⬒** (tata letak cepat): kiri 50% → kanan 50% → atas 50% → bawah 50% → layar penuh → ukuran semula.
- Panel Aplikasi Lain: tombol **📌 Buka pin** membuka semua aplikasi ber-PIN yang punya URL sekaligus (maks. 3 jendela) — ruang kerja favorit dalam satu ketukan.
- Tombol di bilah judul dibuat lebih ramping agar judul tetap terbaca di jendela sempit.
- Service worker cache cdms-v167. Belum dikompilasi/diuji di perangkat.


## Pembaruan V168
- Jendela mengambang (APK) **mengingat posisi dan ukuran per situs**: digeser, diubah ukuran, atau diatur lewat ⬒, lalu dibuka lagi di tempat yang sama. Disimpan di `SharedPreferences` (`float_pos`), dibatasi ke layar saat dipulihkan.
- Panel Aplikasi Lain: tombol **🕘 Buka terakhir** membuka 3 aplikasi ber-URL yang terakhir dipakai sebagai jendela mengambang.
- Service worker cache cdms-v168. Belum dikompilasi/diuji di perangkat.


## Pembaruan V169
- Jendela mengambang (APK): **tekan lama judul** untuk beralih antara **situs seluler** dan **situs desktop** (user agent + viewport lebar, halaman dimuat ulang).
- Menu item (tekan lama ikon di panel): **📋 Salin URL** dan **⧉ Duplikat** (salinan item dengan pengaturan sendiri, mis. lebar atau cara buka berbeda).
- Service worker cache cdms-v169. Belum dikompilasi/diuji di perangkat.


## Pembaruan V170
- Jendela mengambang (APK): **judul halaman** tampil di bilah judul (redup saat memuat); **unduhan** kini diserahkan ke browser (sebelumnya mengetuk tautan unduh tidak melakukan apa pun).
- Panel Aplikasi Lain: pencarian juga mencocokkan **URL** dan **nama package**, bukan hanya nama.
- Service worker cache cdms-v170. Belum dikompilasi/diuji di perangkat.


## Pembaruan V171
- **Perbaikan**: sejak V169 judul jendela mengambang menelan sentuhan (pendengar tekan-lama) sehingga jendela tidak bisa digeser dari teks judul. Kini sentuhan ditangani di bilah: geser tetap jalan, **tekan lama 0,7 dtk** = situs desktop/seluler.
- **Ketuk dua kali judul** = layar penuh ↔ ukuran semula.
- Jendela yang **dikecilkan (–)** menyempit hingga ±220 dp agar tidak menutupi layar, dan melebar lagi saat diperbesar.
- Service worker cache cdms-v171. Belum dikompilasi/diuji di perangkat.


## Pembaruan V172
- **Unggah file di jendela mengambang** (APK): `<input type=file>` di situs yang dibuka sebagai jendela mengambang kini membuka pemilih file Android (sebelumnya tidak melakukan apa pun). Memakai `FilePickerActivity` transparan baru (terdaftar di `AndroidManifest.xml`) karena Service tidak bisa memanggil `startActivityForResult`; dukung pilih banyak file dan filter jenis.
- Service worker cache cdms-v172. Belum dikompilasi/diuji di perangkat.


## Pembaruan V173
- **Dialog situs di jendela mengambang** (APK): `alert()` dan `confirm()` dari situs kini tampil sebagai dialog di atas jendela (tipe overlay). Sebelumnya Service tidak bisa menampilkannya sehingga situs yang meminta konfirmasi (hapus, keluar, dll.) bisa macet tanpa respons. `prompt()` dibatalkan otomatis.
- Service worker cache cdms-v173. Belum dikompilasi/diuji di perangkat.


## Pembaruan V174
- Panel Aplikasi Lain: kolom **Ketik alamat atau kata pencarian** — ketik URL (mis. `wikipedia.org`) atau kata kunci (dicari lewat DuckDuckGo) lalu **Buka ▶** untuk langsung membukanya sebagai jendela mengambang, tanpa harus menambah item ke panel. Hanya http/https.
- Service worker cache cdms-v174.


## Pembaruan V175
- **Video layar penuh di jendela mengambang** (APK): tombol layar penuh pada pemutar video (YouTube, dll.) kini memperbesar video memenuhi jendela itu (`onShowCustomView`/`onHideCustomView`); sebelumnya tombolnya tidak berfungsi. Keluar dari layar penuh mengembalikan halaman.
- Service worker cache cdms-v175. Belum dikompilasi/diuji di perangkat.


## Pembaruan V176
- Jendela mengambang **di browser/PWA** kini punya tombol **⬒** (tata letak cepat: kiri 50% → kanan 50% → atas 50% → bawah 50% → penuh → ukuran semula) dan **ketuk dua kali bilah judul** untuk layar penuh ↔ semula — setara dengan versi APK.
- Service worker cache cdms-v176.


## Pembaruan V177 (Word)
- Tab **Tampilan** > grup **Baca & analisis**: **🔊 Baca keras** (membaca teks terpilih, atau seluruh dokumen, memakai suara bawaan perangkat; per kalimat), **⏹ Berhenti**, dan **📊 Statistik** (kata, karakter, kalimat, paragraf, gambar, tabel, waktu baca, 5 kata paling sering).
- Service worker cache cdms-v177.


## Pembaruan V178 (APK)
- Perbaikan: "Chrome asli" / tombol G kini benar-benar membuka lembar setengah layar. Sebelumnya Chrome dibuka dari konteks aplikasi dengan flag NEW_TASK sehingga selalu layar penuh; sekarang diluncurkan dari Activity (ChromeSheet.java).
- Catatan: jendela mengambang bawaan (overlay) butuh izin "Tampil di atas aplikasi lain". Bila izin belum aktif atau gagal, aplikasi jatuh ke lembar Chrome.
- Service worker cache cdms-v178.
